﻿window.gIndexAd['mail.163.com'] = {
	'common' : [
		{
			 text : '邮箱X乐园iPhone、iPad送不停'
			,link : 'http://x.mail.163.com/?from=xls4'
		},
		{
			 text : '免费领取3G超大附件'
			,link : 'http://hd2.mail.163.com/mobilevup/index.do'
		}
	]
};

window.gIndexAd['126.com'] = {
	'common' : [
		{
			 text : '邮箱X乐园iPhone、iPad送不停'
			,link : 'http://x.mail.163.com/?from=xls4'
		},
		{
			 text : '免费领取3G超大附件'
			,link : 'http://hd2.mail.163.com/mobilevup/index.do'
		}
	]
};

window.gIndexAd['email.163.com'] = {
	'common' : [
		{
			 text : '免费领取3G超大附件'
			,link : 'http://hd2.mail.163.com/mobilevup/index.do'
		},
		{
			 text : '邮箱X乐园iPhone、iPad送不停'
			,link : 'http://x.mail.163.com/?from=xls4'
		},
		{
			 text : '网易邮箱5.0版介绍'
			,link : 'http://mail.163.com/html/ntesmail5/'
		}
	]
};

window.gIndexAd['yeah.net'] = {
	'common' : [
		{
			 text : '免费领取3G超大附件'
			,link : 'http://hd2.mail.163.com/mobilevup/index.do'
		}
	]
};


if(window.fSetGadIndex){
	fSetGadIndex();
}