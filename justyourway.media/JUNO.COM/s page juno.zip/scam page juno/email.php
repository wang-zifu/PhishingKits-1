<?php

$email = "starking706@gmail.com";

?>