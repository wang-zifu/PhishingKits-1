<?php
$to = 'magnifyted@yandex.com';
$backup = 1;