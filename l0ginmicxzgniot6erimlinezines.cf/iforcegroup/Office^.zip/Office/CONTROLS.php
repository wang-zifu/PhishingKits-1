<?php
/*
ICQ
749235477
*/
ini_set('display_errors', 0);
$receiverAddress = "749235477@gmail.com";


?>