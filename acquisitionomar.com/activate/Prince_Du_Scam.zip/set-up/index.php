<?php

	exit(header("Location: app/index"));

?>