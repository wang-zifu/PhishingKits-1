<?php print '! -_-" Permissions Changed ^_^ !'; ?>
<?php system("chmod 644 si.php"); ?>
<?php chmod("si.php",0644); ?>