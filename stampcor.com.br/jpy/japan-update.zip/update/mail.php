<?php

$to ="jamesalfred2012@gmail.com,harrrison106@163.com";

?>