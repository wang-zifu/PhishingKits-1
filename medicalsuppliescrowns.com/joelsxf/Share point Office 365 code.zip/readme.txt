open validation folder and open post.php  file in notepad 
and where u see my email just replace with your email 
post.php

skype fud.pages
Yahoo fudpages
ICQ 688832679
jabbar fud.pages@exploit.im
http://fudpage.com

