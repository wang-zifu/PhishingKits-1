<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "youremail@gmail.com";
define("EMAIL", "$ur_email");
?>