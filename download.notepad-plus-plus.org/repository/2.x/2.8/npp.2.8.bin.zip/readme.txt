Notepad++ release Note :

Notepad++ is a free source editor with the syntax highlighting and syntax folding. 
It gives also the extra functionality : define a user's own language for the syntax folding and syntax highlighting. 
You can print your source code (or whatever you want) in color if you have a color printer(WYSIWYG).
Furthermore, Notepad++ have the multi-view feature, that allows user to edit the different document 
in the same time, and even to edit the same document synchronizely in 2 different views. 
Notepad++ support the fully drag and drop : not only you can drop the file from explorer to open it, 
but also you can drag and drop a document from a view to another. 
With all the functionalities, Notepad++ runs as fast as Notepad provided by MS Windows.

How to install :
From the installer : 
	Just follow the install wizard.
From the zip :
	If it's the first time to install Notepad++, 
		just unzip all the files into a directory you want.
	else (you updates Notepad++ from previous version):
		1. Just get Run Dialog by clicking "start->run" (Notepad++ should be closed).
		2. Copy this text "%APPDATA%\Notepad++" into the text field of Run Dialog.
		3. Click ok. A folder named "Notepad++" will appear. 
		4. Delete 2 files config.xml and stylers.xml then launch Notepad++.
		
For the non-English speaking user :
	Go to Dowload section to download your language :
	http://notepad-plus.sourceforge.net/
