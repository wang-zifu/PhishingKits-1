#ifndef CONSTANT_H
#define CONSTANT_H

const int MARK_BOOKMARK = 1;
const int MARK_HIDELINESBEGIN = 2;
const int MARK_HIDELINESEND = 3;

#endif //CONSTANT_H
