What is Notepad++ ?
===================

Notepad++ is a free (free as in both "free speech" and "free beer") source code editor and Notepad replacement that supports several programming languages and natural languages. Running in the MS Windows environment, its use is governed by GPL License.


To build Notepad++ package from source code:
============================================

There should be several ways to generate Notepad++ binaries, here we show you only the way with which Notepad++ official releases are generated.
* notepad++.exe: Visual Studio 2005
* SciLexer.dll: Visual Studio 2005 (with nmake)

Notepad++ Unicode release binary (notepad++.exe) and Scintilla release binary (SciLexer.dll) will be built in the directories "notepad++\trunk\PowerEditor\bin" and "notepad++\trunk\scintilla\bin" respectively.
You have to copy SciLexer.dll in "notepad++\PowerEditor\bin" in order to launch notepad++.exe


Go to Notepad++ official site for more information :
http://notepad-plus-plus.org/


Notepad++ team
http://notepad-plus-plus.org/contributors
