makefile was renewed after the v5.0 release.
It was testing with a MingW distribution containing
gcc (GCC) 3.4.5 (mingw-vista special r3)
The default make rule should suffice for building Notepad++,
the clean rule call batch file with commands to remove .o files and resource file