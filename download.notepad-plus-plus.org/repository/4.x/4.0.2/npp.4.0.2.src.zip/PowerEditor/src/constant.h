#ifndef CONSTANT_H
#define CONSTANT_H

const int MARK_SYMBOLE = 1;

#endif //CONSTANT_H
