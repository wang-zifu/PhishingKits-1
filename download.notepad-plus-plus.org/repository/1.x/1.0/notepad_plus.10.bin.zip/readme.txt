Notepad++ 1.0 beta release note :

Notepad++ is a Scintilla-based source editor written in C++ with the win32 API (without MFC). 
The aim of Notepad++ is to offer the programmer a better GUI and to offer the general user 
a better customisable Notepad.

Installation :
Just unzip all the files in the same directory.

Please contact me  (click on Menu "About...") if you have any suggestion or find any bug.
