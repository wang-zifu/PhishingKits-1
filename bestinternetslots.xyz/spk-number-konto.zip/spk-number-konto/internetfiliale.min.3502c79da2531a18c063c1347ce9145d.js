/*! jQuery v3.1.1 | (c) jQuery Foundation | jquery.org/license */
!function(d,c){"object"==typeof module&&"object"==typeof module.exports?module.exports=d.document?c(d,!0):function(b){if(!b.document){throw new Error("jQuery requires a window with a document")
}return c(b)
}:c(d)
}("undefined"!=typeof window?window:this,function(bP,bO){var bN=[],bM=bP.document,bL=Object.getPrototypeOf,bJ=bN.slice,bH=bN.concat,bG=bN.push,bF=bN.indexOf,bE={},bD=bE.toString,bC=bE.hasOwnProperty,bB=bC.toString,bA=bB.call(Object),bz={};
function by(e,d){d=d||bM;
var f=d.createElement("script");
f.text=e,d.head.appendChild(f).parentNode.removeChild(f)
}var bw="3.1.1",bv=function(d,c){return new bv.fn.init(d,c)
},bu=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,bt=/^-ms-/,bs=/-([a-z])/g,br=function(d,c){return c.toUpperCase()
};
bv.fn=bv.prototype={jquery:bw,constructor:bv,length:0,toArray:function(){return bJ.call(this)
},get:function(b){return null==b?bJ.call(this):b<0?this[b+this.length]:this[b]
},pushStack:function(d){var c=bv.merge(this.constructor(),d);
return c.prevObject=this,c
},each:function(b){return bv.each(this,b)
},map:function(b){return this.pushStack(bv.map(this,function(a,d){return b.call(a,d,a)
}))
},slice:function(){return this.pushStack(bJ.apply(this,arguments))
},first:function(){return this.eq(0)
},last:function(){return this.eq(-1)
},eq:function(e){var d=this.length,f=+e+(e<0?d:0);
return this.pushStack(f>=0&&f<d?[this[f]]:[])
},end:function(){return this.prevObject||this.constructor()
},push:bG,sort:bN.sort,splice:bN.splice},bv.extend=bv.fn.extend=function(){var t,s,r,q,p,o,n=arguments[0]||{},m=1,l=arguments.length,k=!1;
for("boolean"==typeof n&&(k=n,n=arguments[m]||{},m++),"object"==typeof n||bv.isFunction(n)||(n={}),m===l&&(n=this,m--);
m<l;
m++){if(null!=(t=arguments[m])){for(s in t){r=n[s],q=t[s],n!==q&&(k&&q&&(bv.isPlainObject(q)||(p=bv.isArray(q)))?(p?(p=!1,o=r&&bv.isArray(r)?r:[]):o=r&&bv.isPlainObject(r)?r:{},n[s]=bv.extend(k,o,q)):void 0!==q&&(n[s]=q))
}}}return n
},bv.extend({expando:"jQuery"+(bw+Math.random()).replace(/\D/g,""),isReady:!0,error:function(b){throw new Error(b)
},noop:function(){},isFunction:function(b){return"function"===bv.type(b)
},isArray:Array.isArray,isWindow:function(b){return null!=b&&b===b.window
},isNumeric:function(d){var c=bv.type(d);
return("number"===c||"string"===c)&&!isNaN(d-parseFloat(d))
},isPlainObject:function(e){var d,f;
return !(!e||"[object Object]"!==bD.call(e))&&(!(d=bL(e))||(f=bC.call(d,"constructor")&&d.constructor,"function"==typeof f&&bB.call(f)===bA))
},isEmptyObject:function(d){var c;
for(c in d){return !1
}return !0
},type:function(b){return null==b?b+"":"object"==typeof b||"function"==typeof b?bE[bD.call(b)]||"object":typeof b
},globalEval:function(b){by(b)
},camelCase:function(b){return b.replace(bt,"ms-").replace(bs,br)
},nodeName:function(d,c){return d.nodeName&&d.nodeName.toLowerCase()===c.toLowerCase()
},each:function(f,e){var h,g=0;
if(bq(f)){for(h=f.length;
g<h;
g++){if(e.call(f[g],g,f[g])===!1){break
}}}else{for(g in f){if(e.call(f[g],g,f[g])===!1){break
}}}return f
},trim:function(b){return null==b?"":(b+"").replace(bu,"")
},makeArray:function(e,d){var f=d||[];
return null!=e&&(bq(Object(e))?bv.merge(f,"string"==typeof e?[e]:e):bG.call(f,e)),f
},inArray:function(e,d,f){return null==d?-1:bF.call(d,e,f)
},merge:function(g,f){for(var j=+f.length,i=0,h=g.length;
i<j;
i++){g[h++]=f[i]
}return g.length=h,g
},grep:function(j,i,p){for(var o,n=[],m=0,l=j.length,k=!p;
m<l;
m++){o=!i(j[m],m),o!==k&&n.push(j[m])
}return n
},map:function(i,g,n){var m,l,k=0,j=[];
if(bq(i)){for(m=i.length;
k<m;
k++){l=g(i[k],k,n),null!=l&&j.push(l)
}}else{for(k in i){l=g(i[k],k,n),null!=l&&j.push(l)
}}return bH.apply([],j)
},guid:1,proxy:function(g,f){var j,i,h;
if("string"==typeof f&&(j=g[f],f=g,g=j),bv.isFunction(g)){return i=bJ.call(arguments,2),h=function(){return g.apply(f||this,i.concat(bJ.call(arguments)))
},h.guid=g.guid=g.guid||bv.guid++,h
}},now:Date.now,support:bz}),"function"==typeof Symbol&&(bv.fn[Symbol.iterator]=bN[Symbol.iterator]),bv.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "),function(d,c){bE["[object "+c+"]"]=c.toLowerCase()
});
function bq(e){var d=!!e&&"length" in e&&e.length,f=bv.type(e);
return"function"!==f&&!bv.isWindow(e)&&("array"===f||0===d||"number"==typeof d&&d>0&&d-1 in e)
}var bp=function(dl){var dk,dj,dh,dg,df,de,dd,db,c9,c8,c7,c6,c4,c3,c2,c1,c0,cZ,cY,cX="sizzle"+1*new Date,cW=dl.document,cV=0,cU=0,cT=dH(),cS=dH(),dR=dH(),dQ=function(d,c){return d===c&&(c7=!0),0
},dP={}.hasOwnProperty,dO=[],dM=dO.pop,dL=dO.push,dK=dO.push,dJ=dO.slice,dI=function(f,e){for(var h=0,g=f.length;
h<g;
h++){if(f[h]===e){return h
}}return -1
},dG="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",dF="[\\x20\\t\\r\\n\\f]",dE="(?:\\\\.|[\\w-]|[^\0-\\xa0])+",dD="\\["+dF+"*("+dE+")(?:"+dF+"*([*^$|!~]?=)"+dF+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+dE+"))|)"+dF+"*\\]",dC=":("+dE+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+dD+")*)|.*)\\)|)",dB=new RegExp(dF+"+","g"),dz=new RegExp("^"+dF+"+|((?:^|[^\\\\])(?:\\\\.)*)"+dF+"+$","g"),dy=new RegExp("^"+dF+"*,"+dF+"*"),dx=new RegExp("^"+dF+"*([>+~]|"+dF+")"+dF+"*"),dw=new RegExp("="+dF+"*([^\\]'\"]*?)"+dF+"*\\]","g"),dv=new RegExp(dC),du=new RegExp("^"+dE+"$"),dt={ID:new RegExp("^#("+dE+")"),CLASS:new RegExp("^\\.("+dE+")"),TAG:new RegExp("^("+dE+"|[*])"),ATTR:new RegExp("^"+dD),PSEUDO:new RegExp("^"+dC),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+dF+"*(even|odd|(([+-]|)(\\d*)n|)"+dF+"*(?:([+-]|)"+dF+"*(\\d+)|))"+dF+"*\\)|)","i"),bool:new RegExp("^(?:"+dG+")$","i"),needsContext:new RegExp("^"+dF+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+dF+"*((?:-\\d)?\\d*)"+dF+"*\\)|)(?=[^-]|$)","i")},ds=/^(?:input|select|textarea|button)$/i,dr=/^h\d$/i,dq=/^[^{]+\{\s*\[native \w/,dp=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,dX=/[+~]/,dn=new RegExp("\\\\([\\da-f]{1,6}"+dF+"?|("+dF+")|.)","ig"),dU=function(f,e,h){var g="0x"+e-65536;
return g!==g||h?e:g<0?String.fromCharCode(g+65536):String.fromCharCode(g>>10|55296,1023&g|56320)
},dA=/([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,c5=function(d,c){return c?"\0"===d?"\ufffd":d.slice(0,-1)+"\\"+d.charCodeAt(d.length-1).toString(16)+" ":"\\"+d
},cO=function(){c6()
},bb=dS(function(b){return b.disabled===!0&&("form" in b||"label" in b)
},{dir:"parentNode",next:"legend"});
try{dK.apply(dO=dJ.call(cW.childNodes),cW.childNodes),dO[cW.childNodes.length].nodeType
}catch(d0){dK={apply:dO.length?function(d,c){dL.apply(d,dJ.call(c))
}:function(f,e){var h=f.length,g=0;
while(f[h++]=e[g++]){}f.length=h-1
}}
}function dV(z,v,u,t){var q,p,n,m,i,g,c,B=v&&v.ownerDocument,A=v?v.nodeType:9;
if(u=u||[],"string"!=typeof z||!z||1!==A&&9!==A&&11!==A){return u
}if(!t&&((v?v.ownerDocument||v:cW)!==c4&&c6(v),v=v||c4,c2)){if(11!==A&&(i=dp.exec(z))){if(q=i[1]){if(9===A){if(!(n=v.getElementById(q))){return u
}if(n.id===q){return u.push(n),u
}}else{if(B&&(n=B.getElementById(q))&&cY(v,n)&&n.id===q){return u.push(n),u
}}}else{if(i[2]){return dK.apply(u,v.getElementsByTagName(z)),u
}if((q=i[3])&&dj.getElementsByClassName&&v.getElementsByClassName){return dK.apply(u,v.getElementsByClassName(q)),u
}}}if(dj.qsa&&!dR[z+" "]&&(!c1||!c1.test(z))){if(1!==A){B=v,c=z
}else{if("object"!==v.nodeName.toLowerCase()){(m=v.getAttribute("id"))?m=m.replace(dA,c5):v.setAttribute("id",m=cX),g=de(z),p=g.length;
while(p--){g[p]="#"+m+" "+dY(g[p])
}c=g.join(","),B=dX.test(z)&&cM(v.parentNode)||v
}}if(c){try{return dK.apply(u,B.querySelectorAll(c)),u
}catch(y){}finally{m===cX&&v.removeAttribute("id")
}}}}return db(z.replace(dz,"$1"),v,u,t)
}function dH(){var d=[];
function c(b,a){return d.push(b+" ")>dh.cacheLength&&delete c[d.shift()],c[b+" "]=a
}return c
}function dc(b){return b[cX]=!0,b
}function cP(e){var d=c4.createElement("fieldset");
try{return !!e(d)
}catch(f){return !1
}finally{d.parentNode&&d.parentNode.removeChild(d),d=null
}}function cb(f,d){var h=f.split("|"),g=h.length;
while(g--){dh.attrHandle[h[g]]=d
}}function d1(f,e){var h=e&&f,g=h&&1===f.nodeType&&1===e.nodeType&&f.sourceIndex-e.sourceIndex;
if(g){return g
}if(h){while(h=h.nextSibling){if(h===e){return -1
}}}return f?1:-1
}function dW(b){return function(a){var d=a.nodeName.toLowerCase();
return"input"===d&&a.type===b
}
}function dN(b){return function(a){var d=a.nodeName.toLowerCase();
return("input"===d||"button"===d)&&a.type===b
}
}function di(b){return function(a){return"form" in a?a.parentNode&&a.disabled===!1?"label" in a?"label" in a.parentNode?a.parentNode.disabled===b:a.disabled===b:a.isDisabled===b||a.isDisabled!==!b&&bb(a)===b:a.disabled===b:"label" in a&&a.disabled===b
}
}function cQ(b){return dc(function(a){return a=+a,dc(function(l,k){var j,i=b([],l.length,a),h=i.length;
while(h--){l[j=i[h]]&&(l[j]=!(k[j]=l[j]))
}})
})
}function cM(b){return b&&"undefined"!=typeof b.getElementsByTagName&&b
}dj=dV.support={},df=dV.isXML=function(d){var c=d&&(d.ownerDocument||d).documentElement;
return !!c&&"HTML"!==c.nodeName
},c6=dV.setDocument=function(d){var c,h,f=d?d.ownerDocument||d:cW;
return f!==c4&&9===f.nodeType&&f.documentElement?(c4=f,c3=c4.documentElement,c2=!df(c4),cW!==c4&&(h=c4.defaultView)&&h.top!==h&&(h.addEventListener?h.addEventListener("unload",cO,!1):h.attachEvent&&h.attachEvent("onunload",cO)),dj.attributes=cP(function(b){return b.className="i",!b.getAttribute("className")
}),dj.getElementsByTagName=cP(function(b){return b.appendChild(c4.createComment("")),!b.getElementsByTagName("*").length
}),dj.getElementsByClassName=dq.test(c4.getElementsByClassName),dj.getById=cP(function(b){return c3.appendChild(b).id=cX,!c4.getElementsByName||!c4.getElementsByName(cX).length
}),dj.getById?(dh.filter.ID=function(g){var e=g.replace(dn,dU);
return function(b){return b.getAttribute("id")===e
}
},dh.find.ID=function(g,e){if("undefined"!=typeof e.getElementById&&c2){var i=e.getElementById(g);
return i?[i]:[]
}}):(dh.filter.ID=function(g){var e=g.replace(dn,dU);
return function(b){var i="undefined"!=typeof b.getAttributeNode&&b.getAttributeNode("id");
return i&&i.value===e
}
},dh.find.ID=function(i,g){if("undefined"!=typeof g.getElementById&&c2){var m,l,k,j=g.getElementById(i);
if(j){if(m=j.getAttributeNode("id"),m&&m.value===i){return[j]
}k=g.getElementsByName(i),l=0;
while(j=k[l++]){if(m=j.getAttributeNode("id"),m&&m.value===i){return[j]
}}}return[]
}}),dh.find.TAG=dj.getElementsByTagName?function(g,e){return"undefined"!=typeof e.getElementsByTagName?e.getElementsByTagName(g):dj.qsa?e.querySelectorAll(g):void 0
}:function(i,g){var m,l=[],k=0,j=g.getElementsByTagName(i);
if("*"===i){while(m=j[k++]){1===m.nodeType&&l.push(m)
}return l
}return j
},dh.find.CLASS=dj.getElementsByClassName&&function(g,e){if("undefined"!=typeof e.getElementsByClassName&&c2){return e.getElementsByClassName(g)
}},c0=[],c1=[],(dj.qsa=dq.test(c4.querySelectorAll))&&(cP(function(b){c3.appendChild(b).innerHTML="<a id='"+cX+"'></a><select id='"+cX+"-\r\\' msallowcapture=''><option selected=''></option></select>",b.querySelectorAll("[msallowcapture^='']").length&&c1.push("[*^$]="+dF+"*(?:''|\"\")"),b.querySelectorAll("[selected]").length||c1.push("\\["+dF+"*(?:value|"+dG+")"),b.querySelectorAll("[id~="+cX+"-]").length||c1.push("~="),b.querySelectorAll(":checked").length||c1.push(":checked"),b.querySelectorAll("a#"+cX+"+*").length||c1.push(".#.+[+~]")
}),cP(function(g){g.innerHTML="<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
var e=c4.createElement("input");
e.setAttribute("type","hidden"),g.appendChild(e).setAttribute("name","D"),g.querySelectorAll("[name=d]").length&&c1.push("name"+dF+"*[*^$|!~]?="),2!==g.querySelectorAll(":enabled").length&&c1.push(":enabled",":disabled"),c3.appendChild(g).disabled=!0,2!==g.querySelectorAll(":disabled").length&&c1.push(":enabled",":disabled"),g.querySelectorAll("*,:x"),c1.push(",.*:")
})),(dj.matchesSelector=dq.test(cZ=c3.matches||c3.webkitMatchesSelector||c3.mozMatchesSelector||c3.oMatchesSelector||c3.msMatchesSelector))&&cP(function(b){dj.disconnectedMatch=cZ.call(b,"*"),cZ.call(b,"[s!='']:x"),c0.push("!=",dC)
}),c1=c1.length&&new RegExp(c1.join("|")),c0=c0.length&&new RegExp(c0.join("|")),c=dq.test(c3.compareDocumentPosition),cY=c||dq.test(c3.contains)?function(g,e){var j=9===g.nodeType?g.documentElement:g,i=e&&e.parentNode;
return g===i||!(!i||1!==i.nodeType||!(j.contains?j.contains(i):g.compareDocumentPosition&&16&g.compareDocumentPosition(i)))
}:function(g,e){if(e){while(e=e.parentNode){if(e===g){return !0
}}}return !1
},dQ=c?function(g,e){if(g===e){return c7=!0,0
}var i=!g.compareDocumentPosition-!e.compareDocumentPosition;
return i?i:(i=(g.ownerDocument||g)===(e.ownerDocument||e)?g.compareDocumentPosition(e):1,1&i||!dj.sortDetached&&e.compareDocumentPosition(g)===i?g===c4||g.ownerDocument===cW&&cY(cW,g)?-1:e===c4||e.ownerDocument===cW&&cY(cW,e)?1:c8?dI(c8,g)-dI(c8,e):0:4&i?-1:1)
}:function(j,i){if(j===i){return c7=!0,0
}var p,o=0,n=j.parentNode,m=i.parentNode,l=[j],k=[i];
if(!n||!m){return j===c4?-1:i===c4?1:n?-1:m?1:c8?dI(c8,j)-dI(c8,i):0
}if(n===m){return d1(j,i)
}p=j;
while(p=p.parentNode){l.unshift(p)
}p=i;
while(p=p.parentNode){k.unshift(p)
}while(l[o]===k[o]){o++
}return o?d1(l[o],k[o]):l[o]===cW?-1:k[o]===cW?1:0
},c4):c4
},dV.matches=function(d,c){return dV(d,null,null,c)
},dV.matchesSelector=function(f,c){if((f.ownerDocument||f)!==c4&&c6(f),c=c.replace(dw,"='$1']"),dj.matchesSelector&&c2&&!dR[c+" "]&&(!c0||!c0.test(c))&&(!c1||!c1.test(c))){try{var h=cZ.call(f,c);
if(h||dj.disconnectedMatch||f.document&&11!==f.document.nodeType){return h
}}catch(g){}}return dV(c,c4,null,[f]).length>0
},dV.contains=function(d,c){return(d.ownerDocument||d)!==c4&&c6(d),cY(d,c)
},dV.attr=function(d,c){(d.ownerDocument||d)!==c4&&c6(d);
var h=dh.attrHandle[c.toLowerCase()],g=h&&dP.call(dh.attrHandle,c.toLowerCase())?h(d,c,!c2):void 0;
return void 0!==g?g:dj.attributes||!c2?d.getAttribute(c):(g=d.getAttributeNode(c))&&g.specified?g.value:null
},dV.escape=function(b){return(b+"").replace(dA,c5)
},dV.error=function(b){throw new Error("Syntax error, unrecognized expression: "+b)
},dV.uniqueSort=function(g){var c,j=[],i=0,h=0;
if(c7=!dj.detectDuplicates,c8=!dj.sortStable&&g.slice(0),g.sort(dQ),c7){while(c=g[h++]){c===g[h]&&(i=j.push(h))
}while(i--){g.splice(j[i],1)
}}return c8=null,g
},dg=dV.getText=function(g){var e,j="",i=0,h=g.nodeType;
if(h){if(1===h||9===h||11===h){if("string"==typeof g.textContent){return g.textContent
}for(g=g.firstChild;
g;
g=g.nextSibling){j+=dg(g)
}}else{if(3===h||4===h){return g.nodeValue
}}}else{while(e=g[i++]){j+=dg(e)
}}return j
},dh=dV.selectors={cacheLength:50,createPseudo:dc,match:dt,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(b){return b[1]=b[1].replace(dn,dU),b[3]=(b[3]||b[4]||b[5]||"").replace(dn,dU),"~="===b[2]&&(b[3]=" "+b[3]+" "),b.slice(0,4)
},CHILD:function(b){return b[1]=b[1].toLowerCase(),"nth"===b[1].slice(0,3)?(b[3]||dV.error(b[0]),b[4]=+(b[4]?b[5]+(b[6]||1):2*("even"===b[3]||"odd"===b[3])),b[5]=+(b[7]+b[8]||"odd"===b[3])):b[3]&&dV.error(b[0]),b
},PSEUDO:function(e){var d,f=!e[6]&&e[2];
return dt.CHILD.test(e[0])?null:(e[3]?e[2]=e[4]||e[5]||"":f&&dv.test(f)&&(d=de(f,!0))&&(d=f.indexOf(")",f.length-d)-f.length)&&(e[0]=e[0].slice(0,d),e[2]=f.slice(0,d)),e.slice(0,3))
}},filter:{TAG:function(d){var c=d.replace(dn,dU).toLowerCase();
return"*"===d?function(){return !0
}:function(b){return b.nodeName&&b.nodeName.toLowerCase()===c
}
},CLASS:function(d){var c=cT[d+" "];
return c||(c=new RegExp("(^|"+dF+")"+d+"("+dF+"|$)"))&&cT(d,function(b){return c.test("string"==typeof b.className&&b.className||"undefined"!=typeof b.getAttribute&&b.getAttribute("class")||"")
})
},ATTR:function(e,d,f){return function(b){var a=dV.attr(b,e);
return null==a?"!="===d:!d||(a+="","="===d?a===f:"!="===d?a!==f:"^="===d?f&&0===a.indexOf(f):"*="===d?f&&a.indexOf(f)>-1:"$="===d?f&&a.slice(-f.length)===f:"~="===d?(" "+a.replace(dB," ")+" ").indexOf(f)>-1:"|="===d&&(a===f||a.slice(0,f.length+1)===f+"-"))
}
},CHILD:function(j,i,p,o,n){var m="nth"!==j.slice(0,3),l="last"!==j.slice(-4),k="of-type"===i;
return 1===o&&0===n?function(b){return !!b.parentNode
}:function(z,y,x){var w,v,u,h,g,f,e=m!==l?"nextSibling":"previousSibling",d=z.parentNode,a=k&&z.nodeName.toLowerCase(),B=!x&&!k,A=!1;
if(d){if(m){while(e){h=z;
while(h=h[e]){if(k?h.nodeName.toLowerCase()===a:1===h.nodeType){return !1
}}f=e="only"===j&&!f&&"nextSibling"
}return !0
}if(f=[l?d.firstChild:d.lastChild],l&&B){h=d,u=h[cX]||(h[cX]={}),v=u[h.uniqueID]||(u[h.uniqueID]={}),w=v[j]||[],g=w[0]===cV&&w[1],A=g&&w[2],h=g&&d.childNodes[g];
while(h=++g&&h&&h[e]||(A=g=0)||f.pop()){if(1===h.nodeType&&++A&&h===z){v[j]=[cV,g,A];
break
}}}else{if(B&&(h=z,u=h[cX]||(h[cX]={}),v=u[h.uniqueID]||(u[h.uniqueID]={}),w=v[j]||[],g=w[0]===cV&&w[1],A=g),A===!1){while(h=++g&&h&&h[e]||(A=g=0)||f.pop()){if((k?h.nodeName.toLowerCase()===a:1===h.nodeType)&&++A&&(B&&(u=h[cX]||(h[cX]={}),v=u[h.uniqueID]||(u[h.uniqueID]={}),v[j]=[cV,A]),h===z)){break
}}}}return A-=n,A===o||A%o===0&&A/o>=0
}}
},PSEUDO:function(f,d){var h,g=dh.pseudos[f]||dh.setFilters[f.toLowerCase()]||dV.error("unsupported pseudo: "+f);
return g[cX]?g(d):g.length>1?(h=[f,f,"",d],dh.setFilters.hasOwnProperty(f.toLowerCase())?dc(function(b,k){var j,i=g(b,d),e=i.length;
while(e--){j=dI(b,i[e]),b[j]=!(k[j]=i[e])
}}):function(b){return g(b,0,h)
}):g
}},pseudos:{not:dc(function(f){var e=[],h=[],g=dd(f.replace(dz,"$1"));
return g[cX]?dc(function(i,d,n,m){var l,k=g(i,null,m,[]),j=i.length;
while(j--){(l=k[j])&&(i[j]=!(d[j]=l))
}}):function(b,d,c){return e[0]=b,g(e,null,c,h),e[0]=null,!h.pop()
}
}),has:dc(function(b){return function(a){return dV(b,a).length>0
}
}),contains:dc(function(b){return b=b.replace(dn,dU),function(a){return(a.textContent||a.innerText||dg(a)).indexOf(b)>-1
}
}),lang:dc(function(b){return du.test(b||"")||dV.error("unsupported lang: "+b),b=b.replace(dn,dU).toLowerCase(),function(a){var d;
do{if(d=c2?a.lang:a.getAttribute("xml:lang")||a.getAttribute("lang")){return d=d.toLowerCase(),d===b||0===d.indexOf(b+"-")
}}while((a=a.parentNode)&&1===a.nodeType);
return !1
}
}),target:function(a){var d=dl.location&&dl.location.hash;
return d&&d.slice(1)===a.id
},root:function(b){return b===c3
},focus:function(b){return b===c4.activeElement&&(!c4.hasFocus||c4.hasFocus())&&!!(b.type||b.href||~b.tabIndex)
},enabled:di(!1),disabled:di(!0),checked:function(d){var c=d.nodeName.toLowerCase();
return"input"===c&&!!d.checked||"option"===c&&!!d.selected
},selected:function(b){return b.parentNode&&b.parentNode.selectedIndex,b.selected===!0
},empty:function(b){for(b=b.firstChild;
b;
b=b.nextSibling){if(b.nodeType<6){return !1
}}return !0
},parent:function(b){return !dh.pseudos.empty(b)
},header:function(b){return dr.test(b.nodeName)
},input:function(b){return ds.test(b.nodeName)
},button:function(d){var c=d.nodeName.toLowerCase();
return"input"===c&&"button"===d.type||"button"===c
},text:function(d){var c;
return"input"===d.nodeName.toLowerCase()&&"text"===d.type&&(null==(c=d.getAttribute("type"))||"text"===c.toLowerCase())
},first:cQ(function(){return[0]
}),last:cQ(function(d,c){return[c-1]
}),eq:cQ(function(e,d,f){return[f<0?f+d:f]
}),even:cQ(function(e,d){for(var f=0;
f<d;
f+=2){e.push(f)
}return e
}),odd:cQ(function(e,d){for(var f=1;
f<d;
f+=2){e.push(f)
}return e
}),lt:cQ(function(f,e,h){for(var g=h<0?h+e:h;
--g>=0;
){f.push(g)
}return f
}),gt:cQ(function(f,e,h){for(var g=h<0?h+e:h;
++g<e;
){f.push(g)
}return f
})}},dh.pseudos.nth=dh.pseudos.eq;
for(dk in {radio:!0,checkbox:!0,file:!0,password:!0,image:!0}){dh.pseudos[dk]=dW(dk)
}for(dk in {submit:!0,reset:!0}){dh.pseudos[dk]=dN(dk)
}function d2(){}d2.prototype=dh.filters=dh.pseudos,dh.setFilters=new d2,de=dV.tokenize=function(t,s){var r,q,p,o,n,m,l,d=cS[t+" "];
if(d){return s?0:d.slice(0)
}n=t,m=[],l=dh.preFilter;
while(n){r&&!(q=dy.exec(n))||(q&&(n=n.slice(q[0].length)||n),m.push(p=[])),r=!1,(q=dx.exec(n))&&(r=q.shift(),p.push({value:r,type:q[0].replace(dz," ")}),n=n.slice(r.length));
for(o in dh.filter){!(q=dt[o].exec(n))||l[o]&&!(q=l[o](q))||(r=q.shift(),p.push({value:r,type:o,matches:q}),n=n.slice(r.length))
}if(!r){break
}}return s?n.length:n?dV.error(t):cS(t,m).slice(0)
};
function dY(f){for(var e=0,h=f.length,g="";
e<h;
e++){g+=f[e].value
}return g
}function dS(j,i,p){var o=i.dir,n=i.next,m=n||o,l=p&&"parentNode"===m,k=cU++;
return i.first?function(a,f,d){while(a=a[o]){if(1===a.nodeType||l){return j(a,f,d)
}}return !1
}:function(d,q,h){var g,f,e,a=[cV,k];
if(h){while(d=d[o]){if((1===d.nodeType||l)&&j(d,q,h)){return !0
}}}else{while(d=d[o]){if(1===d.nodeType||l){if(e=d[cX]||(d[cX]={}),f=e[d.uniqueID]||(e[d.uniqueID]={}),n&&n===d.nodeName.toLowerCase()){d=d[o]||d
}else{if((g=f[m])&&g[0]===cV&&g[1]===k){return a[2]=g[2]
}if(f[m]=a,a[2]=j(d,q,h)){return !0
}}}}}return !1
}
}function dm(b){return b.length>1?function(a,h,g){var f=b.length;
while(f--){if(!b[f](a,h,g)){return !1
}}return !0
}:b[0]
}function cR(g,f,j){for(var i=0,h=f.length;
i<h;
i++){dV(g,f[i],j)
}return j
}function cN(t,s,r,q,p){for(var o,n=[],m=0,l=t.length,k=null!=s;
m<l;
m++){(o=t[m])&&(r&&!r(o,q,p)||(n.push(o),k&&s.push(m)))
}return n
}function ab(h,g,l,k,j,i){return k&&!k[cX]&&(k=ab(k)),j&&!j[cX]&&(j=ab(j,i)),dc(function(z,y,x,w){var v,u,t,s=[],e=[],d=y.length,c=z||cR(g||"*",x.nodeType?[x]:x,[]),b=!h||!z&&g?c:cN(c,s,h,x,w),a=l?j||(z?h:d||k)?[]:y:b;
if(l&&l(b,a,x,w),k){v=cN(a,e),k(v,[],x,w),u=v.length;
while(u--){(t=v[u])&&(a[e[u]]=!(b[e[u]]=t))
}}if(z){if(j||h){if(j){v=[],u=a.length;
while(u--){(t=a[u])&&v.push(b[u]=t)
}j(null,a=[],v,w)
}u=a.length;
while(u--){(t=a[u])&&(v=j?dI(z,t):s[u])>-1&&(z[v]=!(y[v]=t))
}}}else{a=cN(a===y?a.splice(d,a.length):a),j?j(null,y,a,w):dK.apply(y,a)
}})
}function dZ(v){for(var u,t,s,r=v.length,q=dh.relative[v[0].type],p=q||dh.relative[" "],o=q?1:0,n=dS(function(b){return b===u
},p,!0),j=dS(function(b){return dI(u,b)>-1
},p,!0),d=[function(b,h,g){var f=!q&&(g||h!==c9)||((u=h).nodeType?n(b,h,g):j(b,h,g));
return u=null,f
}];
o<r;
o++){if(t=dh.relative[v[o].type]){d=[dS(dm(d),t)]
}else{if(t=dh.filter[v[o].type].apply(null,v[o].matches),t[cX]){for(s=++o;
s<r;
s++){if(dh.relative[v[s].type]){break
}}return ab(o>1&&dm(d),o>1&&dY(v.slice(0,o-1).concat({value:" "===v[o-2].type?"*":""})).replace(dz,"$1"),t,o<s&&dZ(v.slice(o,s)),s<r&&dZ(v=v.slice(s)),s<r&&dY(v))
}d.push(t)
}}return dm(d)
}function dT(g,d){var j=d.length>0,i=g.length>0,h=function(A,w,p,n,m){var e,c,b,a=0,H="0",G=A&&[],F=[],E=c9,D=A||i&&dh.find.TAG("*",m),C=cV+=null==E?1:Math.random()||0.1,B=D.length;
for(m&&(c9=w===c4||w||m);
H!==B&&null!=(e=D[H]);
H++){if(i&&e){c=0,w||e.ownerDocument===c4||(c6(e),p=!c2);
while(b=g[c++]){if(b(e,w||c4,p)){n.push(e);
break
}}m&&(cV=C)
}j&&((e=!b&&e)&&a--,A&&G.push(e))
}if(a+=H,j&&H!==a){c=0;
while(b=d[c++]){b(G,F,w,p)
}if(A){if(a>0){while(H--){G[H]||F[H]||(F[H]=dM.call(n))
}}F=cN(F)
}dK.apply(n,F),m&&!A&&F.length>0&&a+d.length>1&&dV.uniqueSort(n)
}return m&&(cV=C,c9=E),G
};
return j?dc(h):h
}return dd=dV.compile=function(h,g){var l,k=[],j=[],i=dR[h+" "];
if(!i){g||(g=de(h)),l=g.length;
while(l--){i=dZ(g[l]),i[cX]?k.push(i):j.push(i)
}i=dR(h,dT(j,k)),i.selector=h
}return i
},db=dV.select=function(v,u,t,s){var r,q,p,o,h,g="function"==typeof v&&v,d=!s&&de(v=g.selector||v);
if(t=t||[],1===d.length){if(q=d[0]=d[0].slice(0),q.length>2&&"ID"===(p=q[0]).type&&9===u.nodeType&&c2&&dh.relative[q[1].type]){if(u=(dh.find.ID(p.matches[0].replace(dn,dU),u)||[])[0],!u){return t
}g&&(u=u.parentNode),v=v.slice(q.shift().value.length)
}r=dt.needsContext.test(v)?0:q.length;
while(r--){if(p=q[r],dh.relative[o=p.type]){break
}if((h=dh.find[o])&&(s=h(p.matches[0].replace(dn,dU),dX.test(q[0].type)&&cM(u.parentNode)||u))){if(q.splice(r,1),v=s.length&&dY(q),!v){return dK.apply(t,s),t
}break
}}}return(g||dd(v,d))(s,u,!c2,t,!u||dX.test(v)&&cM(u.parentNode)||u),t
},dj.sortStable=cX.split("").sort(dQ).join("")===cX,dj.detectDuplicates=!!c7,c6(),dj.sortDetached=cP(function(b){return 1&b.compareDocumentPosition(c4.createElement("fieldset"))
}),cP(function(b){return b.innerHTML="<a href='#'></a>","#"===b.firstChild.getAttribute("href")
})||cb("type|href|height|width",function(e,d,f){if(!f){return e.getAttribute(d,"type"===d.toLowerCase()?1:2)
}}),dj.attributes&&cP(function(b){return b.innerHTML="<input/>",b.firstChild.setAttribute("value",""),""===b.firstChild.getAttribute("value")
})||cb("value",function(e,d,f){if(!f&&"input"===e.nodeName.toLowerCase()){return e.defaultValue
}}),cP(function(b){return null==b.getAttribute("disabled")
})||cb(dG,function(f,e,h){var g;
if(!h){return f[e]===!0?e.toLowerCase():(g=f.getAttributeNode(e))&&g.specified?g.value:null
}}),dV
}(bP);
bv.find=bp,bv.expr=bp.selectors,bv.expr[":"]=bv.expr.pseudos,bv.uniqueSort=bv.unique=bp.uniqueSort,bv.text=bp.getText,bv.isXMLDoc=bp.isXML,bv.contains=bp.contains,bv.escapeSelector=bp.escape;
var bo=function(g,f,j){var i=[],h=void 0!==j;
while((g=g[f])&&9!==g.nodeType){if(1===g.nodeType){if(h&&bv(g).is(j)){break
}i.push(g)
}}return i
},bm=function(e,d){for(var f=[];
e;
e=e.nextSibling){1===e.nodeType&&e!==d&&f.push(e)
}return f
},cp=bv.expr.match.needsContext,co=/^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i,cn=/^.[^:#\[\.,]*$/;
function cm(e,d,f){return bv.isFunction(d)?bv.grep(e,function(b,c){return !!d.call(b,c,b)!==f
}):d.nodeType?bv.grep(e,function(b){return b===d!==f
}):"string"!=typeof d?bv.grep(e,function(b){return bF.call(d,b)>-1!==f
}):cn.test(d)?bv.filter(d,e,f):(d=bv.filter(d,e),bv.grep(e,function(b){return bF.call(d,b)>-1!==f&&1===b.nodeType
}))
}bv.filter=function(f,e,h){var g=e[0];
return h&&(f=":not("+f+")"),1===e.length&&1===g.nodeType?bv.find.matchesSelector(g,f)?[g]:[]:bv.find.matches(f,bv.grep(e,function(b){return 1===b.nodeType
}))
},bv.fn.extend({find:function(g){var f,j,i=this.length,h=this;
if("string"!=typeof g){return this.pushStack(bv(g).filter(function(){for(f=0;
f<i;
f++){if(bv.contains(h[f],this)){return !0
}}}))
}for(j=this.pushStack([]),f=0;
f<i;
f++){bv.find(g,h[f],j)
}return i>1?bv.uniqueSort(j):j
},filter:function(b){return this.pushStack(cm(this,b||[],!1))
},not:function(b){return this.pushStack(cm(this,b||[],!0))
},is:function(b){return !!cm(this,"string"==typeof b&&cp.test(b)?bv(b):b||[],!1).length
}});
var cl,ck=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,ci=bv.fn.init=function(g,d,j){var i,h;
if(!g){return this
}if(j=j||cl,"string"==typeof g){if(i="<"===g[0]&&">"===g[g.length-1]&&g.length>=3?[null,g,null]:ck.exec(g),!i||!i[1]&&d){return !d||d.jquery?(d||j).find(g):this.constructor(d).find(g)
}if(i[1]){if(d=d instanceof bv?d[0]:d,bv.merge(this,bv.parseHTML(i[1],d&&d.nodeType?d.ownerDocument||d:bM,!0)),co.test(i[1])&&bv.isPlainObject(d)){for(i in d){bv.isFunction(this[i])?this[i](d[i]):this.attr(i,d[i])
}}return this
}return h=bM.getElementById(i[2]),h&&(this[0]=h,this.length=1),this
}return g.nodeType?(this[0]=g,this.length=1,this):bv.isFunction(g)?void 0!==j.ready?j.ready(g):g(bv):bv.makeArray(g,this)
};
ci.prototype=bv.fn,cl=bv(bM);
var cg=/^(?:parents|prev(?:Until|All))/,cf={children:!0,contents:!0,next:!0,prev:!0};
bv.fn.extend({has:function(e){var d=bv(e,this),f=d.length;
return this.filter(function(){for(var b=0;
b<f;
b++){if(bv.contains(this,d[b])){return !0
}}})
},closest:function(i,h){var n,m=0,l=this.length,k=[],j="string"!=typeof i&&bv(i);
if(!cp.test(i)){for(;
m<l;
m++){for(n=this[m];
n&&n!==h;
n=n.parentNode){if(n.nodeType<11&&(j?j.index(n)>-1:1===n.nodeType&&bv.find.matchesSelector(n,i))){k.push(n);
break
}}}}return this.pushStack(k.length>1?bv.uniqueSort(k):k)
},index:function(b){return b?"string"==typeof b?bF.call(bv(b),this[0]):bF.call(this,b.jquery?b[0]:b):this[0]&&this[0].parentNode?this.first().prevAll().length:-1
},add:function(d,c){return this.pushStack(bv.uniqueSort(bv.merge(this.get(),bv(d,c))))
},addBack:function(b){return this.add(null==b?this.prevObject:this.prevObject.filter(b))
}});
function ce(d,c){while((d=d[c])&&1!==d.nodeType){}return d
}bv.each({parent:function(d){var c=d.parentNode;
return c&&11!==c.nodeType?c:null
},parents:function(b){return bo(b,"parentNode")
},parentsUntil:function(e,d,f){return bo(e,"parentNode",f)
},next:function(b){return ce(b,"nextSibling")
},prev:function(b){return ce(b,"previousSibling")
},nextAll:function(b){return bo(b,"nextSibling")
},prevAll:function(b){return bo(b,"previousSibling")
},nextUntil:function(e,d,f){return bo(e,"nextSibling",f)
},prevUntil:function(e,d,f){return bo(e,"previousSibling",f)
},siblings:function(b){return bm((b.parentNode||{}).firstChild,b)
},children:function(b){return bm(b.firstChild)
},contents:function(b){return b.contentDocument||bv.merge([],b.childNodes)
}},function(d,c){bv.fn[d]=function(f,b){var a=bv.map(this,c,f);
return"Until"!==d.slice(-5)&&(b=f),b&&"string"==typeof b&&(a=bv.filter(b,a)),this.length>1&&(cf[d]||bv.uniqueSort(a),cg.test(d)&&a.reverse()),this.pushStack(a)
}
});
var cd=/[^\x20\t\r\n\f]+/g;
function cc(d){var c={};
return bv.each(d.match(cd)||[],function(b,e){c[e]=!0
}),c
}bv.Callbacks=function(t){t="string"==typeof t?cc(t):bv.extend({},t);
var s,r,q,p,o=[],n=[],m=-1,l=function(){for(p=t.once,q=s=!0;
n.length;
m=-1){r=n.shift();
while(++m<o.length){o[m].apply(r[0],r[1])===!1&&t.stopOnFalse&&(m=o.length,r=!1)
}}t.memory||(r=!1),s=!1,p&&(o=r?[]:"")
},k={add:function(){return o&&(r&&!s&&(m=o.length-1,n.push(r)),function a(c){bv.each(c,function(d,e){bv.isFunction(e)?t.unique&&k.has(e)||o.push(e):e&&e.length&&"string"!==bv.type(e)&&a(e)
})
}(arguments),r&&!s&&l()),this
},remove:function(){return bv.each(arguments,function(e,d){var f;
while((f=bv.inArray(d,o,f))>-1){o.splice(f,1),f<=m&&m--
}}),this
},has:function(b){return b?bv.inArray(b,o)>-1:o.length>0
},empty:function(){return o&&(o=[]),this
},disable:function(){return p=n=[],o=r="",this
},disabled:function(){return !o
},lock:function(){return p=n=[],r||s||(o=r=""),this
},locked:function(){return !!p
},fireWith:function(b,d){return p||(d=d||[],d=[b,d.slice?d.slice():d],n.push(d),s||l()),this
},fire:function(){return k.fireWith(this,arguments),this
},fired:function(){return !!q
}};
return k
};
function b9(b){return b
}function b8(b){throw b
}function b7(f,e,h){var g;
try{f&&bv.isFunction(g=f.promise)?g.call(f).done(e).fail(h):f&&bv.isFunction(g=f.then)?g.call(f,e,h):e.call(void 0,f)
}catch(f){h.call(void 0,f)
}}bv.extend({Deferred:function(a){var j=[["notify","progress",bv.Callbacks("memory"),bv.Callbacks("memory"),2],["resolve","done",bv.Callbacks("once memory"),bv.Callbacks("once memory"),0,"resolved"],["reject","fail",bv.Callbacks("once memory"),bv.Callbacks("once memory"),1,"rejected"]],i="pending",h={state:function(){return i
},always:function(){return g.done(arguments).fail(arguments),this
},"catch":function(b){return h.then(null,b)
},pipe:function(){var b=arguments;
return bv.Deferred(function(c){bv.each(j,function(l,k){var f=bv.isFunction(b[k[4]])&&b[k[4]];
g[k[1]](function(){var d=f&&f.apply(this,arguments);
d&&bv.isFunction(d.promise)?d.promise().progress(c.notify).done(c.resolve).fail(c.reject):c[k[0]+"With"](this,f?[d]:arguments)
})
}),b=null
}).promise()
},then:function(c,n,m){var l=0;
function k(f,q,p,o){return function(){var r=this,e=arguments,d=function(){var s,t;
if(!(f<l)){if(s=p.apply(r,e),s===q.promise()){throw new TypeError("Thenable self-resolution")
}t=s&&("object"==typeof s||"function"==typeof s)&&s.then,bv.isFunction(t)?o?t.call(s,k(l,q,b9,o),k(l,q,b8,o)):(l++,t.call(s,k(l,q,b9,o),k(l,q,b8,o),k(l,q,b9,q.notifyWith))):(p!==b9&&(r=void 0,e=[s]),(o||q.resolveWith)(r,e))
}},b=o?d:function(){try{d()
}catch(s){bv.Deferred.exceptionHook&&bv.Deferred.exceptionHook(s,b.stackTrace),f+1>=l&&(p!==b8&&(r=void 0,e=[s]),q.rejectWith(r,e))
}};
f?b():(bv.Deferred.getStackHook&&(b.stackTrace=bv.Deferred.getStackHook()),bP.setTimeout(b))
}
}return bv.Deferred(function(b){j[0][3].add(k(0,b,bv.isFunction(m)?m:b9,b.notifyWith)),j[1][3].add(k(0,b,bv.isFunction(c)?c:b9)),j[2][3].add(k(0,b,bv.isFunction(n)?n:b8))
}).promise()
},promise:function(b){return null!=b?bv.extend(b,h):h
}},g={};
return bv.each(j,function(d,c){var f=c[2],e=c[5];
h[c[1]]=f.add,e&&f.add(function(){i=e
},j[3-d][2].disable,j[0][2].lock),f.add(c[3].fire),g[c[0]]=function(){return g[c[0]+"With"](this===g?void 0:this,arguments),this
},g[c[0]+"With"]=f.fireWith
}),h.promise(g),a&&a.call(g,g),g
},when:function(i){var f=arguments.length,n=f,m=Array(n),l=bJ.call(arguments),k=bv.Deferred(),j=function(b){return function(a){m[b]=this,l[b]=arguments.length>1?bJ.call(arguments):a,--f||k.resolveWith(m,l)
}
};
if(f<=1&&(b7(i,k.done(j(n)).resolve,k.reject),"pending"===k.state()||bv.isFunction(l[n]&&l[n].then))){return k.then()
}while(n--){b7(l[n],j(n),k.reject)
}return k.promise()
}});
var b6=/^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
bv.Deferred.exceptionHook=function(a,d){bP.console&&bP.console.warn&&a&&b6.test(a.name)&&bP.console.warn("jQuery.Deferred exception: "+a.message,a.stack,d)
},bv.readyException=function(a){bP.setTimeout(function(){throw a
})
};
var b5=bv.Deferred();
bv.fn.ready=function(b){return b5.then(b)["catch"](function(c){bv.readyException(c)
}),this
},bv.extend({isReady:!1,readyWait:1,holdReady:function(b){b?bv.readyWait++:bv.ready(!0)
},ready:function(b){(b===!0?--bv.readyWait:bv.isReady)||(bv.isReady=!0,b!==!0&&--bv.readyWait>0||b5.resolveWith(bM,[bv]))
}}),bv.ready.then=b5.then;
function b3(){bM.removeEventListener("DOMContentLoaded",b3),bP.removeEventListener("load",b3),bv.ready()
}"complete"===bM.readyState||"loading"!==bM.readyState&&!bM.documentElement.doScroll?bP.setTimeout(bv.ready):(bM.addEventListener("DOMContentLoaded",b3),bP.addEventListener("load",b3));
var b2=function(t,s,r,q,p,o,n){var m=0,l=t.length,k=null==r;
if("object"===bv.type(r)){p=!0;
for(m in r){b2(t,s,m,r[m],!0,o,n)
}}else{if(void 0!==q&&(p=!0,bv.isFunction(q)||(n=!0),k&&(n?(s.call(t,q),s=null):(k=s,s=function(e,d,f){return k.call(bv(e),f)
})),s)){for(;
m<l;
m++){s(t[m],r,n?q:q.call(t[m],m,s(t[m],r)))
}}}return p?t:k?s.call(t):l?s(t[0],r):o
},b1=function(b){return 1===b.nodeType||9===b.nodeType||!+b.nodeType
};
function b0(){this.expando=bv.expando+b0.uid++
}b0.uid=1,b0.prototype={cache:function(d){var c=d[this.expando];
return c||(c={},b1(d)&&(d.nodeType?d[this.expando]=c:Object.defineProperty(d,this.expando,{value:c,configurable:!0}))),c
},set:function(g,f,j){var i,h=this.cache(g);
if("string"==typeof f){h[bv.camelCase(f)]=j
}else{for(i in f){h[bv.camelCase(i)]=f[i]
}}return h
},get:function(d,c){return void 0===c?this.cache(d):d[this.expando]&&d[this.expando][bv.camelCase(c)]
},access:function(e,d,f){return void 0===d||d&&"string"==typeof d&&void 0===f?this.get(e,d):(this.set(e,d,f),void 0!==f?f:d)
},remove:function(f,e){var h,g=f[this.expando];
if(void 0!==g){if(void 0!==e){bv.isArray(e)?e=e.map(bv.camelCase):(e=bv.camelCase(e),e=e in g?[e]:e.match(cd)||[]),h=e.length;
while(h--){delete g[e[h]]
}}(void 0===e||bv.isEmptyObject(g))&&(f.nodeType?f[this.expando]=void 0:delete f[this.expando])
}},hasData:function(d){var c=d[this.expando];
return void 0!==c&&!bv.isEmptyObject(c)
}};
var bZ=new b0,bY=new b0,bX=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,bW=/[A-Z]/g;
function bV(b){return"true"===b||"false"!==b&&("null"===b?null:b===+b+""?+b:bX.test(b)?JSON.parse(b):b)
}function cB(g,f,j){var i;
if(void 0===j&&1===g.nodeType){if(i="data-"+f.replace(bW,"-$&").toLowerCase(),j=g.getAttribute(i),"string"==typeof j){try{j=bV(j)
}catch(h){}bY.set(g,f,j)
}else{j=void 0
}}return j
}bv.extend({hasData:function(b){return bY.hasData(b)||bZ.hasData(b)
},data:function(e,d,f){return bY.access(e,d,f)
},removeData:function(d,c){bY.remove(d,c)
},_data:function(e,d,f){return bZ.access(e,d,f)
},_removeData:function(d,c){bZ.remove(d,c)
}}),bv.fn.extend({data:function(i,h){var n,m,l,k=this[0],j=k&&k.attributes;
if(void 0===i){if(this.length&&(l=bY.get(k),1===k.nodeType&&!bZ.get(k,"hasDataAttrs"))){n=j.length;
while(n--){j[n]&&(m=j[n].name,0===m.indexOf("data-")&&(m=bv.camelCase(m.slice(5)),cB(k,m,l[m])))
}bZ.set(k,"hasDataAttrs",!0)
}return l
}return"object"==typeof i?this.each(function(){bY.set(this,i)
}):b2(this,function(a){var d;
if(k&&void 0===a){if(d=bY.get(k,i),void 0!==d){return d
}if(d=cB(k,i),void 0!==d){return d
}}else{this.each(function(){bY.set(this,i,a)
})
}},null,h,arguments.length>1,null,!0)
},removeData:function(b){return this.each(function(){bY.remove(this,b)
})
}}),bv.extend({queue:function(f,e,h){var g;
if(f){return e=(e||"fx")+"queue",g=bZ.get(f,e),h&&(!g||bv.isArray(h)?g=bZ.access(f,e,bv.makeArray(h)):g.push(h)),g||[]
}},dequeue:function(i,h){h=h||"fx";
var n=bv.queue(i,h),m=n.length,l=n.shift(),k=bv._queueHooks(i,h),j=function(){bv.dequeue(i,h)
};
"inprogress"===l&&(l=n.shift(),m--),l&&("fx"===h&&n.unshift("inprogress"),delete k.stop,l.call(i,j,k)),!m&&k&&k.empty.fire()
},_queueHooks:function(e,d){var f=d+"queueHooks";
return bZ.get(e,f)||bZ.access(e,f,{empty:bv.Callbacks("once memory").add(function(){bZ.remove(e,[d+"queue",f])
})})
}}),bv.fn.extend({queue:function(e,d){var f=2;
return"string"!=typeof e&&(d=e,e="fx",f--),arguments.length<f?bv.queue(this[0],e):void 0===d?this:this.each(function(){var a=bv.queue(this,e,d);
bv._queueHooks(this,e),"fx"===e&&"inprogress"!==a[0]&&bv.dequeue(this,e)
})
},dequeue:function(b){return this.each(function(){bv.dequeue(this,b)
})
},clearQueue:function(b){return this.queue(b||"fx",[])
},promise:function(j,i){var p,o=1,n=bv.Deferred(),m=this,l=this.length,k=function(){--o||n.resolveWith(m,[m])
};
"string"!=typeof j&&(i=j,j=void 0),j=j||"fx";
while(l--){p=bZ.get(m[l],j+"queueHooks"),p&&p.empty&&(o++,p.empty.add(k))
}return k(),n.promise(i)
}});
var bQ=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,cA=new RegExp("^(?:([+-])=|)("+bQ+")([a-z%]*)$","i"),cj=["Top","Right","Bottom","Left"],bK=function(d,c){return d=c||d,"none"===d.style.display||""===d.style.display&&bv.contains(d.ownerDocument,d)&&"none"===bv.css(d,"display")
},bi=function(i,h,n,m){var l,k,j={};
for(k in h){j[k]=i.style[k],i.style[k]=h[k]
}l=n.apply(i,m||[]);
for(k in h){i.style[k]=j[k]
}return l
};
function a9(v,u,t,s){var r,q=1,p=20,o=s?function(){return s.cur()
}:function(){return bv.css(v,u,"")
},n=o(),m=t&&t[3]||(bv.cssNumber[u]?"":"px"),l=(bv.cssNumber[u]||"px"!==m&&+n)&&cA.exec(bv.css(v,u));
if(l&&l[3]!==m){m=m||l[3],t=t||[],l=+n||1;
do{q=q||".5",l/=q,bv.style(v,u,l+m)
}while(q!==(q=o()/n)&&1!==q&&--p)
}return t&&(l=+l||+n||0,r=t[1]?l+(t[1]+1)*t[2]:+t[2],s&&(s.unit=m,s.start=l,s.end=r)),r
}var a2={};
function aT(g){var f,j=g.ownerDocument,i=g.nodeName,h=a2[i];
return h?h:(f=j.body.appendChild(j.createElement(i)),h=bv.css(f,"display"),f.parentNode.removeChild(f),"none"===h&&(h="block"),a2[i]=h,h)
}function aL(i,h){for(var n,m,l=[],k=0,j=i.length;
k<j;
k++){m=i[k],m.style&&(n=m.style.display,h?("none"===n&&(l[k]=bZ.get(m,"display")||null,l[k]||(m.style.display="")),""===m.style.display&&bK(m)&&(l[k]=aT(m))):"none"!==n&&(l[k]="none",bZ.set(m,"display",n)))
}for(k=0;
k<j;
k++){null!=l[k]&&(i[k].style.display=l[k])
}return i
}bv.fn.extend({show:function(){return aL(this,!0)
},hide:function(){return aL(this)
},toggle:function(b){return"boolean"==typeof b?b?this.show():this.hide():this.each(function(){bK(this)?bv(this).show():bv(this).hide()
})
}});
var aD=/^(?:checkbox|radio)$/i,av=/<([a-z][^\/\0>\x20\t\r\n\f]+)/i,am=/^$|\/(?:java|ecma)script/i,ad={option:[1,"<select multiple='multiple'>","</select>"],thead:[1,"<table>","</table>"],col:[2,"<table><colgroup>","</colgroup></table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:[0,"",""]};
ad.optgroup=ad.option,ad.tbody=ad.tfoot=ad.colgroup=ad.caption=ad.thead,ad.th=ad.td;
function cF(e,d){var f;
return f="undefined"!=typeof e.getElementsByTagName?e.getElementsByTagName(d||"*"):"undefined"!=typeof e.querySelectorAll?e.querySelectorAll(d||"*"):[],void 0===d||d&&bv.nodeName(e,d)?bv.merge([e],f):f
}function cu(f,e){for(var h=0,g=f.length;
h<g;
h++){bZ.set(f[h],"globalEval",!e||bZ.get(e[h],"globalEval"))
}}var bU=/<|&#?\w+;/;
function bn(D,C,B,A,z){for(var y,x,w,v,u,t,s=C.createDocumentFragment(),r=[],q=0,p=D.length;
q<p;
q++){if(y=D[q],y||0===y){if("object"===bv.type(y)){bv.merge(r,y.nodeType?[y]:y)
}else{if(bU.test(y)){x=x||s.appendChild(C.createElement("div")),w=(av.exec(y)||["",""])[1].toLowerCase(),v=ad[w]||ad._default,x.innerHTML=v[1]+bv.htmlPrefilter(y)+v[2],t=v[0];
while(t--){x=x.lastChild
}bv.merge(r,x.childNodes),x=s.firstChild,x.textContent=""
}else{r.push(C.createTextNode(y))
}}}}s.textContent="",q=0;
while(y=r[q++]){if(A&&bv.inArray(y,A)>-1){z&&z.push(y)
}else{if(u=bv.contains(y.ownerDocument,y),x=cF(s.appendChild(y),"script"),u&&cu(x),B){t=0;
while(y=x[t++]){am.test(y.type||"")&&B.push(y)
}}}}return s
}!function(){var e=bM.createDocumentFragment(),d=e.appendChild(bM.createElement("div")),f=bM.createElement("input");
f.setAttribute("type","radio"),f.setAttribute("checked","checked"),f.setAttribute("name","t"),d.appendChild(f),bz.checkClone=d.cloneNode(!0).cloneNode(!0).lastChild.checked,d.innerHTML="<textarea>x</textarea>",bz.noCloneChecked=!!d.cloneNode(!0).lastChild.defaultValue
}();
var bf=bM.documentElement,a6=/^key/,aX=/^(?:mouse|pointer|contextmenu|drag|drop)|click/,aP=/^([^.]*)(?:\.(.+)|)/;
function aH(){return !0
}function az(){return !1
}function aq(){try{return bM.activeElement
}catch(b){}}function ah(j,i,p,o,n,m){var l,k;
if("object"==typeof i){"string"!=typeof p&&(o=o||p,p=void 0);
for(k in i){ah(j,k,p,o,i[k],m)
}return j
}if(null==o&&null==n?(n=p,o=p=void 0):null==n&&("string"==typeof p?(n=o,o=void 0):(n=o,o=p,p=void 0)),n===!1){n=az
}else{if(!n){return j
}}return 1===m&&(l=n,n=function(b){return bv().off(b),l.apply(this,arguments)
},n.guid=l.guid||(l.guid=bv.guid++)),j.each(function(){bv.event.add(this,i,n,o,p)
})
}bv.event={global:{},add:function(H,G,F,E,D){var C,B,A,z,y,x,w,v,u,t,s,r=bZ.get(H);
if(r){F.handler&&(C=F,F=C.handler,D=C.selector),D&&bv.find.matchesSelector(bf,D),F.guid||(F.guid=bv.guid++),(z=r.events)||(z=r.events={}),(B=r.handle)||(B=r.handle=function(a){return"undefined"!=typeof bv&&bv.event.triggered!==a.type?bv.event.dispatch.apply(H,arguments):void 0
}),G=(G||"").match(cd)||[""],y=G.length;
while(y--){A=aP.exec(G[y])||[],u=s=A[1],t=(A[2]||"").split(".").sort(),u&&(w=bv.event.special[u]||{},u=(D?w.delegateType:w.bindType)||u,w=bv.event.special[u]||{},x=bv.extend({type:u,origType:s,data:E,handler:F,guid:F.guid,selector:D,needsContext:D&&bv.expr.match.needsContext.test(D),namespace:t.join(".")},C),(v=z[u])||(v=z[u]=[],v.delegateCount=0,w.setup&&w.setup.call(H,E,t,B)!==!1||H.addEventListener&&H.addEventListener(u,B)),w.add&&(w.add.call(H,x),x.handler.guid||(x.handler.guid=F.guid)),D?v.splice(v.delegateCount++,0,x):v.push(x),bv.event.global[u]=!0)
}}},remove:function(H,G,F,E,D){var C,B,A,z,y,x,w,v,u,t,s,r=bZ.hasData(H)&&bZ.get(H);
if(r&&(z=r.events)){G=(G||"").match(cd)||[""],y=G.length;
while(y--){if(A=aP.exec(G[y])||[],u=s=A[1],t=(A[2]||"").split(".").sort(),u){w=bv.event.special[u]||{},u=(E?w.delegateType:w.bindType)||u,v=z[u]||[],A=A[2]&&new RegExp("(^|\\.)"+t.join("\\.(?:.*\\.|)")+"(\\.|$)"),B=C=v.length;
while(C--){x=v[C],!D&&s!==x.origType||F&&F.guid!==x.guid||A&&!A.test(x.namespace)||E&&E!==x.selector&&("**"!==E||!x.selector)||(v.splice(C,1),x.selector&&v.delegateCount--,w.remove&&w.remove.call(H,x))
}B&&!v.length&&(w.teardown&&w.teardown.call(H,t,r.handle)!==!1||bv.removeEvent(H,u,r.handle),delete z[u])
}else{for(u in z){bv.event.remove(H,u+G[y],F,E,!0)
}}}bv.isEmptyObject(z)&&bZ.remove(H,"handle events")
}},dispatch:function(v){var u=bv.event.fix(v),t,s,r,q,p,o,n=new Array(arguments.length),m=(bZ.get(this,"events")||{})[u.type]||[],l=bv.event.special[u.type]||{};
for(n[0]=u,t=1;
t<arguments.length;
t++){n[t]=arguments[t]
}if(u.delegateTarget=this,!l.preDispatch||l.preDispatch.call(this,u)!==!1){o=bv.event.handlers.call(this,u,m),t=0;
while((q=o[t++])&&!u.isPropagationStopped()){u.currentTarget=q.elem,s=0;
while((p=q.handlers[s++])&&!u.isImmediatePropagationStopped()){u.rnamespace&&!u.rnamespace.test(p.namespace)||(u.handleObj=p,u.data=p.data,r=((bv.event.special[p.origType]||{}).handle||p.handler).apply(q.elem,n),void 0!==r&&(u.result=r)===!1&&(u.preventDefault(),u.stopPropagation()))
}}return l.postDispatch&&l.postDispatch.call(this,u),u.result
}},handlers:function(t,s){var r,q,p,o,n,m=[],l=s.delegateCount,k=t.target;
if(l&&k.nodeType&&!("click"===t.type&&t.button>=1)){for(;
k!==this;
k=k.parentNode||this){if(1===k.nodeType&&("click"!==t.type||k.disabled!==!0)){for(o=[],n={},r=0;
r<l;
r++){q=s[r],p=q.selector+" ",void 0===n[p]&&(n[p]=q.needsContext?bv(p,this).index(k)>-1:bv.find(p,this,null,[k]).length),n[p]&&o.push(q)
}o.length&&m.push({elem:k,handlers:o})
}}}return k=this,l<s.length&&m.push({elem:k,handlers:s.slice(l)}),m
},addProp:function(d,c){Object.defineProperty(bv.Event.prototype,d,{enumerable:!0,configurable:!0,get:bv.isFunction(c)?function(){if(this.originalEvent){return c(this.originalEvent)
}}:function(){if(this.originalEvent){return this.originalEvent[d]
}},set:function(a){Object.defineProperty(this,d,{enumerable:!0,configurable:!0,writable:!0,value:a})
}})
},fix:function(b){return b[bv.expando]?b:new bv.Event(b)
},special:{load:{noBubble:!0},focus:{trigger:function(){if(this!==aq()&&this.focus){return this.focus(),!1
}},delegateType:"focusin"},blur:{trigger:function(){if(this===aq()&&this.blur){return this.blur(),!1
}},delegateType:"focusout"},click:{trigger:function(){if("checkbox"===this.type&&this.click&&bv.nodeName(this,"input")){return this.click(),!1
}},_default:function(b){return bv.nodeName(b.target,"a")
}},beforeunload:{postDispatch:function(b){void 0!==b.result&&b.originalEvent&&(b.originalEvent.returnValue=b.result)
}}}},bv.removeEvent=function(e,d,f){e.removeEventListener&&e.removeEventListener(d,f)
},bv.Event=function(d,c){return this instanceof bv.Event?(d&&d.type?(this.originalEvent=d,this.type=d.type,this.isDefaultPrevented=d.defaultPrevented||void 0===d.defaultPrevented&&d.returnValue===!1?aH:az,this.target=d.target&&3===d.target.nodeType?d.target.parentNode:d.target,this.currentTarget=d.currentTarget,this.relatedTarget=d.relatedTarget):this.type=d,c&&bv.extend(this,c),this.timeStamp=d&&d.timeStamp||bv.now(),void (this[bv.expando]=!0)):new bv.Event(d,c)
},bv.Event.prototype={constructor:bv.Event,isDefaultPrevented:az,isPropagationStopped:az,isImmediatePropagationStopped:az,isSimulated:!1,preventDefault:function(){var b=this.originalEvent;
this.isDefaultPrevented=aH,b&&!this.isSimulated&&b.preventDefault()
},stopPropagation:function(){var b=this.originalEvent;
this.isPropagationStopped=aH,b&&!this.isSimulated&&b.stopPropagation()
},stopImmediatePropagation:function(){var b=this.originalEvent;
this.isImmediatePropagationStopped=aH,b&&!this.isSimulated&&b.stopImmediatePropagation(),this.stopPropagation()
}},bv.each({altKey:!0,bubbles:!0,cancelable:!0,changedTouches:!0,ctrlKey:!0,detail:!0,eventPhase:!0,metaKey:!0,pageX:!0,pageY:!0,shiftKey:!0,view:!0,"char":!0,charCode:!0,key:!0,keyCode:!0,button:!0,buttons:!0,clientX:!0,clientY:!0,offsetX:!0,offsetY:!0,pointerId:!0,pointerType:!0,screenX:!0,screenY:!0,targetTouches:!0,toElement:!0,touches:!0,which:function(d){var c=d.button;
return null==d.which&&a6.test(d.type)?null!=d.charCode?d.charCode:d.keyCode:!d.which&&void 0!==c&&aX.test(d.type)?1&c?1:2&c?3:4&c?2:0:d.which
}},bv.event.addProp),bv.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(d,c){bv.event.special[d]={delegateType:c,bindType:c,handle:function(b){var j,i=this,h=b.relatedTarget,g=b.handleObj;
return h&&(h===i||bv.contains(i,h))||(b.type=g.origType,j=g.handler.apply(this,arguments),b.type=c),j
}}
}),bv.fn.extend({on:function(f,e,h,g){return ah(this,f,e,h,g)
},one:function(f,e,h,g){return ah(this,f,e,h,g,1)
},off:function(g,f,j){var i,h;
if(g&&g.preventDefault&&g.handleObj){return i=g.handleObj,bv(g.delegateTarget).off(i.namespace?i.origType+"."+i.namespace:i.origType,i.selector,i.handler),this
}if("object"==typeof g){for(h in g){this.off(h,f,g[h])
}return this
}return f!==!1&&"function"!=typeof f||(j=f,f=void 0),j===!1&&(j=az),this.each(function(){bv.event.remove(this,g,j,f)
})
}});
var cJ=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,cy=/<script|<style|<link/i,a0=/checked\s*(?:[^=]|=\s*.checked.)/i,aR=/^true\/(.*)/,aJ=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
function aB(d,c){return bv.nodeName(d,"table")&&bv.nodeName(11!==c.nodeType?c:c.firstChild,"tr")?d.getElementsByTagName("tbody")[0]||d:d
}function at(b){return b.type=(null!==b.getAttribute("type"))+"/"+b.type,b
}function ak(d){var c=aR.exec(d.type);
return c?d.type=c[1]:d.removeAttribute("type"),d
}function cL(t,s){var r,q,p,o,n,m,l,k;
if(1===s.nodeType){if(bZ.hasData(t)&&(o=bZ.access(t),n=bZ.set(s,o),k=o.events)){delete n.handle,n.events={};
for(p in k){for(r=0,q=k[p].length;
r<q;
r++){bv.event.add(s,p,k[p][r])
}}}bY.hasData(t)&&(m=bY.access(t),l=bv.extend({},m),bY.set(s,l))
}}function cD(e,d){var f=d.nodeName.toLowerCase();
"input"===f&&aD.test(e.type)?d.checked=e.checked:"input"!==f&&"textarea"!==f||(d.defaultValue=e.defaultValue)
}function cs(C,B,A,z){B=bH.apply([],B);
var y,x,w,v,u,t,r=0,p=C.length,o=p-1,g=B[0],D=bv.isFunction(g);
if(D||p>1&&"string"==typeof g&&!bz.checkClone&&a0.test(g)){return C.each(function(b){var a=C.eq(b);
D&&(B[0]=g.call(this,b,a.html())),cs(a,B,A,z)
})
}if(p&&(y=bn(B,C[0].ownerDocument,!1,C,z),x=y.firstChild,1===y.childNodes.length&&(y=x),x||z)){for(w=bv.map(cF(y,"script"),at),v=w.length;
r<p;
r++){u=y,r!==o&&(u=bv.clone(u,!0,!0),v&&bv.merge(w,cF(u,"script"))),A.call(C[r],u,r)
}if(v){for(t=w[w.length-1].ownerDocument,bv.map(w,ak),r=0;
r<v;
r++){u=w[r],am.test(u.type||"")&&!bZ.access(u,"globalEval")&&bv.contains(t,u)&&(u.src?bv._evalUrl&&bv._evalUrl(u.src):by(u.textContent.replace(aJ,""),t))
}}}return C
}function bS(h,g,l){for(var k,j=g?bv.filter(g,h):h,i=0;
null!=(k=j[i]);
i++){l||1!==k.nodeType||bv.cleanData(cF(k)),k.parentNode&&(l&&bv.contains(k.ownerDocument,k)&&cu(cF(k,"script")),k.parentNode.removeChild(k))
}return h
}bv.extend({htmlPrefilter:function(b){return b.replace(cJ,"<$1><$2>")
},clone:function(r,q,p){var o,n,m,l,k=r.cloneNode(!0),j=bv.contains(r.ownerDocument,r);
if(!(bz.noCloneChecked||1!==r.nodeType&&11!==r.nodeType||bv.isXMLDoc(r))){for(l=cF(k),m=cF(r),o=0,n=m.length;
o<n;
o++){cD(m[o],l[o])
}}if(q){if(p){for(m=m||cF(r),l=l||cF(k),o=0,n=m.length;
o<n;
o++){cL(m[o],l[o])
}}else{cL(r,k)
}}return l=cF(k,"script"),l.length>0&&cu(l,!j&&cF(r,"script")),k
},cleanData:function(h){for(var g,l,k,j=bv.event.special,i=0;
void 0!==(l=h[i]);
i++){if(b1(l)){if(g=l[bZ.expando]){if(g.events){for(k in g.events){j[k]?bv.event.remove(l,k):bv.removeEvent(l,k,g.handle)
}}l[bZ.expando]=void 0
}l[bY.expando]&&(l[bY.expando]=void 0)
}}}}),bv.fn.extend({detach:function(b){return bS(this,b,!0)
},remove:function(b){return bS(this,b)
},text:function(b){return b2(this,function(c){return void 0===c?bv.text(this):this.empty().each(function(){1!==this.nodeType&&11!==this.nodeType&&9!==this.nodeType||(this.textContent=c)
})
},null,b,arguments.length)
},append:function(){return cs(this,arguments,function(d){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var c=aB(this,d);
c.appendChild(d)
}})
},prepend:function(){return cs(this,arguments,function(d){if(1===this.nodeType||11===this.nodeType||9===this.nodeType){var c=aB(this,d);
c.insertBefore(d,c.firstChild)
}})
},before:function(){return cs(this,arguments,function(b){this.parentNode&&this.parentNode.insertBefore(b,this)
})
},after:function(){return cs(this,arguments,function(b){this.parentNode&&this.parentNode.insertBefore(b,this.nextSibling)
})
},empty:function(){for(var d,c=0;
null!=(d=this[c]);
c++){1===d.nodeType&&(bv.cleanData(cF(d,!1)),d.textContent="")
}return this
},clone:function(d,c){return d=null!=d&&d,c=null==c?d:c,this.map(function(){return bv.clone(this,d,c)
})
},html:function(b){return b2(this,function(g){var f=this[0]||{},j=0,i=this.length;
if(void 0===g&&1===f.nodeType){return f.innerHTML
}if("string"==typeof g&&!cy.test(g)&&!ad[(av.exec(g)||["",""])[1].toLowerCase()]){g=bv.htmlPrefilter(g);
try{for(;
j<i;
j++){f=this[j]||{},1===f.nodeType&&(bv.cleanData(cF(f,!1)),f.innerHTML=g)
}f=0
}catch(h){}}f&&this.empty().append(g)
},null,b,arguments.length)
},replaceWith:function(){var b=[];
return cs(this,arguments,function(a){var d=this.parentNode;
bv.inArray(this,b)<0&&(bv.cleanData(cF(this)),d&&d.replaceChild(a,this))
},b)
}}),bv.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(d,c){bv.fn[d]=function(b){for(var l,k=[],j=bv(b),i=j.length-1,h=0;
h<=i;
h++){l=h===i?this:this.clone(!0),bv(j[h])[c](l),bG.apply(k,l.get())
}return this.pushStack(k)
}
});
var bk=/^margin/,bd=new RegExp("^("+bQ+")(?!px)[a-z%]+$","i"),a4=function(a){var d=a.ownerDocument.defaultView;
return d&&d.opener||(d=bP),d.getComputedStyle(a)
};
!function(){function a(){if(d){d.style.cssText="box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%",d.innerHTML="",bf.appendChild(j);
var c=bP.getComputedStyle(d);
n="1%"!==c.top,k="2px"===c.marginLeft,m="4px"===c.width,d.style.marginRight="50%",l="4px"===c.marginRight,bf.removeChild(j),d=null
}}var n,m,l,k,j=bM.createElement("div"),d=bM.createElement("div");
d.style&&(d.style.backgroundClip="content-box",d.cloneNode(!0).style.backgroundClip="",bz.clearCloneStyle="content-box"===d.style.backgroundClip,j.style.cssText="border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute",j.appendChild(d),bv.extend(bz,{pixelPosition:function(){return a(),n
},boxSizingReliable:function(){return a(),m
},pixelMarginRight:function(){return a(),l
},reliableMarginLeft:function(){return a(),k
}}))
}();
function aV(j,i,p){var o,n,m,l,k=j.style;
return p=p||a4(j),p&&(l=p.getPropertyValue(i)||p[i],""!==l||bv.contains(j.ownerDocument,j)||(l=bv.style(j,i)),!bz.pixelMarginRight()&&bd.test(l)&&bk.test(i)&&(o=k.width,n=k.minWidth,m=k.maxWidth,k.minWidth=k.maxWidth=k.width=l,l=p.width,k.width=o,k.minWidth=n,k.maxWidth=m)),void 0!==l?l+"":l
}function aN(d,c){return{get:function(){return d()?void delete this.get:(this.get=c).apply(this,arguments)
}}
}var aF=/^(none|table(?!-c[ea]).+)/,ax={position:"absolute",visibility:"hidden",display:"block"},ao={letterSpacing:"0",fontWeight:"400"},af=["Webkit","Moz","ms"],cH=bM.createElement("div").style;
function cw(e){if(e in cH){return e
}var d=e[0].toUpperCase()+e.slice(1),f=af.length;
while(f--){if(e=af[f]+d,e in cH){return e
}}}function b4(f,e,h){var g=cA.exec(e);
return g?Math.max(0,g[2]-(h||0))+(g[3]||"px"):e
}function bx(i,h,n,m,l){var k,j=0;
for(k=n===(m?"border":"content")?4:"width"===h?1:0;
k<4;
k+=2){"margin"===n&&(j+=bv.css(i,n+cj[k],!0,l)),m?("content"===n&&(j-=bv.css(i,"padding"+cj[k],!0,l)),"margin"!==n&&(j-=bv.css(i,"border"+cj[k]+"Width",!0,l))):(j+=bv.css(i,"padding"+cj[k],!0,l),"padding"!==n&&(j+=bv.css(i,"border"+cj[k]+"Width",!0,l)))
}return j
}function bg(i,h,n){var m,l=!0,k=a4(i),j="border-box"===bv.css(i,"boxSizing",!1,k);
if(i.getClientRects().length&&(m=i.getBoundingClientRect()[h]),m<=0||null==m){if(m=aV(i,h,k),(m<0||null==m)&&(m=i.style[h]),bd.test(m)){return m
}l=j&&(bz.boxSizingReliable()||m===i.style[h]),m=parseFloat(m)||0
}return m+bx(i,h,n||(j?"border":"content"),l,k)+"px"
}bv.extend({cssHooks:{opacity:{get:function(e,d){if(d){var f=aV(e,"opacity");
return""===f?"1":f
}}}},cssNumber:{animationIterationCount:!0,columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":"cssFloat"},style:function(r,q,p,o){if(r&&3!==r.nodeType&&8!==r.nodeType&&r.style){var n,m,l,k=bv.camelCase(q),j=r.style;
return q=bv.cssProps[k]||(bv.cssProps[k]=cw(k)||k),l=bv.cssHooks[q]||bv.cssHooks[k],void 0===p?l&&"get" in l&&void 0!==(n=l.get(r,!1,o))?n:j[q]:(m=typeof p,"string"===m&&(n=cA.exec(p))&&n[1]&&(p=a9(r,q,n),m="number"),null!=p&&p===p&&("number"===m&&(p+=n&&n[3]||(bv.cssNumber[k]?"":"px")),bz.clearCloneStyle||""!==p||0!==q.indexOf("background")||(j[q]="inherit"),l&&"set" in l&&void 0===(p=l.set(r,p,o))||(j[q]=p)),void 0)
}},css:function(j,i,p,o){var n,m,l,k=bv.camelCase(i);
return i=bv.cssProps[k]||(bv.cssProps[k]=cw(k)||k),l=bv.cssHooks[i]||bv.cssHooks[k],l&&"get" in l&&(n=l.get(j,!0,p)),void 0===n&&(n=aV(j,i,o)),"normal"===n&&i in ao&&(n=ao[i]),""===p||p?(m=parseFloat(n),p===!0||isFinite(m)?m||0:n):n
}}),bv.each(["height","width"],function(d,c){bv.cssHooks[c]={get:function(b,f,e){if(f){return !aF.test(bv.css(b,"display"))||b.getClientRects().length&&b.getBoundingClientRect().width?bg(b,c,e):bi(b,ax,function(){return bg(b,c,e)
})
}},set:function(b,l,k){var j,i=k&&a4(b),h=k&&bx(b,c,k,"border-box"===bv.css(b,"boxSizing",!1,i),i);
return h&&(j=cA.exec(l))&&"px"!==(j[3]||"px")&&(b.style[c]=l,l=bv.css(b,c)),b4(b,l,h)
}}
}),bv.cssHooks.marginLeft=aN(bz.reliableMarginLeft,function(d,c){if(c){return(parseFloat(aV(d,"marginLeft"))||d.getBoundingClientRect().left-bi(d,{marginLeft:0},function(){return d.getBoundingClientRect().left
}))+"px"
}}),bv.each({margin:"",padding:"",border:"Width"},function(d,c){bv.cssHooks[d+c]={expand:function(h){for(var g=0,b={},a="string"==typeof h?h.split(" "):[h];
g<4;
g++){b[d+cj[g]+c]=a[g]||a[g-2]||a[0]
}return b
}},bk.test(d)||(bv.cssHooks[d+c].set=b4)
}),bv.fn.extend({css:function(d,c){return b2(this,function(i,h,n){var m,l,k={},j=0;
if(bv.isArray(h)){for(m=a4(i),l=h.length;
j<l;
j++){k[h[j]]=bv.css(i,h[j],!1,m)
}return k
}return void 0!==n?bv.style(i,h,n):bv.css(i,h)
},d,c,arguments.length>1)
}});
function a7(g,f,j,i,h){return new a7.prototype.init(g,f,j,i,h)
}bv.Tween=a7,a7.prototype={constructor:a7,init:function(h,g,l,k,j,i){this.elem=h,this.prop=l,this.easing=j||bv.easing._default,this.options=g,this.start=this.now=this.cur(),this.end=k,this.unit=i||(bv.cssNumber[l]?"":"px")
},cur:function(){var b=a7.propHooks[this.prop];
return b&&b.get?b.get(this):a7.propHooks._default.get(this)
},run:function(e){var d,f=a7.propHooks[this.prop];
return this.options.duration?this.pos=d=bv.easing[this.easing](e,this.options.duration*e,0,1,this.options.duration):this.pos=d=e,this.now=(this.end-this.start)*d+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),f&&f.set?f.set(this):a7.propHooks._default.set(this),this
}},a7.prototype.init.prototype=a7.prototype,a7.propHooks={_default:{get:function(d){var c;
return 1!==d.elem.nodeType||null!=d.elem[d.prop]&&null==d.elem.style[d.prop]?d.elem[d.prop]:(c=bv.css(d.elem,d.prop,""),c&&"auto"!==c?c:0)
},set:function(b){bv.fx.step[b.prop]?bv.fx.step[b.prop](b):1!==b.elem.nodeType||null==b.elem.style[bv.cssProps[b.prop]]&&!bv.cssHooks[b.prop]?b.elem[b.prop]=b.now:bv.style(b.elem,b.prop,b.now+b.unit)
}}},a7.propHooks.scrollTop=a7.propHooks.scrollLeft={set:function(b){b.elem.nodeType&&b.elem.parentNode&&(b.elem[b.prop]=b.now)
}},bv.easing={linear:function(b){return b
},swing:function(b){return 0.5-Math.cos(b*Math.PI)/2
},_default:"swing"},bv.fx=a7.prototype.init,bv.fx.step={};
var aY,cq,ai=/^(?:toggle|show|hide)$/,cz=/queueHooks$/;
function ch(){cq&&(bP.requestAnimationFrame(ch),bv.fx.tick())
}function bI(){return bP.setTimeout(function(){aY=void 0
}),aY=bv.now()
}function bh(g,f){var j,i=0,h={height:g};
for(f=f?1:0;
i<4;
i+=2-f){j=cj[i],h["margin"+j]=h["padding"+j]=g
}return f&&(h.opacity=h.width=g),h
}function a8(i,h,n){for(var m,l=(aK.tweeners[h]||[]).concat(aK.tweeners["*"]),k=0,j=l.length;
k<j;
k++){if(m=l[k].call(n,h,i)){return m
}}}function a1(H,G,F){var E,D,C,B,A,z,y,x,w="width" in G||"height" in G,v=this,u={},t=H.style,s=H.nodeType&&bK(H),r=bZ.get(H,"fxshow");
F.queue||(B=bv._queueHooks(H,"fx"),null==B.unqueued&&(B.unqueued=0,A=B.empty.fire,B.empty.fire=function(){B.unqueued||A()
}),B.unqueued++,v.always(function(){v.always(function(){B.unqueued--,bv.queue(H,"fx").length||B.empty.fire()
})
}));
for(E in G){if(D=G[E],ai.test(D)){if(delete G[E],C=C||"toggle"===D,D===(s?"hide":"show")){if("show"!==D||!r||void 0===r[E]){continue
}s=!0
}u[E]=r&&r[E]||bv.style(H,E)
}}if(z=!bv.isEmptyObject(G),z||!bv.isEmptyObject(u)){w&&1===H.nodeType&&(F.overflow=[t.overflow,t.overflowX,t.overflowY],y=r&&r.display,null==y&&(y=bZ.get(H,"display")),x=bv.css(H,"display"),"none"===x&&(y?x=y:(aL([H],!0),y=H.style.display||y,x=bv.css(H,"display"),aL([H]))),("inline"===x||"inline-block"===x&&null!=y)&&"none"===bv.css(H,"float")&&(z||(v.done(function(){t.display=y
}),null==y&&(x=t.display,y="none"===x?"":x)),t.display="inline-block")),F.overflow&&(t.overflow="hidden",v.always(function(){t.overflow=F.overflow[0],t.overflowX=F.overflow[1],t.overflowY=F.overflow[2]
})),z=!1;
for(E in u){z||(r?"hidden" in r&&(s=r.hidden):r=bZ.access(H,"fxshow",{display:y}),C&&(r.hidden=!s),s&&aL([H],!0),v.done(function(){s||aL([H]),bZ.remove(H,"fxshow");
for(E in u){bv.style(H,E,u[E])
}})),z=a8(s?r[E]:0,E,v),E in r||(r[E]=z.start,s&&(z.end=z.start,z.start=0))
}}}function aS(i,h){var n,m,l,k,j;
for(n in i){if(m=bv.camelCase(n),l=h[m],k=i[n],bv.isArray(k)&&(l=k[1],k=i[n]=k[0]),n!==m&&(i[m]=k,delete i[n]),j=bv.cssHooks[m],j&&"expand" in j){k=j.expand(k),delete i[m];
for(n in k){n in i||(i[n]=k[n],h[n]=l)
}}else{h[m]=l
}}}function aK(v,u,t){var s,r,q=0,p=aK.prefilters.length,o=bv.Deferred().always(function(){delete n.elem
}),n=function(){if(r){return !1
}for(var a=aY||bI(),w=Math.max(0,m.startTime+m.duration-a),k=w/m.duration||0,j=1-k,h=0,e=m.tweens.length;
h<e;
h++){m.tweens[h].run(j)
}return o.notifyWith(v,[m,j,w]),j<1&&e?w:(o.resolveWith(v,[m]),!1)
},m=o.promise({elem:v,props:bv.extend({},u),opts:bv.extend(!0,{specialEasing:{},easing:bv.easing._default},t),originalProperties:u,originalOptions:t,startTime:aY||bI(),duration:t.duration,tweens:[],createTween:function(a,f){var e=bv.Tween(v,m.opts,a,f,m.opts.specialEasing[a]||m.opts.easing);
return m.tweens.push(e),e
},stop:function(a){var f=0,e=a?m.tweens.length:0;
if(r){return this
}for(r=!0;
f<e;
f++){m.tweens[f].run(1)
}return a?(o.notifyWith(v,[m,1,0]),o.resolveWith(v,[m,a])):o.rejectWith(v,[m,a]),this
}}),l=m.props;
for(aS(l,m.opts.specialEasing);
q<p;
q++){if(s=aK.prefilters[q].call(m,v,l,m.opts)){return bv.isFunction(s.stop)&&(bv._queueHooks(m.elem,m.opts.queue).stop=bv.proxy(s.stop,s)),s
}}return bv.map(l,a8,m),bv.isFunction(m.opts.start)&&m.opts.start.call(v,m),bv.fx.timer(bv.extend(n,{elem:v,anim:m,queue:m.opts.queue})),m.progress(m.opts.progress).done(m.opts.done,m.opts.complete).fail(m.opts.fail).always(m.opts.always)
}bv.Animation=bv.extend(aK,{tweeners:{"*":[function(e,d){var f=this.createTween(e,d);
return a9(f.elem,e,cA.exec(d),f),f
}]},tweener:function(g,f){bv.isFunction(g)?(f=g,g=["*"]):g=g.match(cd);
for(var j,i=0,h=g.length;
i<h;
i++){j=g[i],aK.tweeners[j]=aK.tweeners[j]||[],aK.tweeners[j].unshift(f)
}},prefilters:[a1],prefilter:function(d,c){c?aK.prefilters.unshift(d):aK.prefilters.push(d)
}}),bv.speed=function(f,d,h){var g=f&&"object"==typeof f?bv.extend({},f):{complete:h||!h&&d||bv.isFunction(f)&&f,duration:f,easing:h&&d||d&&!bv.isFunction(d)&&d};
return bv.fx.off||bM.hidden?g.duration=0:"number"!=typeof g.duration&&(g.duration in bv.fx.speeds?g.duration=bv.fx.speeds[g.duration]:g.duration=bv.fx.speeds._default),null!=g.queue&&g.queue!==!0||(g.queue="fx"),g.old=g.complete,g.complete=function(){bv.isFunction(g.old)&&g.old.call(this),g.queue&&bv.dequeue(this,g.queue)
},g
},bv.fn.extend({fadeTo:function(f,e,h,g){return this.filter(bK).css("opacity",0).show().end().animate({opacity:e},f,h,g)
},animate:function(i,h,n,m){var l=bv.isEmptyObject(i),k=bv.speed(h,n,m),j=function(){var a=aK(this,bv.extend({},i),k);
(l||bZ.get(this,"finish"))&&a.stop(!0)
};
return j.finish=j,l||k.queue===!1?this.each(j):this.queue(k.queue,j)
},stop:function(f,e,h){var g=function(d){var c=d.stop;
delete d.stop,c(h)
};
return"string"!=typeof f&&(h=e,e=f,f=void 0),e&&f!==!1&&this.queue(f||"fx",[]),this.each(function(){var a=!0,i=null!=f&&f+"queueHooks",d=bv.timers,c=bZ.get(this);
if(i){c[i]&&c[i].stop&&g(c[i])
}else{for(i in c){c[i]&&c[i].stop&&cz.test(i)&&g(c[i])
}}for(i=d.length;
i--;
){d[i].elem!==this||null!=f&&d[i].queue!==f||(d[i].anim.stop(h),a=!1,d.splice(i,1))
}!a&&h||bv.dequeue(this,f)
})
},finish:function(b){return b!==!1&&(b=b||"fx"),this.each(function(){var a,l=bZ.get(this),k=l[b+"queue"],j=l[b+"queueHooks"],i=bv.timers,h=k?k.length:0;
for(l.finish=!0,bv.queue(this,b,[]),j&&j.stop&&j.stop.call(this,!0),a=i.length;
a--;
){i[a].elem===this&&i[a].queue===b&&(i[a].anim.stop(!0),i.splice(a,1))
}for(a=0;
a<h;
a++){k[a]&&k[a].finish&&k[a].finish.call(this)
}delete l.finish
})
}}),bv.each(["toggle","show","hide"],function(e,d){var f=bv.fn[d];
bv.fn[d]=function(b,g,c){return null==b||"boolean"==typeof b?f.apply(this,arguments):this.animate(bh(d,!0),b,g,c)
}
}),bv.each({slideDown:bh("show"),slideUp:bh("hide"),slideToggle:bh("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(d,c){bv.fn[d]=function(b,f,e){return this.animate(c,b,f,e)
}
}),bv.timers=[],bv.fx.tick=function(){var e,d=0,f=bv.timers;
for(aY=bv.now();
d<f.length;
d++){e=f[d],e()||f[d]!==e||f.splice(d--,1)
}f.length||bv.fx.stop(),aY=void 0
},bv.fx.timer=function(b){bv.timers.push(b),b()?bv.fx.start():bv.timers.pop()
},bv.fx.interval=13,bv.fx.start=function(){cq||(cq=bP.requestAnimationFrame?bP.requestAnimationFrame(ch):bP.setInterval(bv.fx.tick,bv.fx.interval))
},bv.fx.stop=function(){bP.cancelAnimationFrame?bP.cancelAnimationFrame(cq):bP.clearInterval(cq),cq=null
},bv.fx.speeds={slow:600,fast:200,_default:400},bv.fn.delay=function(a,d){return a=bv.fx?bv.fx.speeds[a]||a:a,d=d||"fx",this.queue(d,function(g,f){var b=bP.setTimeout(g,a);
f.stop=function(){bP.clearTimeout(b)
}
})
},function(){var e=bM.createElement("input"),d=bM.createElement("select"),f=d.appendChild(bM.createElement("option"));
e.type="checkbox",bz.checkOn=""!==e.value,bz.optSelected=f.selected,e=bM.createElement("input"),e.value="t",e.type="radio",bz.radioValue="t"===e.value
}();
var aC,au=bv.expr.attrHandle;
bv.fn.extend({attr:function(d,c){return b2(this,bv.attr,d,c,arguments.length>1)
},removeAttr:function(b){return this.each(function(){bv.removeAttr(this,b)
})
}}),bv.extend({attr:function(h,g,l){var k,j,i=h.nodeType;
if(3!==i&&8!==i&&2!==i){return"undefined"==typeof h.getAttribute?bv.prop(h,g,l):(1===i&&bv.isXMLDoc(h)||(j=bv.attrHooks[g.toLowerCase()]||(bv.expr.match.bool.test(g)?aC:void 0)),void 0!==l?null===l?void bv.removeAttr(h,g):j&&"set" in j&&void 0!==(k=j.set(h,l,g))?k:(h.setAttribute(g,l+""),l):j&&"get" in j&&null!==(k=j.get(h,g))?k:(k=bv.find.attr(h,g),null==k?void 0:k))
}},attrHooks:{type:{set:function(e,d){if(!bz.radioValue&&"radio"===d&&bv.nodeName(e,"input")){var f=e.value;
return e.setAttribute("type",d),f&&(e.value=f),d
}}}},removeAttr:function(g,f){var j,i=0,h=f&&f.match(cd);
if(h&&1===g.nodeType){while(j=h[i++]){g.removeAttribute(j)
}}}}),aC={set:function(e,d,f){return d===!1?bv.removeAttr(e,f):e.setAttribute(f,f),f
}},bv.each(bv.expr.match.bool.source.match(/\w+/g),function(e,d){var f=au[d]||bv.find.attr;
au[d]=function(h,c,l){var k,j,i=c.toLowerCase();
return l||(j=au[i],au[i]=k,k=null!=f(h,c,l)?i:null,au[i]=j),k
}
});
var al=/^(?:input|select|textarea|button)$/i,ac=/^(?:a|area)$/i;
bv.fn.extend({prop:function(d,c){return b2(this,bv.prop,d,c,arguments.length>1)
},removeProp:function(b){return this.each(function(){delete this[bv.propFix[b]||b]
})
}}),bv.extend({prop:function(h,g,l){var k,j,i=h.nodeType;
if(3!==i&&8!==i&&2!==i){return 1===i&&bv.isXMLDoc(h)||(g=bv.propFix[g]||g,j=bv.propHooks[g]),void 0!==l?j&&"set" in j&&void 0!==(k=j.set(h,l,g))?k:h[g]=l:j&&"get" in j&&null!==(k=j.get(h,g))?k:h[g]
}},propHooks:{tabIndex:{get:function(d){var c=bv.find.attr(d,"tabindex");
return c?parseInt(c,10):al.test(d.nodeName)||ac.test(d.nodeName)&&d.href?0:-1
}}},propFix:{"for":"htmlFor","class":"className"}}),bz.optSelected||(bv.propHooks.selected={get:function(d){var c=d.parentNode;
return c&&c.parentNode&&c.parentNode.selectedIndex,null
},set:function(d){var c=d.parentNode;
c&&(c.selectedIndex,c.parentNode&&c.parentNode.selectedIndex)
}}),bv.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){bv.propFix[this.toLowerCase()]=this
});
function cE(d){var c=d.match(cd)||[];
return c.join(" ")
}function ct(b){return b.getAttribute&&b.getAttribute("class")||""
}bv.fn.extend({addClass:function(r){var q,p,o,n,m,l,k,j=0;
if(bv.isFunction(r)){return this.each(function(a){bv(this).addClass(r.call(this,a,ct(this)))
})
}if("string"==typeof r&&r){q=r.match(cd)||[];
while(p=this[j++]){if(n=ct(p),o=1===p.nodeType&&" "+cE(n)+" "){l=0;
while(m=q[l++]){o.indexOf(" "+m+" ")<0&&(o+=m+" ")
}k=cE(o),n!==k&&p.setAttribute("class",k)
}}}return this
},removeClass:function(r){var q,p,o,n,m,l,k,j=0;
if(bv.isFunction(r)){return this.each(function(a){bv(this).removeClass(r.call(this,a,ct(this)))
})
}if(!arguments.length){return this.attr("class","")
}if("string"==typeof r&&r){q=r.match(cd)||[];
while(p=this[j++]){if(n=ct(p),o=1===p.nodeType&&" "+cE(n)+" "){l=0;
while(m=q[l++]){while(o.indexOf(" "+m+" ")>-1){o=o.replace(" "+m+" "," ")
}}k=cE(o),n!==k&&p.setAttribute("class",k)
}}}return this
},toggleClass:function(e,d){var f=typeof e;
return"boolean"==typeof d&&"string"===f?d?this.addClass(e):this.removeClass(e):bv.isFunction(e)?this.each(function(a){bv(this).toggleClass(e.call(this,a,ct(this),d),d)
}):this.each(function(){var a,h,g,c;
if("string"===f){h=0,g=bv(this),c=e.match(cd)||[];
while(a=c[h++]){g.hasClass(a)?g.removeClass(a):g.addClass(a)
}}else{void 0!==e&&"boolean"!==f||(a=ct(this),a&&bZ.set(this,"__className__",a),this.setAttribute&&this.setAttribute("class",a||e===!1?"":bZ.get(this,"__className__")||""))
}})
},hasClass:function(f){var e,h,g=0;
e=" "+f+" ";
while(h=this[g++]){if(1===h.nodeType&&(" "+cE(ct(h))+" ").indexOf(e)>-1){return !0
}}return !1
}});
var bT=/\r/g;
bv.fn.extend({val:function(g){var f,j,i,h=this[0];
if(arguments.length){return i=bv.isFunction(g),this.each(function(b){var a;
1===this.nodeType&&(a=i?g.call(this,b,bv(this).val()):g,null==a?a="":"number"==typeof a?a+="":bv.isArray(a)&&(a=bv.map(a,function(c){return null==c?"":c+""
})),f=bv.valHooks[this.type]||bv.valHooks[this.nodeName.toLowerCase()],f&&"set" in f&&void 0!==f.set(this,a,"value")||(this.value=a))
})
}if(h){return f=bv.valHooks[h.type]||bv.valHooks[h.nodeName.toLowerCase()],f&&"get" in f&&void 0!==(j=f.get(h,"value"))?j:(j=h.value,"string"==typeof j?j.replace(bT,""):null==j?"":j)
}}}),bv.extend({valHooks:{option:{get:function(d){var c=bv.find.attr(d,"value");
return null!=c?c:cE(bv.text(d))
}},select:{get:function(r){var q,p,o,n=r.options,m=r.selectedIndex,l="select-one"===r.type,k=l?null:[],j=l?m+1:n.length;
for(o=m<0?j:l?m:0;
o<j;
o++){if(p=n[o],(p.selected||o===m)&&!p.disabled&&(!p.parentNode.disabled||!bv.nodeName(p.parentNode,"optgroup"))){if(q=bv(p).val(),l){return q
}k.push(q)
}}return k
},set:function(i,h){var n,m,l=i.options,k=bv.makeArray(h),j=l.length;
while(j--){m=l[j],(m.selected=bv.inArray(bv.valHooks.option.get(m),k)>-1)&&(n=!0)
}return n||(i.selectedIndex=-1),k
}}}}),bv.each(["radio","checkbox"],function(){bv.valHooks[this]={set:function(d,c){if(bv.isArray(c)){return d.checked=bv.inArray(bv(d).val(),c)>-1
}}},bz.checkOn||(bv.valHooks[this].get=function(b){return null===b.getAttribute("value")?"on":b.value
})
});
var bl=/^(?:focusinfocus|focusoutblur)$/;
bv.extend(bv.event,{trigger:function(B,A,z,y){var x,w,v,u,t,s,r,l=[z||bM],d=bC.call(B,"type")?B.type:B,a=bC.call(B,"namespace")?B.namespace.split("."):[];
if(w=v=z=z||bM,3!==z.nodeType&&8!==z.nodeType&&!bl.test(d+bv.event.triggered)&&(d.indexOf(".")>-1&&(a=d.split("."),d=a.shift(),a.sort()),t=d.indexOf(":")<0&&"on"+d,B=B[bv.expando]?B:new bv.Event(d,"object"==typeof B&&B),B.isTrigger=y?2:3,B.namespace=a.join("."),B.rnamespace=B.namespace?new RegExp("(^|\\.)"+a.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,B.result=void 0,B.target||(B.target=z),A=null==A?[B]:bv.makeArray(A,[B]),r=bv.event.special[d]||{},y||!r.trigger||r.trigger.apply(z,A)!==!1)){if(!y&&!r.noBubble&&!bv.isWindow(z)){for(u=r.delegateType||d,bl.test(u+d)||(w=w.parentNode);
w;
w=w.parentNode){l.push(w),v=w
}v===(z.ownerDocument||bM)&&l.push(v.defaultView||v.parentWindow||bP)
}x=0;
while((w=l[x++])&&!B.isPropagationStopped()){B.type=x>1?u:r.bindType||d,s=(bZ.get(w,"events")||{})[B.type]&&bZ.get(w,"handle"),s&&s.apply(w,A),s=t&&w[t],s&&s.apply&&b1(w)&&(B.result=s.apply(w,A),B.result===!1&&B.preventDefault())
}return B.type=d,y||B.isDefaultPrevented()||r._default&&r._default.apply(l.pop(),A)!==!1||!b1(z)||t&&bv.isFunction(z[d])&&!bv.isWindow(z)&&(v=z[t],v&&(z[t]=null),bv.event.triggered=d,z[d](),bv.event.triggered=void 0,v&&(z[t]=v)),B.result
}},simulate:function(f,e,h){var g=bv.extend(new bv.Event,h,{type:f,isSimulated:!0});
bv.event.trigger(g,null,e)
}}),bv.fn.extend({trigger:function(d,c){return this.each(function(){bv.event.trigger(d,c,this)
})
},triggerHandler:function(e,d){var f=this[0];
if(f){return bv.event.trigger(e,d,f,!0)
}}}),bv.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "),function(d,c){bv.fn[c]=function(b,e){return arguments.length>0?this.on(c,null,b,e):this.trigger(c)
}
}),bv.fn.extend({hover:function(d,c){return this.mouseenter(d).mouseleave(c||d)
}}),bz.focusin="onfocusin" in bP,bz.focusin||bv.each({focus:"focusin",blur:"focusout"},function(e,d){var f=function(b){bv.event.simulate(d,b.target,bv.event.fix(b))
};
bv.event.special[d]={setup:function(){var b=this.ownerDocument||this,a=bZ.access(b,d);
a||b.addEventListener(e,f,!0),bZ.access(b,d,(a||0)+1)
},teardown:function(){var b=this.ownerDocument||this,a=bZ.access(b,d)-1;
a?bZ.access(b,d,a):(b.removeEventListener(e,f,!0),bZ.remove(b,d))
}}
});
var be=bP.location,a5=bv.now(),aW=/\?/;
bv.parseXML=function(a){var f;
if(!a||"string"!=typeof a){return null
}try{f=(new bP.DOMParser).parseFromString(a,"text/xml")
}catch(e){f=void 0
}return f&&!f.getElementsByTagName("parsererror").length||bv.error("Invalid XML: "+a),f
};
var aO=/\[\]$/,aG=/\r?\n/g,ay=/^(?:submit|button|image|reset|file)$/i,ap=/^(?:input|select|textarea|keygen)/i;
function ag(g,f,j,i){var h;
if(bv.isArray(f)){bv.each(f,function(a,c){j||aO.test(g)?i(g,c):ag(g+"["+("object"==typeof c&&null!=c?a:"")+"]",c,j,i)
})
}else{if(j||"object"!==bv.type(f)){i(g,f)
}else{for(h in f){ag(g+"["+h+"]",f[h],j,i)
}}}}bv.param=function(g,f){var j,i=[],h=function(e,d){var k=bv.isFunction(d)?d():d;
i[i.length]=encodeURIComponent(e)+"="+encodeURIComponent(null==k?"":k)
};
if(bv.isArray(g)||g.jquery&&!bv.isPlainObject(g)){bv.each(g,function(){h(this.name,this.value)
})
}else{for(j in g){ag(j,g[j],f,h)
}}return i.join("&")
},bv.fn.extend({serialize:function(){return bv.param(this.serializeArray())
},serializeArray:function(){return this.map(function(){var b=bv.prop(this,"elements");
return b?bv.makeArray(b):this
}).filter(function(){var b=this.type;
return this.name&&!bv(this).is(":disabled")&&ap.test(this.nodeName)&&!ay.test(b)&&(this.checked||!aD.test(b))
}).map(function(e,d){var f=bv(this).val();
return null==f?null:bv.isArray(f)?bv.map(f,function(b){return{name:d.name,value:b.replace(aG,"\r\n")}
}):{name:d.name,value:f.replace(aG,"\r\n")}
}).get()
}});
var cI=/%20/g,cx=/#.*$/,aZ=/([?&])_=[^&]*/,aQ=/^(.*?):[ \t]*([^\r\n]*)$/gm,aI=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,aA=/^(?:GET|HEAD)$/,ar=/^\/\//,aj={},cK={},cC="*/".concat("*"),cr=bM.createElement("a");
cr.href=be.href;
function bR(b){return function(a,j){"string"!=typeof a&&(j=a,a="*");
var i,h=0,g=a.toLowerCase().match(cd)||[];
if(bv.isFunction(j)){while(i=g[h++]){"+"===i[0]?(i=i.slice(1)||"*",(b[i]=b[i]||[]).unshift(j)):(b[i]=b[i]||[]).push(j)
}}}
}function bj(i,h,n,m){var l={},k=i===cK;
function j(b){var a;
return l[b]=!0,bv.each(i[b]||[],function(c,e){var d=e(h,n,m);
return"string"!=typeof d||k||l[d]?k?!(a=d):void 0:(h.dataTypes.unshift(d),j(d),!1)
}),a
}return j(h.dataTypes[0])||!l["*"]&&j("*")
}function bc(g,f){var j,i,h=bv.ajaxSettings.flatOptions||{};
for(j in f){void 0!==f[j]&&((h[j]?g:i||(i={}))[j]=f[j])
}return i&&bv.extend(!0,g,i),g
}function a3(r,q,p){var o,n,m,l,k=r.contents,j=r.dataTypes;
while("*"===j[0]){j.shift(),void 0===o&&(o=r.mimeType||q.getResponseHeader("Content-Type"))
}if(o){for(n in k){if(k[n]&&k[n].test(o)){j.unshift(n);
break
}}}if(j[0] in p){m=j[0]
}else{for(n in p){if(!j[0]||r.converters[n+" "+j[0]]){m=n;
break
}l||(l=n)
}m=m||l
}if(m){return m!==j[0]&&j.unshift(m),p[m]
}}function aU(x,w,v,u){var t,s,r,q,p,o={},n=x.dataTypes.slice();
if(n[1]){for(r in x.converters){o[r.toLowerCase()]=x.converters[r]
}}s=n.shift();
while(s){if(x.responseFields[s]&&(v[x.responseFields[s]]=w),!p&&u&&x.dataFilter&&(w=x.dataFilter(w,x.dataType)),p=s,s=n.shift()){if("*"===s){s=p
}else{if("*"!==p&&p!==s){if(r=o[p+" "+s]||o["* "+s],!r){for(t in o){if(q=t.split(" "),q[1]===s&&(r=o[p+" "+q[0]]||o["* "+q[0]])){r===!0?r=o[t]:o[t]!==!0&&(s=q[0],n.unshift(q[1]));
break
}}}if(r!==!0){if(r&&x["throws"]){w=r(w)
}else{try{w=r(w)
}catch(m){return{state:"parsererror",error:r?m:"No conversion from "+p+" to "+s}
}}}}}}}return{state:"success",data:w}
}bv.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:be.href,type:"GET",isLocal:aI.test(be.protocol),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":cC,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/\bxml\b/,html:/\bhtml/,json:/\bjson\b/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":JSON.parse,"text xml":bv.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(d,c){return c?bc(bc(d,bv.ajaxSettings),c):bc(bv.ajaxSettings,d)
},ajaxPrefilter:bR(aj),ajaxTransport:bR(cK),ajax:function(V,U){"object"==typeof V&&(U=V,V=void 0),U=U||{};
var T,S,R,Q,P,O,N,M,L,K,J=bv.ajaxSetup({},U),I=J.context||J,G=J.context&&(I.nodeType||I.jquery)?bv(I):bv.event,F=bv.Deferred(),E=bv.Callbacks("once memory"),D=J.statusCode||{},C={},B={},r="canceled",d={readyState:0,getResponseHeader:function(e){var c;
if(N){if(!Q){Q={};
while(c=aQ.exec(R)){Q[c[1].toLowerCase()]=c[2]
}}c=Q[e.toLowerCase()]
}return null==c?null:c
},getAllResponseHeaders:function(){return N?R:null
},setRequestHeader:function(e,c){return null==N&&(e=B[e.toLowerCase()]=B[e.toLowerCase()]||e,C[e]=c),this
},overrideMimeType:function(b){return null==N&&(J.mimeType=b),this
},statusCode:function(e){var c;
if(e){if(N){d.always(e[d.status])
}else{for(c in e){D[c]=[D[c],e[c]]
}}}return this
},abort:function(e){var c=e||r;
return T&&T.abort(c),H(0,c),this
}};
if(F.promise(d),J.url=((V||J.url||be.href)+"").replace(ar,be.protocol+"//"),J.type=U.method||U.type||J.method||J.type,J.dataTypes=(J.dataType||"*").toLowerCase().match(cd)||[""],null==J.crossDomain){O=bM.createElement("a");
try{O.href=J.url,O.href=O.href,J.crossDomain=cr.protocol+"//"+cr.host!=O.protocol+"//"+O.host
}catch(a){J.crossDomain=!0
}}if(J.data&&J.processData&&"string"!=typeof J.data&&(J.data=bv.param(J.data,J.traditional)),bj(aj,J,U,d),N){return d
}M=bv.event&&J.global,M&&0===bv.active++&&bv.event.trigger("ajaxStart"),J.type=J.type.toUpperCase(),J.hasContent=!aA.test(J.type),S=J.url.replace(cx,""),J.hasContent?J.data&&J.processData&&0===(J.contentType||"").indexOf("application/x-www-form-urlencoded")&&(J.data=J.data.replace(cI,"+")):(K=J.url.slice(S.length),J.data&&(S+=(aW.test(S)?"&":"?")+J.data,delete J.data),J.cache===!1&&(S=S.replace(aZ,"$1"),K=(aW.test(S)?"&":"?")+"_="+a5+++K),J.url=S+K),J.ifModified&&(bv.lastModified[S]&&d.setRequestHeader("If-Modified-Since",bv.lastModified[S]),bv.etag[S]&&d.setRequestHeader("If-None-Match",bv.etag[S])),(J.data&&J.hasContent&&J.contentType!==!1||U.contentType)&&d.setRequestHeader("Content-Type",J.contentType),d.setRequestHeader("Accept",J.dataTypes[0]&&J.accepts[J.dataTypes[0]]?J.accepts[J.dataTypes[0]]+("*"!==J.dataTypes[0]?", "+cC+"; q=0.01":""):J.accepts["*"]);
for(L in J.headers){d.setRequestHeader(L,J.headers[L])
}if(J.beforeSend&&(J.beforeSend.call(I,d,J)===!1||N)){return d.abort()
}if(r="abort",E.add(J.complete),d.done(J.success),d.fail(J.error),T=bj(cK,J,U,d)){if(d.readyState=1,M&&G.trigger("ajaxSend",[d,J]),N){return d
}J.async&&J.timeout>0&&(P=bP.setTimeout(function(){d.abort("timeout")
},J.timeout));
try{N=!1,T.send(C,H)
}catch(a){if(N){throw a
}H(-1,a)
}}else{H(-1,"No Transport")
}function H(o,l,k,i){var g,f,e,s,q,p=l;
N||(N=!0,P&&bP.clearTimeout(P),T=void 0,R=i||"",d.readyState=o>0?4:0,g=o>=200&&o<300||304===o,k&&(s=a3(J,d,k)),s=aU(J,s,d,g),g?(J.ifModified&&(q=d.getResponseHeader("Last-Modified"),q&&(bv.lastModified[S]=q),q=d.getResponseHeader("etag"),q&&(bv.etag[S]=q)),204===o||"HEAD"===J.type?p="nocontent":304===o?p="notmodified":(p=s.state,f=s.data,e=s.error,g=!e)):(e=p,!o&&p||(p="error",o<0&&(o=0))),d.status=o,d.statusText=(l||p)+"",g?F.resolveWith(I,[f,p,d]):F.rejectWith(I,[d,p,e]),d.statusCode(D),D=void 0,M&&G.trigger(g?"ajaxSuccess":"ajaxError",[d,J,g?f:e]),E.fireWith(I,[d,p]),M&&(G.trigger("ajaxComplete",[d,J]),--bv.active||bv.event.trigger("ajaxStop")))
}return d
},getJSON:function(e,d,f){return bv.get(e,d,f,"json")
},getScript:function(d,c){return bv.get(d,void 0,c,"script")
}}),bv.each(["get","post"],function(d,c){bv[c]=function(b,h,g,f){return bv.isFunction(h)&&(f=f||g,g=h,h=void 0),bv.ajax(bv.extend({url:b,type:c,dataType:f,data:h,success:g},bv.isPlainObject(b)&&b))
}
}),bv._evalUrl=function(b){return bv.ajax({url:b,type:"GET",dataType:"script",cache:!0,async:!1,global:!1,"throws":!0})
},bv.fn.extend({wrapAll:function(d){var c;
return this[0]&&(bv.isFunction(d)&&(d=d.call(this[0])),c=bv(d,this[0].ownerDocument).eq(0).clone(!0),this[0].parentNode&&c.insertBefore(this[0]),c.map(function(){var b=this;
while(b.firstElementChild){b=b.firstElementChild
}return b
}).append(this)),this
},wrapInner:function(b){return bv.isFunction(b)?this.each(function(a){bv(this).wrapInner(b.call(this,a))
}):this.each(function(){var a=bv(this),d=a.contents();
d.length?d.wrapAll(b):a.append(b)
})
},wrap:function(d){var c=bv.isFunction(d);
return this.each(function(a){bv(this).wrapAll(c?d.call(this,a):d)
})
},unwrap:function(b){return this.parent(b).not("body").each(function(){bv(this).replaceWith(this.childNodes)
}),this
}}),bv.expr.pseudos.hidden=function(b){return !bv.expr.pseudos.visible(b)
},bv.expr.pseudos.visible=function(b){return !!(b.offsetWidth||b.offsetHeight||b.getClientRects().length)
},bv.ajaxSettings.xhr=function(){try{return new bP.XMLHttpRequest
}catch(a){}};
var aM={0:200,1223:204},aE=bv.ajaxSettings.xhr();
bz.cors=!!aE&&"withCredentials" in aE,bz.ajax=aE=!!aE,bv.ajaxTransport(function(a){var f,e;
if(bz.cors||aE&&!a.crossDomain){return{send:function(k,j){var d,c=a.xhr();
if(c.open(a.type,a.url,a.async,a.username,a.password),a.xhrFields){for(d in a.xhrFields){c[d]=a.xhrFields[d]
}}a.mimeType&&c.overrideMimeType&&c.overrideMimeType(a.mimeType),a.crossDomain||k["X-Requested-With"]||(k["X-Requested-With"]="XMLHttpRequest");
for(d in k){c.setRequestHeader(d,k[d])
}f=function(g){return function(){f&&(f=e=c.onload=c.onerror=c.onabort=c.onreadystatechange=null,"abort"===g?c.abort():"error"===g?"number"!=typeof c.status?j(0,"error"):j(c.status,c.statusText):j(aM[c.status]||c.status,c.statusText,"text"!==(c.responseType||"text")||"string"!=typeof c.responseText?{binary:c.response}:{text:c.responseText},c.getAllResponseHeaders()))
}
},c.onload=f(),e=c.onerror=f("error"),void 0!==c.onabort?c.onabort=e:c.onreadystatechange=function(){4===c.readyState&&bP.setTimeout(function(){f&&e()
})
},f=f("abort");
try{c.send(a.hasContent&&a.data||null)
}catch(b){if(f){throw b
}}},abort:function(){f&&f()
}}
}}),bv.ajaxPrefilter(function(b){b.crossDomain&&(b.contents.script=!1)
}),bv.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/\b(?:java|ecma)script\b/},converters:{"text script":function(b){return bv.globalEval(b),b
}}}),bv.ajaxPrefilter("script",function(b){void 0===b.cache&&(b.cache=!1),b.crossDomain&&(b.type="GET")
}),bv.ajaxTransport("script",function(e){if(e.crossDomain){var d,f;
return{send:function(b,a){d=bv("<script>").prop({charset:e.scriptCharset,src:e.url}).on("load error",f=function(c){d.remove(),f=null,c&&a("error"===c.type?404:200,c.type)
}),bM.head.appendChild(d[0])
},abort:function(){f&&f()
}}
}});
var aw=[],an=/(=)\?(?=&|$)|\?\?/;
bv.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var b=aw.pop()||bv.expando+"_"+a5++;
return this[b]=!0,b
}}),bv.ajaxPrefilter("json jsonp",function(a,n,m){var l,k,j,i=a.jsonp!==!1&&(an.test(a.url)?"url":"string"==typeof a.data&&0===(a.contentType||"").indexOf("application/x-www-form-urlencoded")&&an.test(a.data)&&"data");
if(i||"jsonp"===a.dataTypes[0]){return l=a.jsonpCallback=bv.isFunction(a.jsonpCallback)?a.jsonpCallback():a.jsonpCallback,i?a[i]=a[i].replace(an,"$1"+l):a.jsonp!==!1&&(a.url+=(aW.test(a.url)?"&":"?")+a.jsonp+"="+l),a.converters["script json"]=function(){return j||bv.error(l+" was not called"),j[0]
},a.dataTypes[0]="json",k=bP[l],bP[l]=function(){j=arguments
},m.always(function(){void 0===k?bv(bP).removeProp(l):bP[l]=k,a[l]&&(a.jsonpCallback=n.jsonpCallback,aw.push(l)),j&&bv.isFunction(k)&&k(j[0]),j=k=void 0
}),"script"
}}),bz.createHTMLDocument=function(){var b=bM.implementation.createHTMLDocument("").body;
return b.innerHTML="<form></form><form></form>",2===b.childNodes.length
}(),bv.parseHTML=function(h,d,l){if("string"!=typeof h){return[]
}"boolean"==typeof d&&(l=d,d=!1);
var k,j,i;
return d||(bz.createHTMLDocument?(d=bM.implementation.createHTMLDocument(""),k=d.createElement("base"),k.href=bM.location.href,d.head.appendChild(k)):d=bM),j=co.exec(h),i=!l&&[],j?[d.createElement(j[1])]:(j=bn([h],d,i),i&&i.length&&bv(i).remove(),bv.merge([],j.childNodes))
},bv.fn.load=function(j,i,p){var o,n,m,l=this,k=j.indexOf(" ");
return k>-1&&(o=cE(j.slice(k)),j=j.slice(0,k)),bv.isFunction(i)?(p=i,i=void 0):i&&"object"==typeof i&&(n="POST"),l.length>0&&bv.ajax({url:j,type:n||"GET",dataType:"html",data:i}).done(function(b){m=arguments,l.html(o?bv("<div>").append(bv.parseHTML(b)).find(o):b)
}).always(p&&function(d,c){l.each(function(){p.apply(this,m||[d.responseText,c,d])
})
}),this
},bv.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(d,c){bv.fn[c]=function(b){return this.on(c,b)
}
}),bv.expr.pseudos.animated=function(b){return bv.grep(bv.timers,function(a){return b===a.elem
}).length
};
function ae(b){return bv.isWindow(b)?b:9===b.nodeType&&b.defaultView
}bv.offset={setOffset:function(z,y,x){var w,v,u,t,s,r,q,p=bv.css(z,"position"),o=bv(z),n={};
"static"===p&&(z.style.position="relative"),s=o.offset(),u=bv.css(z,"top"),r=bv.css(z,"left"),q=("absolute"===p||"fixed"===p)&&(u+r).indexOf("auto")>-1,q?(w=o.position(),t=w.top,v=w.left):(t=parseFloat(u)||0,v=parseFloat(r)||0),bv.isFunction(y)&&(y=y.call(z,x,bv.extend({},s))),null!=y.top&&(n.top=y.top-s.top+t),null!=y.left&&(n.left=y.left-s.left+v),"using" in y?y.using.call(z,n):o.css(n)
}},bv.fn.extend({offset:function(h){if(arguments.length){return void 0===h?this:this.each(function(a){bv.offset.setOffset(this,h,a)
})
}var g,l,k,j,i=this[0];
if(i){return i.getClientRects().length?(k=i.getBoundingClientRect(),k.width||k.height?(j=i.ownerDocument,l=ae(j),g=j.documentElement,{top:k.top+l.pageYOffset-g.clientTop,left:k.left+l.pageXOffset-g.clientLeft}):k):{top:0,left:0}
}},position:function(){if(this[0]){var f,e,h=this[0],g={top:0,left:0};
return"fixed"===bv.css(h,"position")?e=h.getBoundingClientRect():(f=this.offsetParent(),e=this.offset(),bv.nodeName(f[0],"html")||(g=f.offset()),g={top:g.top+bv.css(f[0],"borderTopWidth",!0),left:g.left+bv.css(f[0],"borderLeftWidth",!0)}),{top:e.top-g.top-bv.css(h,"marginTop",!0),left:e.left-g.left-bv.css(h,"marginLeft",!0)}
}},offsetParent:function(){return this.map(function(){var b=this.offsetParent;
while(b&&"static"===bv.css(b,"position")){b=b.offsetParent
}return b||bf
})
}}),bv.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(e,d){var f="pageYOffset"===d;
bv.fn[e]=function(a){return b2(this,function(b,h,g){var c=ae(b);
return void 0===g?c?c[d]:b[h]:void (c?c.scrollTo(f?c.pageXOffset:g,f?g:c.pageYOffset):b[h]=g)
},e,a,arguments.length)
}
}),bv.each(["top","left"],function(d,c){bv.cssHooks[c]=aN(bz.pixelPosition,function(b,e){if(e){return e=aV(b,c),bd.test(e)?bv(b).position()[c]+"px":e
}})
}),bv.each({Height:"height",Width:"width"},function(d,c){bv.each({padding:"inner"+d,content:c,"":"outer"+d},function(b,a){bv.fn[a]=function(l,k){var j=arguments.length&&(b||"boolean"!=typeof l),i=b||(l===!0||k===!0?"margin":"border");
return b2(this,function(g,n,m){var h;
return bv.isWindow(g)?0===a.indexOf("outer")?g["inner"+d]:g.document.documentElement["client"+d]:9===g.nodeType?(h=g.documentElement,Math.max(g.body["scroll"+d],h["scroll"+d],g.body["offset"+d],h["offset"+d],h["client"+d])):void 0===m?bv.css(g,n,i):bv.style(g,n,m,i)
},c,j?l:void 0,j)
}
})
}),bv.fn.extend({bind:function(e,d,f){return this.on(e,null,d,f)
},unbind:function(d,c){return this.off(d,null,c)
},delegate:function(f,e,h,g){return this.on(e,f,h,g)
},undelegate:function(e,d,f){return 1===arguments.length?this.off(e,"**"):this.off(d,e||"**",f)
}}),bv.parseJSON=JSON.parse,"function"==typeof define&&define.amd&&define("jquery",[],function(){return bv
});
var cG=bP.jQuery,cv=bP.$;
return bv.noConflict=function(a){return bP.$===bv&&(bP.$=cv),a&&bP.jQuery===bv&&(bP.jQuery=cG),bv
},bO||(bP.jQuery=bP.$=bv),bv
});
/*! jQuery UI - v1.11.4 - 2015-11-04
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.js, position.js, draggable.js, droppable.js, resizable.js, button.js, dialog.js, slider.js
* Copyright jQuery Foundation and other contributors; Licensed MIT */
(function(a){if(typeof define==="function"&&define.amd){define(["jquery"],a)
}else{a(jQuery)
}}(function(f){
/*!
 * jQuery UI Core 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/category/ui-core/
 */
f.ui=f.ui||{};
f.extend(f.ui,{version:"1.11.4",keyCode:{BACKSPACE:8,COMMA:188,DELETE:46,DOWN:40,END:35,ENTER:13,ESCAPE:27,HOME:36,LEFT:37,PAGE_DOWN:34,PAGE_UP:33,PERIOD:190,RIGHT:39,SPACE:32,TAB:9,UP:38}});
f.fn.extend({scrollParent:function(w){var v=this.css("position"),u=v==="absolute",x=w?/(auto|scroll|hidden)/:/(auto|scroll)/,y=this.parents().filter(function(){var z=f(this);
if(u&&z.css("position")==="static"){return false
}return x.test(z.css("overflow")+z.css("overflow-y")+z.css("overflow-x"))
}).eq(0);
return v==="fixed"||!y.length?f(this[0].ownerDocument||document):y
},uniqueId:(function(){var u=0;
return function(){return this.each(function(){if(!this.id){this.id="ui-id-"+(++u)
}})
}
})(),removeUniqueId:function(){return this.each(function(){if(/^ui-id-\d+$/.test(this.id)){f(this).removeAttr("id")
}})
}});
function o(w,u){var y,x,v,z=w.nodeName.toLowerCase();
if("area"===z){y=w.parentNode;
x=y.name;
if(!w.href||!x||y.nodeName.toLowerCase()!=="map"){return false
}v=f("img[usemap='#"+x+"']")[0];
return !!v&&c(v)
}return(/^(input|select|textarea|button|object)$/.test(z)?!w.disabled:"a"===z?w.href||u:u)&&c(w)
}function c(u){return f.expr.filters.visible(u)&&!f(u).parents().addBack().filter(function(){return f.css(this,"visibility")==="hidden"
}).length
}f.extend(f.expr[":"],{data:f.expr.createPseudo?f.expr.createPseudo(function(u){return function(v){return !!f.data(v,u)
}
}):function(w,v,u){return !!f.data(w,u[3])
},focusable:function(u){return o(u,!isNaN(f.attr(u,"tabindex")))
},tabbable:function(w){var u=f.attr(w,"tabindex"),v=isNaN(u);
return(v||u>=0)&&o(w,!v)
}});
if(!f("<a>").outerWidth(1).jquery){f.each(["Width","Height"],function(w,u){var v=u==="Width"?["Left","Right"]:["Top","Bottom"],x=u.toLowerCase(),z={innerWidth:f.fn.innerWidth,innerHeight:f.fn.innerHeight,outerWidth:f.fn.outerWidth,outerHeight:f.fn.outerHeight};
function y(C,B,A,D){f.each(v,function(){B-=parseFloat(f.css(C,"padding"+this))||0;
if(A){B-=parseFloat(f.css(C,"border"+this+"Width"))||0
}if(D){B-=parseFloat(f.css(C,"margin"+this))||0
}});
return B
}f.fn["inner"+u]=function(A){if(A===undefined){return z["inner"+u].call(this)
}return this.each(function(){f(this).css(x,y(this,A)+"px")
})
};
f.fn["outer"+u]=function(A,B){if(typeof A!=="number"){return z["outer"+u].call(this,A)
}return this.each(function(){f(this).css(x,y(this,A,true,B)+"px")
})
}
})
}if(!f.fn.addBack){f.fn.addBack=function(u){return this.add(u==null?this.prevObject:this.prevObject.filter(u))
}
}if(f("<a>").data("a-b","a").removeData("a-b").data("a-b")){f.fn.removeData=(function(u){return function(v){if(arguments.length){return u.call(this,f.camelCase(v))
}else{return u.call(this)
}}
})(f.fn.removeData)
}f.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase());
f.fn.extend({focus:(function(u){return function(v,w){return typeof v==="number"?this.each(function(){var x=this;
setTimeout(function(){f(x).focus();
if(w){w.call(x)
}},v)
}):u.apply(this,arguments)
}
})(f.fn.focus),disableSelection:(function(){var u="onselectstart" in document.createElement("div")?"selectstart":"mousedown";
return function(){return this.bind(u+".ui-disableSelection",function(v){v.preventDefault()
})
}
})(),enableSelection:function(){return this.unbind(".ui-disableSelection")
},zIndex:function(x){if(x!==undefined){return this.css("zIndex",x)
}if(this.length){var v=f(this[0]),u,w;
while(v.length&&v[0]!==document){u=v.css("position");
if(u==="absolute"||u==="relative"||u==="fixed"){w=parseInt(v.css("zIndex"),10);
if(!isNaN(w)&&w!==0){return w
}}v=v.parent()
}}return 0
}});
f.ui.plugin={add:function(v,w,y){var u,x=f.ui[v].prototype;
for(u in y){x.plugins[u]=x.plugins[u]||[];
x.plugins[u].push([w,y[u]])
}},call:function(u,x,w,v){var y,z=u.plugins[x];
if(!z){return
}if(!v&&(!u.element[0].parentNode||u.element[0].parentNode.nodeType===11)){return
}for(y=0;
y<z.length;
y++){if(u.options[z[y][0]]){z[y][1].apply(u.element,w)
}}}};
/*!
 * jQuery UI Widget 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/jQuery.widget/
 */
var i=0,p=Array.prototype.slice;
f.cleanData=(function(u){return function(v){var x,y,w;
for(w=0;
(y=v[w])!=null;
w++){try{x=f._data(y,"events");
if(x&&x.remove){f(y).triggerHandler("remove")
}}catch(z){}}u(v)
}
})(f.cleanData);
f.widget=function(u,v,C){var z,A,x,B,w={},y=u.split(".")[0];
u=u.split(".")[1];
z=y+"-"+u;
if(!C){C=v;
v=f.Widget
}f.expr[":"][z.toLowerCase()]=function(D){return !!f.data(D,z)
};
f[y]=f[y]||{};
A=f[y][u];
x=f[y][u]=function(D,E){if(!this._createWidget){return new x(D,E)
}if(arguments.length){this._createWidget(D,E)
}};
f.extend(x,A,{version:C.version,_proto:f.extend({},C),_childConstructors:[]});
B=new v();
B.options=f.widget.extend({},B.options);
f.each(C,function(E,D){if(!f.isFunction(D)){w[E]=D;
return
}w[E]=(function(){var F=function(){return v.prototype[E].apply(this,arguments)
},G=function(H){return v.prototype[E].apply(this,H)
};
return function(){var J=this._super,H=this._superApply,I;
this._super=F;
this._superApply=G;
I=D.apply(this,arguments);
this._super=J;
this._superApply=H;
return I
}
})()
});
x.prototype=f.widget.extend(B,{widgetEventPrefix:A?(B.widgetEventPrefix||u):u},w,{constructor:x,namespace:y,widgetName:u,widgetFullName:z});
if(A){f.each(A._childConstructors,function(E,F){var D=F.prototype;
f.widget(D.namespace+"."+D.widgetName,x,F._proto)
});
delete A._childConstructors
}else{v._childConstructors.push(x)
}f.widget.bridge(u,x);
return x
};
f.widget.extend=function(z){var v=p.call(arguments,1),y=0,u=v.length,w,x;
for(;
y<u;
y++){for(w in v[y]){x=v[y][w];
if(v[y].hasOwnProperty(w)&&x!==undefined){if(f.isPlainObject(x)){z[w]=f.isPlainObject(z[w])?f.widget.extend({},z[w],x):f.widget.extend({},x)
}else{z[w]=x
}}}}return z
};
f.widget.bridge=function(v,u){var w=u.prototype.widgetFullName||v;
f.fn[v]=function(z){var x=typeof z==="string",y=p.call(arguments,1),A=this;
if(x){this.each(function(){var C,B=f.data(this,w);
if(z==="instance"){A=B;
return false
}if(!B){return f.error("cannot call methods on "+v+" prior to initialization; attempted to call method '"+z+"'")
}if(!f.isFunction(B[z])||z.charAt(0)==="_"){return f.error("no such method '"+z+"' for "+v+" widget instance")
}C=B[z].apply(B,y);
if(C!==B&&C!==undefined){A=C&&C.jquery?A.pushStack(C.get()):C;
return false
}})
}else{if(y.length){z=f.widget.extend.apply(null,[z].concat(y))
}this.each(function(){var B=f.data(this,w);
if(B){B.option(z||{});
if(B._init){B._init()
}}else{f.data(this,w,new u(z,this))
}})
}return A
}
};
f.Widget=function(){};
f.Widget._childConstructors=[];
f.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{disabled:false,create:null},_createWidget:function(u,v){v=f(v||this.defaultElement||this)[0];
this.element=f(v);
this.uuid=i++;
this.eventNamespace="."+this.widgetName+this.uuid;
this.bindings=f();
this.hoverable=f();
this.focusable=f();
if(v!==this){f.data(v,this.widgetFullName,this);
this._on(true,this.element,{remove:function(w){if(w.target===v){this.destroy()
}}});
this.document=f(v.style?v.ownerDocument:v.document||v);
this.window=f(this.document[0].defaultView||this.document[0].parentWindow)
}this.options=f.widget.extend({},this.options,this._getCreateOptions(),u);
this._create();
this._trigger("create",null,this._getCreateEventData());
this._init()
},_getCreateOptions:f.noop,_getCreateEventData:f.noop,_create:f.noop,_init:f.noop,destroy:function(){this._destroy();
this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(f.camelCase(this.widgetFullName));
this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName+"-disabled ui-state-disabled");
this.bindings.unbind(this.eventNamespace);
this.hoverable.removeClass("ui-state-hover");
this.focusable.removeClass("ui-state-focus")
},_destroy:f.noop,widget:function(){return this.element
},option:function(x,y){var u=x,z,w,v;
if(arguments.length===0){return f.widget.extend({},this.options)
}if(typeof x==="string"){u={};
z=x.split(".");
x=z.shift();
if(z.length){w=u[x]=f.widget.extend({},this.options[x]);
for(v=0;
v<z.length-1;
v++){w[z[v]]=w[z[v]]||{};
w=w[z[v]]
}x=z.pop();
if(arguments.length===1){return w[x]===undefined?null:w[x]
}w[x]=y
}else{if(arguments.length===1){return this.options[x]===undefined?null:this.options[x]
}u[x]=y
}}this._setOptions(u);
return this
},_setOptions:function(u){var v;
for(v in u){this._setOption(v,u[v])
}return this
},_setOption:function(u,v){this.options[u]=v;
if(u==="disabled"){this.widget().toggleClass(this.widgetFullName+"-disabled",!!v);
if(v){this.hoverable.removeClass("ui-state-hover");
this.focusable.removeClass("ui-state-focus")
}}return this
},enable:function(){return this._setOptions({disabled:false})
},disable:function(){return this._setOptions({disabled:true})
},_on:function(x,w,v){var y,u=this;
if(typeof x!=="boolean"){v=w;
w=x;
x=false
}if(!v){v=w;
w=this.element;
y=this.widget()
}else{w=y=f(w);
this.bindings=this.bindings.add(w)
}f.each(v,function(E,D){function B(){if(!x&&(u.options.disabled===true||f(this).hasClass("ui-state-disabled"))){return
}return(typeof D==="string"?u[D]:D).apply(u,arguments)
}if(typeof D!=="string"){B.guid=D.guid=D.guid||B.guid||f.guid++
}var C=E.match(/^([\w:-]*)\s*(.*)$/),A=C[1]+u.eventNamespace,z=C[2];
if(z){y.delegate(z,A,B)
}else{w.bind(A,B)
}})
},_off:function(v,u){u=(u||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace;
v.unbind(u).undelegate(u);
this.bindings=f(this.bindings.not(v).get());
this.focusable=f(this.focusable.not(v).get());
this.hoverable=f(this.hoverable.not(v).get())
},_delay:function(x,w){function v(){return(typeof x==="string"?u[x]:x).apply(u,arguments)
}var u=this;
return setTimeout(v,w||0)
},_hoverable:function(u){this.hoverable=this.hoverable.add(u);
this._on(u,{mouseenter:function(v){f(v.currentTarget).addClass("ui-state-hover")
},mouseleave:function(v){f(v.currentTarget).removeClass("ui-state-hover")
}})
},_focusable:function(u){this.focusable=this.focusable.add(u);
this._on(u,{focusin:function(v){f(v.currentTarget).addClass("ui-state-focus")
},focusout:function(v){f(v.currentTarget).removeClass("ui-state-focus")
}})
},_trigger:function(u,v,w){var z,y,x=this.options[u];
w=w||{};
v=f.Event(v);
v.type=(u===this.widgetEventPrefix?u:this.widgetEventPrefix+u).toLowerCase();
v.target=this.element[0];
y=v.originalEvent;
if(y){for(z in y){if(!(z in v)){v[z]=y[z]
}}}this.element.trigger(v,w);
return !(f.isFunction(x)&&x.apply(this.element[0],[v].concat(w))===false||v.isDefaultPrevented())
}};
f.each({show:"fadeIn",hide:"fadeOut"},function(v,u){f.Widget.prototype["_"+v]=function(y,x,A){if(typeof x==="string"){x={effect:x}
}var z,w=!x?v:x===true||typeof x==="number"?u:x.effect||u;
x=x||{};
if(typeof x==="number"){x={duration:x}
}z=!f.isEmptyObject(x);
x.complete=A;
if(x.delay){y.delay(x.delay)
}if(z&&f.effects&&f.effects.effect[w]){y[v](x)
}else{if(w!==v&&y[w]){y[w](x.duration,x.easing,A)
}else{y.queue(function(B){f(this)[v]();
if(A){A.call(y[0])
}B()
})
}}}
});
var e=f.widget;
/*!
 * jQuery UI Mouse 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/mouse/
 */
var m=false;
f(document).mouseup(function(){m=false
});
var k=f.widget("ui.mouse",{version:"1.11.4",options:{cancel:"input,textarea,button,select,option",distance:1,delay:0},_mouseInit:function(){var u=this;
this.element.bind("mousedown."+this.widgetName,function(v){return u._mouseDown(v)
}).bind("click."+this.widgetName,function(v){if(true===f.data(v.target,u.widgetName+".preventClickEvent")){f.removeData(v.target,u.widgetName+".preventClickEvent");
v.stopImmediatePropagation();
return false
}});
this.started=false
},_mouseDestroy:function(){this.element.unbind("."+this.widgetName);
if(this._mouseMoveDelegate){this.document.unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate)
}},_mouseDown:function(w){if(m){return
}this._mouseMoved=false;
(this._mouseStarted&&this._mouseUp(w));
this._mouseDownEvent=w;
var v=this,x=(w.which===1),u=(typeof this.options.cancel==="string"&&w.target.nodeName?f(w.target).closest(this.options.cancel).length:false);
if(!x||u||!this._mouseCapture(w)){return true
}this.mouseDelayMet=!this.options.delay;
if(!this.mouseDelayMet){this._mouseDelayTimer=setTimeout(function(){v.mouseDelayMet=true
},this.options.delay)
}if(this._mouseDistanceMet(w)&&this._mouseDelayMet(w)){this._mouseStarted=(this._mouseStart(w)!==false);
if(!this._mouseStarted){w.preventDefault();
return true
}}if(true===f.data(w.target,this.widgetName+".preventClickEvent")){f.removeData(w.target,this.widgetName+".preventClickEvent")
}this._mouseMoveDelegate=function(y){return v._mouseMove(y)
};
this._mouseUpDelegate=function(y){return v._mouseUp(y)
};
this.document.bind("mousemove."+this.widgetName,this._mouseMoveDelegate).bind("mouseup."+this.widgetName,this._mouseUpDelegate);
w.preventDefault();
m=true;
return true
},_mouseMove:function(u){if(this._mouseMoved){if(f.ui.ie&&(!document.documentMode||document.documentMode<9)&&!u.button){return this._mouseUp(u)
}else{if(!u.which){return this._mouseUp(u)
}}}if(u.which||u.button){this._mouseMoved=true
}if(this._mouseStarted){this._mouseDrag(u);
return u.preventDefault()
}if(this._mouseDistanceMet(u)&&this._mouseDelayMet(u)){this._mouseStarted=(this._mouseStart(this._mouseDownEvent,u)!==false);
(this._mouseStarted?this._mouseDrag(u):this._mouseUp(u))
}return !this._mouseStarted
},_mouseUp:function(u){this.document.unbind("mousemove."+this.widgetName,this._mouseMoveDelegate).unbind("mouseup."+this.widgetName,this._mouseUpDelegate);
if(this._mouseStarted){this._mouseStarted=false;
if(u.target===this._mouseDownEvent.target){f.data(u.target,this.widgetName+".preventClickEvent",true)
}this._mouseStop(u)
}m=false;
return false
},_mouseDistanceMet:function(u){return(Math.max(Math.abs(this._mouseDownEvent.pageX-u.pageX),Math.abs(this._mouseDownEvent.pageY-u.pageY))>=this.options.distance)
},_mouseDelayMet:function(){return this.mouseDelayMet
},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return true
}});
/*!
 * jQuery UI Position 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/position/
 */
(function(){f.ui=f.ui||{};
var B,E,C=Math.max,H=Math.abs,F=Math.round,w=/left|center|right/,z=/top|center|bottom/,u=/[\+\-]\d+(\.[\d]+)?%?/,D=/^\w+/,v=/%$/,y=f.fn.position;
function G(K,J,I){return[parseFloat(K[0])*(v.test(K[0])?J/100:1),parseFloat(K[1])*(v.test(K[1])?I/100:1)]
}function A(I,J){return parseInt(f.css(I,J),10)||0
}function x(J){var I=J[0];
if(I.nodeType===9){return{width:J.width(),height:J.height(),offset:{top:0,left:0}}
}if(f.isWindow(I)){return{width:J.width(),height:J.height(),offset:{top:J.scrollTop(),left:J.scrollLeft()}}
}if(I.preventDefault){return{width:0,height:0,offset:{top:I.pageY,left:I.pageX}}
}return{width:J.outerWidth(),height:J.outerHeight(),offset:J.offset()}
}f.position={scrollbarWidth:function(){if(B!==undefined){return B
}var J,I,L=f("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),K=L.children()[0];
f("body").append(L);
J=K.offsetWidth;
L.css("overflow","scroll");
I=K.offsetWidth;
if(J===I){I=L[0].clientWidth
}L.remove();
return(B=J-I)
},getScrollInfo:function(M){var L=M.isWindow||M.isDocument?"":M.element.css("overflow-x"),K=M.isWindow||M.isDocument?"":M.element.css("overflow-y"),J=L==="scroll"||(L==="auto"&&M.width<M.element[0].scrollWidth),I=K==="scroll"||(K==="auto"&&M.height<M.element[0].scrollHeight);
return{width:I?f.position.scrollbarWidth():0,height:J?f.position.scrollbarWidth():0}
},getWithinInfo:function(J){var K=f(J||window),I=f.isWindow(K[0]),L=!!K[0]&&K[0].nodeType===9;
return{element:K,isWindow:I,isDocument:L,offset:K.offset()||{left:0,top:0},scrollLeft:K.scrollLeft(),scrollTop:K.scrollTop(),width:I||L?K.width():K.outerWidth(),height:I||L?K.height():K.outerHeight()}
}};
f.fn.position=function(S){if(!S||!S.of){return y.apply(this,arguments)
}S=f.extend({},S);
var T,P,N,R,M,I,O=f(S.of),L=f.position.getWithinInfo(S.within),J=f.position.getScrollInfo(L),Q=(S.collision||"flip").split(" "),K={};
I=x(O);
if(O[0].preventDefault){S.at="left top"
}P=I.width;
N=I.height;
R=I.offset;
M=f.extend({},R);
f.each(["my","at"],function(){var W=(S[this]||"").split(" "),V,U;
if(W.length===1){W=w.test(W[0])?W.concat(["center"]):z.test(W[0])?["center"].concat(W):["center","center"]
}W[0]=w.test(W[0])?W[0]:"center";
W[1]=z.test(W[1])?W[1]:"center";
V=u.exec(W[0]);
U=u.exec(W[1]);
K[this]=[V?V[0]:0,U?U[0]:0];
S[this]=[D.exec(W[0])[0],D.exec(W[1])[0]]
});
if(Q.length===1){Q[1]=Q[0]
}if(S.at[0]==="right"){M.left+=P
}else{if(S.at[0]==="center"){M.left+=P/2
}}if(S.at[1]==="bottom"){M.top+=N
}else{if(S.at[1]==="center"){M.top+=N/2
}}T=G(K.at,P,N);
M.left+=T[0];
M.top+=T[1];
return this.each(function(){var V,ae,X=f(this),Z=X.outerWidth(),W=X.outerHeight(),Y=A(this,"marginLeft"),U=A(this,"marginTop"),ad=Z+Y+A(this,"marginRight")+J.width,ac=W+U+A(this,"marginBottom")+J.height,aa=f.extend({},M),ab=G(K.my,X.outerWidth(),X.outerHeight());
if(S.my[0]==="right"){aa.left-=Z
}else{if(S.my[0]==="center"){aa.left-=Z/2
}}if(S.my[1]==="bottom"){aa.top-=W
}else{if(S.my[1]==="center"){aa.top-=W/2
}}aa.left+=ab[0];
aa.top+=ab[1];
if(!E){aa.left=F(aa.left);
aa.top=F(aa.top)
}V={marginLeft:Y,marginTop:U};
f.each(["left","top"],function(ag,af){if(f.ui.position[Q[ag]]){f.ui.position[Q[ag]][af](aa,{targetWidth:P,targetHeight:N,elemWidth:Z,elemHeight:W,collisionPosition:V,collisionWidth:ad,collisionHeight:ac,offset:[T[0]+ab[0],T[1]+ab[1]],my:S.my,at:S.at,within:L,elem:X})
}});
if(S.using){ae=function(ai){var ak=R.left-aa.left,ah=ak+P-Z,aj=R.top-aa.top,ag=aj+N-W,af={target:{element:O,left:R.left,top:R.top,width:P,height:N},element:{element:X,left:aa.left,top:aa.top,width:Z,height:W},horizontal:ah<0?"left":ak>0?"right":"center",vertical:ag<0?"top":aj>0?"bottom":"middle"};
if(P<Z&&H(ak+ah)<P){af.horizontal="center"
}if(N<W&&H(aj+ag)<N){af.vertical="middle"
}if(C(H(ak),H(ah))>C(H(aj),H(ag))){af.important="horizontal"
}else{af.important="vertical"
}S.using.call(this,ai,af)
}
}X.offset(f.extend(aa,{using:ae}))
})
};
f.ui.position={fit:{left:function(M,L){var K=L.within,O=K.isWindow?K.scrollLeft:K.offset.left,Q=K.width,N=M.left-L.collisionPosition.marginLeft,P=O-N,J=N+L.collisionWidth-Q-O,I;
if(L.collisionWidth>Q){if(P>0&&J<=0){I=M.left+P+L.collisionWidth-Q-O;
M.left+=P-I
}else{if(J>0&&P<=0){M.left=O
}else{if(P>J){M.left=O+Q-L.collisionWidth
}else{M.left=O
}}}}else{if(P>0){M.left+=P
}else{if(J>0){M.left-=J
}else{M.left=C(M.left-N,M.left)
}}}},top:function(L,K){var J=K.within,P=J.isWindow?J.scrollTop:J.offset.top,Q=K.within.height,N=L.top-K.collisionPosition.marginTop,O=P-N,M=N+K.collisionHeight-Q-P,I;
if(K.collisionHeight>Q){if(O>0&&M<=0){I=L.top+O+K.collisionHeight-Q-P;
L.top+=O-I
}else{if(M>0&&O<=0){L.top=P
}else{if(O>M){L.top=P+Q-K.collisionHeight
}else{L.top=P
}}}}else{if(O>0){L.top+=O
}else{if(M>0){L.top-=M
}else{L.top=C(L.top-N,L.top)
}}}}},flip:{left:function(O,N){var M=N.within,S=M.offset.left+M.scrollLeft,V=M.width,K=M.isWindow?M.scrollLeft:M.offset.left,P=O.left-N.collisionPosition.marginLeft,T=P-K,J=P+N.collisionWidth-V-K,R=N.my[0]==="left"?-N.elemWidth:N.my[0]==="right"?N.elemWidth:0,U=N.at[0]==="left"?N.targetWidth:N.at[0]==="right"?-N.targetWidth:0,L=-2*N.offset[0],I,Q;
if(T<0){I=O.left+R+U+L+N.collisionWidth-V-S;
if(I<0||I<H(T)){O.left+=R+U+L
}}else{if(J>0){Q=O.left-N.collisionPosition.marginLeft+R+U+L-K;
if(Q>0||H(Q)<J){O.left+=R+U+L
}}}},top:function(N,M){var L=M.within,U=L.offset.top+L.scrollTop,V=L.height,I=L.isWindow?L.scrollTop:L.offset.top,P=N.top-M.collisionPosition.marginTop,R=P-I,O=P+M.collisionHeight-V-I,S=M.my[1]==="top",Q=S?-M.elemHeight:M.my[1]==="bottom"?M.elemHeight:0,W=M.at[1]==="top"?M.targetHeight:M.at[1]==="bottom"?-M.targetHeight:0,K=-2*M.offset[1],T,J;
if(R<0){J=N.top+Q+W+K+M.collisionHeight-V-U;
if(J<0||J<H(R)){N.top+=Q+W+K
}}else{if(O>0){T=N.top-M.collisionPosition.marginTop+Q+W+K-I;
if(T>0||H(T)<O){N.top+=Q+W+K
}}}}},flipfit:{left:function(){f.ui.position.flip.left.apply(this,arguments);
f.ui.position.fit.left.apply(this,arguments)
},top:function(){f.ui.position.flip.top.apply(this,arguments);
f.ui.position.fit.top.apply(this,arguments)
}}};
(function(){var M,O,J,L,K,I=document.getElementsByTagName("body")[0],N=document.createElement("div");
M=document.createElement(I?"div":"body");
J={visibility:"hidden",width:0,height:0,border:0,margin:0,background:"none"};
if(I){f.extend(J,{position:"absolute",left:"-1000px",top:"-1000px"})
}for(K in J){M.style[K]=J[K]
}M.appendChild(N);
O=I||document.documentElement;
O.insertBefore(M,O.firstChild);
N.style.cssText="position: absolute; left: 10.7432222px;";
L=f(N).offset().left;
E=L>10&&L<11;
M.innerHTML="";
O.removeChild(M)
})()
})();
var s=f.ui.position;
/*!
 * jQuery UI Draggable 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/draggable/
 */
f.widget("ui.draggable",f.ui.mouse,{version:"1.11.4",widgetEventPrefix:"drag",options:{addClasses:true,appendTo:"parent",axis:false,connectToSortable:false,containment:false,cursor:"auto",cursorAt:false,grid:false,handle:false,helper:"original",iframeFix:false,opacity:false,refreshPositions:false,revert:false,revertDuration:500,scope:"default",scroll:true,scrollSensitivity:20,scrollSpeed:20,snap:false,snapMode:"both",snapTolerance:20,stack:false,zIndex:false,drag:null,start:null,stop:null},_create:function(){if(this.options.helper==="original"){this._setPositionRelative()
}if(this.options.addClasses){this.element.addClass("ui-draggable")
}if(this.options.disabled){this.element.addClass("ui-draggable-disabled")
}this._setHandleClassName();
this._mouseInit()
},_setOption:function(u,v){this._super(u,v);
if(u==="handle"){this._removeHandleClassName();
this._setHandleClassName()
}},_destroy:function(){if((this.helper||this.element).is(".ui-draggable-dragging")){this.destroyOnClear=true;
return
}this.element.removeClass("ui-draggable ui-draggable-dragging ui-draggable-disabled");
this._removeHandleClassName();
this._mouseDestroy()
},_mouseCapture:function(u){var v=this.options;
this._blurActiveElement(u);
if(this.helper||v.disabled||f(u.target).closest(".ui-resizable-handle").length>0){return false
}this.handle=this._getHandle(u);
if(!this.handle){return false
}this._blockFrames(v.iframeFix===true?"iframe":v.iframeFix);
return true
},_blockFrames:function(u){this.iframeBlocks=this.document.find(u).map(function(){var v=f(this);
return f("<div>").css("position","absolute").appendTo(v.parent()).outerWidth(v.outerWidth()).outerHeight(v.outerHeight()).offset(v.offset())[0]
})
},_unblockFrames:function(){if(this.iframeBlocks){this.iframeBlocks.remove();
delete this.iframeBlocks
}},_blurActiveElement:function(w){var u=this.document[0];
if(!this.handleElement.is(w.target)){return
}try{if(u.activeElement&&u.activeElement.nodeName.toLowerCase()!=="body"){f(u.activeElement).blur()
}}catch(v){}},_mouseStart:function(u){var v=this.options;
this.helper=this._createHelper(u);
this.helper.addClass("ui-draggable-dragging");
this._cacheHelperProportions();
if(f.ui.ddmanager){f.ui.ddmanager.current=this
}this._cacheMargins();
this.cssPosition=this.helper.css("position");
this.scrollParent=this.helper.scrollParent(true);
this.offsetParent=this.helper.offsetParent();
this.hasFixedAncestor=this.helper.parents().filter(function(){return f(this).css("position")==="fixed"
}).length>0;
this.positionAbs=this.element.offset();
this._refreshOffsets(u);
this.originalPosition=this.position=this._generatePosition(u,false);
this.originalPageX=u.pageX;
this.originalPageY=u.pageY;
(v.cursorAt&&this._adjustOffsetFromHelper(v.cursorAt));
this._setContainment();
if(this._trigger("start",u)===false){this._clear();
return false
}this._cacheHelperProportions();
if(f.ui.ddmanager&&!v.dropBehaviour){f.ui.ddmanager.prepareOffsets(this,u)
}this._normalizeRightBottom();
this._mouseDrag(u,true);
if(f.ui.ddmanager){f.ui.ddmanager.dragStart(this,u)
}return true
},_refreshOffsets:function(u){this.offset={top:this.positionAbs.top-this.margins.top,left:this.positionAbs.left-this.margins.left,scroll:false,parent:this._getParentOffset(),relative:this._getRelativeOffset()};
this.offset.click={left:u.pageX-this.offset.left,top:u.pageY-this.offset.top}
},_mouseDrag:function(u,w){if(this.hasFixedAncestor){this.offset.parent=this._getParentOffset()
}this.position=this._generatePosition(u,true);
this.positionAbs=this._convertPositionTo("absolute");
if(!w){var v=this._uiHash();
if(this._trigger("drag",u,v)===false){this._mouseUp({});
return false
}this.position=v.position
}this.helper[0].style.left=this.position.left+"px";
this.helper[0].style.top=this.position.top+"px";
if(f.ui.ddmanager){f.ui.ddmanager.drag(this,u)
}return false
},_mouseStop:function(v){var u=this,w=false;
if(f.ui.ddmanager&&!this.options.dropBehaviour){w=f.ui.ddmanager.drop(this,v)
}if(this.dropped){w=this.dropped;
this.dropped=false
}if((this.options.revert==="invalid"&&!w)||(this.options.revert==="valid"&&w)||this.options.revert===true||(f.isFunction(this.options.revert)&&this.options.revert.call(this.element,w))){f(this.helper).animate(this.originalPosition,parseInt(this.options.revertDuration,10),function(){if(u._trigger("stop",v)!==false){u._clear()
}})
}else{if(this._trigger("stop",v)!==false){this._clear()
}}return false
},_mouseUp:function(u){this._unblockFrames();
if(f.ui.ddmanager){f.ui.ddmanager.dragStop(this,u)
}if(this.handleElement.is(u.target)){this.element.focus()
}return f.ui.mouse.prototype._mouseUp.call(this,u)
},cancel:function(){if(this.helper.is(".ui-draggable-dragging")){this._mouseUp({})
}else{this._clear()
}return this
},_getHandle:function(u){return this.options.handle?!!f(u.target).closest(this.element.find(this.options.handle)).length:true
},_setHandleClassName:function(){this.handleElement=this.options.handle?this.element.find(this.options.handle):this.element;
this.handleElement.addClass("ui-draggable-handle")
},_removeHandleClassName:function(){this.handleElement.removeClass("ui-draggable-handle")
},_createHelper:function(v){var x=this.options,w=f.isFunction(x.helper),u=w?f(x.helper.apply(this.element[0],[v])):(x.helper==="clone"?this.element.clone().removeAttr("id"):this.element);
if(!u.parents("body").length){u.appendTo((x.appendTo==="parent"?this.element[0].parentNode:x.appendTo))
}if(w&&u[0]===this.element[0]){this._setPositionRelative()
}if(u[0]!==this.element[0]&&!(/(fixed|absolute)/).test(u.css("position"))){u.css("position","absolute")
}return u
},_setPositionRelative:function(){if(!(/^(?:r|a|f)/).test(this.element.css("position"))){this.element[0].style.position="relative"
}},_adjustOffsetFromHelper:function(u){if(typeof u==="string"){u=u.split(" ")
}if(f.isArray(u)){u={left:+u[0],top:+u[1]||0}
}if("left" in u){this.offset.click.left=u.left+this.margins.left
}if("right" in u){this.offset.click.left=this.helperProportions.width-u.right+this.margins.left
}if("top" in u){this.offset.click.top=u.top+this.margins.top
}if("bottom" in u){this.offset.click.top=this.helperProportions.height-u.bottom+this.margins.top
}},_isRootNode:function(u){return(/(html|body)/i).test(u.tagName)||u===this.document[0]
},_getParentOffset:function(){var v=this.offsetParent.offset(),u=this.document[0];
if(this.cssPosition==="absolute"&&this.scrollParent[0]!==u&&f.contains(this.scrollParent[0],this.offsetParent[0])){v.left+=this.scrollParent.scrollLeft();
v.top+=this.scrollParent.scrollTop()
}if(this._isRootNode(this.offsetParent[0])){v={top:0,left:0}
}return{top:v.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:v.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}
},_getRelativeOffset:function(){if(this.cssPosition!=="relative"){return{top:0,left:0}
}var u=this.element.position(),v=this._isRootNode(this.scrollParent[0]);
return{top:u.top-(parseInt(this.helper.css("top"),10)||0)+(!v?this.scrollParent.scrollTop():0),left:u.left-(parseInt(this.helper.css("left"),10)||0)+(!v?this.scrollParent.scrollLeft():0)}
},_cacheMargins:function(){this.margins={left:(parseInt(this.element.css("marginLeft"),10)||0),top:(parseInt(this.element.css("marginTop"),10)||0),right:(parseInt(this.element.css("marginRight"),10)||0),bottom:(parseInt(this.element.css("marginBottom"),10)||0)}
},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}
},_setContainment:function(){var v,y,w,x=this.options,u=this.document[0];
this.relativeContainer=null;
if(!x.containment){this.containment=null;
return
}if(x.containment==="window"){this.containment=[f(window).scrollLeft()-this.offset.relative.left-this.offset.parent.left,f(window).scrollTop()-this.offset.relative.top-this.offset.parent.top,f(window).scrollLeft()+f(window).width()-this.helperProportions.width-this.margins.left,f(window).scrollTop()+(f(window).height()||u.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top];
return
}if(x.containment==="document"){this.containment=[0,0,f(u).width()-this.helperProportions.width-this.margins.left,(f(u).height()||u.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top];
return
}if(x.containment.constructor===Array){this.containment=x.containment;
return
}if(x.containment==="parent"){x.containment=this.helper[0].parentNode
}y=f(x.containment);
w=y[0];
if(!w){return
}v=/(scroll|auto)/.test(y.css("overflow"));
this.containment=[(parseInt(y.css("borderLeftWidth"),10)||0)+(parseInt(y.css("paddingLeft"),10)||0),(parseInt(y.css("borderTopWidth"),10)||0)+(parseInt(y.css("paddingTop"),10)||0),(v?Math.max(w.scrollWidth,w.offsetWidth):w.offsetWidth)-(parseInt(y.css("borderRightWidth"),10)||0)-(parseInt(y.css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left-this.margins.right,(v?Math.max(w.scrollHeight,w.offsetHeight):w.offsetHeight)-(parseInt(y.css("borderBottomWidth"),10)||0)-(parseInt(y.css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top-this.margins.bottom];
this.relativeContainer=y
},_convertPositionTo:function(v,x){if(!x){x=this.position
}var u=v==="absolute"?1:-1,w=this._isRootNode(this.scrollParent[0]);
return{top:(x.top+this.offset.relative.top*u+this.offset.parent.top*u-((this.cssPosition==="fixed"?-this.offset.scroll.top:(w?0:this.offset.scroll.top))*u)),left:(x.left+this.offset.relative.left*u+this.offset.parent.left*u-((this.cssPosition==="fixed"?-this.offset.scroll.left:(w?0:this.offset.scroll.left))*u))}
},_generatePosition:function(v,B){var u,C,D,x,w=this.options,A=this._isRootNode(this.scrollParent[0]),z=v.pageX,y=v.pageY;
if(!A||!this.offset.scroll){this.offset.scroll={top:this.scrollParent.scrollTop(),left:this.scrollParent.scrollLeft()}
}if(B){if(this.containment){if(this.relativeContainer){C=this.relativeContainer.offset();
u=[this.containment[0]+C.left,this.containment[1]+C.top,this.containment[2]+C.left,this.containment[3]+C.top]
}else{u=this.containment
}if(v.pageX-this.offset.click.left<u[0]){z=u[0]+this.offset.click.left
}if(v.pageY-this.offset.click.top<u[1]){y=u[1]+this.offset.click.top
}if(v.pageX-this.offset.click.left>u[2]){z=u[2]+this.offset.click.left
}if(v.pageY-this.offset.click.top>u[3]){y=u[3]+this.offset.click.top
}}if(w.grid){D=w.grid[1]?this.originalPageY+Math.round((y-this.originalPageY)/w.grid[1])*w.grid[1]:this.originalPageY;
y=u?((D-this.offset.click.top>=u[1]||D-this.offset.click.top>u[3])?D:((D-this.offset.click.top>=u[1])?D-w.grid[1]:D+w.grid[1])):D;
x=w.grid[0]?this.originalPageX+Math.round((z-this.originalPageX)/w.grid[0])*w.grid[0]:this.originalPageX;
z=u?((x-this.offset.click.left>=u[0]||x-this.offset.click.left>u[2])?x:((x-this.offset.click.left>=u[0])?x-w.grid[0]:x+w.grid[0])):x
}if(w.axis==="y"){z=this.originalPageX
}if(w.axis==="x"){y=this.originalPageY
}}return{top:(y-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+(this.cssPosition==="fixed"?-this.offset.scroll.top:(A?0:this.offset.scroll.top))),left:(z-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+(this.cssPosition==="fixed"?-this.offset.scroll.left:(A?0:this.offset.scroll.left)))}
},_clear:function(){this.helper.removeClass("ui-draggable-dragging");
if(this.helper[0]!==this.element[0]&&!this.cancelHelperRemoval){this.helper.remove()
}this.helper=null;
this.cancelHelperRemoval=false;
if(this.destroyOnClear){this.destroy()
}},_normalizeRightBottom:function(){if(this.options.axis!=="y"&&this.helper.css("right")!=="auto"){this.helper.width(this.helper.width());
this.helper.css("right","auto")
}if(this.options.axis!=="x"&&this.helper.css("bottom")!=="auto"){this.helper.height(this.helper.height());
this.helper.css("bottom","auto")
}},_trigger:function(u,v,w){w=w||this._uiHash();
f.ui.plugin.call(this,u,[v,w,this],true);
if(/^(drag|start|stop)/.test(u)){this.positionAbs=this._convertPositionTo("absolute");
w.offset=this.positionAbs
}return f.Widget.prototype._trigger.call(this,u,v,w)
},plugins:{},_uiHash:function(){return{helper:this.helper,position:this.position,originalPosition:this.originalPosition,offset:this.positionAbs}
}});
f.ui.plugin.add("draggable","connectToSortable",{start:function(w,x,u){var v=f.extend({},x,{item:u.element});
u.sortables=[];
f(u.options.connectToSortable).each(function(){var y=f(this).sortable("instance");
if(y&&!y.options.disabled){u.sortables.push(y);
y.refreshPositions();
y._trigger("activate",w,v)
}})
},stop:function(w,x,u){var v=f.extend({},x,{item:u.element});
u.cancelHelperRemoval=false;
f.each(u.sortables,function(){var y=this;
if(y.isOver){y.isOver=0;
u.cancelHelperRemoval=true;
y.cancelHelperRemoval=false;
y._storedCSS={position:y.placeholder.css("position"),top:y.placeholder.css("top"),left:y.placeholder.css("left")};
y._mouseStop(w);
y.options.helper=y.options._helper
}else{y.cancelHelperRemoval=true;
y._trigger("deactivate",w,v)
}})
},drag:function(v,w,u){f.each(u.sortables,function(){var x=false,y=this;
y.positionAbs=u.positionAbs;
y.helperProportions=u.helperProportions;
y.offset.click=u.offset.click;
if(y._intersectsWith(y.containerCache)){x=true;
f.each(u.sortables,function(){this.positionAbs=u.positionAbs;
this.helperProportions=u.helperProportions;
this.offset.click=u.offset.click;
if(this!==y&&this._intersectsWith(this.containerCache)&&f.contains(y.element[0],this.element[0])){x=false
}return x
})
}if(x){if(!y.isOver){y.isOver=1;
u._parent=w.helper.parent();
y.currentItem=w.helper.appendTo(y.element).data("ui-sortable-item",true);
y.options._helper=y.options.helper;
y.options.helper=function(){return w.helper[0]
};
v.target=y.currentItem[0];
y._mouseCapture(v,true);
y._mouseStart(v,true,true);
y.offset.click.top=u.offset.click.top;
y.offset.click.left=u.offset.click.left;
y.offset.parent.left-=u.offset.parent.left-y.offset.parent.left;
y.offset.parent.top-=u.offset.parent.top-y.offset.parent.top;
u._trigger("toSortable",v);
u.dropped=y.element;
f.each(u.sortables,function(){this.refreshPositions()
});
u.currentItem=u.element;
y.fromOutside=u
}if(y.currentItem){y._mouseDrag(v);
w.position=y.position
}}else{if(y.isOver){y.isOver=0;
y.cancelHelperRemoval=true;
y.options._revert=y.options.revert;
y.options.revert=false;
y._trigger("out",v,y._uiHash(y));
y._mouseStop(v,true);
y.options.revert=y.options._revert;
y.options.helper=y.options._helper;
if(y.placeholder){y.placeholder.remove()
}w.helper.appendTo(u._parent);
u._refreshOffsets(v);
w.position=u._generatePosition(v,true);
u._trigger("fromSortable",v);
u.dropped=false;
f.each(u.sortables,function(){this.refreshPositions()
})
}}})
}});
f.ui.plugin.add("draggable","cursor",{start:function(w,x,u){var v=f("body"),y=u.options;
if(v.css("cursor")){y._cursor=v.css("cursor")
}v.css("cursor",y.cursor)
},stop:function(v,w,u){var x=u.options;
if(x._cursor){f("body").css("cursor",x._cursor)
}}});
f.ui.plugin.add("draggable","opacity",{start:function(w,x,u){var v=f(x.helper),y=u.options;
if(v.css("opacity")){y._opacity=v.css("opacity")
}v.css("opacity",y.opacity)
},stop:function(v,w,u){var x=u.options;
if(x._opacity){f(w.helper).css("opacity",x._opacity)
}}});
f.ui.plugin.add("draggable","scroll",{start:function(v,w,u){if(!u.scrollParentNotHidden){u.scrollParentNotHidden=u.helper.scrollParent(false)
}if(u.scrollParentNotHidden[0]!==u.document[0]&&u.scrollParentNotHidden[0].tagName!=="HTML"){u.overflowOffset=u.scrollParentNotHidden.offset()
}},drag:function(x,y,w){var z=w.options,v=false,A=w.scrollParentNotHidden[0],u=w.document[0];
if(A!==u&&A.tagName!=="HTML"){if(!z.axis||z.axis!=="x"){if((w.overflowOffset.top+A.offsetHeight)-x.pageY<z.scrollSensitivity){A.scrollTop=v=A.scrollTop+z.scrollSpeed
}else{if(x.pageY-w.overflowOffset.top<z.scrollSensitivity){A.scrollTop=v=A.scrollTop-z.scrollSpeed
}}}if(!z.axis||z.axis!=="y"){if((w.overflowOffset.left+A.offsetWidth)-x.pageX<z.scrollSensitivity){A.scrollLeft=v=A.scrollLeft+z.scrollSpeed
}else{if(x.pageX-w.overflowOffset.left<z.scrollSensitivity){A.scrollLeft=v=A.scrollLeft-z.scrollSpeed
}}}}else{if(!z.axis||z.axis!=="x"){if(x.pageY-f(u).scrollTop()<z.scrollSensitivity){v=f(u).scrollTop(f(u).scrollTop()-z.scrollSpeed)
}else{if(f(window).height()-(x.pageY-f(u).scrollTop())<z.scrollSensitivity){v=f(u).scrollTop(f(u).scrollTop()+z.scrollSpeed)
}}}if(!z.axis||z.axis!=="y"){if(x.pageX-f(u).scrollLeft()<z.scrollSensitivity){v=f(u).scrollLeft(f(u).scrollLeft()-z.scrollSpeed)
}else{if(f(window).width()-(x.pageX-f(u).scrollLeft())<z.scrollSensitivity){v=f(u).scrollLeft(f(u).scrollLeft()+z.scrollSpeed)
}}}}if(v!==false&&f.ui.ddmanager&&!z.dropBehaviour){f.ui.ddmanager.prepareOffsets(w,x)
}}});
f.ui.plugin.add("draggable","snap",{start:function(v,w,u){var x=u.options;
u.snapElements=[];
f(x.snap.constructor!==String?(x.snap.items||":data(ui-draggable)"):x.snap).each(function(){var z=f(this),y=z.offset();
if(this!==u.element[0]){u.snapElements.push({item:this,width:z.outerWidth(),height:z.outerHeight(),top:y.top,left:y.left})
}})
},drag:function(G,D,x){var u,L,z,A,F,C,B,M,H,y,E=x.options,K=E.snapTolerance,J=D.offset.left,I=J+x.helperProportions.width,w=D.offset.top,v=w+x.helperProportions.height;
for(H=x.snapElements.length-1;
H>=0;
H--){F=x.snapElements[H].left-x.margins.left;
C=F+x.snapElements[H].width;
B=x.snapElements[H].top-x.margins.top;
M=B+x.snapElements[H].height;
if(I<F-K||J>C+K||v<B-K||w>M+K||!f.contains(x.snapElements[H].item.ownerDocument,x.snapElements[H].item)){if(x.snapElements[H].snapping){(x.options.snap.release&&x.options.snap.release.call(x.element,G,f.extend(x._uiHash(),{snapItem:x.snapElements[H].item})))
}x.snapElements[H].snapping=false;
continue
}if(E.snapMode!=="inner"){u=Math.abs(B-v)<=K;
L=Math.abs(M-w)<=K;
z=Math.abs(F-I)<=K;
A=Math.abs(C-J)<=K;
if(u){D.position.top=x._convertPositionTo("relative",{top:B-x.helperProportions.height,left:0}).top
}if(L){D.position.top=x._convertPositionTo("relative",{top:M,left:0}).top
}if(z){D.position.left=x._convertPositionTo("relative",{top:0,left:F-x.helperProportions.width}).left
}if(A){D.position.left=x._convertPositionTo("relative",{top:0,left:C}).left
}}y=(u||L||z||A);
if(E.snapMode!=="outer"){u=Math.abs(B-w)<=K;
L=Math.abs(M-v)<=K;
z=Math.abs(F-J)<=K;
A=Math.abs(C-I)<=K;
if(u){D.position.top=x._convertPositionTo("relative",{top:B,left:0}).top
}if(L){D.position.top=x._convertPositionTo("relative",{top:M-x.helperProportions.height,left:0}).top
}if(z){D.position.left=x._convertPositionTo("relative",{top:0,left:F}).left
}if(A){D.position.left=x._convertPositionTo("relative",{top:0,left:C-x.helperProportions.width}).left
}}if(!x.snapElements[H].snapping&&(u||L||z||A||y)){(x.options.snap.snap&&x.options.snap.snap.call(x.element,G,f.extend(x._uiHash(),{snapItem:x.snapElements[H].item})))
}x.snapElements[H].snapping=(u||L||z||A||y)
}}});
f.ui.plugin.add("draggable","stack",{start:function(w,x,u){var v,z=u.options,y=f.makeArray(f(z.stack)).sort(function(B,A){return(parseInt(f(B).css("zIndex"),10)||0)-(parseInt(f(A).css("zIndex"),10)||0)
});
if(!y.length){return
}v=parseInt(f(y[0]).css("zIndex"),10)||0;
f(y).each(function(A){f(this).css("zIndex",v+A)
});
this.css("zIndex",(v+y.length))
}});
f.ui.plugin.add("draggable","zIndex",{start:function(w,x,u){var v=f(x.helper),y=u.options;
if(v.css("zIndex")){y._zIndex=v.css("zIndex")
}v.css("zIndex",y.zIndex)
},stop:function(v,w,u){var x=u.options;
if(x._zIndex){f(w.helper).css("zIndex",x._zIndex)
}}});
var d=f.ui.draggable;
/*!
 * jQuery UI Droppable 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/droppable/
 */
f.widget("ui.droppable",{version:"1.11.4",widgetEventPrefix:"drop",options:{accept:"*",activeClass:false,addClasses:true,greedy:false,hoverClass:false,scope:"default",tolerance:"intersect",activate:null,deactivate:null,drop:null,out:null,over:null},_create:function(){var v,w=this.options,u=w.accept;
this.isover=false;
this.isout=true;
this.accept=f.isFunction(u)?u:function(x){return x.is(u)
};
this.proportions=function(){if(arguments.length){v=arguments[0]
}else{return v?v:v={width:this.element[0].offsetWidth,height:this.element[0].offsetHeight}
}};
this._addToManager(w.scope);
w.addClasses&&this.element.addClass("ui-droppable")
},_addToManager:function(u){f.ui.ddmanager.droppables[u]=f.ui.ddmanager.droppables[u]||[];
f.ui.ddmanager.droppables[u].push(this)
},_splice:function(u){var v=0;
for(;
v<u.length;
v++){if(u[v]===this){u.splice(v,1)
}}},_destroy:function(){var u=f.ui.ddmanager.droppables[this.options.scope];
this._splice(u);
this.element.removeClass("ui-droppable ui-droppable-disabled")
},_setOption:function(v,w){if(v==="accept"){this.accept=f.isFunction(w)?w:function(x){return x.is(w)
}
}else{if(v==="scope"){var u=f.ui.ddmanager.droppables[this.options.scope];
this._splice(u);
this._addToManager(w)
}}this._super(v,w)
},_activate:function(v){var u=f.ui.ddmanager.current;
if(this.options.activeClass){this.element.addClass(this.options.activeClass)
}if(u){this._trigger("activate",v,this.ui(u))
}},_deactivate:function(v){var u=f.ui.ddmanager.current;
if(this.options.activeClass){this.element.removeClass(this.options.activeClass)
}if(u){this._trigger("deactivate",v,this.ui(u))
}},_over:function(v){var u=f.ui.ddmanager.current;
if(!u||(u.currentItem||u.element)[0]===this.element[0]){return
}if(this.accept.call(this.element[0],(u.currentItem||u.element))){if(this.options.hoverClass){this.element.addClass(this.options.hoverClass)
}this._trigger("over",v,this.ui(u))
}},_out:function(v){var u=f.ui.ddmanager.current;
if(!u||(u.currentItem||u.element)[0]===this.element[0]){return
}if(this.accept.call(this.element[0],(u.currentItem||u.element))){if(this.options.hoverClass){this.element.removeClass(this.options.hoverClass)
}this._trigger("out",v,this.ui(u))
}},_drop:function(v,w){var u=w||f.ui.ddmanager.current,x=false;
if(!u||(u.currentItem||u.element)[0]===this.element[0]){return false
}this.element.find(":data(ui-droppable)").not(".ui-draggable-dragging").each(function(){var y=f(this).droppable("instance");
if(y.options.greedy&&!y.options.disabled&&y.options.scope===u.options.scope&&y.accept.call(y.element[0],(u.currentItem||u.element))&&f.ui.intersect(u,f.extend(y,{offset:y.element.offset()}),y.options.tolerance,v)){x=true;
return false
}});
if(x){return false
}if(this.accept.call(this.element[0],(u.currentItem||u.element))){if(this.options.activeClass){this.element.removeClass(this.options.activeClass)
}if(this.options.hoverClass){this.element.removeClass(this.options.hoverClass)
}this._trigger("drop",v,this.ui(u));
return this.element
}return false
},ui:function(u){return{draggable:(u.currentItem||u.element),helper:u.helper,position:u.position,offset:u.positionAbs}
}});
f.ui.intersect=(function(){function u(w,v,y){return(w>=v)&&(w<(v+y))
}return function(G,A,E,w){if(!A.offset){return false
}var y=(G.positionAbs||G.position.absolute).left+G.margins.left,D=(G.positionAbs||G.position.absolute).top+G.margins.top,x=y+G.helperProportions.width,C=D+G.helperProportions.height,z=A.offset.left,F=A.offset.top,v=z+A.proportions().width,B=F+A.proportions().height;
switch(E){case"fit":return(z<=y&&x<=v&&F<=D&&C<=B);
case"intersect":return(z<y+(G.helperProportions.width/2)&&x-(G.helperProportions.width/2)<v&&F<D+(G.helperProportions.height/2)&&C-(G.helperProportions.height/2)<B);
case"pointer":return u(w.pageY,F,A.proportions().height)&&u(w.pageX,z,A.proportions().width);
case"touch":return((D>=F&&D<=B)||(C>=F&&C<=B)||(D<F&&C>B))&&((y>=z&&y<=v)||(x>=z&&x<=v)||(y<z&&x>v));
default:return false
}}
})();
f.ui.ddmanager={current:null,droppables:{"default":[]},prepareOffsets:function(x,z){var w,v,u=f.ui.ddmanager.droppables[x.options.scope]||[],y=z?z.type:null,A=(x.currentItem||x.element).find(":data(ui-droppable)").addBack();
droppablesLoop:for(w=0;
w<u.length;
w++){if(u[w].options.disabled||(x&&!u[w].accept.call(u[w].element[0],(x.currentItem||x.element)))){continue
}for(v=0;
v<A.length;
v++){if(A[v]===u[w].element[0]){u[w].proportions().height=0;
continue droppablesLoop
}}u[w].visible=u[w].element.css("display")!=="none";
if(!u[w].visible){continue
}if(y==="mousedown"){u[w]._activate.call(u[w],z)
}u[w].offset=u[w].element.offset();
u[w].proportions({width:u[w].element[0].offsetWidth,height:u[w].element[0].offsetHeight})
}},drop:function(u,v){var w=false;
f.each((f.ui.ddmanager.droppables[u.options.scope]||[]).slice(),function(){if(!this.options){return
}if(!this.options.disabled&&this.visible&&f.ui.intersect(u,this,this.options.tolerance,v)){w=this._drop.call(this,v)||w
}if(!this.options.disabled&&this.visible&&this.accept.call(this.element[0],(u.currentItem||u.element))){this.isout=true;
this.isover=false;
this._deactivate.call(this,v)
}});
return w
},dragStart:function(u,v){u.element.parentsUntil("body").bind("scroll.droppable",function(){if(!u.options.refreshPositions){f.ui.ddmanager.prepareOffsets(u,v)
}})
},drag:function(u,v){if(u.options.refreshPositions){f.ui.ddmanager.prepareOffsets(u,v)
}f.each(f.ui.ddmanager.droppables[u.options.scope]||[],function(){if(this.options.disabled||this.greedyChild||!this.visible){return
}var z,x,w,y=f.ui.intersect(u,this,this.options.tolerance,v),A=!y&&this.isover?"isout":(y&&!this.isover?"isover":null);
if(!A){return
}if(this.options.greedy){x=this.options.scope;
w=this.element.parents(":data(ui-droppable)").filter(function(){return f(this).droppable("instance").options.scope===x
});
if(w.length){z=f(w[0]).droppable("instance");
z.greedyChild=(A==="isover")
}}if(z&&A==="isover"){z.isover=false;
z.isout=true;
z._out.call(z,v)
}this[A]=true;
this[A==="isout"?"isover":"isout"]=false;
this[A==="isover"?"_over":"_out"].call(this,v);
if(z&&A==="isout"){z.isout=false;
z.isover=true;
z._over.call(z,v)
}})
},dragStop:function(u,v){u.element.parentsUntil("body").unbind("scroll.droppable");
if(!u.options.refreshPositions){f.ui.ddmanager.prepareOffsets(u,v)
}}};
var t=f.ui.droppable;
/*!
 * jQuery UI Resizable 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/resizable/
 */
f.widget("ui.resizable",f.ui.mouse,{version:"1.11.4",widgetEventPrefix:"resize",options:{alsoResize:false,animate:false,animateDuration:"slow",animateEasing:"swing",aspectRatio:false,autoHide:false,containment:false,ghost:false,grid:false,handles:"e,s,se",helper:false,maxHeight:null,maxWidth:null,minHeight:10,minWidth:10,zIndex:90,resize:null,start:null,stop:null},_num:function(u){return parseInt(u,10)||0
},_isNumber:function(u){return !isNaN(parseInt(u,10))
},_hasScroll:function(x,v){if(f(x).css("overflow")==="hidden"){return false
}var u=(v&&v==="left")?"scrollLeft":"scrollTop",w=false;
if(x[u]>0){return true
}x[u]=1;
w=(x[u]>0);
x[u]=0;
return w
},_create:function(){var A,v,y,w,u,x=this,z=this.options;
this.element.addClass("ui-resizable");
f.extend(this,{_aspectRatio:!!(z.aspectRatio),aspectRatio:z.aspectRatio,originalElement:this.element,_proportionallyResizeElements:[],_helper:z.helper||z.ghost||z.animate?z.helper||"ui-resizable-helper":null});
if(this.element[0].nodeName.match(/^(canvas|textarea|input|select|button|img)$/i)){this.element.wrap(f("<div class='ui-wrapper' style='overflow: hidden;'></div>").css({position:this.element.css("position"),width:this.element.outerWidth(),height:this.element.outerHeight(),top:this.element.css("top"),left:this.element.css("left")}));
this.element=this.element.parent().data("ui-resizable",this.element.resizable("instance"));
this.elementIsWrapper=true;
this.element.css({marginLeft:this.originalElement.css("marginLeft"),marginTop:this.originalElement.css("marginTop"),marginRight:this.originalElement.css("marginRight"),marginBottom:this.originalElement.css("marginBottom")});
this.originalElement.css({marginLeft:0,marginTop:0,marginRight:0,marginBottom:0});
this.originalResizeStyle=this.originalElement.css("resize");
this.originalElement.css("resize","none");
this._proportionallyResizeElements.push(this.originalElement.css({position:"static",zoom:1,display:"block"}));
this.originalElement.css({margin:this.originalElement.css("margin")});
this._proportionallyResize()
}this.handles=z.handles||(!f(".ui-resizable-handle",this.element).length?"e,s,se":{n:".ui-resizable-n",e:".ui-resizable-e",s:".ui-resizable-s",w:".ui-resizable-w",se:".ui-resizable-se",sw:".ui-resizable-sw",ne:".ui-resizable-ne",nw:".ui-resizable-nw"});
this._handles=f();
if(this.handles.constructor===String){if(this.handles==="all"){this.handles="n,e,s,w,se,sw,ne,nw"
}A=this.handles.split(",");
this.handles={};
for(v=0;
v<A.length;
v++){y=f.trim(A[v]);
u="ui-resizable-"+y;
w=f("<div class='ui-resizable-handle "+u+"'></div>");
w.css({zIndex:z.zIndex});
if("se"===y){w.addClass("ui-icon ui-icon-gripsmall-diagonal-se")
}this.handles[y]=".ui-resizable-"+y;
this.element.append(w)
}}this._renderAxis=function(F){var C,D,B,E;
F=F||this.element;
for(C in this.handles){if(this.handles[C].constructor===String){this.handles[C]=this.element.children(this.handles[C]).first().show()
}else{if(this.handles[C].jquery||this.handles[C].nodeType){this.handles[C]=f(this.handles[C]);
this._on(this.handles[C],{mousedown:x._mouseDown})
}}if(this.elementIsWrapper&&this.originalElement[0].nodeName.match(/^(textarea|input|select|button)$/i)){D=f(this.handles[C],this.element);
E=/sw|ne|nw|se|n|s/.test(C)?D.outerHeight():D.outerWidth();
B=["padding",/ne|nw|n/.test(C)?"Top":/se|sw|s/.test(C)?"Bottom":/^e$/.test(C)?"Right":"Left"].join("");
F.css(B,E);
this._proportionallyResize()
}this._handles=this._handles.add(this.handles[C])
}};
this._renderAxis(this.element);
this._handles=this._handles.add(this.element.find(".ui-resizable-handle"));
this._handles.disableSelection();
this._handles.mouseover(function(){if(!x.resizing){if(this.className){w=this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)
}x.axis=w&&w[1]?w[1]:"se"
}});
if(z.autoHide){this._handles.hide();
f(this.element).addClass("ui-resizable-autohide").mouseenter(function(){if(z.disabled){return
}f(this).removeClass("ui-resizable-autohide");
x._handles.show()
}).mouseleave(function(){if(z.disabled){return
}if(!x.resizing){f(this).addClass("ui-resizable-autohide");
x._handles.hide()
}})
}this._mouseInit()
},_destroy:function(){this._mouseDestroy();
var v,u=function(w){f(w).removeClass("ui-resizable ui-resizable-disabled ui-resizable-resizing").removeData("resizable").removeData("ui-resizable").unbind(".resizable").find(".ui-resizable-handle").remove()
};
if(this.elementIsWrapper){u(this.element);
v=this.element;
this.originalElement.css({position:v.css("position"),width:v.outerWidth(),height:v.outerHeight(),top:v.css("top"),left:v.css("left")}).insertAfter(v);
v.remove()
}this.originalElement.css("resize",this.originalResizeStyle);
u(this.originalElement);
return this
},_mouseCapture:function(w){var v,x,u=false;
for(v in this.handles){x=f(this.handles[v])[0];
if(x===w.target||f.contains(x,w.target)){u=true
}}return !this.options.disabled&&u
},_mouseStart:function(v){var z,w,y,x=this.options,u=this.element;
this.resizing=true;
this._renderProxy();
z=this._num(this.helper.css("left"));
w=this._num(this.helper.css("top"));
if(x.containment){z+=f(x.containment).scrollLeft()||0;
w+=f(x.containment).scrollTop()||0
}this.offset=this.helper.offset();
this.position={left:z,top:w};
this.size=this._helper?{width:this.helper.width(),height:this.helper.height()}:{width:u.width(),height:u.height()};
this.originalSize=this._helper?{width:u.outerWidth(),height:u.outerHeight()}:{width:u.width(),height:u.height()};
this.sizeDiff={width:u.outerWidth()-u.width(),height:u.outerHeight()-u.height()};
this.originalPosition={left:z,top:w};
this.originalMousePosition={left:v.pageX,top:v.pageY};
this.aspectRatio=(typeof x.aspectRatio==="number")?x.aspectRatio:((this.originalSize.width/this.originalSize.height)||1);
y=f(".ui-resizable-"+this.axis).css("cursor");
f("body").css("cursor",y==="auto"?this.axis+"-resize":y);
u.addClass("ui-resizable-resizing");
this._propagate("start",v);
return true
},_mouseDrag:function(z){var A,y,B=this.originalMousePosition,v=this.axis,w=(z.pageX-B.left)||0,u=(z.pageY-B.top)||0,x=this._change[v];
this._updatePrevProperties();
if(!x){return false
}A=x.apply(this,[z,w,u]);
this._updateVirtualBoundaries(z.shiftKey);
if(this._aspectRatio||z.shiftKey){A=this._updateRatio(A,z)
}A=this._respectSize(A,z);
this._updateCache(A);
this._propagate("resize",z);
y=this._applyChanges();
if(!this._helper&&this._proportionallyResizeElements.length){this._proportionallyResize()
}if(!f.isEmptyObject(y)){this._updatePrevProperties();
this._trigger("resize",z,this.ui());
this._applyChanges()
}return false
},_mouseStop:function(x){this.resizing=false;
var w,u,v,A,D,z,C,y=this.options,B=this;
if(this._helper){w=this._proportionallyResizeElements;
u=w.length&&(/textarea/i).test(w[0].nodeName);
v=u&&this._hasScroll(w[0],"left")?0:B.sizeDiff.height;
A=u?0:B.sizeDiff.width;
D={width:(B.helper.width()-A),height:(B.helper.height()-v)};
z=(parseInt(B.element.css("left"),10)+(B.position.left-B.originalPosition.left))||null;
C=(parseInt(B.element.css("top"),10)+(B.position.top-B.originalPosition.top))||null;
if(!y.animate){this.element.css(f.extend(D,{top:C,left:z}))
}B.helper.height(B.size.height);
B.helper.width(B.size.width);
if(this._helper&&!y.animate){this._proportionallyResize()
}}f("body").css("cursor","auto");
this.element.removeClass("ui-resizable-resizing");
this._propagate("stop",x);
if(this._helper){this.helper.remove()
}return false
},_updatePrevProperties:function(){this.prevPosition={top:this.position.top,left:this.position.left};
this.prevSize={width:this.size.width,height:this.size.height}
},_applyChanges:function(){var u={};
if(this.position.top!==this.prevPosition.top){u.top=this.position.top+"px"
}if(this.position.left!==this.prevPosition.left){u.left=this.position.left+"px"
}if(this.size.width!==this.prevSize.width){u.width=this.size.width+"px"
}if(this.size.height!==this.prevSize.height){u.height=this.size.height+"px"
}this.helper.css(u);
return u
},_updateVirtualBoundaries:function(w){var y,x,v,A,u,z=this.options;
u={minWidth:this._isNumber(z.minWidth)?z.minWidth:0,maxWidth:this._isNumber(z.maxWidth)?z.maxWidth:Infinity,minHeight:this._isNumber(z.minHeight)?z.minHeight:0,maxHeight:this._isNumber(z.maxHeight)?z.maxHeight:Infinity};
if(this._aspectRatio||w){y=u.minHeight*this.aspectRatio;
v=u.minWidth/this.aspectRatio;
x=u.maxHeight*this.aspectRatio;
A=u.maxWidth/this.aspectRatio;
if(y>u.minWidth){u.minWidth=y
}if(v>u.minHeight){u.minHeight=v
}if(x<u.maxWidth){u.maxWidth=x
}if(A<u.maxHeight){u.maxHeight=A
}}this._vBoundaries=u
},_updateCache:function(u){this.offset=this.helper.offset();
if(this._isNumber(u.left)){this.position.left=u.left
}if(this._isNumber(u.top)){this.position.top=u.top
}if(this._isNumber(u.height)){this.size.height=u.height
}if(this._isNumber(u.width)){this.size.width=u.width
}},_updateRatio:function(w){var x=this.position,v=this.size,u=this.axis;
if(this._isNumber(w.height)){w.width=(w.height*this.aspectRatio)
}else{if(this._isNumber(w.width)){w.height=(w.width/this.aspectRatio)
}}if(u==="sw"){w.left=x.left+(v.width-w.width);
w.top=null
}if(u==="nw"){w.top=x.top+(v.height-w.height);
w.left=x.left+(v.width-w.width)
}return w
},_respectSize:function(z){var w=this._vBoundaries,C=this.axis,E=this._isNumber(z.width)&&w.maxWidth&&(w.maxWidth<z.width),A=this._isNumber(z.height)&&w.maxHeight&&(w.maxHeight<z.height),x=this._isNumber(z.width)&&w.minWidth&&(w.minWidth>z.width),D=this._isNumber(z.height)&&w.minHeight&&(w.minHeight>z.height),v=this.originalPosition.left+this.originalSize.width,B=this.position.top+this.size.height,y=/sw|nw|w/.test(C),u=/nw|ne|n/.test(C);
if(x){z.width=w.minWidth
}if(D){z.height=w.minHeight
}if(E){z.width=w.maxWidth
}if(A){z.height=w.maxHeight
}if(x&&y){z.left=v-w.minWidth
}if(E&&y){z.left=v-w.maxWidth
}if(D&&u){z.top=B-w.minHeight
}if(A&&u){z.top=B-w.maxHeight
}if(!z.width&&!z.height&&!z.left&&z.top){z.top=null
}else{if(!z.width&&!z.height&&!z.top&&z.left){z.left=null
}}return z
},_getPaddingPlusBorderDimensions:function(w){var v=0,x=[],y=[w.css("borderTopWidth"),w.css("borderRightWidth"),w.css("borderBottomWidth"),w.css("borderLeftWidth")],u=[w.css("paddingTop"),w.css("paddingRight"),w.css("paddingBottom"),w.css("paddingLeft")];
for(;
v<4;
v++){x[v]=(parseInt(y[v],10)||0);
x[v]+=(parseInt(u[v],10)||0)
}return{height:x[0]+x[2],width:x[1]+x[3]}
},_proportionallyResize:function(){if(!this._proportionallyResizeElements.length){return
}var w,v=0,u=this.helper||this.element;
for(;
v<this._proportionallyResizeElements.length;
v++){w=this._proportionallyResizeElements[v];
if(!this.outerDimensions){this.outerDimensions=this._getPaddingPlusBorderDimensions(w)
}w.css({height:(u.height()-this.outerDimensions.height)||0,width:(u.width()-this.outerDimensions.width)||0})
}},_renderProxy:function(){var u=this.element,v=this.options;
this.elementOffset=u.offset();
if(this._helper){this.helper=this.helper||f("<div style='overflow:hidden;'></div>");
this.helper.addClass(this._helper).css({width:this.element.outerWidth()-1,height:this.element.outerHeight()-1,position:"absolute",left:this.elementOffset.left+"px",top:this.elementOffset.top+"px",zIndex:++v.zIndex});
this.helper.appendTo("body").disableSelection()
}else{this.helper=this.element
}},_change:{e:function(v,u){return{width:this.originalSize.width+u}
},w:function(w,u){var v=this.originalSize,x=this.originalPosition;
return{left:x.left+u,width:v.width-u}
},n:function(x,v,u){var w=this.originalSize,y=this.originalPosition;
return{top:y.top+u,height:w.height-u}
},s:function(w,v,u){return{height:this.originalSize.height+u}
},se:function(w,v,u){return f.extend(this._change.s.apply(this,arguments),this._change.e.apply(this,[w,v,u]))
},sw:function(w,v,u){return f.extend(this._change.s.apply(this,arguments),this._change.w.apply(this,[w,v,u]))
},ne:function(w,v,u){return f.extend(this._change.n.apply(this,arguments),this._change.e.apply(this,[w,v,u]))
},nw:function(w,v,u){return f.extend(this._change.n.apply(this,arguments),this._change.w.apply(this,[w,v,u]))
}},_propagate:function(v,u){f.ui.plugin.call(this,v,[u,this.ui()]);
(v!=="resize"&&this._trigger(v,u,this.ui()))
},plugins:{},ui:function(){return{originalElement:this.originalElement,element:this.element,helper:this.helper,position:this.position,size:this.size,originalSize:this.originalSize,originalPosition:this.originalPosition}
}});
f.ui.plugin.add("resizable","animate",{stop:function(x){var C=f(this).resizable("instance"),z=C.options,w=C._proportionallyResizeElements,u=w.length&&(/textarea/i).test(w[0].nodeName),v=u&&C._hasScroll(w[0],"left")?0:C.sizeDiff.height,B=u?0:C.sizeDiff.width,y={width:(C.size.width-B),height:(C.size.height-v)},A=(parseInt(C.element.css("left"),10)+(C.position.left-C.originalPosition.left))||null,D=(parseInt(C.element.css("top"),10)+(C.position.top-C.originalPosition.top))||null;
C.element.animate(f.extend(y,D&&A?{top:D,left:A}:{}),{duration:z.animateDuration,easing:z.animateEasing,step:function(){var E={width:parseInt(C.element.css("width"),10),height:parseInt(C.element.css("height"),10),top:parseInt(C.element.css("top"),10),left:parseInt(C.element.css("left"),10)};
if(w&&w.length){f(w[0]).css({width:E.width,height:E.height})
}C._updateCache(E);
C._propagate("resize",x)
}})
}});
f.ui.plugin.add("resizable","containment",{start:function(){var C,w,E,u,B,x,F,D=f(this).resizable("instance"),A=D.options,z=D.element,v=A.containment,y=(v instanceof f)?v.get(0):(/parent/.test(v))?z.parent().get(0):v;
if(!y){return
}D.containerElement=f(y);
if(/document/.test(v)||v===document){D.containerOffset={left:0,top:0};
D.containerPosition={left:0,top:0};
D.parentData={element:f(document),left:0,top:0,width:f(document).width(),height:f(document).height()||document.body.parentNode.scrollHeight}
}else{C=f(y);
w=[];
f(["Top","Right","Left","Bottom"]).each(function(H,G){w[H]=D._num(C.css("padding"+G))
});
D.containerOffset=C.offset();
D.containerPosition=C.position();
D.containerSize={height:(C.innerHeight()-w[3]),width:(C.innerWidth()-w[1])};
E=D.containerOffset;
u=D.containerSize.height;
B=D.containerSize.width;
x=(D._hasScroll(y,"left")?y.scrollWidth:B);
F=(D._hasScroll(y)?y.scrollHeight:u);
D.parentData={element:y,left:E.left,top:E.top,width:x,height:F}
}},resize:function(v){var B,G,A,y,C=f(this).resizable("instance"),x=C.options,E=C.containerOffset,D=C.position,F=C._aspectRatio||v.shiftKey,u={top:0,left:0},w=C.containerElement,z=true;
if(w[0]!==document&&(/static/).test(w.css("position"))){u=E
}if(D.left<(C._helper?E.left:0)){C.size.width=C.size.width+(C._helper?(C.position.left-E.left):(C.position.left-u.left));
if(F){C.size.height=C.size.width/C.aspectRatio;
z=false
}C.position.left=x.helper?E.left:0
}if(D.top<(C._helper?E.top:0)){C.size.height=C.size.height+(C._helper?(C.position.top-E.top):C.position.top);
if(F){C.size.width=C.size.height*C.aspectRatio;
z=false
}C.position.top=C._helper?E.top:0
}A=C.containerElement.get(0)===C.element.parent().get(0);
y=/relative|absolute/.test(C.containerElement.css("position"));
if(A&&y){C.offset.left=C.parentData.left+C.position.left;
C.offset.top=C.parentData.top+C.position.top
}else{C.offset.left=C.element.offset().left;
C.offset.top=C.element.offset().top
}B=Math.abs(C.sizeDiff.width+(C._helper?C.offset.left-u.left:(C.offset.left-E.left)));
G=Math.abs(C.sizeDiff.height+(C._helper?C.offset.top-u.top:(C.offset.top-E.top)));
if(B+C.size.width>=C.parentData.width){C.size.width=C.parentData.width-B;
if(F){C.size.height=C.size.width/C.aspectRatio;
z=false
}}if(G+C.size.height>=C.parentData.height){C.size.height=C.parentData.height-G;
if(F){C.size.width=C.size.height*C.aspectRatio;
z=false
}}if(!z){C.position.left=C.prevPosition.left;
C.position.top=C.prevPosition.top;
C.size.width=C.prevSize.width;
C.size.height=C.prevSize.height
}},stop:function(){var A=f(this).resizable("instance"),v=A.options,B=A.containerOffset,u=A.containerPosition,x=A.containerElement,y=f(A.helper),D=y.offset(),C=y.outerWidth()-A.sizeDiff.width,z=y.outerHeight()-A.sizeDiff.height;
if(A._helper&&!v.animate&&(/relative/).test(x.css("position"))){f(this).css({left:D.left-u.left-B.left,width:C,height:z})
}if(A._helper&&!v.animate&&(/static/).test(x.css("position"))){f(this).css({left:D.left-u.left-B.left,width:C,height:z})
}}});
f.ui.plugin.add("resizable","alsoResize",{start:function(){var u=f(this).resizable("instance"),v=u.options;
f(v.alsoResize).each(function(){var w=f(this);
w.data("ui-resizable-alsoresize",{width:parseInt(w.width(),10),height:parseInt(w.height(),10),left:parseInt(w.css("left"),10),top:parseInt(w.css("top"),10)})
})
},resize:function(v,x){var u=f(this).resizable("instance"),y=u.options,w=u.originalSize,A=u.originalPosition,z={height:(u.size.height-w.height)||0,width:(u.size.width-w.width)||0,top:(u.position.top-A.top)||0,left:(u.position.left-A.left)||0};
f(y.alsoResize).each(function(){var D=f(this),E=f(this).data("ui-resizable-alsoresize"),C={},B=D.parents(x.originalElement[0]).length?["width","height"]:["width","height","top","left"];
f.each(B,function(F,H){var G=(E[H]||0)+(z[H]||0);
if(G&&G>=0){C[H]=G||null
}});
D.css(C)
})
},stop:function(){f(this).removeData("resizable-alsoresize")
}});
f.ui.plugin.add("resizable","ghost",{start:function(){var v=f(this).resizable("instance"),w=v.options,u=v.size;
v.ghost=v.originalElement.clone();
v.ghost.css({opacity:0.25,display:"block",position:"relative",height:u.height,width:u.width,margin:0,left:0,top:0}).addClass("ui-resizable-ghost").addClass(typeof w.ghost==="string"?w.ghost:"");
v.ghost.appendTo(v.helper)
},resize:function(){var u=f(this).resizable("instance");
if(u.ghost){u.ghost.css({position:"relative",height:u.size.height,width:u.size.width})
}},stop:function(){var u=f(this).resizable("instance");
if(u.ghost&&u.helper){u.helper.get(0).removeChild(u.ghost.get(0))
}}});
f.ui.plugin.add("resizable","grid",{resize:function(){var x,C=f(this).resizable("instance"),G=C.options,A=C.size,B=C.originalSize,D=C.originalPosition,L=C.axis,u=typeof G.grid==="number"?[G.grid,G.grid]:G.grid,J=(u[0]||1),I=(u[1]||1),z=Math.round((A.width-B.width)/J)*J,y=Math.round((A.height-B.height)/I)*I,E=B.width+z,H=B.height+y,w=G.maxWidth&&(G.maxWidth<E),F=G.maxHeight&&(G.maxHeight<H),K=G.minWidth&&(G.minWidth>E),v=G.minHeight&&(G.minHeight>H);
G.grid=u;
if(K){E+=J
}if(v){H+=I
}if(w){E-=J
}if(F){H-=I
}if(/^(se|s|e)$/.test(L)){C.size.width=E;
C.size.height=H
}else{if(/^(ne)$/.test(L)){C.size.width=E;
C.size.height=H;
C.position.top=D.top-y
}else{if(/^(sw)$/.test(L)){C.size.width=E;
C.size.height=H;
C.position.left=D.left-z
}else{if(H-I<=0||E-J<=0){x=C._getPaddingPlusBorderDimensions(this)
}if(H-I>0){C.size.height=H;
C.position.top=D.top-y
}else{H=I-x.height;
C.size.height=H;
C.position.top=D.top+B.height-H
}if(E-J>0){C.size.width=E;
C.position.left=D.left-z
}else{E=J-x.width;
C.size.width=E;
C.position.left=D.left+B.width-E
}}}}}});
var h=f.ui.resizable;
/*!
 * jQuery UI Button 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/button/
 */
var l,r="ui-button ui-widget ui-state-default ui-corner-all",j="ui-button-icons-only ui-button-icon-only ui-button-text-icons ui-button-text-icon-primary ui-button-text-icon-secondary ui-button-text-only",b=function(){var u=f(this);
setTimeout(function(){u.find(":ui-button").button("refresh")
},1)
},g=function(v){var u=v.name,w=v.form,x=f([]);
if(u){u=u.replace(/'/g,"\\'");
if(w){x=f(w).find("[name='"+u+"'][type=radio]")
}else{x=f("[name='"+u+"'][type=radio]",v.ownerDocument).filter(function(){return !this.form
})
}}return x
};
f.widget("ui.button",{version:"1.11.4",defaultElement:"<button>",options:{disabled:null,text:true,label:null,icons:{primary:null,secondary:null}},_create:function(){this.element.closest("form").unbind("reset"+this.eventNamespace).bind("reset"+this.eventNamespace,b);
if(typeof this.options.disabled!=="boolean"){this.options.disabled=!!this.element.prop("disabled")
}else{this.element.prop("disabled",this.options.disabled)
}this._determineButtonType();
this.hasTitle=!!this.buttonElement.attr("title");
var w=this,u=this.options,x=this.type==="checkbox"||this.type==="radio",v=!x?"ui-state-active":"";
if(u.label===null){u.label=(this.type==="input"?this.buttonElement.val():this.buttonElement.html())
}this._hoverable(this.buttonElement);
this.buttonElement.addClass(r).attr("role","button").bind("mouseenter"+this.eventNamespace,function(){if(u.disabled){return
}if(this===l){f(this).addClass("ui-state-active")
}}).bind("mouseleave"+this.eventNamespace,function(){if(u.disabled){return
}f(this).removeClass(v)
}).bind("click"+this.eventNamespace,function(y){if(u.disabled){y.preventDefault();
y.stopImmediatePropagation()
}});
this._on({focus:function(){this.buttonElement.addClass("ui-state-focus")
},blur:function(){this.buttonElement.removeClass("ui-state-focus")
}});
if(x){this.element.bind("change"+this.eventNamespace,function(){w.refresh()
})
}if(this.type==="checkbox"){this.buttonElement.bind("click"+this.eventNamespace,function(){if(u.disabled){return false
}})
}else{if(this.type==="radio"){this.buttonElement.bind("click"+this.eventNamespace,function(){if(u.disabled){return false
}f(this).addClass("ui-state-active");
w.buttonElement.attr("aria-pressed","true");
var y=w.element[0];
g(y).not(y).map(function(){return f(this).button("widget")[0]
}).removeClass("ui-state-active").attr("aria-pressed","false")
})
}else{this.buttonElement.bind("mousedown"+this.eventNamespace,function(){if(u.disabled){return false
}f(this).addClass("ui-state-active");
l=this;
w.document.one("mouseup",function(){l=null
})
}).bind("mouseup"+this.eventNamespace,function(){if(u.disabled){return false
}f(this).removeClass("ui-state-active")
}).bind("keydown"+this.eventNamespace,function(y){if(u.disabled){return false
}if(y.keyCode===f.ui.keyCode.SPACE||y.keyCode===f.ui.keyCode.ENTER){f(this).addClass("ui-state-active")
}}).bind("keyup"+this.eventNamespace+" blur"+this.eventNamespace,function(){f(this).removeClass("ui-state-active")
});
if(this.buttonElement.is("a")){this.buttonElement.keyup(function(y){if(y.keyCode===f.ui.keyCode.SPACE){f(this).click()
}})
}}}this._setOption("disabled",u.disabled);
this._resetButton()
},_determineButtonType:function(){var u,w,v;
if(this.element.is("[type=checkbox]")){this.type="checkbox"
}else{if(this.element.is("[type=radio]")){this.type="radio"
}else{if(this.element.is("input")){this.type="input"
}else{this.type="button"
}}}if(this.type==="checkbox"||this.type==="radio"){u=this.element.parents().last();
w="label[for='"+this.element.attr("id")+"']";
this.buttonElement=u.find(w);
if(!this.buttonElement.length){u=u.length?u.siblings():this.element.siblings();
this.buttonElement=u.filter(w);
if(!this.buttonElement.length){this.buttonElement=u.find(w)
}}this.element.addClass("ui-helper-hidden-accessible");
v=this.element.is(":checked");
if(v){this.buttonElement.addClass("ui-state-active")
}this.buttonElement.prop("aria-pressed",v)
}else{this.buttonElement=this.element
}},widget:function(){return this.buttonElement
},_destroy:function(){this.element.removeClass("ui-helper-hidden-accessible");
this.buttonElement.removeClass(r+" ui-state-active "+j).removeAttr("role").removeAttr("aria-pressed").html(this.buttonElement.find(".ui-button-text").html());
if(!this.hasTitle){this.buttonElement.removeAttr("title")
}},_setOption:function(u,v){this._super(u,v);
if(u==="disabled"){this.widget().toggleClass("ui-state-disabled",!!v);
this.element.prop("disabled",!!v);
if(v){if(this.type==="checkbox"||this.type==="radio"){this.buttonElement.removeClass("ui-state-focus")
}else{this.buttonElement.removeClass("ui-state-focus ui-state-active")
}}return
}this._resetButton()
},refresh:function(){var u=this.element.is("input, button")?this.element.is(":disabled"):this.element.hasClass("ui-button-disabled");
if(u!==this.options.disabled){this._setOption("disabled",u)
}if(this.type==="radio"){g(this.element[0]).each(function(){if(f(this).is(":checked")){f(this).button("widget").addClass("ui-state-active").attr("aria-pressed","true")
}else{f(this).button("widget").removeClass("ui-state-active").attr("aria-pressed","false")
}})
}else{if(this.type==="checkbox"){if(this.element.is(":checked")){this.buttonElement.addClass("ui-state-active").attr("aria-pressed","true")
}else{this.buttonElement.removeClass("ui-state-active").attr("aria-pressed","false")
}}}},_resetButton:function(){if(this.type==="input"){if(this.options.label){this.element.val(this.options.label)
}return
}var y=this.buttonElement.removeClass(j),w=f("<span></span>",this.document[0]).addClass("ui-button-text").html(this.options.label).appendTo(y.empty()).text(),v=this.options.icons,u=v.primary&&v.secondary,x=[];
if(v.primary||v.secondary){if(this.options.text){x.push("ui-button-text-icon"+(u?"s":(v.primary?"-primary":"-secondary")))
}if(v.primary){y.prepend("<span class='ui-button-icon-primary ui-icon "+v.primary+"'></span>")
}if(v.secondary){y.append("<span class='ui-button-icon-secondary ui-icon "+v.secondary+"'></span>")
}if(!this.options.text){x.push(u?"ui-button-icons-only":"ui-button-icon-only");
if(!this.hasTitle){y.attr("title",f.trim(w))
}}}else{x.push("ui-button-text-only")
}y.addClass(x.join(" "))
}});
f.widget("ui.buttonset",{version:"1.11.4",options:{items:"button, input[type=button], input[type=submit], input[type=reset], input[type=checkbox], input[type=radio], a, :data(ui-button)"},_create:function(){this.element.addClass("ui-buttonset")
},_init:function(){this.refresh()
},_setOption:function(u,v){if(u==="disabled"){this.buttons.button("option",u,v)
}this._super(u,v)
},refresh:function(){var v=this.element.css("direction")==="rtl",u=this.element.find(this.options.items),w=u.filter(":ui-button");
u.not(":ui-button").button();
w.button("refresh");
this.buttons=u.map(function(){return f(this).button("widget")[0]
}).removeClass("ui-corner-all ui-corner-left ui-corner-right").filter(":first").addClass(v?"ui-corner-right":"ui-corner-left").end().filter(":last").addClass(v?"ui-corner-left":"ui-corner-right").end().end()
},_destroy:function(){this.element.removeClass("ui-buttonset");
this.buttons.map(function(){return f(this).button("widget")[0]
}).removeClass("ui-corner-left ui-corner-right").end().button("destroy")
}});
var a=f.ui.button;
/*!
 * jQuery UI Dialog 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/dialog/
 */
var q=f.widget("ui.dialog",{version:"1.11.4",options:{appendTo:"body",autoOpen:true,buttons:[],closeOnEscape:true,closeText:"Close",dialogClass:"",draggable:true,hide:null,height:"auto",maxHeight:null,maxWidth:null,minHeight:150,minWidth:150,modal:false,position:{my:"center",at:"center",of:window,collision:"fit",using:function(v){var u=f(this).css(v).offset().top;
if(u<0){f(this).css("top",v.top-u)
}}},resizable:true,show:null,title:null,width:300,beforeClose:null,close:null,drag:null,dragStart:null,dragStop:null,focus:null,open:null,resize:null,resizeStart:null,resizeStop:null},sizeRelatedOptions:{buttons:true,height:true,maxHeight:true,maxWidth:true,minHeight:true,minWidth:true,width:true},resizableRelatedOptions:{maxHeight:true,maxWidth:true,minHeight:true,minWidth:true},_create:function(){this.originalCss={display:this.element[0].style.display,width:this.element[0].style.width,minHeight:this.element[0].style.minHeight,maxHeight:this.element[0].style.maxHeight,height:this.element[0].style.height};
this.originalPosition={parent:this.element.parent(),index:this.element.parent().children().index(this.element)};
this.originalTitle=this.element.attr("title");
this.options.title=this.options.title||this.originalTitle;
this._createWrapper();
this.element.show().removeAttr("title").addClass("ui-dialog-content ui-widget-content").appendTo(this.uiDialog);
this._createTitlebar();
this._createButtonPane();
if(this.options.draggable&&f.fn.draggable){this._makeDraggable()
}if(this.options.resizable&&f.fn.resizable){this._makeResizable()
}this._isOpen=false;
this._trackFocus()
},_init:function(){if(this.options.autoOpen){this.open()
}},_appendTo:function(){var u=this.options.appendTo;
if(u&&(u.jquery||u.nodeType)){return f(u)
}return this.document.find(u||"body").eq(0)
},_destroy:function(){var v,u=this.originalPosition;
this._untrackInstance();
this._destroyOverlay();
this.element.removeUniqueId().removeClass("ui-dialog-content ui-widget-content").css(this.originalCss).detach();
this.uiDialog.stop(true,true).remove();
if(this.originalTitle){this.element.attr("title",this.originalTitle)
}v=u.parent.children().eq(u.index);
if(v.length&&v[0]!==this.element[0]){v.before(this.element)
}else{u.parent.append(this.element)
}},widget:function(){return this.uiDialog
},disable:f.noop,enable:f.noop,close:function(x){var w,v=this;
if(!this._isOpen||this._trigger("beforeClose",x)===false){return
}this._isOpen=false;
this._focusedElement=null;
this._destroyOverlay();
this._untrackInstance();
if(!this.opener.filter(":focusable").focus().length){try{w=this.document[0].activeElement;
if(w&&w.nodeName.toLowerCase()!=="body"){f(w).blur()
}}catch(u){}}this._hide(this.uiDialog,this.options.hide,function(){v._trigger("close",x)
})
},isOpen:function(){return this._isOpen
},moveToTop:function(){this._moveToTop()
},_moveToTop:function(y,u){var x=false,w=this.uiDialog.siblings(".ui-front:visible").map(function(){return +f(this).css("z-index")
}).get(),v=Math.max.apply(null,w);
if(v>=+this.uiDialog.css("z-index")){this.uiDialog.css("z-index",v+1);
x=true
}if(x&&!u){this._trigger("focus",y)
}return x
},open:function(){var u=this;
if(this._isOpen){if(this._moveToTop()){this._focusTabbable()
}return
}this._isOpen=true;
this.opener=f(this.document[0].activeElement);
this._size();
this._position();
this._createOverlay();
this._moveToTop(null,true);
if(this.overlay){this.overlay.css("z-index",this.uiDialog.css("z-index")-1)
}this._show(this.uiDialog,this.options.show,function(){u._focusTabbable();
u._trigger("focus")
});
this._makeFocusTarget();
this._trigger("open")
},_focusTabbable:function(){var u=this._focusedElement;
if(!u){u=this.element.find("[autofocus]")
}if(!u.length){u=this.element.find(":tabbable")
}if(!u.length){u=this.uiDialogButtonPane.find(":tabbable")
}if(!u.length){u=this.uiDialogTitlebarClose.filter(":tabbable")
}if(!u.length){u=this.uiDialog
}u.eq(0).focus()
},_keepFocus:function(u){function v(){var x=this.document[0].activeElement,w=this.uiDialog[0]===x||f.contains(this.uiDialog[0],x);
if(!w){this._focusTabbable()
}}u.preventDefault();
v.call(this);
this._delay(v)
},_createWrapper:function(){this.uiDialog=f("<div>").addClass("ui-dialog ui-widget ui-widget-content ui-corner-all ui-front "+this.options.dialogClass).hide().attr({tabIndex:-1,role:"dialog"}).appendTo(this._appendTo());
this._on(this.uiDialog,{keydown:function(w){if(this.options.closeOnEscape&&!w.isDefaultPrevented()&&w.keyCode&&w.keyCode===f.ui.keyCode.ESCAPE){w.preventDefault();
this.close(w);
return
}if(w.keyCode!==f.ui.keyCode.TAB||w.isDefaultPrevented()){return
}var v=this.uiDialog.find(":tabbable"),x=v.filter(":first"),u=v.filter(":last");
if((w.target===u[0]||w.target===this.uiDialog[0])&&!w.shiftKey){this._delay(function(){x.focus()
});
w.preventDefault()
}else{if((w.target===x[0]||w.target===this.uiDialog[0])&&w.shiftKey){this._delay(function(){u.focus()
});
w.preventDefault()
}}},mousedown:function(u){if(this._moveToTop(u)){this._focusTabbable()
}}});
if(!this.element.find("[aria-describedby]").length){this.uiDialog.attr({"aria-describedby":this.element.uniqueId().attr("id")})
}},_createTitlebar:function(){var u;
this.uiDialogTitlebar=f("<div>").addClass("ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix").prependTo(this.uiDialog);
this._on(this.uiDialogTitlebar,{mousedown:function(v){if(!f(v.target).closest(".ui-dialog-titlebar-close")){this.uiDialog.focus()
}}});
this.uiDialogTitlebarClose=f("<button type='button'></button>").button({label:this.options.closeText,icons:{primary:"ui-icon-closethick"},text:false}).addClass("ui-dialog-titlebar-close").appendTo(this.uiDialogTitlebar);
this._on(this.uiDialogTitlebarClose,{click:function(v){v.preventDefault();
this.close(v)
}});
u=f("<span>").uniqueId().addClass("ui-dialog-title").prependTo(this.uiDialogTitlebar);
this._title(u);
this.uiDialog.attr({"aria-labelledby":u.attr("id")})
},_title:function(u){if(!this.options.title){u.html("&#160;")
}u.text(this.options.title)
},_createButtonPane:function(){this.uiDialogButtonPane=f("<div>").addClass("ui-dialog-buttonpane ui-widget-content ui-helper-clearfix");
this.uiButtonSet=f("<div>").addClass("ui-dialog-buttonset").appendTo(this.uiDialogButtonPane);
this._createButtons()
},_createButtons:function(){var v=this,u=this.options.buttons;
this.uiDialogButtonPane.remove();
this.uiButtonSet.empty();
if(f.isEmptyObject(u)||(f.isArray(u)&&!u.length)){this.uiDialog.removeClass("ui-dialog-buttons");
return
}f.each(u,function(w,x){var y,z;
x=f.isFunction(x)?{click:x,text:w}:x;
x=f.extend({type:"button"},x);
y=x.click;
x.click=function(){y.apply(v.element[0],arguments)
};
z={icons:x.icons,text:x.showText};
delete x.icons;
delete x.showText;
f("<button></button>",x).button(z).appendTo(v.uiButtonSet)
});
this.uiDialog.addClass("ui-dialog-buttons");
this.uiDialogButtonPane.appendTo(this.uiDialog)
},_makeDraggable:function(){var w=this,v=this.options;
function u(x){return{position:x.position,offset:x.offset}
}this.uiDialog.draggable({cancel:".ui-dialog-content, .ui-dialog-titlebar-close",handle:".ui-dialog-titlebar",containment:"document",start:function(x,y){f(this).addClass("ui-dialog-dragging");
w._blockFrames();
w._trigger("dragStart",x,u(y))
},drag:function(x,y){w._trigger("drag",x,u(y))
},stop:function(x,y){var A=y.offset.left-w.document.scrollLeft(),z=y.offset.top-w.document.scrollTop();
v.position={my:"left top",at:"left"+(A>=0?"+":"")+A+" top"+(z>=0?"+":"")+z,of:w.window};
f(this).removeClass("ui-dialog-dragging");
w._unblockFrames();
w._trigger("dragStop",x,u(y))
}})
},_makeResizable:function(){var z=this,x=this.options,y=x.resizable,u=this.uiDialog.css("position"),w=typeof y==="string"?y:"n,e,s,w,se,sw,ne,nw";
function v(A){return{originalPosition:A.originalPosition,originalSize:A.originalSize,position:A.position,size:A.size}
}this.uiDialog.resizable({cancel:".ui-dialog-content",containment:"document",alsoResize:this.element,maxWidth:x.maxWidth,maxHeight:x.maxHeight,minWidth:x.minWidth,minHeight:this._minHeight(),handles:w,start:function(A,B){f(this).addClass("ui-dialog-resizing");
z._blockFrames();
z._trigger("resizeStart",A,v(B))
},resize:function(A,B){z._trigger("resize",A,v(B))
},stop:function(A,B){var E=z.uiDialog.offset(),D=E.left-z.document.scrollLeft(),C=E.top-z.document.scrollTop();
x.height=z.uiDialog.height();
x.width=z.uiDialog.width();
x.position={my:"left top",at:"left"+(D>=0?"+":"")+D+" top"+(C>=0?"+":"")+C,of:z.window};
f(this).removeClass("ui-dialog-resizing");
z._unblockFrames();
z._trigger("resizeStop",A,v(B))
}}).css("position",u)
},_trackFocus:function(){this._on(this.widget(),{focusin:function(u){this._makeFocusTarget();
this._focusedElement=f(u.target)
}})
},_makeFocusTarget:function(){this._untrackInstance();
this._trackingInstances().unshift(this)
},_untrackInstance:function(){var v=this._trackingInstances(),u=f.inArray(this,v);
if(u!==-1){v.splice(u,1)
}},_trackingInstances:function(){var u=this.document.data("ui-dialog-instances");
if(!u){u=[];
this.document.data("ui-dialog-instances",u)
}return u
},_minHeight:function(){var u=this.options;
return u.height==="auto"?u.minHeight:Math.min(u.minHeight,u.height)
},_position:function(){var u=this.uiDialog.is(":visible");
if(!u){this.uiDialog.show()
}this.uiDialog.position(this.options.position);
if(!u){this.uiDialog.hide()
}},_setOptions:function(w){var x=this,v=false,u={};
f.each(w,function(y,z){x._setOption(y,z);
if(y in x.sizeRelatedOptions){v=true
}if(y in x.resizableRelatedOptions){u[y]=z
}});
if(v){this._size();
this._position()
}if(this.uiDialog.is(":data(ui-resizable)")){this.uiDialog.resizable("option",u)
}},_setOption:function(w,x){var v,y,u=this.uiDialog;
if(w==="dialogClass"){u.removeClass(this.options.dialogClass).addClass(x)
}if(w==="disabled"){return
}this._super(w,x);
if(w==="appendTo"){this.uiDialog.appendTo(this._appendTo())
}if(w==="buttons"){this._createButtons()
}if(w==="closeText"){this.uiDialogTitlebarClose.button({label:""+x})
}if(w==="draggable"){v=u.is(":data(ui-draggable)");
if(v&&!x){u.draggable("destroy")
}if(!v&&x){this._makeDraggable()
}}if(w==="position"){this._position()
}if(w==="resizable"){y=u.is(":data(ui-resizable)");
if(y&&!x){u.resizable("destroy")
}if(y&&typeof x==="string"){u.resizable("option","handles",x)
}if(!y&&x!==false){this._makeResizable()
}}if(w==="title"){this._title(this.uiDialogTitlebar.find(".ui-dialog-title"))
}},_size:function(){var u,w,x,v=this.options;
this.element.show().css({width:"auto",minHeight:0,maxHeight:"none",height:0});
if(v.minWidth>v.width){v.width=v.minWidth
}u=this.uiDialog.css({height:"auto",width:v.width}).outerHeight();
w=Math.max(0,v.minHeight-u);
x=typeof v.maxHeight==="number"?Math.max(0,v.maxHeight-u):"none";
if(v.height==="auto"){this.element.css({minHeight:w,maxHeight:x,height:"auto"})
}else{this.element.height(Math.max(0,v.height-u))
}if(this.uiDialog.is(":data(ui-resizable)")){this.uiDialog.resizable("option","minHeight",this._minHeight())
}},_blockFrames:function(){this.iframeBlocks=this.document.find("iframe").map(function(){var u=f(this);
return f("<div>").css({position:"absolute",width:u.outerWidth(),height:u.outerHeight()}).appendTo(u.parent()).offset(u.offset())[0]
})
},_unblockFrames:function(){if(this.iframeBlocks){this.iframeBlocks.remove();
delete this.iframeBlocks
}},_allowInteraction:function(u){if(f(u.target).closest(".ui-dialog").length){return true
}return !!f(u.target).closest(".ui-datepicker").length
},_createOverlay:function(){if(!this.options.modal){return
}var u=true;
this._delay(function(){u=false
});
if(!this.document.data("ui-dialog-overlays")){this._on(this.document,{focusin:function(v){if(u){return
}if(!this._allowInteraction(v)){v.preventDefault();
this._trackingInstances()[0]._focusTabbable()
}}})
}this.overlay=f("<div>").addClass("ui-widget-overlay ui-front").appendTo(this._appendTo());
this._on(this.overlay,{mousedown:"_keepFocus"});
this.document.data("ui-dialog-overlays",(this.document.data("ui-dialog-overlays")||0)+1)
},_destroyOverlay:function(){if(!this.options.modal){return
}if(this.overlay){var u=this.document.data("ui-dialog-overlays")-1;
if(!u){this.document.unbind("focusin").removeData("ui-dialog-overlays")
}else{this.document.data("ui-dialog-overlays",u)
}this.overlay.remove();
this.overlay=null
}}});
/*!
 * jQuery UI Slider 1.11.4
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 *
 * http://api.jqueryui.com/slider/
 */
var n=f.widget("ui.slider",f.ui.mouse,{version:"1.11.4",widgetEventPrefix:"slide",options:{animate:false,distance:0,max:100,min:0,orientation:"horizontal",range:false,step:1,value:0,values:null,change:null,slide:null,start:null,stop:null},numPages:5,_create:function(){this._keySliding=false;
this._mouseSliding=false;
this._animateOff=true;
this._handleIndex=null;
this._detectOrientation();
this._mouseInit();
this._calculateNewMax();
this.element.addClass("ui-slider ui-slider-"+this.orientation+" ui-widget ui-widget-content ui-corner-all");
this._refresh();
this._setOption("disabled",this.options.disabled);
this._animateOff=false
},_refresh:function(){this._createRange();
this._createHandles();
this._setupEvents();
this._refreshValue()
},_createHandles:function(){var x,u,v=this.options,z=this.element.find(".ui-slider-handle").addClass("ui-state-default ui-corner-all"),y="<span class='ui-slider-handle ui-state-default ui-corner-all' tabindex='0'></span>",w=[];
u=(v.values&&v.values.length)||1;
if(z.length>u){z.slice(u).remove();
z=z.slice(0,u)
}for(x=z.length;
x<u;
x++){w.push(y)
}this.handles=z.add(f(w.join("")).appendTo(this.element));
this.handle=this.handles.eq(0);
this.handles.each(function(A){f(this).data("ui-slider-handle-index",A)
})
},_createRange:function(){var u=this.options,v="";
if(u.range){if(u.range===true){if(!u.values){u.values=[this._valueMin(),this._valueMin()]
}else{if(u.values.length&&u.values.length!==2){u.values=[u.values[0],u.values[0]]
}else{if(f.isArray(u.values)){u.values=u.values.slice(0)
}}}}if(!this.range||!this.range.length){this.range=f("<div></div>").appendTo(this.element);
v="ui-slider-range ui-widget-header ui-corner-all"
}else{this.range.removeClass("ui-slider-range-min ui-slider-range-max").css({left:"",bottom:""})
}this.range.addClass(v+((u.range==="min"||u.range==="max")?" ui-slider-range-"+u.range:""))
}else{if(this.range){this.range.remove()
}this.range=null
}},_setupEvents:function(){this._off(this.handles);
this._on(this.handles,this._handleEvents);
this._hoverable(this.handles);
this._focusable(this.handles)
},_destroy:function(){this.handles.remove();
if(this.range){this.range.remove()
}this.element.removeClass("ui-slider ui-slider-horizontal ui-slider-vertical ui-widget ui-widget-content ui-corner-all");
this._mouseDestroy()
},_mouseCapture:function(w){var A,D,v,y,C,E,z,u,B=this,x=this.options;
if(x.disabled){return false
}this.elementSize={width:this.element.outerWidth(),height:this.element.outerHeight()};
this.elementOffset=this.element.offset();
A={x:w.pageX,y:w.pageY};
D=this._normValueFromMouse(A);
v=this._valueMax()-this._valueMin()+1;
this.handles.each(function(F){var G=Math.abs(D-B.values(F));
if((v>G)||(v===G&&(F===B._lastChangedValue||B.values(F)===x.min))){v=G;
y=f(this);
C=F
}});
E=this._start(w,C);
if(E===false){return false
}this._mouseSliding=true;
this._handleIndex=C;
y.addClass("ui-state-active").focus();
z=y.offset();
u=!f(w.target).parents().addBack().is(".ui-slider-handle");
this._clickOffset=u?{left:0,top:0}:{left:w.pageX-z.left-(y.width()/2),top:w.pageY-z.top-(y.height()/2)-(parseInt(y.css("borderTopWidth"),10)||0)-(parseInt(y.css("borderBottomWidth"),10)||0)+(parseInt(y.css("marginTop"),10)||0)};
if(!this.handles.hasClass("ui-state-hover")){this._slide(w,C,D)
}this._animateOff=true;
return true
},_mouseStart:function(){return true
},_mouseDrag:function(w){var u={x:w.pageX,y:w.pageY},v=this._normValueFromMouse(u);
this._slide(w,this._handleIndex,v);
return false
},_mouseStop:function(u){this.handles.removeClass("ui-state-active");
this._mouseSliding=false;
this._stop(u,this._handleIndex);
this._change(u,this._handleIndex);
this._handleIndex=null;
this._clickOffset=null;
this._animateOff=false;
return false
},_detectOrientation:function(){this.orientation=(this.options.orientation==="vertical")?"vertical":"horizontal"
},_normValueFromMouse:function(v){var u,y,x,w,z;
if(this.orientation==="horizontal"){u=this.elementSize.width;
y=v.x-this.elementOffset.left-(this._clickOffset?this._clickOffset.left:0)
}else{u=this.elementSize.height;
y=v.y-this.elementOffset.top-(this._clickOffset?this._clickOffset.top:0)
}x=(y/u);
if(x>1){x=1
}if(x<0){x=0
}if(this.orientation==="vertical"){x=1-x
}w=this._valueMax()-this._valueMin();
z=this._valueMin()+x*w;
return this._trimAlignValue(z)
},_start:function(w,v){var u={handle:this.handles[v],value:this.value()};
if(this.options.values&&this.options.values.length){u.value=this.values(v);
u.values=this.values()
}return this._trigger("start",w,u)
},_slide:function(y,x,w){var u,v,z;
if(this.options.values&&this.options.values.length){u=this.values(x?0:1);
if((this.options.values.length===2&&this.options.range===true)&&((x===0&&w>u)||(x===1&&w<u))){w=u
}if(w!==this.values(x)){v=this.values();
v[x]=w;
z=this._trigger("slide",y,{handle:this.handles[x],value:w,values:v});
u=this.values(x?0:1);
if(z!==false){this.values(x,w)
}}}else{if(w!==this.value()){z=this._trigger("slide",y,{handle:this.handles[x],value:w});
if(z!==false){this.value(w)
}}}},_stop:function(w,v){var u={handle:this.handles[v],value:this.value()};
if(this.options.values&&this.options.values.length){u.value=this.values(v);
u.values=this.values()
}this._trigger("stop",w,u)
},_change:function(w,v){if(!this._keySliding&&!this._mouseSliding){var u={handle:this.handles[v],value:this.value()};
if(this.options.values&&this.options.values.length){u.value=this.values(v);
u.values=this.values()
}this._lastChangedValue=v;
this._trigger("change",w,u)
}},value:function(u){if(arguments.length){this.options.value=this._trimAlignValue(u);
this._refreshValue();
this._change(null,0);
return
}return this._value()
},values:function(v,y){var x,u,w;
if(arguments.length>1){this.options.values[v]=this._trimAlignValue(y);
this._refreshValue();
this._change(null,v);
return
}if(arguments.length){if(f.isArray(arguments[0])){x=this.options.values;
u=arguments[0];
for(w=0;
w<x.length;
w+=1){x[w]=this._trimAlignValue(u[w]);
this._change(null,w)
}this._refreshValue()
}else{if(this.options.values&&this.options.values.length){return this._values(v)
}else{return this.value()
}}}else{return this._values()
}},_setOption:function(v,w){var u,x=0;
if(v==="range"&&this.options.range===true){if(w==="min"){this.options.value=this._values(0);
this.options.values=null
}else{if(w==="max"){this.options.value=this._values(this.options.values.length-1);
this.options.values=null
}}}if(f.isArray(this.options.values)){x=this.options.values.length
}if(v==="disabled"){this.element.toggleClass("ui-state-disabled",!!w)
}this._super(v,w);
switch(v){case"orientation":this._detectOrientation();
this.element.removeClass("ui-slider-horizontal ui-slider-vertical").addClass("ui-slider-"+this.orientation);
this._refreshValue();
this.handles.css(w==="horizontal"?"bottom":"left","");
break;
case"value":this._animateOff=true;
this._refreshValue();
this._change(null,0);
this._animateOff=false;
break;
case"values":this._animateOff=true;
this._refreshValue();
for(u=0;
u<x;
u+=1){this._change(null,u)
}this._animateOff=false;
break;
case"step":case"min":case"max":this._animateOff=true;
this._calculateNewMax();
this._refreshValue();
this._animateOff=false;
break;
case"range":this._animateOff=true;
this._refresh();
this._animateOff=false;
break
}},_value:function(){var u=this.options.value;
u=this._trimAlignValue(u);
return u
},_values:function(u){var x,w,v;
if(arguments.length){x=this.options.values[u];
x=this._trimAlignValue(x);
return x
}else{if(this.options.values&&this.options.values.length){w=this.options.values.slice();
for(v=0;
v<w.length;
v+=1){w[v]=this._trimAlignValue(w[v])
}return w
}else{return[]
}}},_trimAlignValue:function(x){if(x<=this._valueMin()){return this._valueMin()
}if(x>=this._valueMax()){return this._valueMax()
}var u=(this.options.step>0)?this.options.step:1,w=(x-this._valueMin())%u,v=x-w;
if(Math.abs(w)*2>=u){v+=(w>0)?u:(-u)
}return parseFloat(v.toFixed(5))
},_calculateNewMax:function(){var u=this.options.max,v=this._valueMin(),w=this.options.step,x=Math.floor((+(u-v).toFixed(this._precision()))/w)*w;
u=x+v;
this.max=parseFloat(u.toFixed(this._precision()))
},_precision:function(){var u=this._precisionOf(this.options.step);
if(this.options.min!==null){u=Math.max(u,this._precisionOf(this.options.min))
}return u
},_precisionOf:function(v){var w=v.toString(),u=w.indexOf(".");
return u===-1?0:w.length-u-1
},_valueMin:function(){return this.options.min
},_valueMax:function(){return this.max
},_refreshValue:function(){var z,y,C,A,D,x=this.options.range,w=this.options,B=this,v=(!this._animateOff)?w.animate:false,u={};
if(this.options.values&&this.options.values.length){this.handles.each(function(E){y=(B.values(E)-B._valueMin())/(B._valueMax()-B._valueMin())*100;
u[B.orientation==="horizontal"?"left":"bottom"]=y+"%";
f(this).stop(1,1)[v?"animate":"css"](u,w.animate);
if(B.options.range===true){if(B.orientation==="horizontal"){if(E===0){B.range.stop(1,1)[v?"animate":"css"]({left:y+"%"},w.animate)
}if(E===1){B.range[v?"animate":"css"]({width:(y-z)+"%"},{queue:false,duration:w.animate})
}}else{if(E===0){B.range.stop(1,1)[v?"animate":"css"]({bottom:(y)+"%"},w.animate)
}if(E===1){B.range[v?"animate":"css"]({height:(y-z)+"%"},{queue:false,duration:w.animate})
}}}z=y
})
}else{C=this.value();
A=this._valueMin();
D=this._valueMax();
y=(D!==A)?(C-A)/(D-A)*100:0;
u[this.orientation==="horizontal"?"left":"bottom"]=y+"%";
this.handle.stop(1,1)[v?"animate":"css"](u,w.animate);
if(x==="min"&&this.orientation==="horizontal"){this.range.stop(1,1)[v?"animate":"css"]({width:y+"%"},w.animate)
}if(x==="max"&&this.orientation==="horizontal"){this.range[v?"animate":"css"]({width:(100-y)+"%"},{queue:false,duration:w.animate})
}if(x==="min"&&this.orientation==="vertical"){this.range.stop(1,1)[v?"animate":"css"]({height:y+"%"},w.animate)
}if(x==="max"&&this.orientation==="vertical"){this.range[v?"animate":"css"]({height:(100-y)+"%"},{queue:false,duration:w.animate})
}}},_handleEvents:{keydown:function(y){var z,w,v,x,u=f(y.target).data("ui-slider-handle-index");
switch(y.keyCode){case f.ui.keyCode.HOME:case f.ui.keyCode.END:case f.ui.keyCode.PAGE_UP:case f.ui.keyCode.PAGE_DOWN:case f.ui.keyCode.UP:case f.ui.keyCode.RIGHT:case f.ui.keyCode.DOWN:case f.ui.keyCode.LEFT:y.preventDefault();
if(!this._keySliding){this._keySliding=true;
f(y.target).addClass("ui-state-active");
z=this._start(y,u);
if(z===false){return
}}break
}x=this.options.step;
if(this.options.values&&this.options.values.length){w=v=this.values(u)
}else{w=v=this.value()
}switch(y.keyCode){case f.ui.keyCode.HOME:v=this._valueMin();
break;
case f.ui.keyCode.END:v=this._valueMax();
break;
case f.ui.keyCode.PAGE_UP:v=this._trimAlignValue(w+((this._valueMax()-this._valueMin())/this.numPages));
break;
case f.ui.keyCode.PAGE_DOWN:v=this._trimAlignValue(w-((this._valueMax()-this._valueMin())/this.numPages));
break;
case f.ui.keyCode.UP:case f.ui.keyCode.RIGHT:if(w===this._valueMax()){return
}v=this._trimAlignValue(w+x);
break;
case f.ui.keyCode.DOWN:case f.ui.keyCode.LEFT:if(w===this._valueMin()){return
}v=this._trimAlignValue(w-x);
break
}this._slide(y,u,v)
},keyup:function(v){var u=f(v.target).data("ui-slider-handle-index");
if(this._keySliding){this._keySliding=false;
this._stop(v,u);
this._change(v,u);
f(v.target).removeClass("ui-state-active")
}}}})
}));
/*!
 * jQuery UI Touch Punch 0.2.3
 *
 * Copyright 2011–2014, Dave Furfero
 * Dual licensed under the MIT or GPL Version 2 licenses.
 *
 * Depends:
 *  jquery.ui.widget.js
 *  jquery.ui.mouse.js
 */
!function(h){function i(f,e){if(!(f.originalEvent.touches.length>1)){f.preventDefault();
var n=f.originalEvent.changedTouches[0],m=document.createEvent("MouseEvents");
m.initMouseEvent(e,!0,!0,window,1,n.screenX,n.screenY,n.clientX,n.clientY,!1,!1,!1,!1,0,null),f.target.dispatchEvent(m)
}}if(h.support.touch="ontouchend" in document,h.support.touch){var j,g=h.ui.mouse.prototype,l=g._mouseInit,k=g._mouseDestroy;
g._touchStart=function(d){var c=this;
!j&&c._mouseCapture(d.originalEvent.changedTouches[0])&&(j=!0,c._touchMoved=!1,i(d,"mouseover"),i(d,"mousemove"),i(d,"mousedown"))
},g._touchMove=function(b){j&&(this._touchMoved=!0,i(b,"mousemove"))
},g._touchEnd=function(b){j&&(i(b,"mouseup"),i(b,"mouseout"),this._touchMoved||i(b,"click"),j=!1)
},g._mouseInit=function(){var a=this;
a.element.bind({touchstart:h.proxy(a,"_touchStart"),touchmove:h.proxy(a,"_touchMove"),touchend:h.proxy(a,"_touchEnd")}),l.call(a)
},g._mouseDestroy=function(){var a=this;
a.element.unbind({touchstart:h.proxy(a,"_touchStart"),touchmove:h.proxy(a,"_touchMove"),touchend:h.proxy(a,"_touchEnd")}),k.call(a)
}
}}(jQuery);
(function(a){if(typeof define==="function"&&define.amd){define(["jquery"],a)
}else{if(typeof exports==="object"&&typeof require==="function"){a(require("jquery"))
}else{a(jQuery)
}}}(function(d){var a=(function(){return{escapeRegExChars:function(e){return e.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&")
},createNode:function(e){var f=document.createElement("div");
f.className=e;
f.style.display="none";
return f
}}
}()),c={ESC:27,TAB:9,RETURN:13,LEFT:37,UP:38,RIGHT:39,DOWN:40};
function b(f,e){var h=function(){},g=this,i={ajaxSettings:{},autoSelectFirst:false,appendTo:document.body,serviceUrl:null,lookup:null,onSelect:null,width:"auto",minChars:1,maxHeight:300,deferRequestBy:0,params:{},formatResult:b.formatResult,delimiter:null,zIndex:9999,type:"GET",noCache:false,onSearchStart:h,onSearchComplete:h,onSearchError:h,preserveInput:false,containerClass:"autocomplete-suggestions",suggestionsWrapperClass:"autocomplete-suggestions-wrapper",tabDisabled:false,dataType:"text",currentRequest:null,triggerSelectOnValidInput:true,preventBadQueries:true,lookupFilter:function(k,j,l){return k.value.toLowerCase().indexOf(l)!==-1
},paramName:"query",transformResult:function(j){return typeof j==="string"?d.parseJSON(j):j
},showNoSuggestionNotice:false,noSuggestionNotice:"No results",orientation:"bottom",forceFixPosition:false};
g.element=f;
g.el=d(f);
g.suggestions=[];
g.badQueries=[];
g.selectedIndex=-1;
g.currentValue=g.element.value;
g.intervalId=0;
g.cachedResponse={};
g.onChangeInterval=null;
g.onChange=null;
g.isLocal=false;
g.suggestionsContainer=null;
g.noSuggestionsContainer=null;
g.options=d.extend({},i,e);
g.classes={selected:"autocomplete-selected",suggestion:"autocomplete-suggestion"};
g.hint=null;
g.hintValue="";
g.selection=null;
g.initialize();
g.setOptions(e)
}b.utils=a;
d.Autocomplete=b;
b.formatResult=function(e,f){var h=e.value.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
var g="("+a.escapeRegExChars(f)+")";
return h.replace(new RegExp(g,"gi"),"<strong>$1</strong>")
};
b.prototype={killerFn:null,initialize:function(){var i=this,j="."+i.classes.suggestion,g=i.classes.selected,f=i.options,e;
i.element.setAttribute("autocomplete","off");
i.killerFn=function(k){if(d(k.target).closest("."+i.options.containerClass).length===0){i.killSuggestions();
i.disableKillerFn()
}};
i.noSuggestionsContainer=d('<div class="autocomplete-no-suggestion"></div>').html(this.options.noSuggestionNotice).get(0);
i.suggestionsContainer=b.utils.createNode(f.containerClass);
e=d(i.suggestionsContainer);
var h=d("."+f.suggestionsWrapperClass);
e.appendTo(h);
if(f.width!=="auto"){e.width(f.width)
}e.on("mouseover.autocomplete",j,function(){i.activate(d(this).data("index"))
});
e.on("mouseout.autocomplete",function(){i.selectedIndex=-1;
e.children("."+g).removeClass(g)
});
e.on("click.autocomplete",j,function(){i.select(d(this).data("index"))
});
i.fixPositionCapture=function(){if(i.visible){i.fixPosition()
}};
d(window).on("resize.autocomplete",i.fixPositionCapture);
i.el.on("keydown.autocomplete",function(k){i.onKeyPress(k)
});
i.el.on("keyup.autocomplete",function(k){i.onKeyUp(k)
});
i.el.on("blur.autocomplete",function(){i.onBlur()
});
i.el.on("focus.autocomplete",function(){i.onFocus()
});
i.el.on("change.autocomplete",function(k){i.onKeyUp(k)
});
i.el.on("input.autocomplete",function(k){i.onKeyUp(k)
})
},onFocus:function(){var e=this;
e.fixPosition();
if(e.options.minChars<=e.el.val().length){e.onValueChange()
}},onBlur:function(){this.enableKillerFn()
},setOptions:function(g){var f=this,e=f.options;
d.extend(e,g);
f.isLocal=d.isArray(e.lookup);
if(f.isLocal){e.lookup=f.verifySuggestionsFormat(e.lookup)
}e.orientation=f.validateOrientation(e.orientation,"bottom")
},clearCache:function(){this.cachedResponse={};
this.badQueries=[]
},clear:function(){this.clearCache();
this.currentValue="";
this.suggestions=[]
},disable:function(){var e=this;
e.disabled=true;
clearInterval(e.onChangeInterval);
if(e.currentRequest){e.currentRequest.abort()
}},enable:function(){this.disabled=false
},fixPosition:function(){},enableKillerFn:function(){var e=this;
d(document).on("click.autocomplete",e.killerFn)
},disableKillerFn:function(){var e=this;
d(document).off("click.autocomplete",e.killerFn)
},killSuggestions:function(){var e=this;
e.stopKillSuggestions();
e.intervalId=window.setInterval(function(){e.hide();
e.stopKillSuggestions()
},50)
},stopKillSuggestions:function(){window.clearInterval(this.intervalId)
},isCursorAtEnd:function(){var g=this,f=g.el.val().length,h=g.element.selectionStart,e;
if(typeof h==="number"){return h===f
}if(document.selection){e=document.selection.createRange();
e.moveStart("character",-f);
return f===e.text.length
}return true
},onKeyPress:function(g){var f=this;
if(!f.disabled&&!f.visible&&g.which===c.DOWN&&f.currentValue){f.suggest();
return
}if(f.disabled||!f.visible){return
}switch(g.which){case c.ESC:f.el.val(f.currentValue);
f.hide();
break;
case c.RIGHT:if(f.hint&&f.options.onHint&&f.isCursorAtEnd()){f.selectHint();
break
}return;
case c.TAB:if(f.hint&&f.options.onHint){f.selectHint();
return
}if(f.selectedIndex===-1){f.hide();
return
}f.select(f.selectedIndex);
if(f.options.tabDisabled===false){return
}break;
case c.RETURN:if(f.selectedIndex===-1){f.hide();
return
}f.select(f.selectedIndex);
break;
case c.UP:f.moveUp();
break;
case c.DOWN:f.moveDown();
break;
default:return
}g.stopImmediatePropagation();
g.preventDefault()
},onKeyUp:function(g){var f=this;
if(f.disabled){return
}switch(g.which){case c.UP:case c.DOWN:return
}clearInterval(f.onChangeInterval);
if(f.currentValue!==f.el.val()){f.findBestHint();
if(f.options.deferRequestBy>0){f.onChangeInterval=setInterval(function(){f.onValueChange()
},f.options.deferRequestBy)
}else{f.onValueChange()
}}},onValueChange:function(){var g=this,f=g.options,i=g.el.val(),h=g.getQuery(i),e;
if(g.selection&&g.currentValue!==h){g.selection=null;
(f.onInvalidateSelection||d.noop).call(g.element)
}clearInterval(g.onChangeInterval);
g.currentValue=i;
g.selectedIndex=-1;
if(f.triggerSelectOnValidInput){e=g.findSuggestionIndex(h);
if(e!==-1){g.select(e);
return
}}if(h.length<f.minChars){g.hide()
}else{g.getSuggestions(h)
}},findSuggestionIndex:function(h){var g=this,f=-1,e=h.toLowerCase();
d.each(g.suggestions,function(k,j){if(j.value.toLowerCase()===e){f=k;
return false
}});
return f
},getQuery:function(f){var e=this.options.delimiter,g;
if(!e){return f
}g=f.split(e);
return d.trim(g[g.length-1])
},getSuggestionsLocal:function(k){var i=this,g=i.options,f=k.toLowerCase(),h=g.lookupFilter,e=parseInt(g.lookupLimit,10),j;
j={suggestions:d.grep(g.lookup,function(l){return h(l,k,f)
})};
if(e&&j.suggestions.length>e){j.suggestions=j.suggestions.slice(0,e)
}return j
},getSuggestions:function(i){var e,g=this,f=g.options,j=f.serviceUrl,l,k,h;
f.params[f.paramName]=i;
l=f.ignoreParams?null:f.params;
if(f.onSearchStart.call(g.element,f.params)===false){return
}if(d.isFunction(f.lookup)){f.lookup(i,function(m){g.suggestions=m.suggestions;
g.suggest();
f.onSearchComplete.call(g.element,i,m.suggestions)
});
return
}if(g.isLocal){e=g.getSuggestionsLocal(i)
}else{if(d.isFunction(j)){j=j.call(g.element,i)
}k=j+"?"+d.param(l||{});
e=g.cachedResponse[k]
}if(e&&d.isArray(e.suggestions)){g.suggestions=e.suggestions;
g.suggest();
f.onSearchComplete.call(g.element,i,e.suggestions)
}else{if(!g.isBadQuery(i)){if(g.currentRequest){g.currentRequest.abort()
}h={url:j,data:l,type:f.type,dataType:f.dataType};
d.extend(h,f.ajaxSettings);
g.currentRequest=d.ajax(h).done(function(n){var m;
g.currentRequest=null;
m=f.transformResult(n);
g.processResponse(m,i,k);
f.onSearchComplete.call(g.element,i,m.suggestions)
}).fail(function(m,o,n){f.onSearchError.call(g.element,i,m,o,n)
})
}else{f.onSearchComplete.call(g.element,i,[])
}}},isBadQuery:function(f){if(!this.options.preventBadQueries){return false
}var g=this.badQueries,e=g.length;
while(e--){if(f.indexOf(g[e])===0){return true
}}return false
},hide:function(){var f=this,e=d(f.suggestionsContainer);
if(d.isFunction(f.options.onHide)&&f.visible){f.options.onHide.call(f.element,e)
}f.visible=false;
f.selectedIndex=-1;
clearInterval(f.onChangeInterval);
d(f.suggestionsContainer).hide();
f.signalHint(null)
},suggest:function(){if(this.suggestions.length===0){if(this.options.showNoSuggestionNotice){this.noSuggestions()
}else{this.hide()
}return
}var l=this,r=l.options,p=r.groupBy,n=r.formatResult,o=l.getQuery(l.currentValue),m=l.classes.suggestion,g=l.classes.selected,e=d(l.suggestionsContainer),j=d(l.noSuggestionsContainer),q=r.beforeRender,i="",f,h=function(t,u){var s=t.data[p];
if(f===s){return""
}f=s;
return'<div class="autocomplete-group"><strong>'+f+"</strong></div>"
},k;
if(r.triggerSelectOnValidInput){k=l.findSuggestionIndex(o);
if(k!==-1){l.select(k);
return
}}d.each(l.suggestions,function(t,s){if(p){i+=h(s,o,t)
}i+='<div class="'+m+'" data-index="'+t+'">'+n(s,o)+"</div>"
});
this.adjustContainerWidth();
j.detach();
e.html(i);
if(d.isFunction(q)){q.call(l.element,e)
}l.fixPosition();
e.show();
e.closest("."+r.suggestionsWrapperClass).show();
if(r.autoSelectFirst){l.selectedIndex=0;
e.scrollTop(0);
e.children("."+m).first().addClass(g)
}l.visible=true;
l.findBestHint()
},noSuggestions:function(){var g=this,e=d(g.suggestionsContainer),f=d(g.noSuggestionsContainer);
this.adjustContainerWidth();
f.detach();
e.empty();
e.append(f);
g.fixPosition();
e.show();
g.visible=true;
e.closest("."+g.options.suggestionsWrapperClass).hide()
},adjustContainerWidth:function(){},findBestHint:function(){var f=this,g=f.el.val().toLowerCase(),e=null;
if(!g){return
}d.each(f.suggestions,function(j,h){var k=h.value.toLowerCase().indexOf(g)===0;
if(k){e=h
}return !k
});
f.signalHint(e)
},signalHint:function(f){var e="",g=this;
if(f){e=g.currentValue+f.value.substr(g.currentValue.length)
}if(g.hintValue!==e){g.hintValue=e;
g.hint=f;
(this.options.onHint||d.noop)(e)
}},verifySuggestionsFormat:function(e){if(e.length&&typeof e[0]==="string"){return d.map(e,function(f){return{value:f,data:null}
})
}return e
},validateOrientation:function(e,f){e=d.trim(e||"").toLowerCase();
if(d.inArray(e,["auto","bottom","top"])===-1){e=f
}return e
},processResponse:function(e,f,i){var h=this,g=h.options;
e.suggestions=h.verifySuggestionsFormat(e.suggestions);
if(!g.noCache){h.cachedResponse[i]=e;
if(g.preventBadQueries&&e.suggestions.length===0){h.badQueries.push(f)
}}if(f!==h.getQuery(h.currentValue)){return
}h.suggestions=e.suggestions;
h.suggest()
},activate:function(f){var i=this,j,h=i.classes.selected,e=d(i.suggestionsContainer),g=e.find("."+i.classes.suggestion);
e.find("."+h).removeClass(h);
i.selectedIndex=f;
if(i.selectedIndex!==-1&&g.length>i.selectedIndex){j=g.get(i.selectedIndex);
d(j).addClass(h);
return j
}return null
},selectHint:function(){var f=this,e=d.inArray(f.hint,f.suggestions);
f.select(e)
},select:function(e){var f=this;
f.hide();
f.onSelect(e)
},moveUp:function(){var e=this;
if(e.selectedIndex===-1){return
}if(e.selectedIndex===0){d(e.suggestionsContainer).children().first().removeClass(e.classes.selected);
e.selectedIndex=-1;
e.el.val(e.currentValue);
e.findBestHint();
return
}e.adjustScroll(e.selectedIndex-1)
},moveDown:function(){var e=this;
if(e.selectedIndex===(e.suggestions.length-1)){return
}e.adjustScroll(e.selectedIndex+1)
},adjustScroll:function(e){var g=this,k=g.activate(e);
if(!k){return
}var f,i,j,h=d(k).outerHeight();
f=k.offsetTop;
i=d(g.suggestionsContainer).scrollTop();
j=i+g.options.maxHeight-h;
if(f<i){d(g.suggestionsContainer).scrollTop(f)
}else{if(f>j){d(g.suggestionsContainer).scrollTop(f-g.options.maxHeight+h)
}}if(!g.options.preserveInput){g.el.val(g.getValue(g.suggestions[e].value))
}g.signalHint(null)
},onSelect:function(f){var h=this,g=h.options.onSelect,e=h.suggestions[f];
h.currentValue=h.getValue(e.value);
if(h.currentValue!==h.el.val()&&!h.options.preserveInput){h.el.val(h.currentValue)
}h.signalHint(null);
h.suggestions=[];
h.selection=e;
if(d.isFunction(g)){g.call(h.element,e)
}},getValue:function(h){var g=this,e=g.options.delimiter,f,i;
if(!e){return h
}f=g.currentValue;
i=f.split(e);
if(i.length===1){return h
}return f.substr(0,f.length-i[i.length-1].length)+h
},dispose:function(){var e=this;
e.el.off(".autocomplete").removeData("autocomplete");
e.disableKillerFn();
d(window).off("resize.autocomplete",e.fixPositionCapture);
d(e.suggestionsContainer).remove()
}};
d.fn.autocomplete=d.fn.devbridgeAutocomplete=function(f,e){var g="autocomplete";
if(arguments.length===0){return this.first().data(g)
}return this.each(function(){var i=d(this),h=i.data(g);
if(typeof f==="string"){if(h&&typeof h[f]==="function"){h[f](e)
}}else{if(h&&h.dispose){h.dispose()
}h=new b(this,f);
i.data(g,h)
}})
}
}));
jQuery.easing.jswing=jQuery.easing.swing;
jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(j,i,b,c,d){return jQuery.easing[jQuery.easing.def](j,i,b,c,d)
},easeInQuad:function(j,i,b,c,d){return c*(i/=d)*i+b
},easeOutQuad:function(j,i,b,c,d){return -c*(i/=d)*(i-2)+b
},easeInOutQuad:function(j,i,b,c,d){if((i/=d/2)<1){return c/2*i*i+b
}return -c/2*((--i)*(i-2)-1)+b
},easeInCubic:function(j,i,b,c,d){return c*(i/=d)*i*i+b
},easeOutCubic:function(j,i,b,c,d){return c*((i=i/d-1)*i*i+1)+b
},easeInOutCubic:function(j,i,b,c,d){if((i/=d/2)<1){return c/2*i*i*i+b
}return c/2*((i-=2)*i*i+2)+b
},easeInQuart:function(j,i,b,c,d){return c*(i/=d)*i*i*i+b
},easeOutQuart:function(j,i,b,c,d){return -c*((i=i/d-1)*i*i*i-1)+b
},easeInOutQuart:function(j,i,b,c,d){if((i/=d/2)<1){return c/2*i*i*i*i+b
}return -c/2*((i-=2)*i*i*i-2)+b
},easeInQuint:function(j,i,b,c,d){return c*(i/=d)*i*i*i*i+b
},easeOutQuint:function(j,i,b,c,d){return c*((i=i/d-1)*i*i*i*i+1)+b
},easeInOutQuint:function(j,i,b,c,d){if((i/=d/2)<1){return c/2*i*i*i*i*i+b
}return c/2*((i-=2)*i*i*i*i+2)+b
},easeInSine:function(j,i,b,c,d){return -c*Math.cos(i/d*(Math.PI/2))+c+b
},easeOutSine:function(j,i,b,c,d){return c*Math.sin(i/d*(Math.PI/2))+b
},easeInOutSine:function(j,i,b,c,d){return -c/2*(Math.cos(Math.PI*i/d)-1)+b
},easeInExpo:function(j,i,b,c,d){return(i==0)?b:c*Math.pow(2,10*(i/d-1))+b
},easeOutExpo:function(j,i,b,c,d){return(i==d)?b+c:c*(-Math.pow(2,-10*i/d)+1)+b
},easeInOutExpo:function(j,i,b,c,d){if(i==0){return b
}if(i==d){return b+c
}if((i/=d/2)<1){return c/2*Math.pow(2,10*(i-1))+b
}return c/2*(-Math.pow(2,-10*--i)+2)+b
},easeInCirc:function(j,i,b,c,d){return -c*(Math.sqrt(1-(i/=d)*i)-1)+b
},easeOutCirc:function(j,i,b,c,d){return c*Math.sqrt(1-(i=i/d-1)*i)+b
},easeInOutCirc:function(j,i,b,c,d){if((i/=d/2)<1){return -c/2*(Math.sqrt(1-i*i)-1)+b
}return c/2*(Math.sqrt(1-(i-=2)*i)+1)+b
},easeInElastic:function(o,m,p,a,b){var d=1.70158;
var c=0;
var n=a;
if(m==0){return p
}if((m/=b)==1){return p+a
}if(!c){c=b*0.3
}if(n<Math.abs(a)){n=a;
var d=c/4
}else{var d=c/(2*Math.PI)*Math.asin(a/n)
}return -(n*Math.pow(2,10*(m-=1))*Math.sin((m*b-d)*(2*Math.PI)/c))+p
},easeOutElastic:function(o,m,p,a,b){var d=1.70158;
var c=0;
var n=a;
if(m==0){return p
}if((m/=b)==1){return p+a
}if(!c){c=b*0.3
}if(n<Math.abs(a)){n=a;
var d=c/4
}else{var d=c/(2*Math.PI)*Math.asin(a/n)
}return n*Math.pow(2,-10*m)*Math.sin((m*b-d)*(2*Math.PI)/c)+a+p
},easeInOutElastic:function(o,m,p,a,b){var d=1.70158;
var c=0;
var n=a;
if(m==0){return p
}if((m/=b/2)==2){return p+a
}if(!c){c=b*(0.3*1.5)
}if(n<Math.abs(a)){n=a;
var d=c/4
}else{var d=c/(2*Math.PI)*Math.asin(a/n)
}if(m<1){return -0.5*(n*Math.pow(2,10*(m-=1))*Math.sin((m*b-d)*(2*Math.PI)/c))+p
}return n*Math.pow(2,-10*(m-=1))*Math.sin((m*b-d)*(2*Math.PI)/c)*0.5+a+p
},easeInBack:function(l,k,b,c,d,j){if(j==undefined){j=1.70158
}return c*(k/=d)*k*((j+1)*k-j)+b
},easeOutBack:function(l,k,b,c,d,j){if(j==undefined){j=1.70158
}return c*((k=k/d-1)*k*((j+1)*k+j)+1)+b
},easeInOutBack:function(l,k,b,c,d,j){if(j==undefined){j=1.70158
}if((k/=d/2)<1){return c/2*(k*k*(((j*=(1.525))+1)*k-j))+b
}return c/2*((k-=2)*k*(((j*=(1.525))+1)*k+j)+2)+b
},easeInBounce:function(j,i,b,c,d){return c-jQuery.easing.easeOutBounce(j,d-i,0,c,d)+b
},easeOutBounce:function(j,i,b,c,d){if((i/=d)<(1/2.75)){return c*(7.5625*i*i)+b
}else{if(i<(2/2.75)){return c*(7.5625*(i-=(1.5/2.75))*i+0.75)+b
}else{if(i<(2.5/2.75)){return c*(7.5625*(i-=(2.25/2.75))*i+0.9375)+b
}else{return c*(7.5625*(i-=(2.625/2.75))*i+0.984375)+b
}}}},easeInOutBounce:function(j,i,b,c,d){if(i<d/2){return jQuery.easing.easeInBounce(j,i*2,0,c,d)*0.5+b
}return jQuery.easing.easeOutBounce(j,i*2-d,0,c,d)*0.5+c*0.5+b
}});
$(function(){$(".searchresult-item a").click(function(){$.ajax({url:$(this).attr("href").replace(/(?:\.html)?(?:\?\S*)?$/,"")+".searchresultclick.json",cache:false,data:{resultType:"explizit",queryId:$(this).closest("ul.searchresult-items").attr("data-queryId")},timeout:500,async:false,dataType:"json"})
})
});
(function(a,b){if(typeof define==="function"&&define.amd){define(b)
}else{if(typeof module==="object"&&module.exports){module.exports=b()
}else{a.SLURI=b()
}}}(this,function(){var e=1,d="",c="Failed to construct 'URL': Invalid URL";
function f(i){return encodeURI(i).replace(/%5B/g,"[").replace(/%5D/g,"]")
}function a(i){return encodeURIComponent(i).replace(/[!'()*]/g,function(j){return"%"+j.charCodeAt(0).toString(16)
})
}function g(j){var l,n,m=[];
if(j){l=(d+j).replace("?","");
n=l.split("&");
for(var i=0;
i<n.length;
i++){var k=n[i].split("=");
m.push({key:k[0],value:k[1]||d})
}}this.toString=function(){var p=[];
for(var o=0;
o<m.length;
o++){p.push(a(m[o].key)+"="+a(m[o].value))
}return p.length>0?p.join("&"):d
};
this.toLocaleString=function(){return this.toString()
};
this.has=function(p){for(var o=0;
o<m.length;
o++){if(m[o].key===p){return true
}}return false
};
this.get=function(p){for(var o=0;
o<m.length;
o++){if(m[o].key===p){return m[o].value
}}return null
};
this.getAll=function(q){var p=[];
for(var o=0;
o<m.length;
o++){if(m[o].key===q){p.push(m[o].value)
}}return p
};
this.sluriDelete=function(p){for(var o=0;
o<m.length;
o++){if(m[o].key===p){m.splice(o,1)
}}};
this.append=function(o,p){m.push({key:o,value:p})
};
this.set=function(p,r){var q=0;
for(var o=0;
o<m.length;
o++){if(m[o].key===p){if(!q){m[o].value=r
}else{m.splice(o,1)
}q++
}}if(q===0){this.append(p,r)
}};
this.keys=function(){var p=[];
for(var o=0;
o<m.length;
o++){p.push(m[o].key)
}return p
};
this.values=function(){var p=[];
for(var o=0;
o<m.length;
o++){p.push(m[o].value)
}return p
}
}function b(j){var i=[];
if(j){i=j.split(".")
}this.toString=function(){return f(i.join("."))
};
this.toLocaleString=function(){return this.toString()
};
this.has=function(k){return i.indexOf(k)!==-1
};
this.append=function(k){i.push(k)
};
this.sluriDelete=function(k){var l=i.indexOf(k);
if(l!==-1){i.splice(l,1)
}};
this.values=function(){return i
}
}var h=function(z,C){var n=this,o,B,t,q,y,j,l,w,p,u,v,A;
if(!(this instanceof h)){throw new TypeError("Failed to construct 'SLURI': Please use the 'new' operator, this DOM object constructor cannot be called as a function.")
}if(arguments.length<e){throw new TypeError("Failed to construct 'URL': "+e+" argument required, but only "+arguments.length+" present.")
}function x(E){return/^[a-zA-Z][a-zA-Z0-9+\.-]+:\/\//.test(E)
}function k(E){return E instanceof h||(typeof Location!=="undefined"&&E instanceof Location)||(typeof HTMLAnchorElement!=="undefined"&&E instanceof HTMLAnchorElement)||(typeof URL!=="undefined"&&E instanceof URL)
}function s(E){var G=E%256;
for(var F=3;
F>0;
F--){E=Math.floor(E/256);
G=E%256+"."+G
}return G
}function D(E){var F,I="/",J="/",G="",K="",H="";
if(E){E=""+E;
if(E.indexOf("/")!==0){E="/"+E
}F=E.split(".");
J=F[0];
G=F.slice(1,F.length-1).join(".");
K=F[F.length-1].split("/")[0];
if(F.length>=2){H=F[F.length-1].split("/").slice(1).join("/");
H=H?"/"+H:"";
I=J+"."+(G&&(G+"."))+K
}else{F=E.split("/");
I=F.length>2?F[1]:E
}}return{pathname:I,resourcePath:J,selectorString:G,extension:K,suffix:H}
}function m(G){var K,J,M,P,I,N,L,E,O,Q,H,F;
K=new RegExp(/^(?:(?:(([^:\/#\?]+:)?(?:(?:\/\/)(?:(?:(?:([^:@\/#\?]+)(?:\:([^:@\/#\?]*))?)@)?(([^:\/#\?]+|\[[^\/\]@#?]+\])(?:\:([0-9]+))?))?)?)?((?:\/?(?:[^\/\?#]+\/+)*)(?:[^\?#]*)))?(\?[^#]+)?)(#.*)?/);
J=K.exec(G);
M=J[1]||"";
P=J[2]||"";
I=J[3]||"";
N=J[4]||"";
L=J[6]||"";
E=J[7]||"";
O=J[8]||"";
Q=J[9]||"";
H=J[10]||"";
F=D(O);
return{protocol:P,username:I,password:N,hostname:L,port:E,origin:M,pathname:F.pathname,resourcePath:F.resourcePath,selectorString:F.selectorString,extension:F.extension,suffix:F.suffix,search:Q,hash:H}
}function r(E){n.protocol=E.protocol;
n.username=E.username;
n.password=E.password;
n.hostname=E.hostname;
n.port=E.port;
l=f(E.resourcePath);
n.selectorString=E.selectorString;
p=f(E.extension);
n.suffix=E.suffix;
n.search=E.search;
n.hash=E.hash
}function i(){var E,F;
if(typeof z==="string"){if(z.indexOf("/")===0){if(C){if(k(C)){E=C.origin
}else{F=m(C);
E=F.hostname&&F.origin
}if(E){z=E+z;
o=m(z)
}}}else{if(x(z)){o=m(z)
}}}else{if(k(z)){o=m(z.href)
}}if(!o){throw new TypeError(c)
}}Object.defineProperties(this,{protocol:{enumerable:true,configurable:true,get:function(){return B||d
},set:function(E){if(E&&/^[a-zA-Z][a-zA-Z0-9+\.-]+:?$/.test(E)){B=E.substr(-1)===":"?E:E+":"
}}},username:{enumerable:true,configurable:true,get:function(){return t||d
},set:function(E){t=f(d+E)
}},password:{enumerable:true,configurable:true,get:function(){return q||d
},set:function(E){q=f(d+E)
}},hostname:{enumerable:true,configurable:true,get:function(){return y||d
},set:function(E){if(E){if(!isNaN(E)){y=s(E)
}else{y=f(E.split(":")[0])
}}}},host:{enumerable:true,configurable:true,get:function(){var E=y||d;
if(j){E+=":"+j
}return E
},set:function(E){if(E){var F=E.split(":"),H=F[0],G=F[1];
this.hostname=H;
if(G){this.port=G
}}}},port:{enumerable:true,configurable:true,get:function(){return j||d
},set:function(E){if(E!==null&&E!==undefined){if(E===d){j=E
}else{if(typeof E==="number"||/^\d+(\.\d+)?$/.test(E)){j=d+parseInt(E,10)
}}}}},origin:{enumerable:true,configurable:true,get:function(){return this.protocol+"//"+this.host
},set:function(){}},pathname:{enumerable:true,configurable:true,get:function(){var E;
if(l&&l!=="/"){E=l;
if(this.selectorString){E+="."+this.selectorString
}if(p){E+="."+p
}}return E||"/"
},set:function(F){var E;
if(!null&&!undefined){E=D(F);
l=f(E.resourcePath);
p=f(E.extension);
this.selectorString=E.selectorString
}}},resourcePath:{enumerable:true,configurable:true,get:function(){return l
},set:function(E){if(E!==null&&E!==undefined){l=f(E)
}}},selectorString:{enumerable:true,configurable:true,get:function(){return this.selectors.toString()
},set:function(E){if(E!==null&&E!==undefined){this.selectors=new b(E)
}}},selectors:{enumerable:true,configurable:true,get:function(){return w
},set:function(E){if(E instanceof b){w=E
}}},extension:{enumerable:true,configurable:true,get:function(){return p||""
},set:function(E){if(p&&E){p=f(E)
}}},suffix:{enumerable:true,configurable:true,get:function(){return u
},set:function(E){if(E!==null&&E!==undefined){u=f(E)
}}},search:{enumerable:true,configurable:true,get:function(){var E=v.toString();
return E?"?"+E:d
},set:function(E){if(E!==null&&E!==undefined){v=new g(E)
}}},searchParams:{enumerable:true,configurable:true,get:function(){return v
},set:function(E){if(E instanceof g){v=E
}}},hash:{enumerable:true,configurable:true,get:function(){return A||d
},set:function(E){if(E){A=E.indexOf("#")===0?E:"#"+E
}else{A=d
}}},href:{enumerable:true,configurable:true,get:function(){var E=[];
E.push(this.protocol+"//");
E.push(this.username);
E.push(this.password&&":"+this.password);
E.push((this.username||this.password)&&"@");
E.push(this.host);
E.push(this.pathname);
E.push(this.suffix);
E.push(this.search);
E.push(this.hash);
return E.join("")
},set:function(E){if(E){o=m(E);
r(o)
}}}});
i();
r(o)
};
h.prototype.toString=function(){return this.href
};
h.prototype.toLocaleString=function(){return this.href
};
return h
}));
var IF6={focus_obj:null,last_window_width:0,lightbox_fragments:[],last_scroll_pos:0};
IF6.statistics={config:{pagenav:{delay:10000},timeout:10000},state:{pagenav:{scroll:{}}},event:function(b,a){if(IF6.statistics.config.url){$.ajax({url:IF6.statistics.config.url,async:!a,type:"GET",dataType:"html",data:$.extend({type:"jslog",url:location.href},b),timeout:IF6.statistics.config.timeout})
}}};
$(document).ready(function(){var a=$("body");
IF6.statistics.config.url=a.data("statistics-url")
});
$(window).resize(function(){if(IF6.last_window_width!==window.innerWidth){var a=$("body");
if(a.hasClass("navigation_visible")){IF6.statistics.event({stref:"hnav-auto"})
}if(a.hasClass("contact_visible")){IF6.statistics.event({stref:"kontakt-auto"});
$(document).trigger("contact-auto")
}a.removeClass("navigation_visible contact_visible pagenav_visible");
$('.if6_navigation>a,.if6_contact>a[href="#"]').attr("aria-expanded","false");
$(".if6_navigation div div").removeClass("navvisible");
$(".if6_navigation li").removeClass("focus anim hold");
$(document).trigger("hide-bcontent",true);
IF6.last_window_width=window.innerWidth
}$(".if6_lightbox>.if6_inner").scroll()
}).on("load",function(){$(window).resize()
});
$("html").addClass("js");
if("ontouchstart" in document.documentElement){$("html").removeClass("no-touch")
}document.createElement("section");
document.createElement("header");
document.createElement("footer");
document.createElement("nav");
$(window).on("load",function(){if(IF6.focus_obj){IF6.focus_obj.focus()
}});
$(function(){$('.if6_header input[type="text"],.if6_header input[type="password"],.login input[type="text"],.login input[type="password"]').on("keyup",function(){this.className=(this.value||this.in_focus)?"nonempty":""
}).on("paste",function(){var a=$(this);
window.setTimeout(function(){a.trigger("keyup")
},30)
}).on("click",function(){this.className="nonempty";
this.in_focus=true
}).on("blur",function(){this.in_focus=false;
$(this).trigger("keyup")
}).trigger("keyup");
$(".if6_header .header-login").append("<span class=\"close-icon\" onclick=\"$('body').removeClass('login_visible');\"></span>");
$(".if6_header .secselect").click(function(){$(this).toggleClass("secselect_visible")
});
$(".if6_navigation>a,.if6_contact>a,.loginlogout .background").on("touchmove",function(){return false
});
$(".if6_section").each(function(){$(this).attr("role","main");
var a=$(this).find(".if6_inner>h6").html();
if(a){$(this).attr("aria-label",a)
}});
$(".if6_navigation").attr("role","navigation").attr("aria-label",$(".if6_navigation>a").attr("title"));
$(".if6_block>.micronav").attr("role","navigation");
$(".if6_contact").attr("role","complementary").attr("aria-label",$(".if6_contact>a:first-child").attr("title"));
$(".if6_header .search").attr("role","search");
$(".iconbar_overlay").click(function(){if(IF6.page){if(IF6.page.navigation){IF6.page.navigation.close()
}if(IF6.page.contact){IF6.page.contact.close()
}}return false
});
$(document).trigger("if6_page_ready")
});
$(document).on("if6_page_ready",function(){$(".im+.ficon,.il+.ficon,.ixl+.ficon,.ixxl+.ficon,.im+.helptxt,.il+.helptxt,.ixl+.helptxt,.ixxl+.helptxt").prev().addClass("followed-by-icon");
$(".bline").not(function(){return($(this).find("input,.ficon,.helptxt,select,textarea,.bslider,.bgauge").length>0)
}).addClass("btext-only");
$(".bpulldown>span").not(function(){var a=this.click_added;
this.click_added=true;
return a
}).click(function(){$(this).closest(".bpulldown").toggleClass("pulldown_visible")
});
$(".bpager div.active").each(function(){$(this.nextSibling).addClass("next");
$(this.previousSibling).addClass("prev")
});
$("div.ficon>input,.buttonline input,.loginlogout .login input,.loginlogout .logout input").not(function(){var a=this.focus_added;
this.focus_added=true;
return a
}).focus(function(){$(this.parentNode).addClass("focus")
}).blur(function(){$(this.parentNode).removeClass("focus")
});
$(".buttonline>.bgroup1>div").not(function(){var a=this.click_added;
this.click_added=true;
return a
}).on("click",function(a){if(a.target.tagName==="DIV"){$(this.firstChild).click()
}});
$(".btableblock table.row-clickable tr.tablerowodd,.btableblock table.row-clickable tr.tableroweven").not(this.click_added).each(function(){this.click_added=true;
if($(this).find("td a").length>0){$(this).addClass("clickable").attr("title",$(this).find("td a").first().attr("title")).on("click",function(a){if(a&&a.target){switch(a.target.tagName){case"A":case"INPUT":break;
case"SPAN":if(!$(a.target).hasClass("checkbox")&&!$(a.target).hasClass("radio")){$(this).find("td a").get(0).click();
return false
}break;
default:$(this).find("td a").get(0).click();
return false
}}})
}})
});
$(document).on("if6_page_ready",function(){$('.if6_main input[type="checkbox"]').not(function(){if($(this.nextSibling).hasClass("checkbox")){return true
}return($(this).closest(".no-if6-changes").length>0)
}).after('<span class="checkbox"></span>').on("click blur",function(){if(this.checked){$(this.nextSibling).addClass("checked")
}else{$(this.nextSibling).removeClass("checked")
}});
$("span.checkbox").each(function(){if(this.previousSibling.checked){$(this).addClass("checked")
}else{$(this).removeClass("checked")
}}).not(function(){var a=this.click_added;
this.click_added=true;
return a
}).click(function(){if(!this.previousSibling.disabled){$(this.previousSibling).click()
}})
});
$(document).on("if6_page_ready",function(){$('.if6_main input[type="radio"]').not(function(){if($(this.nextSibling).hasClass("radio")){return true
}return($(this).closest(".no-if6-changes").length>0)
}).after('<span class="radio"></span>').click(function(){$('input[name="'+this.name+'"]+span.radio').each(function(){if(this.previousSibling.checked){$(this).addClass("checked")
}else{$(this).removeClass("checked")
}})
}).each(function(){var a=this.getAttribute("id");
if(typeof a==="string"){$(this).parents(".bline").find('input[type="text"],input[type="submit"],select').on("click change keypress",function(){document.getElementById(a).checked=true;
$("#"+a).click()
})
}});
$("span.radio").each(function(){if(this.previousSibling.checked){$(this).addClass("checked")
}else{$(this).removeClass("checked")
}}).not(function(){var a=this.click_added;
this.click_added=true;
return a
}).click(function(){if(!this.previousSibling.disabled){this.previousSibling.checked=true;
$(this.previousSibling).click()
}})
});
$(document).on("if6_page_ready",function(){$("select").not(function(){return($(this).closest(".no-if6-changes").length>0)
}).each(function(){if(this.multiple){return
}if(!$(this.nextSibling).hasClass("select")){var b=$(this).attr("class");
$(this).wrap('<div class="select-wrap '+b+'"></div>');
$(this).after('<span class="select">&nbsp;</span>');
$(this).removeClass("followed-by-icon")
}var a=Math.round($(this).height());
var c=Math.round($(this.nextSibling).height());
$(this).addClass("select-modified");
if(a===c+1){$(this).addClass("select-reduce-by-one")
}if(a===c+2){$(this).addClass("select-reduce-by-two")
}if(a===c+3){$(this).addClass("select-reduce-by-three")
}if(a===c+4){$(this).addClass("select-reduce-by-four")
}if(a===c+5){$(this).addClass("select-reduce-by-five")
}})
});
$(function(){$(".if6_main").on("click","div.helptxt",function(){if($(this).closest(".no-if6-changes").length<=0&&$(this).children().length<=0){var h=this.getAttribute("title");
if(h){$(this).html('<div title=""><div>'+h+"</div></div>")
}}if($(this).children().length<=0){return
}var g=$(this).hasClass("visible");
$("div.helptxt.visible").removeClass("visible");
if(!g){$(this).addClass("visible");
var b=$(this).parents(".if6_inner");
var e=b.offset().left+b.innerWidth();
var d=$(this).find("div div");
if(d&&d.length>0){d.css({width:"",left:""});
var a=d.innerWidth();
var f=d.innerHeight();
if(f>a){d.css({width:b.innerWidth()})
}var c=d.offset().left+d.innerWidth();
if(c>e){d.css({left:(e-c)})
}}}})
});
function getQueryParamValue(b,a){var d=b.split("?")[1];
if(d!==undefined){var e=d.split("&");
var c,f;
for(c=0;
c<e.length;
c++){f=e[c].split("=");
if(f[0]===a){return f[1]
}}}return false
}var IF6_lightbox_closeicon_text;
function overlayShow(h){var a=h.getAttribute("href");
if(a.charAt(0)!=="/"){return false
}var i=getQueryParamValue(a,"lightbox");
i=decodeURIComponent(i);
var g=i.split("?")[1];
i=i.split("?")[0];
var b=i.replace(/\//g,"_");
if(g){b+="_"+g.replace(/[&=+ .,;]/g,"-")
}var e;
if($("#"+b).length<=0){var f=a.split("?")[0];
var c=f.indexOf(".webview.html")>-1?".webview":"";
var d=a.indexOf("isVP=true")===-1?"/jcr:content/section/section":"";
jQuery.ajax({url:i+d+c+".html"+(g?("?"+g):""),timeout:20000}).done(function(j){IF6.lightbox_fragments[i]=j;
e='<div id="'+b+'" class="if6_outer if6_lightbox lightbox-visible"><div class="if6_inner"><a href="#" title="'+IF6_lightbox_closeicon_text+'" class="close-icon" onclick="return overlayClose(this);">'+IF6_lightbox_closeicon_text+"</a>"+IF6.lightbox_fragments[i]+"</div></div>";
$(".if6_main").append(e);
$("#"+b).data("lightboxPreviousFocus",h);
$("body").addClass("lightbox_visible");
$(document).trigger("if6_page_ready")
}).fail(function(){window.location.href=a
})
}else{$("#"+b).addClass("lightbox-visible").data("lightboxPreviousFocus",h);
$("body").addClass("lightbox_visible");
$(document).trigger("if6_page_ready")
}return false
}$(document).on("if6_page_ready",function(){$("a").not(function(){return this.lightbox_checked
}).each(function(){this.lightbox_checked=true;
var a=this.getAttribute("href");
if(!a||a.charAt(0)!=="/"){return
}var b=a.indexOf("lightbox=");
if(b<=0||("?"!==a.charAt(b-1)&&"&"!==a.charAt(b-1))||$("body").hasClass("templ-searchresultpage")){return
}$(this).click(function(){return overlayShow(this)
})
});
$(".if6_lightbox>.if6_inner").not(function(){var a=this.closeIconPosition;
this.closeIconPosition=true;
return a
}).scroll(function(){var b=$(this).scrollTop();
$(this).children(".close-icon").css({marginTop:b});
var a=$(this).height();
$(this).find(".cbox-banking .btopbuttonline>div").css({marginTop:b});
$(this).find(".cbox-banking .bbottombuttonline>div").each(function(){$(this).css({bottom:"auto",top:b+a-parseInt($(this).css("height"),10)})
});
$(this).find('.cbox-banking input[type="text"]:visible, .cbox-banking textarea:visible').last().each(function(){var c=$(this).closest(".if6_lightbox .if6_inner").offset().left;
if(c<20){var d=$(this).position().top+$(this).height();
var f=$(this).closest(".cbox-banking").height();
var e=d+300-f;
if(e>0){$(this).closest(".cbox-banking").css({paddingBottom:e+"px"})
}}else{$(this).closest(".cbox-banking").css({paddingBottom:""})
}})
}).scroll();
$(".if6_lightbox").not(function(){var a=this.click_added;
this.click_added=true;
return a
}).on("click",function(a){if($(this).hasClass("lightbox-visible")&&a&&a.target&&a.target===this){$(this).find(".if6_inner>a.close-icon").click()
}});
if($(".lightbox-visible").length>0){$(".if6_outer").each(function(){if($(this).hasClass("lightbox-visible")){$(this).attr("aria-hidden","false");
$(this).find(".if6_inner>a.close-icon").focus()
}else{if($(this).hasClass("if6_header")){$(this).attr("aria-hidden","false")
}else{$(this).attr("aria-hidden","true")
}}})
}else{$(".if6_outer").each(function(){if($(this).hasClass("if6_lightbox")){$(this).attr("aria-hidden","true")
}else{$(this).attr("aria-hidden","false")
}})
}});
function overlayClose(a){$(a).parents(".if6_lightbox").removeClass("lightbox-visible").attr("aria-hidden","true");
var b=$(a).parents(".if6_lightbox").data("lightboxPreviousFocus");
$(a).parents(".if6_lightbox").data("lightboxPreviousFocus",null);
$(".if6_outer").each(function(){if($(this).hasClass("if6_lightbox")){$(this).attr("aria-hidden","true")
}else{$(this).attr("aria-hidden","false")
}});
$("body").removeClass("lightbox_visible");
if(b){b.focus()
}return false
}$(window).scroll(function(){var b=$(".if6_iconbar");
if(!b||!b.length){return
}var a=window.pageYOffset;
if(a<b.offset().top){b.removeClass("iconbar-fixed")
}else{b.addClass("iconbar-fixed")
}});
$(document).on("if6_page_ready",function(){$(".iconbar-added").removeClass("iconbar-added");
$(".iconbarbuttons").remove();
var b=$(".if6_section").not(function(){return $(this).hasClass("ajstep-replace")
}).find("a[data-iconbar],input[data-iconbar]").toArray();
function a(e){var d,f,h,c,g;
for(d=0;
d<b.length;
++d){if($(b[d]).data("iconbar")===e){break
}}if(d<b.length&&$(b[d]).data("iconbar")===e){if("INPUT"===b[d].tagName){h=b[d].value;
g=b[d].getAttribute("title")||"";
c=b[d].parentNode.getAttribute("class")
}else{h=b[d].innerHTML;
g=b[d].getAttribute("title")||"";
c=b[d].getAttribute("class")
}if(c){c=c.match(/icon-[A-Za-z0-9_\-]*/);
if(c){c+=" "
}else{c=""
}}else{c=""
}f='<a href="#" class="'+c+e+'" title="'+g+'">'+h+"</a>";
$(".iconbarbuttons div").append(f);
if(e==="micronavback"){$(".iconbarbuttons .micronavback").click(function(){$(document).trigger("hide-bcontent");
return false
})
}else{$(".iconbarbuttons ."+e).click(function(){b[d].click();
return false
})
}$(b[d]).addClass("iconbar-added");
return
}}if(b.length>0){$(".if6_iconbar .if6_inner").append('<div class="iconbarbuttons"><div></div></div>');
if($(".iconbarbuttons").length<=0){return
}a("micronavback");
a("back");
a("right2");
a("right1")
}});
$(window).scroll(function(){if(IF6.last_scroll_pos!==window.pageYOffset){if($("body").hasClass("navigation_visible")||$("body").hasClass("contact_visible")||$(".lightbox-visible").length>0){$("html,body").scrollTop(IF6.last_scroll_pos)
}else{IF6.last_scroll_pos=window.pageYOffset
}}}).on("load",function(){$(window).scroll()
});
$(document).on("if6_page_ready",function(){$('input[type="date"]').not(function(){return($(this).closest(".no-if6-changes").length>0)
}).each(function(){if(this.type!=="date"){var a=/^(\d\d\d\d)-(\d\d)-(\d\d)$/.exec(this.value);
if(a){this.value=a[3]+"."+a[2]+"."+a[1]
}}else{$(this).addClass("working-date")
}})
});
$(function(){function a(e){var b,c=0,d;
for(b=0;
b<e.length;
++b){d=Math.abs(parseInt($(e[b]).css("left"),10));
if(d>0&&(0===c||d<c)){c=d
}}return c
}$(".carousel,.if6_openerstage").on("swiperight",function(){$(this).trigger("carousel-prev",false)
}).on("swipeleft",function(){$(this).trigger("carousel-next",false)
}).on("carousel-next",function(j,l){if(this.animated){return
}this.animated=(j!==null)||true;
if(this.carouseltimer){window.clearTimeout(this.carouseltimer);
this.carouseltimer=null
}var h=this,k=$(this).find(".cbox:visible,.if6_opener:visible").toArray();
var g,c,b=a(k),e,f;
$(this).find(".carousel_play li.active").removeClass("active");
var d=function(){$(h).find(c).addClass("active");
h.animated=false
};
for(g=k.length-1;
g>=0;
--g){f=parseInt($(k[g]).css("left"),10);
if(f<0){f+=k.length*b;
$(k[g]).css({left:f+"px"})
}e=f-b;
if(e>=0&&e<b){e=0
}if(0===e){c=".carousel_play li:nth-child("+(g+1)+")";
$(k[g]).animate({left:e+"px"},500,"easeInOutExpo",d)
}else{$(k[g]).animate({left:e+"px"},500,"easeInOutExpo")
}}if(l){this.carouseltimer=window.setTimeout(function(){$(h).trigger("carousel-auto-next")
},10000)
}}).on("carousel-prev",function(j,l){if(this.animated){return
}this.animated=(j!==null)||true;
if(this.carouseltimer){window.clearTimeout(this.carouseltimer);
this.carouseltimer=null
}var h=this,k=$(this).find(".cbox:visible,.if6_opener:visible").toArray();
var g,c,b=a(k),e,f;
$(this).find(".carousel_play li.active").removeClass("active");
var d=function(){$(h).find(c).addClass("active");
h.animated=false
};
for(g=0;
g<k.length;
++g){f=parseInt($(k[g]).css("left"),10);
e=f+b;
if(e>(k.length-1)*b){$(k[g]).css({left:(-b)+"px"});
e=0
}if(0===e){c=".carousel_play li:nth-child("+(g+1)+")";
$(k[g]).animate({left:e+"px"},500,"easeInOutExpo",d)
}else{$(k[g]).animate({left:e+"px"},500,"easeInOutExpo")
}}if(l){this.carouseltimer=window.setTimeout(function(){$(h).trigger("carousel-auto-prev")
},10000)
}}).on("carousel-auto-next",function(){if(!$("body").hasClass("cq-wcm-edit")){$(this).trigger("carousel-next",true)
}}).on("carousel-auto-prev",function(){if(!$("body").hasClass("cq-wcm-edit")){$(this).trigger("carousel-prev",true)
}}).on("carousel-select",function(j,m){if(this.animated){return
}this.animated=(j!==null)||true;
if(this.carouseltimer){window.clearTimeout(this.carouseltimer);
this.carouseltimer=null
}var h=this,l=$(this).find(".cbox:visible,.if6_opener:visible").toArray();
var g,c,b=a(l),e,f;
$(this).find(".carousel_play li.active").removeClass("active");
if(isNaN(m)||m<0||m>=l.length){return
}for(g=0;
g<l.length-1;
++g){if(0===parseInt($(l[g]).css("left"),10)){c=g;
break
}}for(g=0;
g<c;
++g){f=parseInt($(l[g]).css("left"),10);
if(f>0){e=f-l.length*b;
$(l[g]).css({left:e+"px"})
}}for(g=c+1;
g<l.length;
++g){f=parseInt($(l[g]).css("left"),10);
if(f<0){e=f+l.length*b;
$(l[g]).css({left:e+"px"})
}}var k=parseInt($(l[m]).css("left"),10);
var d=function(){$(h).find(c).addClass("active");
h.animated=false
};
for(g=0;
g<l.length;
++g){f=parseInt($(l[g]).css("left"),10);
e=f-k;
if(0===e){c=".carousel_play li:nth-child("+(g+1)+")";
$(l[g]).animate({left:e+"px"},500,"easeInOutExpo",d)
}else{$(l[g]).animate({left:e+"px"},500,"easeInOutExpo")
}}})
});
(function(a){if(!(a.hasOwnProperty("chat"))){a.chat={}
}a.chat.popupOptions="width=375,height=655,scrollbars=yes,resizable=yes,toolbar=no,status=no,menubar=no";
a.chat.openPopup=function(b){var e=window.innerWidth;
var c="wide";
if(e<650){c="small"
}else{if(e<1080){c="medium"
}}var i=b.split("?");
var m=i[0];
var l=i[1];
if(l===undefined){l=["device",c].join("=")
}else{var f=l.split("#");
var k=f[1];
var g=f[0].split("&");
var j;
var h;
for(j=g.length;
j>0;
j--){h=g[j-1].split("=");
if(h[0]==="device"){h[1]=c;
g[j-1]=h.join("=");
break
}}if(j===0){g[g.length]=["device",c].join("=")
}l=g.join("&");
if(k!==undefined){l=[l,k].join("#")
}}b=[m,l].join("?");
var d=function(){var n=window.open(b,"chat",a.chat.popupOptions);
$(document).trigger("chat-open");
return n
};
if(!(a.chat.hasOwnProperty("popupHandle"))){a.chat.popupHandle=d()
}else{if(a.chat.popupHandle.closed){a.chat.popupHandle=d()
}}if(a.chat.popupHandle){a.chat.popupHandle.focus()
}};
$(document).on("if6_page_ready",function(){$("a.chatlink").not(function(){if($(this).closest(".no-if6-changes").length>0){return true
}var b=this.click_added;
this.click_added=true;
return b
}).click(function(){if(this.href&&this.target){a.chat.openPopup(this.href,this.target);
return false
}return true
})
})
}(IF6));
$(document).on("if6_page_ready",function(){$(".bline input[data-sayt]").not(function(){return this.previousSibling&&$(this.previousSibling).hasClass("bsayt")
}).on("keyup",function(){if(!this.previousSibling||!$(this.previousSibling).hasClass("bsayt")){return
}if(this.previousSibling.closeTimeout){window.clearTimeout(this.previousSibling.closeTimeout);
this.previousSibling.closeTimeout=null
}else{$(this.previousSibling).hide();
if(this.value.length<3){return
}var d=IF[this.getAttribute("data-sayt")];
var a,c="",b=this.value.toLowerCase();
for(a=0;
a<d.length;
++a){if(d[a].cmp.indexOf(b)<0){continue
}c+="<li><h3>"+d[a].value+"</h3>";
if(d[a].add){c+="<p>"+d[a].add+"</p>"
}c+='<div><input type="submit" name="'+d[a].name+'" value="'+d[a].value+'" /></div></li>'
}if(""===c){return
}$(this.previousSibling).html('<div onscroll="if (this.parentNode.closeTimeout){$(this.parentNode.nextSibling).focus();}return true;"><ul>'+c+"</ul></div>").css({display:"inline-block"})
}}).before(function(){var b,c,a=this.getAttribute("data-sayt");
if(!a||!a.length||!IF[a]||!IF[a].length){return
}c=IF[a];
for(b=0;
b<c.length;
++b){c[b].cmp=c[b].value.toLowerCase()
}return'<div class="bsayt '+this.getAttribute("class")+'"></div>'
}).on("blur",function(){if(!this.previousSibling||!$(this.previousSibling).hasClass("bsayt")){return
}var a=this.previousSibling;
var b=$(a);
a.closeTimeout=window.setTimeout(function(){b.hide()
},300)
}).on("focus",function(){$(this).trigger("keyup")
})
});
$(function(){$("table.has-action-column").each(function(){$(this).find("td:last-child").each(function(){if($(this).find(".ficon.rank5").length){return
}var b=$(this).find(".ficon.rank3,.ficon.rank4").clone();
if(1===b.length){$(this).find(".ficon.rank3,.ficon.rank4").removeClass("rank3 rank4")
}else{if(b.length>1){var a='<div class="bpulldown baction"><span class="ficon icon-if5_i_aktionen"></span><div><div><ul></ul></div></div></div>';
$(this).append(a);
$(this).find(".bpulldown div div ul").append(b);
$(this).find(".bpulldown div div ul .ficon").wrap("<li></li>");
$(this).find(".bpulldown>span").not(function(){var c=this.click_added;
this.click_added=true;
return c
}).click(function(){var c=$(this).closest(".bpulldown").hasClass("pulldown_visible");
$(".bpulldown").removeClass("pulldown_visible");
if(!c){$(this).closest(".bpulldown").addClass("pulldown_visible")
}})
}}})
})
});
$(function(){$(".cbox-banking form").each(function(){var a=$(this).find(".blineover .msgerror li:visible").first();
if(a&&a.length){var b=$(this).attr("data-msg-hinweisvorhanden"),c=$(this).attr("data-msg-hinweislink");
if(b&&c){$(this).prepend('<div class="msglink">'+b+'<div class="textbutton"><a href="#">'+c+"</a></div></div>");
$(".msglink a").click(function(){var e=a.offset().top;
var d=($(".if6_iconbar .iconbar").css("display")!=="none")?$(".if6_iconbar .iconbar").height():$(".if6_pagenav").height();
$("html,body").animate({scrollTop:e-d},750,"easeInOutExpo");
$(this).blur();
return false
})
}}})
});
var setSessionTimeout;
function focusBankingFormularElement(a){if(!a||a.length<=0){return
}var d=false,b,c=a.find("a:visible, select:visible, textarea:visible, input:visible").toArray();
for(b=0;
!d&&b<c.length;
++b){if(c[b].disabled){continue
}if(c[b].tagName==="INPUT"&&(c[b].type==="hidden"||c[b].type==="submit")){continue
}c[b].focus();
if(c[b].tagName==="A"){c[b].blur()
}d=true
}}$(document).on("if6_page_ready",function(){function d(f){var g=f.indexOf("if6_outer");
if(g>0){f=f.substr(0,g)+f.substr(g+9)
}g=f.indexOf("if6_inner");
if(g>0){f=f.substr(0,g)+f.substr(g+9)
}return f
}function a(g,f){var h;
if(g&&f){h=g.indexOf("?");
if(h>0){g=g.substr(0,h)
}h=f.indexOf("?");
if(h>0){f=f.substr(0,h)
}return g===f
}return false
}function c(f){f.find("form").each(function(){var g=$(this).attr("action");
if(g){g=g.replace(/\.ajstep/,"");
$(this).attr("action",g)
}});
f.find("a").each(function(){var g=$(this).attr("href");
if(g){g=g.replace(/\.ajstep/,"");
$(this).attr("href",g)
}})
}function e(m,l,k,j){m.find("[id]").attr("id",null);
m.attr("aria-hidden","true");
var h=$(l).insertAfter(m);
var i=m.closest(".if6_lightbox");
if(i){if(i.find(".lightbox-autoclose").length>0){var g=i.find(".lightbox-autoclose").siblings(".buttonline").find('input[type="submit"]').get(0);
if(g){$(document).trigger("if6_page_ready");
window.setTimeout(function(){g.click()
},100);
return
}}focusBankingFormularElement(h)
}c(h);
if(j){var f=h.find(".bcontainer-content");
if(f.length>0){f.prepend(j)
}else{f=h.find(".cbox-banking").first();
if(f.length>0){f.prepend(j)
}else{h.prepend(j)
}}}$(".if6_section").each(function(){$(this).attr("role","main");
var n=$(this).find(".if6_inner>h6").html();
if(n){$(this).attr("aria-label",n)
}});
m.addClass("ajstep-replace").fadeOut(400,function(){m.remove()
});
$(document).trigger("if6_page_ready");
if(typeof setSessionTimeout==="function"){setSessionTimeout()
}if(k){$(document).trigger(k)
}}function b(f){if(f.indexOf(".webview.")>0){return f.replace(/\.webview\./,".ajstep.webview.")
}return f.replace(/\.html/,".ajstep.html")
}$('.cbox-banking form[data-ajstep] input[type="submit"], .cbox-banking form[data-ajstep] input[type="image"], .cbox-banking form[data-ajstep] a').not(function(){var f=this.ajstep_added;
this.ajstep_added=true;
if(this.target||$(this).data("ajstep-disabled")||(this.href&&this.href.indexOf("javascript:")===0)){return true
}return f
}).on("click",function(){if($("body").hasClass("cq-wcm-edit")){return true
}if($(this).data("ajstep-disabled")){return true
}var r=this,h,f,m="",p=false;
if(this.form){var n,j=this.form,l=false;
h=$(j).attr("action");
f="POST";
p="application/x-www-form-urlencoded; charset=UTF-8";
for(n=0;
n<j.elements.length;
++n){switch(j.elements[n].type){case"image":case"submit":break;
case"checkbox":case"radio":if(j.elements[n].checked){m+=j.elements[n].name+"="+encodeURI(j.elements[n].value)+"&"
}break;
case"file":l=true;
break;
default:m+=j.elements[n].name+"="+encodeURI(j.elements[n].value)+"&";
break
}}if(l){m=new FormData(j);
m.append(this.name,this.value);
p=false
}else{m+=this.name+"="+encodeURI(this.value)
}}else{h=$(this).attr("href");
f="GET"
}var q=$(this).data("ajstep-anim")||"none";
var o=$(this).closest(".if6_section").addClass("ajstep-start anim-"+q);
var k=false;
if(o.closest(".if6_lightbox").length>0){k=true
}var g=$(this).data("ajstep-complete-event");
$.ajax({method:f,url:b(h),timeout:20000,processData:false,contentType:p,data:m}).done(function(w){var v=false,t=false,s;
if(w.indexOf("<section")<0){var x=w.indexOf("AJSTEP_LOCATION=");
if(x>=0){t=true;
s=w.substr(x+16)
}else{x=w.indexOf("REDIRECT_LOCATION=");
if(x>=0){t=true;
s=w.substr(x+18)
}else{x=w.indexOf("AJSTEP_LIGHTBOX_LOCATION=");
if(x>=0){v=true;
s=w.substr(x+25)
}}}}if(t){if(k&&a(s,o.closest(".if6_lightbox").data("ajstep-parent-url"))){var i=o.closest(".if6_lightbox").data("ajstep-parent-section");
var u=null;
if(o.find(".lightbox-autoclose").length>0){u=o.find(".success-msg, .failure-msg").clone()
}$("body").removeClass("lightbox_visible");
o.closest(".if6_lightbox").remove();
$.ajax({method:"GET",url:b(s),timeout:20000}).done(function(y){e(i,y,g,u)
}).fail(function(){window.location.href=s
})
}else{window.location.href=s;
o.removeClass("ajstep-start anim-"+q)
}}else{if(v){$.ajax({method:"GET",url:b(s),timeout:20000}).done(function(z){z=d(z);
if(!k){z='<div class="if6_outer if6_lightbox lightbox-visible" data-ajstep-parent-url="'+h+'"><div class="if6_inner">'+z+"</div></div>";
var y=$(z).appendTo(".if6_main").data("ajstep-parent-section",o);
c(y);
$("body").addClass("lightbox_visible");
focusBankingFormularElement(y);
$(document).trigger("if6_page_ready");
if(typeof setSessionTimeout==="function"){setSessionTimeout()
}if(g){$(document).trigger(g)
}}else{e(o,z,g,null)
}}).fail(function(){window.location.href=s
})
}else{if(k){w=d(w)
}e(o,w,g,null)
}}}).fail(function(){o.removeClass("ajstep-start anim-"+q);
$(r).data("ajstep-disabled","true");
window.setTimeout(function(){r.click()
},100)
});
return false
})
});
$(function(){$("body").on("if6_tablecampaign",function(){$(".cbox-banking .campaign").each(function(){var d=$(this);
$(this).find(".campaign-top").on("click",function(){d.toggleClass("campaign-visible");
if(d.hasClass("campaign-visible")){d.attr("aria-expanded","true")
}else{d.attr("aria-expanded","false")
}$(this).blur();
return false
});
d.attr("aria-expanded","false");
var a=$(this).attr("data-campref");
var b=$(this).attr("data-camprefcol");
if(!a){return
}var c=new RegExp("\\b"+a.replace(/\*/g,"\\*")+"\\b");
$(this).closest(".cbox-banking").find(".btableblock .btable").each(function(){if(isNaN(b)){return
}var f,g=0,e;
for(f=0;
f<this.rows.length;
++f){if(this.rows[f].cells.length>g){g=this.rows[f].cells.length
}if(this.rows[f].cells.lenght<=b){continue
}if(c.test(this.rows[f].cells[b].innerHTML)){e=this.insertRow(f+1);
if(e){$(e).addClass("tablecampaign").html('<td colspan="'+g+'"></td>');
$(e).find("td").append(d.detach())
}b=null;
break
}}})
})
});
$("body").trigger("if6_tablecampaign")
});
var SLURI;
IF6.urlutil={webviewSelector:"webview",resetWorkflowParameter:"n",isExternal:function(a){return(typeof a==="string")&&(a.indexOf(":/")>-1)
},isInternal:function(a){return(typeof a==="string")&&!this.isExternal(a)
},endsWith:function(b,a){return(b.length>=a.length)&&(b.indexOf(a,b.length-a.length)!==-1)
},convertUrl:function(b){var c;
var e=new SLURI(window.location.href);
var a=this.isInternal(b);
if(a){if((typeof window.location.href==="string")){if(window.location.href.indexOf("http://localhost")!==0&&window.location.href.indexOf("https://localhost")!==0){if((typeof CQ!=="undefined")||(window.location.href.indexOf(".cqa.")>=0)){if(b.indexOf("/cqa")!==0){b="/cqa"+b
}}}}var d=new SLURI(b,window.location.href);
if(e.selectors.has(this.webviewSelector)&&!d.selectors.has(this.webviewSelector)){d.selectors.append(this.webviewSelector)
}if((d.extension==="html")&&!d.searchParams.has(this.resetWorkflowParameter)){d.searchParams.set(this.resetWorkflowParameter,"true")
}c=d.toString()
}else{c=b
}return c
}};
var getQueryParamValue;
$(document).on("if6_page_ready",function(){if(!$("html").hasClass("webview")){return
}var e=false;
var b=false;
var c=null;
var a=window.location.search;
var d=getQueryParamValue(a,"wstart")==="true";
if($(".templ-bankingpage, .templ-bankingstartpage").length>0){$(".bgroup2 > *").each(function(){if(!$(this).closest(".if6_section").hasClass("ajstep-replace")){if($(this).find("input").data("iconbar")==="micronavback"){e=true
}if($(this).find("input").data("iconbar")==="back"){b=true
}c=$(this).get(0)
}});
if((c&&!d)||e||b){$("body").addClass("backbutton_visible");
if(e||b){$("body").addClass("webview-micronav")
}if(c.tagName==="DIV"&&c.firstChild&&c.firstChild.tagName==="INPUT"){c=c.firstChild
}else{if(c.tagName!=="A"){c=null
}}$(".back-button a").data("webview-button",c);
if(c){$(".back-button a").not(function(){var f=this.clickHandlerAdded;
this.clickHandlerAdded=true;
return f
}).click(function(){var f=$(this).data("webview-button");
if(!f){return true
}if($(f).data("iconbar")==="micronavback"){$(document).trigger("hide-bcontent");
return false
}$(f).click();
return false
})
}}else{if(getQueryParamValue(a,"n")==="true"&&history.length>1&&!d){$("body").addClass("backbutton_visible")
}}}else{if(history.length>1&&!d){$("body").addClass("backbutton_visible")
}}});
var IF6_lightbox_closeicon_text;
$(function(){var a=0;
$("body").on("if6_bannercampaign",function(){$(".if6_main .smartphonebanner .smartphone-banner_outer").each(function(){var e=this;
a++;
var g=$(e).closest(".smartphonebanner");
var b=$(e).detach();
$(".if6_main").append(b);
var d;
d='<div id="lightbox_smartphonebanner'+a+'" class="if6_outer if6_lightbox"><div class="if6_inner"><a href="#" title="'+IF6_lightbox_closeicon_text+'" class="close-icon" onclick="return overlayClose(this);">'+IF6_lightbox_closeicon_text+"</a></div></div>";
$(".if6_main").append(d);
var f=g.find(".cbox-bannerbox").detach();
$("#lightbox_smartphonebanner"+a+" .if6_inner").append(f);
g.not(function(){return $(this).children().length>0
}).remove();
var i=$(e).find(".smartphone-banner_inner").attr("data-kampagne");
if(i){$("#lightbox_smartphonebanner"+a+" .if6_inner").attr("data-kampagne",i)
}i=$(e).find(".smartphone-banner_inner").attr("data-mdi");
if(i){$("#lightbox_smartphonebanner"+a+" .if6_inner").attr("data-mdi",i)
}$(document).trigger("if6_page_ready");
var h=true;
var c=($(".cbox-medium.cbox-banking, .cbox-large.cbox-banking").filter(":visible").length>0);
var j=0;
if(c){$(window).not(this.awaitingScroll).each(function(){this.awaitingScroll=true
}).scroll(function(){if(j>4){var k=($(".if6_outer.if6_lightbox .cbox-eyecatcher").filter(":visible").length>0);
if(h&&!k){var l=$(".cbox-medium.cbox-banking, .cbox-large.cbox-banking").filter(":visible").eq(-1).offset().top;
var n=$(window).height();
var m=$(window).scrollTop();
if(l<(n+m)){h=false;
$(e).find(".smartphone-banner_inner").animate({bottom:"-80px"},3000,"easeInOutExpo",function(){$(e).hide()
})
}}}j++
})
}$(e).find(".smartphone-banner_inner a").not(this.awaitingClick).each(function(){this.awaitingClick=true
}).click(function(){h=false;
$("#lightbox_smartphonebanner"+a).addClass("lightbox-visible");
$("body").addClass("lightbox_visible");
$(document).trigger("if6_page_ready");
$(e).find(".smartphone-banner_inner").hide();
return false
})
})
});
$("body").trigger("if6_bannercampaign")
});
$(document).on("imageoptimize",function(){$(".img-optimize").each(function(){var f=$(this).attr("data-imgsrc"),e=$(this).attr("data-imgtitle")||"",d=$(this).attr("data-imgalt")||"";
var b=window.devicePixelRatio||1;
var c=window.innerWidth*b;
var a="";
if(!f){return
}if(c<=768){a="res768"
}else{if(c<=1280){a="res1280"
}else{if(c<=1920){a="res1920"
}else{a="res2400"
}}}f=f.replace(/(\.img\.|\.epimgref\.)/,"$1"+a+".");
$(this).html('<img onload="this.loaded=true;$(window).resize();" src="'+f+'" alt="'+d+'" title="'+e+'" />');
$(this).removeClass("img-optimize")
})
}).on("ready if6_page_ready",function(){$(this).trigger("imageoptimize")
});
var focusBankingFormularElement;
function moveBContent(){$(".banking-container .bcontainer-content").css({marginTop:""});
var b=$(".banking-container .bcontainer-content").offset().top;
var a=$(".banking-container .bcontainer-content").closest(".if6_section").offset().top;
$(".banking-container .bcontainer-content").css({marginTop:(a-b)+"px"})
}$(document).on("if6_page_ready",function(){$(".tgroup-toggle+ul").attr("aria-expanded","false");
$(".tgroup-toggle>a").not(function(){var b=this.click_added;
this.click_added=true;
return b
}).attr("data-ajstep-disabled","true").click(function(){if(!$(this).hasClass("disabled")){var e=$(this).closest(".tgroup");
var d=e.find(".tgroup-toggle+ul");
var c=false;
if(e.hasClass("visible")){e.removeClass("visible");
d.attr("aria-expanded","false")
}else{e.addClass("visible");
c=true;
d.attr("aria-expanded","true")
}var b=this.tabIndex;
this.tabIndex=-1;
this.blur();
$(this).siblings().each(function(){this.tabIndex=b;
if(c){this.focus()
}else{this.blur()
}})
}return false
});
$(".if6_main").on("click",function(b){if(b&&b.target&&($(b.target).closest(".tgroup").length<=0||$(b.target).hasClass("tgroup"))){$(".tgroup").removeClass("visible");
$(".tgroup-toggle+ul").attr("aria-expanded","false")
}});
$(".tgroup").each(function(){var b=$(this).find(".ficon[data-tgroup-mode],.ficon>input[data-tgroup-mode]");
if(b&&b.length>0){b.closest(".cbox-banking").each(function(){var d=$(this);
function c(){var e=d.find('.btableblock td input[type="checkbox"]:checked').length;
d.find(".ficon[data-tgroup-mode],.ficon>input[data-tgroup-mode]").each(function(){var i=$(this).data("tgroup-mode");
var h=$(this).closest(".ficon");
switch(i){case 1:if(1===e){h.removeClass("disabled");
h.find("input").removeAttr("disabled")
}else{h.addClass("disabled");
h.find("input").attr("disabled","disabled")
}break;
case 2:if(e>=1){h.removeClass("disabled");
h.find("input").removeAttr("disabled")
}else{h.addClass("disabled");
h.find("input").attr("disabled","disabled")
}break;
default:break
}var g=$(this).closest("ul").siblings(".tgroup-toggle");
if(g.length>0){if($(this).closest("ul").find(".ficon").length===$(this).closest("ul").find(".ficon.disabled").length){g.find(".ficon").addClass("disabled").attr("tabindex","-1");
g.closest(".tgroup").removeClass("visible")
}else{g.find(".ficon").removeClass("disabled").removeAttr("tabindex")
}}});
var f=d.find(".tgroup");
if(f.find(".ficon:visible").length>f.find(".ficon.disabled:visible").length){f.addClass("usable")
}else{f.removeClass("usable")
}return true
}c();
$(this).find('.btableblock td input[type="checkbox"]').not(function(){var e=this.tgroup_check_added;
this.tgroup_check_added=true;
return e
}).on("click blur",c)
})
}else{$(this).addClass("usable")
}});
$(".micronav li a").attr("data-ajstep-complete-event","show-bcontent");
if($(".lightbox-visible").length<=0){var a=$(".show-bcontent-completed .bcontainer-content");
if(a&&a.length>0){focusBankingFormularElement(a)
}else{focusBankingFormularElement($(".bcontainer-micronav"))
}}if($("body").hasClass("show-bcontent")){moveBContent()
}$(".block.success-msg, .block.failure-msg").each(function(){var c=$(this),b=c.css("height");
var d=c.closest(".if6_lightbox>.if6_inner");
if(c.closest(".bcontainer-content").css("position")==="absolute"){c.detach().prependTo(".if6_section:first .parsys")
}$("html,body").animate({scrollTop:0},750,"easeInOutExpo");
if(c.hasClass("success-msg")){window.setTimeout(function(){c.animate({marginTop:"-"+b},800,"swing",function(){c.remove();
d.scroll()
})
},4000)
}})
});
$(document).on("show-bcontent",function(){if($(".banking-container .bcontainer-content").css("position")!=="absolute"){return
}moveBContent();
$("body").addClass("show-bcontent");
$(".bcontainer-content,.iconbarbuttons>div").animate({left:0},1500,"easeInOutExpo",function(){$("body").addClass("show-bcontent-completed");
focusBankingFormularElement($(".bcontainer-content"))
});
var b=$(".banking-container .bcontainer-content").closest(".if6_section").offset().top;
var a=b-$(".if6_iconbar").height()+10;
if(window.pageYOffset>a){$("html,body").animate({scrollTop:a},750,"easeInOutExpo")
}});
$(document).on("hide-bcontent",function(b,a){$("body").removeClass("show-bcontent show-bcontent-completed");
if(a||!b){$(".banking-container .bcontainer-content, .iconbarbuttons>div").css({marginTop:"",left:""})
}else{$(".bcontainer-content, .iconbarbuttons>div").animate({left:"110%"},1500,"easeInOutExpo")
}});
$(function(){$("body").on("if6_kmmstat",function(){var a=$(".cbox.cbox-campaign.cbox-small.kmm .description").attr("data-kampagne");
if(a){$(".cbox.cbox-campaign.cbox-small.kmm").attr("data-kampagne",a);
$(".cbox.cbox-campaign.cbox-small.kmm .description").removeAttr("data-kampagne")
}a=$(".cbox-campaign.cbox.cbox-large.kmm .image").attr("data-kampagne");
if(a){$(".cbox-campaign.cbox.cbox-large.kmm").attr("data-kampagne",a);
$(".cbox-campaign.cbox.cbox-large.kmm .image").removeAttr("data-kampagne")
}$(".cbox-campaign.cbox.cbox-small.mdi").each(function(){a=$(this).find(".description").attr("data-mdi");
if(a){$(this).attr("data-mdi",a);
$(this).find(".description").removeAttr("data-mdi")
}});
$(".cbox-campaign.cbox.cbox-large.mdi").each(function(){a=$(this).find(".image").attr("data-mdi");
if(a){$(this).attr("data-mdi",a);
$(this).find(".image").removeAttr("data-mdi")
}})
});
$("body").trigger("if6_kmmstat")
});
function editTeaserRef(a){var b=jQuery(a.el.dom).children("div").eq(0).attr("ref");
if(b!=="."){window.location.href=encodeURI((b+".html?origin="+window.location.href))
}}$(function(){if($(".cbox-market").length>0){var a={".GDAXI":[1,"DAX"],".MDAXI":[2,"MDAX"],".DJI":[3,"Dow Jones"]};
$.ajax({url:$(".market-table").data("url"),cache:false,timeout:1500,async:false,dataType:"json"}).done(function(j){var k,g,n,o,b,p,f,e,d,h,c,l,q;
function m(i){return !(i||i==="0"||i===0)
}if(j){if(j.antworten){l=true;
for(k=0;
k<3;
++k){e=j.antworten.antwort_12[k];
if(e!==null){g=e.STD_Symbol;
q=a[g];
if(q!==null){b=q[0];
n=q[1];
o=e.STD_Price;
p=e.STD_DiffP;
f=e.STD_PriceTimeDateFull;
if(m(n)||m(o)||m(p)||m(f)){l=false
}else{if(p.length>0){d=p.charAt(0)
}h=null;
if(d==="+"){h="plus"
}if(d==="-"){h="minus"
}if(f.length>0){f=f.substr(0,e.STD_PriceTimeDateFull.lastIndexOf(":"))+" Uhr";
f=f.replace(/\.20/,".")
}c=".market_entry"+b;
$(".market_label",c).text(n);
$(".market_val",c).text(o);
$(".market_tend span",c).text(p);
if(h!==null){$(".market_tend span",c).addClass(h)
}$(".market_time",c).text(f)
}}else{l=false
}}}if(l){$(".market-table").not(".market-editmode").parent().addClass("data-loaded")
}else{$(".market-table").parent().find(".market-invalid-author").show()
}}}})
}});
$(function(){if($("#head_ftsearch").length&&$("#search").length){var a={minChars:3,saytResultsClass:".sayt-results",sinvestorResultsClass:".sinvestor-results"};
var c=function(){jQuery(a.saytResultsClass).hide();
jQuery(a.sinvestorResultsClass).hide()
};
var b=function(){if($(a.saytResultsClass).children().length>0){jQuery(a.saytResultsClass).show()
}if($(a.sinvestorResultsClass).children().length>0){jQuery(a.sinvestorResultsClass).show()
}};
var d={serviceUrl:window.location.pathname.replace(/(?:\.external)?\.[a-z]+$/i,"")+".autosuggest.json",paramName:"q",forceFixPosition:true,minChars:a.minChars,appendTo:".autocomplete-suggestions-wrapper",maxHeight:400,zIndex:2100,triggerSelectOnValidInput:false,containerClass:"autocomplete-suggestions",showNoSuggestionNotice:false,formatResult:function(e){return e.data
},deferRequestBy:200,params:{autosuggest_count:jQuery("#head_ftsearch").attr("data-autosuggest_count"),_charset_:"UTF-8"},noCache:false,onSearchStart:function(e){e.q=$.trim(e.q);
if($.trim(e.q).length<a.minChars){return false
}},onSelect:function(){var e=$(this).closest("form");
if(e.find(".srcIsAutosuggest").length===0){e.append("<input type='hidden' name='src_auto' class='srcIsAutosuggest' value='true'/>")
}e.submit()
},onHide:function(e){c();
e.parent().hide()
},beforeRender:function(e){b()
}};
jQuery("#search").devbridgeAutocomplete(d);
c();
jQuery("#search").instantResults();
$(".if6_main").on("click",function(f){if($(f.target).parents("#head_ftsearch").length===0){c();
if(jQuery("#search").devbridgeAutocomplete()!==undefined){jQuery("#search").devbridgeAutocomplete().hide()
}}})
}});
(function(a){a.instantResults=function(g,r){var j=this;
j.onChangeInterval2=null;
var l=a("#head_ftsearch");
var d={visibilityIndicatorClass:"sayt-display-detect",containerClass:"sayt-container",containerId:"sayt-container",resultsClass:"sayt-results",resultsHeadline:l.attr("data-instantresults_resultsHeadline"),instantresultsCount:l.attr("data-instantresults_count"),instantresultsShowAllResults:l.attr("data-instantresults_showAllResults"),sinvestorInstId:(l.attr("data-sinvestor_instid")!==undefined)?l.attr("data-sinvestor_instid"):"",sinvestorInstantresultsCount:l.attr("data-sinvestor_instantresults_count"),sinvestorLinkDekaFonds:l.attr("data-sinvestor_link_deka_fonds"),sinvestorLinkDekaZertifikate:l.attr("data-sinvestor_link_deka_zertifikate"),sinvestorUrl:l.attr("data-sinvestor_url"),sinvestorResultsClass:"sinvestor-results",sinvestorShowAllResults:l.attr("data-sinvestor_showAllResults"),sinvestorNameshares:l.attr("data-sinvestor_name_shares"),sinvestorNamebonds:l.attr("data-sinvestor_name_bonds"),sinvestorNamefunds:l.attr("data-sinvestor_name_funds"),sinvestorNamecerts:l.attr("data-sinvestor_name_certs"),minChars:3,deferRequestBy:200};
var i=this;
i.settings={};
var o=a(g);
var q=0;
var k="";
var p=function(t){return String(t).replace(/&(?!\w+;)/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")
};
i.reset=function(){k=""
};
var n=function(s,t){jQuery.ajax({url:window.location.pathname.replace(/(?:\.external)?\.[a-z]+$/i,"")+".sayt.json",dataType:"json",data:{q:s.val(),seq:++q,instantresults_count:i.settings.instantresultsCount,_charset_:"UTF-8"},timeout:1000,success:function(z){if((z.seq!==undefined)&&(z.seq===q)){var x="";
if((z.results!==undefined)&&Array.isArray(z.results)&&(z.results.length>0)){var u=[];
a.each(z.results,function(A,C){var B='<li class="searchresult-item" id="sayt-'+p(A)+'">';
if(C.url){if(C.title){B+="<h3>"+p(C.title)+"</h3>"
}if(C.descr){B+="<p>"+p(C.descr)+"</p>"
}B+='<a href="'+p(C.url)+'"';
if(C.target){B+=' target="'+p(C.target)+'"'
}if(C.elevated){B+=' data-elevated="'+p(C.elevated)+'"'
}if(C.url){B+=' data-externalizedUrl="'+p(C.externalizedUrl)+'"'
}if(C.externalId){B+=' data-externalId="'+p(C.externalId)+'"'
}B+=">";
B+="</a>"
}B+="</li>";
u.push(B)
});
var w=a("<div/>").text(z.q).html();
x+="<h3>"+i.settings.resultsHeadline.replace(/\%/,w)+"</h3>";
x+='<ul class="sayt-resultlist">'+u.join("")+"</ul>";
x+='<div class="sayt-all"><a href="#" onclick="$(this).closest(\'form\').submit();return false;">'+i.settings.instantresultsShowAllResults+"</a></div>"
}if(x!==""){a("."+i.settings.resultsClass,t).html(x).show()
}else{a("."+i.settings.resultsClass,t).html("").hide()
}var v=[];
var y;
a(".sayt-resultlist a",t).each(function(){y={externalId:this.getAttribute("data-externalId"),externalizedUrl:this.getAttribute("data-externalizedUrl"),elevated:this.getAttribute("data-elevated")};
v.push(y)
});
a(".sayt-resultlist a",t).click(function(){a.ajax({url:a(this).attr("href").replace(/(?:\.html)?(?:\?[\S ]*)?$/,"")+".searchresultclick.json",cache:false,data:{resultType:"SAYT",numResults:a(".sayt-resultlist a").length,results:JSON.stringify(v),queryId:a(this).closest("ul.searchresult-items").attr("data-queryId"),q:s.val(),_charset_:"UTF-8"},timeout:500,async:false,dataType:"json"})
})
}},error:function(){a("."+i.settings.resultsClass,t).html("").hide()
}})
};
var m=["shares","bonds","funds","certs"];
var f=function(t){var s=0;
if(t!==undefined){a.each(m,function(u,v){if((t[v]!==undefined)&&Array.isArray(t[v].entries)){s+=t[v].entries.length
}})
}return s
};
var b=function(w,y,z){var s="";
var x;
var u;
var v;
var t;
s+='<li><h3><a href="'+p(w[y].categoryLink)+'" target="_blank">'+p(z)+"</a></h3><ul>";
a.each(w[y].entries,function(A,B){v=B.link;
x="_blank";
if(B.deka){u="";
if(y==="funds"){u=i.settings.sinvestorLinkDekaFonds
}else{if(y==="certs"){u=i.settings.sinvestorLinkDekaZertifikate
}}if((u!==undefined)&&(u!=="")){t=new SLURI(IF6.urlutil.convertUrl(u));
if(B.isin){t.searchParams.set("isin",B.isin)
}v=t.toString();
x="_top"
}}if(v&&B.name){s+='<li class="searchresult-item">';
s+='<a href="'+p(v)+'" target="'+x+'">'+p(B.name);
if(B.isin){s+=" ("+p(B.isin)+")"
}s+="</a>";
s+="</li>"
}});
s+="</ul></li>";
return s
};
var e=function(u,v,t){var s=0;
if(!t.is(":visible")){s=1
}jQuery.ajax({url:i.settings.sinvestorUrl,dataType:"json",data:{INST_ID:i.settings.sinvestorInstId,searchfor:u.val(),maxitems:i.settings.sinvestorInstantresultsCount,mobile:s,dekafonds:1},timeout:1000,success:function(z,B,y){if(z===undefined){z={error:{code:999}}
}if(z.error===undefined){z.error={code:0}
}var w=f(z);
var x="";
var A="";
if((z.error.code===0)&&(w>0)){x+='<ul class="sinvestor-resultlist">';
a.each(m,function(C,D){if((z[D]!==undefined)&&Array.isArray(z[D].entries)&&z[D].entries.length>0){A=i.settings["sinvestorName"+D];
x+=b(z,D,A)
}});
x+="</ul>"
}if((undefined!==z.linkAllStocks)&&(((z.error.code===0)&&(w>0))||(z.error.code>0))){x+='<div class="sinvestor-all">';
x+='<a href="'+p(z.linkAllStocks)+'" target="_blank">'+p(i.settings.sinvestorShowAllResults)+"</a>";
x+="</div>"
}if(x!==""){a("."+i.settings.sinvestorResultsClass,v).html(x).show()
}else{a("."+i.settings.sinvestorResultsClass,v).html("").hide()
}},error:function(){a("."+i.settings.sinvestorResultsClass,v).html("").hide()
}})
};
var c=function(s,u){clearInterval(j.onChangeInterval2);
var t=a("."+i.settings.visibilityIndicatorClass,u);
if((i.settings.instantresultsCount>0)&&t.is(":visible")){n(s,u)
}else{a("."+i.settings.resultsClass,u).html("").hide()
}if((i.settings.sinvestorInstId.length>0)&&(i.settings.sinvestorInstantresultsCount>0)){e(s,u,t)
}else{a("."+i.settings.sinvestorResultsClass,u).html("").hide()
}};
var h=function(){o.on("input propertychange keyup focus",function(v){if(v.type==="keyup"){var t=v.keyCode||v.which;
if(t===13||t===27){return
}}var s=a(this);
var u=s.parent();
if(s.val().length>=i.settings.minChars){if(k!==s.val()){clearInterval(j.onChangeInterval2);
if(i.settings.deferRequestBy>0){j.onChangeInterval2=setInterval(function(){c(s,u)
},i.settings.deferRequestBy)
}else{c(s,u)
}}}else{a("."+i.settings.resultsClass,u).html("").hide();
a("."+i.settings.sinvestorResultsClass,u).html("").hide()
}k=s.val()
})
};
i.init=function(){i.settings=a.extend({},d,r);
h()
};
i.init()
};
a.fn.instantResults=function(b){this.each(function(){if(undefined===a(this).data("instantResults")){var c=new a.instantResults(this,b);
a(this).data("instantResults",c)
}});
return this
}
}(jQuery));
$(function(){$("#head_ftsearch").on("submit",function(){var a=$("#search",$(this));
a.val(a.val().trim());
if(a.val()===""){return false
}})
});
$(function(){$(".if6_opener .ty1 .overlay>a").not(function(){return $(this).hasClass("linktext")
}).click(function(){return false
})
});
$(window).resize(function(){var u=$(".if6_openerstage").get(0);
var v=$(".if6_opener:visible .opener_image");
var g=$(".if6_opener:visible");
var n,o,m,c=v.css("position"),b,a;
var t=v.toArray(),p;
var d=g.toArray();
var e,l,j,s,h,f;
var q=function(){$(u).trigger("carousel-auto-next")
};
for(n=0;
n<3;
++n){b=false;
m=$(t[0]).find("img[src]").height()||0;
for(o=0;
o<t.length;
++o){p=$(t[o]).find("img[src]").height()||0;
e=$(t[o]).find("img[src]").get(0);
if(e&&e.loaded){b=true;
e.loaded=false
}if(p>=50&&p<m){m=p
}}a=$(d[0]).width();
if(u){if(a!==u.opener_width){b=true;
u.opener_width=a
}if(u.windowWidth&&u.windowWidth===window.innerWidth&&!b){return
}u.windowWidth=window.innerWidth;
if(u.carouseltimer){window.clearTimeout(u.carouseltimer);
u.carouseltimer=null
}}if(!m){m=null
}for(o=0;
o<t.length;
++o){if(c!=="relative"){$(d[o]).height(m);
$(t[o]).height("auto")
}else{$(d[o]).height("auto");
$(t[o]).height(m)
}}if(d.length>1){j='<div class="carousel_play"><div><span class="left" onclick="$(this).trigger(\'carousel-prev\',false);"></span><ul><li class="active" onclick="$(this).trigger(\'carousel-select\',0);"></li>';
m=0;
$(d[0]).css({left:0});
for(o=1;
o<d.length;
++o){l=$(d[o-1]).height();
if(l>m){m=l
}j+="<li onclick=\"$(this).trigger('carousel-select',"+o+');"></li>';
$(d[o]).css({left:(o*a)+"px",marginTop:-l+"px"});
$(d[o-1]).css({height:l+"px"})
}l=$(d[d.length-1]).height();
if(l>m){m=l
}j+='</ul><span class="right" onclick="$(this).trigger(\'carousel-next\',false);"></span></div></div>';
$(".if6_openerstage .if6_inner").height(m);
if($(d[0]).width()!==a){continue
}s=$(".if6_openerstage .carousel_play");
if(s.length>0){s.replaceWith(j)
}else{$(d[d.length-1]).after(j)
}if(u&&u.carouseltimer){window.clearTimeout(u.carouseltimer)
}u.carouseltimer=window.setTimeout(q,10000);
if(c==="relative"){h=$(d[0]).find(".opener_image").height();
f=h-$(".if6_openerstage .carousel_play").height();
$(".if6_openerstage .carousel_play").css({top:f+"px"})
}else{$(".if6_openerstage .carousel_play").css({top:"auto"})
}}n=3
}});
IF6.page=IF6.page||{};
IF6.page.navigation={close:function(){var a=$("body");
if(a.hasClass("navigation_visible")){$("body").removeClass("navigation_visible");
$(".if6_navigation>a").attr("aria-expanded","false");
IF6.statistics.event({stref:"hnav-zu"})
}}};
$(function(){$("body").on("initNavigation",function(){var a=$(".if6_navigation li.active>div").length;
if(a>3){a=3
}$(".if6_navigation>div>div").css("left",-a*$(".if6_navigation>div>div").width());
$(".hnav .if6_navigation li>a").not(function(){var b=this.focus_added;
this.focus_added=true;
return b
}).focus(function(){if(this.blur_timeout){window.clearTimeout(this.blur_timeout);
this.blur_timeout=null
}$(this.parentNode).siblings(".focus").removeClass("focus hover").find(".focus").removeClass("focus");
$(this.parentNode).addClass("focus");
if($(this.parentNode.parentNode).closest("li").length<=0){$(this.parentNode).addClass("hover");
if($(this.parentNode).children("div").length>0){$("body").addClass("hnav_visible")
}else{$("body").removeClass("hnav_visible")
}}}).blur(function(){var b=this.parentNode;
this.blur_timeout=window.setTimeout(function(){var c=$(":focus");
if(!c||c.length<=0||c.closest(".if6_navigation").length<=0){$("body").removeClass("hnav_visible");
$(".if6_navigation li").removeClass("focus hover hold")
}else{if($(b).find(".focus").length<=0){$(b).removeClass("focus hover hold")
}}},200)
});
$(".hnav .if6_navigation>div>div>ul>li>div>.h2,.hnav .if6_navigation>div>div>ul>li>div ul").click(function(){$("body").removeClass("hnav_visible");
$(".if6_navigation li").removeClass("focus hover hold")
});
$(".no-touch .hnav .if6_navigation>div>div>ul>li").not(function(){var b=this.hover_added;
this.over_added=true;
return b
}).hover(function(){var b=this;
if($("body").hasClass("hnav")&&$(".iconbar").is(":hidden")){window.clearTimeout(this.hnav_timeout);
$(this).addClass("hover");
if($(".if6_navigation>div>div>ul>li.focus").length>0){this.hnav_timeout=window.setTimeout(function(){$(b).children("a").focus()
},300)
}else{this.hnav_timeout=window.setTimeout(function(){$(b).children("a").focus()
},500)
}}},function(){window.clearTimeout(this.hnav_timeout);
$(this).removeClass("hover")
});
$(".no-touch .hnav .if6_navigation>div>div>ul").not(function(){var b=this.hover_added;
this.hover_added=true;
return b
}).hover(function(){window.clearTimeout(window.hnav_timeout)
},function(c){var b=this;
window.hnav_timeout=window.setTimeout(function(){var g=$(b).offset();
var f=$(b).width();
var d=$(b).height();
if(c.pageX>=g.left&&c.pageY>=g.top&&c.pageX<=g.left+f&&c.pageY<=g.top+d){return
}$(".if6_navigation li").removeClass("focus hover hold");
$("body").removeClass("hnav_visible");
var e=$(":focus");
if(e&&e.length>0&&e.closest(".if6_navigation").length>0){e.blur()
}},300)
});
$(".no-touch .hnav .if6_navigation>div>div>ul ul>li").not(function(){var b=this.hover_added;
this.hover_added=true;
return b
}).hover(function(){if($("body").hasClass("hnav")&&$(".iconbar").is(":hidden")){if($(this).siblings(".hold").length<=0){$(this).siblings(".focus").removeClass("focus").find(".focus").removeClass("focus");
$(this).addClass("focus");
if($(this).children("div").length>0){$(this).addClass("hold")
}if($(this).siblings().children("a:focus").length>0){$(this.parentNode).closest("li").children("a").focus()
}}return false
}},function(d){var e=$(this).offset();
var c=$(this).width();
var b=$(this).height();
if(d.pageX>=e.left&&d.pageY>=e.top&&d.pageX<=e.left+c&&d.pageY<=e.top+b){return false
}if($("body").hasClass("hnav")&&$(".iconbar").is(":hidden")){if(!$(this).hasClass("hold")){$(this).removeClass("focus")
}}});
$(".no-touch .hnav .if6_navigation>div>div>ul ul").mousemove(function(e){if($("body").hasClass("hnav")&&$(".iconbar").is(":hidden")){var g,h,d,b,f=$(this).children(".hold");
if(f&&f.length>0){h=f.offset();
d=f.width();
b=f.height();
if(e.pageX>=h.left&&e.pageY>=h.top&&e.pageX<=h.left+d&&e.pageY<=h.top+b){this.hnav_startpos=[e.pageX,e.pageY];
return false
}if(this.hnav_startpos&&e.pageX>this.hnav_startpos[0]){if(!this.hnav_lastpos||e.pageX>=this.hnav_lastpos[0]){this.hnav_lastpos=[e.pageX,e.pageY];
if(e.pageY===this.hnav_startpos[1]){return false
}if(e.pageY<this.hnav_startpos[1]){g=f.find(">div>ul>li:first-child").offset();
if(e.pageY>=(this.hnav_startpos[1]+(e.pageX-this.hnav_startpos[0])*(g.top-this.hnav_startpos[1])/(g.left-this.hnav_startpos[0]))){return false
}}else{g=f.find(">div>ul>li:last-child").offset();
g.top+=b;
if(e.pageY<=(this.hnav_startpos[1]+(e.pageX-this.hnav_startpos[0])*(g.top-this.hnav_startpos[1])/(g.left-this.hnav_startpos[0]))){return false
}}}}f.removeClass("hold");
this.hnav_startpos=null;
this.hnav_lastpos=null;
if(e.pageX<h.left){f.mouseleave()
}else{if(e.pageX<=h.left+d){if(e.pageY<h.top){f.removeClass("focus");
f.prev().mouseenter()
}else{f.removeClass("focus");
f.next().mouseenter()
}}}}else{var c=$(this).children(".focus");
if(c&&c.length>0){h=c.offset();
d=c.width();
b=c.height();
if(e.pageX>=h.left&&e.pageX<=h.left+d){if(e.pageY<h.top){c.removeClass("focus");
c.prev().mouseenter()
}}}}return false
}});
$(".if6_navigation>a").click(function(){var b=$("body").hasClass("navigation_visible");
if(!b){$(".if6_navigation>div").scrollTop(0);
$(".if6_navigation div div div").removeClass("navvisible");
$(".if6_navigation li.active>div").addClass("navvisible");
var c=$(".if6_navigation li.active>div").length;
if(c>3){c=3
}$(".if6_navigation>div>div").css("left",-c*$(".if6_navigation>div>div").width());
$(this).attr("aria-expanded","true");
IF6.statistics.event({stref:"hnav-auf"})
}else{$(this).attr("aria-expanded","false");
IF6.statistics.event({stref:"hnav-zu"})
}$("body").toggleClass("navigation_visible");
return false
});
$(".if6_navigation .close-icon").click(function(){IF6.page.navigation.close();
return false
});
$("body").on("swipeleft",function(){IF6.page.navigation.close()
});
$(".if6_navigation li a+div").remove("li li li li a+div").prevAll().click(function(){$(this.parentNode).siblings().removeClass("focus").children("div").removeClass("navvisible");
if($("body").hasClass("hnav")&&$(".iconbar").is(":hidden")){$(this).focus();
return false
}$(this.parentNode).children("div").addClass("navvisible");
var b=$(".if6_navigation>div>div").offset().left;
b-=$(".if6_navigation>div>div").width();
$(".if6_navigation>div>div").css("left",b);
$(".if6_navigation>div").scrollTop(0);
return false
});
$(".if6_navigation .navtop").click(function(){$(".if6_navigation>div>div").css("left",0);
$(".if6_navigation>div").scrollTop(0);
return false
});
$(".if6_navigation a.navback").click(function(){var b=$(".if6_navigation>div>div").offset().left;
b+=$(".if6_navigation>div>div").width();
$(".if6_navigation>div>div").css("left",b);
$(".if6_navigation>div").scrollTop(0);
return false
})
});
$("body").trigger("initNavigation")
});
$(function(){$(".if6_langselect>div>span").on("click",function(){$("body").toggleClass("langselect_visible")
})
});
$(function(){$("[data-myif-async-campaign]").each(function(){var b=$(this);
if(b.is(":visible")){var a=b.data("url");
if(a.indexOf("?")===-1){a+="?t="+(new Date()).getTime()
}else{a+="&t="+(new Date()).getTime()
}$.get(a).done(function(c){if(!c.match(/\sdata-myif-async-campaign/)){if(c!==undefined){b.replaceWith(c);
window.setTimeout(function(){$(window).resize()
},1000);
$("body").trigger("if6_tablecampaign");
$("body").trigger("if6_bannercampaign");
$("body").trigger("if6_kmmstat")
}}})
}})
});
IF6.page=IF6.page||{};
IF6.page.contact={close:function(){var a=$("body");
if(a.hasClass("contact_visible")){$("body").removeClass("contact_visible");
$('.if6_contact>a[href="#"]').attr("aria-expanded","false");
IF6.statistics.event({stref:"kontakt-zu"});
$(document).trigger("contact-close")
}}};
$(function(){$('.if6_contact>a[href="#"]').click(function(){$("body").toggleClass("contact_visible");
if($("body").hasClass("contact_visible")){$('.if6_contact>a[href="#"]').attr("aria-expanded","true");
IF6.statistics.event({stref:"kontakt-auf"});
$(document).trigger("contact-open")
}else{$('.if6_contact>a[href="#"]').attr("aria-expanded","false");
IF6.statistics.event({stref:"kontakt-zu"});
$(document).trigger("contact-close")
}return false
});
$(".if6_contact .close-icon").click(function(){IF6.page.contact.close();
return false
});
$("body").on("swiperight",function(){IF6.page.contact.close()
})
});
function pagenav_statistics_send(a,c){var b=a.prevAll().length;
var d=$(".if6_section:visible .if6_inner>h6").eq(b).html();
IF6.statistics.event({stref:c,pos:b+1,titel:d})
}function pagenav_statistics(b,c){if(IF6.statistics.state.pagenav.timeout){window.clearTimeout(IF6.statistics.state.pagenav.timeout)
}if(!c||c.length===0){c=$(".if6_pagenav .pagenav li.active")
}if(c.length>0){var a=c.prevAll().length;
if(!IF6.statistics.state.pagenav.scroll["i"+a]){if(b>0){IF6.statistics.state.pagenav.timeout=window.setTimeout(pagenav_statistics,b)
}else{IF6.statistics.state.pagenav.scroll["i"+a]=Date.now();
pagenav_statistics_send(c,"iNav-view")
}}}}$(window).resize(function(){var b,c,d,a=$(".if6_section:visible .if6_inner>h6").toArray();
$(".if6_pagenav").remove();
$("body").removeClass("with-pagenav");
$(".pagenavcurrent").remove();
if(a.length<2){return
}c='<div class="if6_outer if6_pagenav"><div class="if6_inner"><ul class="pagenav'+(a.length>4?" pagenav-five":"")+'">';
for(b=0;
b<a.length&&b<5;
++b){c+="<li><div><div>"+a[b].innerHTML+"</div></div></li>"
}c+="</ul></div></div>";
d=$(".if6_breadcrumb");
if(!d||!d.length){d=$(".if6_section:visible").first()
}if(d&&d.length){d.before(c);
$("body").addClass("with-pagenav")
}$(".iconbar").append('<div class="pagenavcurrent"></div>');
$(".iconbar .pagenavcurrent").click(function(){if(!$("body").hasClass("pagenav_visible")){$(".if6_pagenav").removeClass("more-left");
var e=$(".if6_pagenav .pagenav");
e.scrollLeft(0);
e=e.get(0);
if(e){if(e.clientWidth<e.scrollWidth){$(".if6_pagenav").addClass("more-right")
}else{$(".if6_pagenav").removeClass("more-right")
}}}$("body").toggleClass("pagenav_visible")
});
$(".if6_pagenav .pagenav").scroll(function(){var e=this;
if(e.if6_pagenavScrollTimeout){window.clearTimeout(e.if6_pagenavScrollTimeout)
}e.if6_pagenavScrollTimeout=window.setTimeout(function(){var f=$(e).scrollLeft();
if(f>0){$(".if6_pagenav").addClass("more-left")
}else{$(".if6_pagenav").removeClass("more-left")
}if(f+e.clientWidth<e.scrollWidth){$(".if6_pagenav").addClass("more-right")
}else{$(".if6_pagenav").removeClass("more-right")
}},200)
});
$(window).scroll();
$(".if6_pagenav .pagenav li").click(function(){var g=$(this);
var h=g.prevAll().length;
var f=$(".if6_section:visible .if6_inner>h6").parent().parent().toArray();
var e=($(".if6_iconbar .iconbar").css("display")!=="none")?$(".if6_iconbar .iconbar").height():$(".if6_pagenav").height();
var j=Math.ceil($(f[h]).offset().top-e+parseInt($(f[h]).css("marginTop"),10)+3);
$("html,body").animate({scrollTop:j},750,"easeInOutExpo");
$("body").removeClass("pagenav_visible");
pagenav_statistics_send(g,"iNav")
})
});
function pagenav_scroll(f){var b=$(".if6_pagenav");
if(!b||!b.length){return
}var j=window.pageYOffset;
var h=$(".if6_iconbar .iconbar").css("display")!=="none";
if(h){if($(".if6_iconbar").hasClass("iconbar-fixed")){b.addClass("nav-fixed")
}else{b.removeClass("nav-fixed")
}}else{if(j<b.offset().top){b.removeClass("nav-fixed")
}else{b.addClass("nav-fixed")
}}if(j<b.offset().top){$(".if6_pagenav .pagenav li,.iconbar .pagenavcurrent").removeClass("active");
$(".iconbar .pagenavcurrent").html($(".if6_section:visible .if6_inner>h6").first().html())
}else{var d,e=$(".if6_section:visible .if6_inner>h6").parent().parent().toArray();
if(h){j+=$(".if6_iconbar .iconbar").height()
}else{j+=b.height()
}var k,m,g;
for(d=0;
d<e.length;
++d){k=$(e[d]).offset().top;
m=$(e[d]).height()+(d+1<e.length?2*parseInt($(e[d+1]).css("marginTop"),10):0);
if(!d&&$(".if6_section:visible:first-child .if6_inner h6").length){g=$(".if6_breadcrumb");
if(g&&g.length){k-=g.height();
m+=g.height()
}}if(j>=k&&j<k+m){break
}}if(d<e.length){d++;
var a=$(".if6_pagenav .pagenav li:nth-child("+d+")");
if(!a.hasClass("active")){var c=$(".iconbar .pagenavcurrent");
var l=$(".if6_section:visible .if6_inner>h6").eq(d-1).html();
$(".if6_pagenav .pagenav li").removeClass("active");
$.merge(a,c).addClass("active");
c.html(l);
if(f){pagenav_statistics(f)
}}}else{$(".if6_pagenav .pagenav li, .iconbar .pagenavcurrent").removeClass("active");
$(".iconbar .pagenavcurrent").html($(".if6_section:visible .if6_inner>h6").first().html())
}}}function pagenav_scroll_window(){pagenav_scroll(IF6.statistics.config.pagenav.delay)
}$(window).scroll(function(){pagenav_scroll_window();
if(IF6.pagenavScrollTimeout){window.clearTimeout(IF6.pagenavScrollTimeout)
}IF6.pagenavScrollTimeout=window.setTimeout(pagenav_scroll_window,200)
});
$(function(){$(".if6_buttonline .buttonline_inner").each(function(){var a,b=$(this).find(".contactsel:first");
if(b&&b.length>0){a=b.clone();
$(this).append(a);
b.addClass("hide050");
a.addClass("show050")
}$(this).find(".contactsel>a").attr("aria-expanded","false").on("click",function(){$(this.parentNode).toggleClass("visible");
if($(this.parentNode).hasClass("visible")){$(this).attr("aria-expanded","true")
}else{$(this).attr("aria-expanded","false")
}$(this).blur();
return false
})
})
});
$(window).on("resize",function(){if($("body").hasClass("templ-bankingstartpage")||$("body").hasClass("templ-bankingpage")){var a,c;
a=$(".templ-bankingstartpage .cbox-small:visible").toArray();
if(a&&a.length>0){var d=$(a[0]).prevAll(".cbox-medium:visible").last();
if(d&&d.length>0){var f=$(a[0]).position();
if(f.left-d.position().left<30){$(".cbox-small").css({marginTop:""})
}else{$(a[0]).css({marginTop:d.position().top-f.top-parseInt($(a[0]).css("borderTopWidth"),10)});
var b,e;
for(c=1;
c<a.length;
++c){e=$(a[c]).position();
if(f.left!==e.left){break
}b=parseInt($(a[c-1]).css("height"),10);
f.top+=parseInt($(a[c-1]).css("marginTop"),10);
f.top+=parseInt($(a[c-1]).css("marginBottom"),10);
if(e.top<=f.top+b){break
}$(a[c]).css({marginTop:f.top+b-e.top-parseInt($(a[c]).css("borderTopWidth"),10)});
f=e
}}}}return
}$(".if6_section,.if6_homepagearea").each(function(){var n,l,k,g,q,o,m,p,h;
$(this).addClass("resizing");
n=$(this).find(".cbox:visible,.if6_teaserarea .if6_teaser:visible").not(".carousel .cbox-large:visible").toArray();
for(l=0;
l<n.length;
++l){$(n[l]).height("auto")
}for(l=0;
l<n.length;
++l){g=l;
q=true;
o=parseInt($(n[g]).css("height"),10);
while(q){q=false;
m=$(n[g]).offset().top;
for(k=g+1;
k<n.length;
++k){p=$(n[k]).offset().top;
if(p>m){l=k-1;
break
}h=parseInt($(n[k]).css("height"),10);
if(h>o){o=h;
q=true;
break
}if(g+1===k){$(n[k-1]).css("height",o)
}$(n[k]).css("height",o)
}}}$(this).removeClass("resizing")
})
});
$(document).on("if6_page_ready",function(){function b(i){var k,j;
if(i.tagName==="TH"){k=i.innerHTML;
k=k.replace(/&nbsp;/g," ");
k=k.replace(/&shy;/g,"");
k=k.replace(/<div class="ficon.*div>/g,"");
k=k.replace(/<wbr><u class="wbr"><\/u>/g,"");
k=k.replace(/<\/?em>/g,"");
k=k.replace(/\n/g,"");
k=k.replace(/^\s*/,"");
k=k.replace(/\s*$/,"");
k=k.replace(/\s*<br *\/?>\s*$/,"");
k=k.replace(/\s*<br *\/?>\s*/g,"\x0A");
j=k.split("\x0A").length;
return{header:k,cnt:j}
}return null
}var f,d,c,e=$(".table table,table.kkivergleich,table.autoheader").toArray(),g,h,a;
for(f=0;
f<e.length;
++f){if(!e[f].rows||!e[f].rows[0]){continue
}g=[];
h=$(e[f]).hasClass("autoheader");
a=$(e[f]).hasClass("has-checkbox-column");
for(d=0;
d<e[f].rows[0].cells.length;
++d){g[d]=b(e[f].rows[0].cells[d])
}for(c=1;
c<e[f].rows.length;
++c){for(d=0;
d<e[f].rows[c].cells.length;
++d){if(0===d&&a){continue
}if(h&&e[f].rows[c].cells[d].tagName==="TH"){g[d]=b(e[f].rows[c].cells[d])
}else{if(e[f].rows[c].cells[d].tagName==="TD"&&d<g.length&&g[d]){e[f].rows[c].cells[d].setAttribute("data-header",g[d].header);
if(g[d].cnt>1){$(e[f].rows[c].cells[d]).addClass("lines-"+g[d].cnt)
}}}}}}});
$(window).on("resize",function(){$(".if6_contactstage .cs-phone,.if6_contactstage .cs-link").removeClass("with-separator");
var b,a=$(".if6_contactstage .cs-phone:visible,.if6_contactstage .cs-link:visible").toArray();
for(b=1;
b<a.length;
++b){if($(a[b]).offset().top===$(a[b-1]).offset().top){$(a[b]).addClass("with-separator")
}}});
$(window).resize(function(){$(".carousel").each(function(){if(this.windowWidth&&this.windowWidth===window.innerWidth){return
}this.windowWidth=window.innerWidth;
if(this.carouseltimer){window.clearTimeout(this.carouseltimer);
this.carouseltimer=null
}$(this).find(".cbox:visible").height("auto");
var b=$(this).find(".cbox:visible").toArray();
if(b.length>0){$(this).removeClass("carousel-empty");
var d,c=0;
var a,e=parseInt($(b[0]).css("width"),10),g='<div class="carousel_play"><div><span class="left" onclick="$(this).trigger(\'carousel-prev\',false);"></span><ul><li class="active" onclick="$(this).trigger(\'carousel-select\',0);"></li>';
var f=this;
for(d=0;
d<b.length;
++d){a=parseInt($(b[d]).css("height"),10);
if(a>c){c=a
}}$(b[0]).css({left:0,marginTop:0});
for(d=1;
d<b.length;
++d){g+="<li onclick=\"$(this).trigger('carousel-select',"+d+');"></li>';
$(b[d]).css({left:(d*e)+"px",marginTop:-(c+parseInt($(b[d]).css("marginBottom"),10))+"px"})
}g+='</ul><span class="right" onclick="$(this).trigger(\'carousel-next\',false);"></span></div></div>';
$(this).find(".cbox:visible").css({height:c+"px"});
var h=$(this).find(".carousel_play");
if(b.length>1){if(h&&h.length>0){h.replaceWith(g)
}else{$(b[b.length-1]).after(g)
}h=$(this).find(".carousel_play");
$(this).height(c+parseInt($(h).css("height"),10));
this.carouseltimer=window.setTimeout(function(){$(f).trigger("carousel-auto-next")
},10000)
}else{if(h){h.remove()
}$(this).height(c)
}}else{$(this).find(".carousel_play").remove();
$(this).height("auto");
$(this).addClass("carousel-empty")
}})
});
$(document).on("if6_page_ready",function(){$(".accordion .accordion-head.initial-open").not(".initial-invisible").addClass("open").removeClass("initial-open").next(".parsys").fadeIn(0);
$(".accordion .accordion-head").not(function(){var a=this.accordion_added;
this.accordion_added=true;
return a
}).click(function(){$(this).toggleClass("open");
if($(this).hasClass("open")){$(this).nextAll(".parsys").fadeIn("slow");
$(window).resize()
}else{$(this).nextAll(".parsys").fadeOut("slow")
}return false
});
$(".accordion .showall").not(function(){var a=this.accordion_added;
this.accordion_added=true;
return a
}).click(function(){$(this).closest(".accordion").find(".accordion-head").not(".open").click();
$(this).closest(".accordion").find(".showmore").click();
return false
});
$(".accordion .hideall").not(function(){var a=this.accordion_added;
this.accordion_added=true;
return a
}).click(function(){$(this).closest(".accordion").find(".accordion-head.open").click();
return false
});
$(".accordion .showmore").not(function(){var a=this.accordion_added;
this.accordion_added=true;
return a
}).click(function(){$(this).closest(".accordion").find(".accordion-head.initial-invisible").fadeIn("slow");
$(this).closest(".accordion").find(".accordion-head.initial-invisible.initial-open").addClass("open").removeClass("initial-open").next(".parsys").fadeIn("slow");
$(this).remove();
return false
})
});
$(window).on("load",function(){IF6.iconsFixedUsage={};
IF6.iconsVariableUsage={};
IF6.iconsVariableUsageList=[];
IF6.iconsPathPrefix="internetfiliale";
IF6.iconsRuleWritten={};
$(document).trigger("check-iconfont");
if(IF6.refreshIconfontRules){$(document).on("if6_page_ready",function(){$(document).trigger("check-iconfont")
})
}});
$(document).on("check-iconfont",function(){function a(i){if(i.content){var l=i.content;
if(l.charAt(0)==='"'||l.charAt(0)==="'"){l=l.substr(1,l.length-2)
}if(0===l.length){return -1
}if(1===l.length){return l.charCodeAt(0)
}if("\\"===l.charAt(0)){return parseInt(l.substr(1),16)
}}return -1
}function d(l){if(l.font){var i=/^(\d+)px.*Pictos/.exec(l.font);
if(i){return parseInt(i[1],10)
}}return -1
}function k(m){if(m.color){var i=m.color;
var l=/rgb\((\d+), *(\d+), *(\d+)\)/.exec(i);
if(l){i="000000"+Number((parseInt(l[1],10)*256+parseInt(l[2],10))*256+parseInt(l[3],10)).toString(16);
i=i.substr(i.length-6)
}else{if("#"===i.charAt(0)){i=i.substr(1)
}else{i="000000"
}}return i.toLowerCase()
}return null
}function j(n,i,t,q,l,v,p,m){var o,x,s,r,w="";
if(p>0&&m>=0){o=-(p*(m%16));
var y=[2,3,4,6,7,13,3936,3937,3938,3939,3952,3953,3954,3955,3956,3957,3958,3959,3960,3961,3962,3963,3964,3965];
for(s=0;
s<y.length;
++s){if(y[s]===Math.floor(m/16)){x=-(s*p);
x+=p/50;
break
}}if(s>=y.length){return
}w+="background-position:"+o+"px "+x+"px;"
}r=k(l);
if(r){w+="background-image:url("+IF6.iconsPathPrefix+"/fonts/pictos-if-"+r+".png);"
}if(v>0){w+="background-size:"+(16*v)+"px auto;";
w+="background-repeat:no-repeat;";
w+='content:"\\a0" !important;';
if(!l.height){w+="height:"+p+"px;"
}if(!l.width){w+="width:"+p+"px;"
}}if(IF6.iconsRuleWritten[n+q]){return
}IF6.iconsRuleWritten[n+q]=true;
if(i.insertRule){try{i.insertRule(q+"{"+w+"}",t<0||t>i.cssRules.length?i.cssRules.length:t)
}catch(u){}}else{if(i.addRule){try{i.addRule(q,w,t<0||t>i.cssRules.length?i.cssRules.length:t)
}catch(u){}}}}function b(i,m){var q,p,v,o,s,n,t,l,r,u;
v=i.cssRules||i.rules;
for(q=0;
q<v.length;
++q){if(v[q].type===4){b(v[q],v[q].media.mediaText||"media");
continue
}if(!v[q].style){continue
}if(!v[q].selectorText){continue
}o=v[q].selectorText.split(",");
for(p=0;
p<o.length;
++p){if(o[p].indexOf(".no-iconfont")>=0||o[p].indexOf(".iconfonttest")>=0){continue
}u="";
n=o[p];
if(n.match(/:before$/)){u=":before"
}else{if(n.match(/:after$/)){u=":after"
}}n=n.replace(/:+(before|after)$/,"");
n=n.replace(/^\s+/,"");
r=".no-iconfont";
if(n.indexOf(".js.no-touch")>=0){n=n.replace(/.js.no-touch /,"")
}else{if(n.indexOf(".no-touch.js")>=0){n=n.replace(/.no-touch.js /,"")
}else{if(n.indexOf(".no-touch")>=0){n=n.replace(/.no-touch /,"")
}else{if(n.indexOf(".js")>=0){n=n.replace(/.js /,"")
}else{r+=" "
}}}}if(n.indexOf(":hover")>=0){n=n.replace(/:+hover/,"");
if(IF6.iconsFixedUsage[n+u]||!isNaN(IF6.iconsVariableUsage[n+u])){j(m,i,q+1,r+(o[p].replace(/^\s+/,"")),v[q].style,-1,-1,-1);
continue
}}t=d(v[q].style);
l=a(v[q].style);
if(t<0){continue
}if(l<0&&IF6.iconsFixedUsage[n+u]){l=a(IF6.iconsFixedUsage[n+u])
}if(l<0){if(!IF6.iconsVariableUsage[n+u+m]){IF6.iconsVariableUsage[n+u+m]=IF6.iconsVariableUsageList.length;
IF6.iconsVariableUsageList.push({fontsize:t,media:m,stylesheet:i,sel:n})
}}else{if(!IF6.iconsFixedUsage[n+u]){IF6.iconsFixedUsage[n+u]=v[q].style
}}j(m,i,q+1,r+(o[p].replace(/^\s+/,"")),v[q].style,t,t,l)
}}}function c(){var t,s,q,o,w,p,u,n,r,v,l;
for(t=0;
t<document.styleSheets.length;
++t){b(document.styleSheets[t],"")
}for(t=0;
t<document.styleSheets.length;
++t){w=document.styleSheets[t].cssRules||document.styleSheets[t].rules;
for(s=0;
s<w.length;
++s){if(!w[s].style){continue
}if(!w[s].selectorText){continue
}p=w[s].selectorText.split(",");
for(q=0;
q<p.length;
++q){if(0!==p[q].indexOf(".icon-")){continue
}l=a(w[s].style);
if(l>=0){r=p[q];
r=r.replace(/:+(before|after)$/,"");
r=r.replace(/^(\s+)/,"");
if($(r).length<=0){continue
}for(o=0;
o<IF6.iconsVariableUsageList.length;
++o){n=r;
if(".actioniconLink"===IF6.iconsVariableUsageList[o].sel){n=IF6.iconsVariableUsageList[o].sel
}else{if(IF6.iconsVariableUsageList[o].fontsize===IF6.iconsVariableUsageList[IF6.iconsVariableUsage[".actioniconLink:before"]].fontsize){continue
}}if(n===IF6.iconsVariableUsageList[o].sel){n=".no-iconfont "+p[q]
}else{if($(IF6.iconsVariableUsageList[o].sel+r).length<=0){continue
}n=".no-iconfont "+IF6.iconsVariableUsageList[o].sel+p[q]
}j(IF6.iconsVariableUsageList[o].media,IF6.iconsVariableUsageList[o].stylesheet,""===IF6.iconsVariableUsageList[o].media?s+1:-1,n,w[s].style,-1,IF6.iconsVariableUsageList[o].fontsize,l)
}}}}}}function h(m){var n,l,i,o;
o=m.cssRules||m.rules;
n=/^(.*\/)81%(.*Pictos.*)$/;
for(i=0;
i<o.length;
++i){if(o[i].type===4){h(o[i]);
continue
}if(!o[i].style){continue
}if(!o[i].selectorText){continue
}if(!o[i].style.font){continue
}if(o[i].selectorText.indexOf(":before")<0&&o[i].selectorText.indexOf("after")<0){continue
}l=n.exec(o[i].style.font);
if(l){o[i].style.font=l[1]+"65%"+l[2]
}}}if(IF6.refreshIconfontRules){c();
return
}var g=$(".iconfonttest span+span").width();
if(g>0&&g<20){c();
$("html").addClass("no-iconfont");
IF6.refreshIconfontRules=true
}else{var e,f=$(".iconfonttest").children().toArray();
if(2===f.length){if($(f[0]).height()!==$(f[1]).height()){for(e=0;
e<document.styleSheets.length;
++e){h(document.styleSheets[e])
}}}}$(".iconfonttest").remove()
});
$(function(){$("body,.swipe-horizontal").on("touchstart",function(b){if($(this).hasClass("swipe-horizontal")||$(this).hasClass("navigation_visible")||$(this).hasClass("contact_visible")){var a=b.originalEvent||b;
this.firstEvent={ts:Date.now(),x:a.touches[0].pageX,y:a.touches[0].pageY,velocity:0};
this.lastEvent=this.firstEvent
}else{this.lastEvent=null
}}).on("touchmove",function(f){if(!this.lastEvent){return
}var e=f.originalEvent||f;
e={x:e.touches[0].pageX,y:e.touches[0].pageY};
var b=Math.abs(this.firstEvent.x-e.x),g=Math.abs(this.firstEvent.y-e.y);
if((b>9||g>9)&&b<=g){this.lastEvent=null;
return
}var c=Date.now();
var d;
var a=c-this.lastEvent.ts;
if(a>50||!this.lastEvent.velocity){d=Math.abs(this.lastEvent.x-e.x)/a||0
}else{d=this.lastEvent.velocity
}this.lastEvent=e;
this.lastEvent.ts=c;
this.lastEvent.velocity=d;
f.preventDefault()
}).on("touchend",function(){if(!this.lastEvent){return
}if(this.lastEvent.velocity<0.3){return
}var a=this.firstEvent.x-this.lastEvent.x;
if(a<-50){$(this).trigger("swiperight")
}else{if(a>50){$(this).trigger("swipeleft")
}}})
});