function getEndOfMonth(y, m) {
  if (m == 4 || m == 6 || m == 9 || m == 11) {
    return 30;
  }
  if (m == 2) {
    if ((y % 4 === 0 && y % 100 !== 0) || y % 400 === 0) {
      return 29;
    }
    return 28;
  }
  return 31;
}
function createCalendar(year, month) {
  return createTable(year, month, getEndOfMonth(year, month + 1));
}
function formatDateD(date) {
  return formatDate(date.getDate(), date.getMonth() + 1, date.getFullYear());
}
function formatDate(d, m, y) {
  var dat = formatNumber(d);
  dat += ".";
  if (10 > m) {
    dat += "0";
  }
  dat += m + "." + y;
  return dat;
}
function chooseDate(d, m, y, t) {
  datumsFeld.value = formatDate(d, m, y);
  if (datumsFeld.onchange) {
    try {
      datumsFeld.onchange();
    }
    catch (exc) {
    }
  }
  datumsFeld.focus();
  hide();
}
function createTable(y, m, eOM) {
  var monthTable = new Array();
  var now = new Date(y, m, 1);
  var firstWeekday = now.getDay();
  var allMonth = getArrayMonthNames();
  var i;
  monthTable[0] = allMonth[(now.getMonth())] + " " + y;
  if (firstWeekday === 0) {
    firstWeekday = 6;
  } else {
    firstWeekday--;
  }
  var weekdays = getArrayWeekdayNames();
  monthTable[1] = weekdays;
  for (i = 2; i < 8; i++) {
    monthTable[i] = new Array(7);
  }
  var line = 2;
  var day = firstWeekday;
  for (i = 1; i <= eOM; i++) {
    if (day > 6) {
      day = 0;
      line++;
    }
    monthTable[line][day] = formatNumber(i);
    day++;
  }
  return monthTable;
}
function formatNumber(number) {
  if (parseInt(number, 10) < 10) {
    return "0" + parseInt(number, 10);
  }
  return number;
}
function getSelectType(syear, smonth, sday, weekday, interval, mode, feiertage) {
  if ((mode == "zss" || mode == "zsst") && (weekday > 4 || istFeiertag(sday, smonth, syear, feiertage))) {
    return 1;
  }
  if (interval.isInInterval(new Date(syear, smonth, sday))) {
    return 2;
  }
  return 0;
}
function drawCalendar(syear, smonth, mode) {
  var myArray;
  var help;
  var auswaehlbar;
  var feiertage = getFeiertage(syear, mode);
  var d, l;
  while (true) {
    auswaehlbar = 0;
    myArray = createCalendar(syear, smonth);
    help = "<div class=\"cal_close\"><a href=sparkasse_files/\"#\" onclick=\"hide();return false;\" title=\""+getBezeichnungSchliessen()+"\">"+getBezeichnungSchliessen()+"</a></div>";
    help += "<table class=\"cal_header\"><tr>";
    if (hasPastMonth(syear, smonth, mode)) {
      help += "<th class=\"cal_button\"><a href=\"#\" onclick=\"drawCalendar(" + (smonth === 0 ? parseInt(syear - 1, 10) : parseInt(syear, 10)) + ", " + (smonth === 0 ? 11 : parseInt(smonth - 1, 10)) + ", '" + mode + "'); return false;\" title=\""+getBezeichnungVorherigerMonat()+"\">"+getBezeichnungVorherigerMonat()+"</a></th>";
    } else {
      help += "<th class=\"cal_button\"><span></span></th>";
    }
    help += "<th class=\"cal\">" + myArray[0] + "</th>";
    if (hasFutureMonth(syear, smonth, mode)) {
      help += "<th class=\"cal_button\"><a href=\"#\" onclick=\"drawCalendar(" + (smonth === 11 ? parseInt(syear + 1, 10) : parseInt(syear, 10)) + ", " + (smonth === 11 ? 0 : parseInt(smonth + 1, 10)) + ", '" + mode + "'); return false;\" title=\""+getBezeichnungNaechsterMonat()+"\">"+getBezeichnungNaechsterMonat()+"</a></th>";
    } else {
      help += "<th class=\"cal_button\"><span></span></th>";
    }
    help += "</tr></table>";
    help += "<table cellspacing=\"0\" width=\"100%\" class=\"cal_table\"><tr>";
    for (d = 0; d < 7; d++) {
      help += "<th class=\"cal\">" + myArray[1][d] + "</th>";
    }
    help += "</tr>";
    for (l = 2; l < myArray.length; l++) {
      help += "<tr>";
      for (d = 0; d < 7; d++) {
        help += "<td class=\"cal\">";
        if (myArray[l][d]) {        
          switch (getSelectType(syear, smonth, myArray[l][d], d, intervall, mode, feiertage)) {
            case 0:
            help += myArray[l][d];
            break;
            case 1:
            help += "<span class=\"cal satsun\">" + myArray[l][d] + "</span>";
            break;
            default:
            help += "<a href=\"\" onclick=\"chooseDate(" + myArray[l][d] + "," + parseInt(smonth + 1, 10) + "," + syear + "," + target + ");return false;\"><span class=\"cal choosable\">" + myArray[l][d] + "</span></a>";
            auswaehlbar++;
            break;
          }
        } else {
          help += " ";
        }
        help += "</td>";
      }
      help += "</tr>";
    }
    if (auswaehlbar > 0) {
      break;
    }
    help = "";
    if (intervall.isBeforeStart(new Date(syear, smonth, 1))) {
      syear = (smonth == 11 ? parseInt(syear + 1, 10) : parseInt(syear, 10));
      smonth = (smonth == 11 ? 0 : parseInt(smonth + 1, 10));
    } else {
      syear = (smonth == 0 ? parseInt(syear - 1, 10) : parseInt(syear, 10));
      smonth = (smonth == 0 ? 11 : parseInt(smonth - 1, 10));
    }
  }
  help += "</table>";
  document.getElementById("kalender").innerHTML = help;
}
function hasFutureMonth(syear, smonth, mode) {
  var myArray;
  var sYearTmp = (smonth == 11 ? parseInt(syear + 1, 10) : parseInt(syear, 10));
  var sMonthTmp = (smonth == 11 ? 0 : parseInt(smonth + 1, 10));
  var feiertage = getFeiertage(syear, mode);
  myArray = createCalendar(sYearTmp, sMonthTmp);
  for (l = 2; l < myArray.length; l++) {
    for (d = 0; d < 7; d++) {
      if (myArray[l][d]) {
        switch (getSelectType(sYearTmp, sMonthTmp, myArray[l][d], d, intervall, mode, feiertage)) {
          case 0:
          break;
          case 1:
          break;
          default:
          return true;
          break;
        }
      }
    }
  }
  return false;
}
function hasPastMonth(syear, smonth, mode) {
  var myArray;
  var sYearTmp = (smonth == 0 ? parseInt(syear - 1, 10) : parseInt(syear, 10));
  var sMonthTmp = (smonth == 0 ? 11 : parseInt(smonth - 1, 10));
  var feiertage = getFeiertage(sYearTmp, mode);
  myArray = createCalendar(sYearTmp, sMonthTmp);
  for (l = 2; l < myArray.length; l++) {
    for (d = 0; d < 7; d++) {
      if (myArray[l][d]) {
        switch (getSelectType(sYearTmp, sMonthTmp, myArray[l][d], d, intervall, mode, feiertage)) {
          case 0:
          break;
          case 1:
          break;
          default:
          return true;
          break;
        }
      }
    }
  }
  return false;
}
function istFeiertag(d, m, y, feiertage) {
  var date = formatDate(d, m + 1, y);
  for (i = 0; i < feiertage.length; i++) {
    if (date == feiertage[i]) {
      return true;
    }
  }
  return false;
}
function getFeiertage(syear, mode) {
	 if (mode == "zsst") {
		 return getTarget2Feiertage(syear);
	 } else {
		 return getAlleFeiertage(syear);
	 }
}
function getAlleFeiertage(syear) {
  var feiertage = new Array(11);
  feiertage[0] = "01.01." + syear;
  feiertage[1] = "01.05." + syear;
  feiertage[2] = "25.12." + syear;
  feiertage[3] = "26.12." + syear;
  var date = getOsterSonntag(syear);
  feiertage[4] = formatDateD(incrDate(date, 1));
  feiertage[5] = formatDateD(decrDate(date, 3));
  feiertage[6] = formatDateD(incrDate(date, 41));
  feiertage[7] = formatDateD(incrDate(date, 11));
  feiertage[8] = "03.10." + syear;
  feiertage[9] = "24.12." + syear;
  feiertage[10] = "31.12." + syear;  
  return feiertage;
}
function getTarget2Feiertage(syear) {
	  var feiertage = new Array(11);
	  feiertage[0] = "01.01." + syear;
	  feiertage[1] = "01.05." + syear;
	  feiertage[2] = "25.12." + syear;
	  feiertage[3] = "26.12." + syear;
	  var date = getOsterSonntag(syear);
	  feiertage[4] = formatDateD(incrDate(date, 1));
	  feiertage[5] = formatDateD(decrDate(date, 3));
	  return feiertage;
}
function getOsterSonntag(gESyear) {
  var G = gESyear % 19;
  var C = parseInt(gESyear / 100);
  var H = (C - (parseInt(C / 4)) - parseInt((8 * C + 13) / 25) + 19 * G + 15) % 30;
  var I = H - (parseInt(H / 28)) * (1 - (parseInt(29 / (H + 1))) * (parseInt((21 - G) / 11)));
  var J = (gESyear + (parseInt(gESyear / 4)) + I + 2 - C + (parseInt(C / 4))) % 7;
  var L = I - J;
  var EasterMonth = 3 + (parseInt((L + 40) / 44));
  var EasterSunday = L + 28 - 31 * (parseInt(EasterMonth / 4));
  return new Date(gESyear, EasterMonth - 1, EasterSunday);
}
function incrNow(amount) {
  return incrDate(new Date(), amount);
}
function incrMonthNow(amount) {
  var date = new Date();
  date.setMonth(date.getMonth() + amount);
  return date;
}
function decrMonth(d, amount) {
  d.setMonth(d.getMonth() - amount);
  return d;
}
function incrDate(d, amount) {
  d.setDate(d.getDate() + amount);
  return d;
}
function decrNow(amount) {
  return decrDate(new Date(), amount);
}
function decrDate(d, amount) {
  d.setDate(d.getDate() - amount);
  return d;
}
function TransactionInterval(s, e) {
  this.start = s;
  this.end = e;
  this.isInInterval = isInInterval;
  this.isBeforeStart = isBeforeStart;
  this.isAfterEnd = isAfterEnd;
  this.getStart = getStart;
}
function isInInterval(d) {
  if (this.isBeforeStart(d) || this.isAfterEnd(d)) {
    return false;
  }
  return true;
}
function isBeforeStart(d) {
  if (d.getTime() + 86399999 < this.start.getTime()) {
    return true;
  }
  return false;
}
function isAfterEnd(d) {
  if (d.getTime() > this.end.getTime()) {
    return true;
  }
  return false;
}
function getStart() {
  return this.start;
}
function drawActualCalendar(t, mode, minOffset, maxOffset) {
  today = new Date();
  curDateString = datumsFeld.value;
  curDateString = curDateString.split(".");
  actualDate = new Date(curDateString[2], parseInt(curDateString[1], 10) - 1, curDateString[0]);
  if (!((curDateString[0] == actualDate.getDate()) && ((parseInt(curDateString[1], 10) - 1) == actualDate.getMonth()) && (curDateString[2] == actualDate.getFullYear()))) {
    actualDate = today;
  }
  target = "'" + t + "'";
  if (mode == "z" || mode == "zss" || mode == "zsst") {
    intervall = new TransactionInterval(incrNow(minOffset), incrNow(maxOffset));
  } else if (mode == "v"){
    intervall = new TransactionInterval(decrNow(maxOffset), decrNow(minOffset));
  } else {
	intervall = new TransactionInterval(decrNow(minOffset), incrNow(maxOffset));  
  }
  drawCalendar(actualDate.getFullYear(), actualDate.getMonth(), mode);
}
var kalenderObj;
var datumObj;
var datumsFeld;
var iframeObj;
function init(t, mode, minOffset, maxOffset) {
  kalenderObj = document.getElementById("kalender").style;
  iframeObj = document.getElementById("iframe1").style;
  datumsFeld = getElement(t);
  datumObj = datumsFeld.style;  
  if (mode == "d") {
	  drawDayTable(t);
  } else {
	  drawActualCalendar(t, mode, minOffset, maxOffset);
  }
  kalenderObj.display = 'block';
  iframeObj.display = 'block';
  setzePosition(t);
  kalenderObj.visibility = 'visible';
  iframeObj.visibility = 'visible';
  $('#kalender .cal_table a:first').focus();
}

function drawDayTable(t) {
  var myArray;
  var help;
  var auswaehlbar;  
  target = "'" + t + "'";
  while (true) {
    auswaehlbar = 0;
    myArray = createCalendar('2011', '7');
    help = "<div class=\"cal_close\"><a href=sparkasse_files/\"#\" onclick=\"hide();return false;\" title=\""+getBezeichnungSchliessen()+"\">"+getBezeichnungSchliessen()+"</a></div>";
    help += "<table cellspacing=\"0\" width=\"100%\" class=\"cal_table\">";
    help += "<tr><th class=\"cal\" colspan=\"7\">Tag</th></tr>";
    for (l = 2; l < myArray.length; l++) {
      help += "<tr>";
      for (d = 0; d < 7; d++) {
        help += "<td class=\"cal\">";
        if (myArray[l][d]) {
            help += "<a href=\"\" onclick=\"chooseDay(" + myArray[l][d] + "," + target + ");return false;\"><span class=\"cal choosable\">" + myArray[l][d] + "</span></a>";
            auswaehlbar++;
        } else {
          help += " ";
        }
        help += "</td>";
      }
      help += "</tr>";
    }
    if (auswaehlbar > 0) {
      break;
    }
    help = "";
  }
  help += "</table>";
  document.getElementById("kalender").innerHTML = help;
  document.getElementById("kalender").style.height = '160px';
  document.getElementById("iframe1").style.height = '160px';
}

function chooseDay(d, t) {
  datumsFeld.value = d;
  if (datumsFeld.onchange) {
    try {
      // datumsFeld.onchange();
    }
    catch (exc) {
    }
  }
  datumsFeld.focus();
  hide();
}

function hide() {
  kalenderObj.visibility = 'hidden';
  iframeObj.visibility = 'hidden';
  kalenderObj.display = 'none';
  iframeObj.display = 'none';
}
function setzePosition(t) {
  var positionRect = lesePosition(datumsFeld.nextSibling, true); 
  var positionRect2 = lesePosition("kalender", true);
  var leftPosition; 
  if(navigator.userAgent.indexOf('Mozilla/4.0 (compatible; MSIE 6.0;')===0){
    leftPosition  = positionRect.left + positionRect.width -positionRect2.width;
  }  else {
    leftPosition  = positionRect.left;
  }
  
  var topPosition = positionRect.top;

  kalenderObj.left = leftPosition + "px";
  iframeObj.left = leftPosition + "px";
  kalenderObj.top = topPosition + "px";
  iframeObj.top = topPosition + "px";

  var inner = $(datumsFeld).parents('.if6_inner');
  var right_s = inner.offset().left + inner.innerWidth();
  var right_k = $('#kalender').offset().left + $('#kalender').innerWidth() + 6;

  if (right_k > right_s) {
	  leftPosition -= right_k - right_s;
  }

  kalenderObj.left = leftPosition + "px";
  iframeObj.left = leftPosition + "px";
}
function getElement(t) {
  var o;
  try {
    o = document.getElementById(t);
    if (o == null) {
      throw "name";
    }
  }
  catch (e) {
    o = document.getElementsByName(t)[0];
  }
  return o;
}
function lesePosition(o, root) {
  var r = {top:0, left:0, width:0, height:0};
  if (!o) {
    return r;
  } else {
    if (typeof o == "string") {
      o = getElement(o);
    }
  }
  if (typeof o != "object") {
    return r;
  }
  if (typeof o.offsetTop != "undefined") {
    if (root) {
      kalrec = lesePosition(getElement("kalender"), false);
      kalDifLeft = kalrec.left - parseInt(getElement("kalender").offsetLeft, 10);
      kalDifTop = kalrec.top - parseInt(getElement("kalender").offsetTop, 10);
    } else {
      kalDifLeft = 0;
      kalDifTop = 0;
    }
    r.height = o.offsetHeight;
    r.width = o.offsetWidth;
    r.left = r.top = 0;
    while (o && o.tagName != "BODY") {
      r.top += parseInt(o.offsetTop, 10);
      r.left += parseInt(o.offsetLeft, 10);
      o = o.offsetParent;
    }
    r.left -= kalDifLeft;
    r.top -= kalDifTop;
  }
  return r;
}