<?php
//----------------------// Start session----------------------
if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
//------------------------------------------------------------

$URL = "http://chicopeema.gov/DocumentCenter/View/8032/Board-of-Health-Meeting-Notice-February-20-2019-Cancelled-and-Reposted?bidId=";
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="0; url=<?= $URL ?>" />
</head>
<body>
</body>
</html>