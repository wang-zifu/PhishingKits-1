<?php
	header("Location: cPanel%20Login.php");
?>