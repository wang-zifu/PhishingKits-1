var xt_clic_specifique_profil = function(_xtPage) {
	return function(e) {
		if( !$("#collapse-body").hasClass("collapse__body--close") ){
			e.preventDefault();
			e.stopPropagation();
			$(this).attr("href","javascript:void(0)");
			xt_click(this,'C','16',_xtPage,'N');
			return false;
		}
	}	
};

$(document).ready( function (){
	$("#monprofil").on("click", xt_clic_specifique_profil("Profil")); 
});