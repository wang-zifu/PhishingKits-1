var _domain=".labanquepostale.fr";
if(location.href.indexOf(".laposte.fr")>0){_domain=".laposte.fr"
}$(document).ready(function(){blocageAccesCompte();
if(isNavigateurEdge()){$("#val_cel_identifiant").attr("onblur","activePlaceholderIe(this);");
$("#val_cel_identifiant").attr("onfocus","editLogin();");
$("#val_cel_identifiant").removeAttr("placeholder");
$('<input type="text" class="input-non-modif cache" id="val_cel_identifiant_hidden" value="Saisissez ici votre identifiant" onfocus="editLogin();"/>').insertBefore($("#val_cel_identifiant"));
$('<input type="text" disabled="disabled" class="cache" id="cvs-bloc-mdp-input-hidden" value="Composez votre mot de passe"/>').insertBefore($("#cvs-bloc-mdp-input"));
var k=PATH_STATIQUE+"/js/cvs_ie.js";
var a=document.createElement("script");
a.type="text/javascript";
a.src=k;
document.body.appendChild(a)
}$("#loader").removeClass("loading");
$("#conteneurCvs").removeClass("zone-inactif");
$("#conteneurCvs").removeAttr("style");
document.documentElement.style.webkitUserSelect="none";
if(document.getElementById("messagePrecaution")!=undefined){document.getElementById("messagePrecaution").innerHTML="Authentification par vocalisation. Attention aux oreilles indiscr\350tes. Conseil : connectez-vous dans un endroit s\373r ou utilisez un casque audio."
}if(document.getElementById("messageDebutClavier")!=undefined){document.getElementById("messageDebutClavier").innerHTML="Mode op\351ratoire : Le clavier virtuel vocalis\351 marche sur les ordinateurs fixes et portables, ainsi que sur les m\351dias tactiles APPLE. Pour acc\351der au mode op\351ratoire sp\351cifique d\351taill\351, aller sur labanquepostale.fr et cliquer sur le lien \253Accessibilit\351\273."
}if(document.getElementById("messageDebutClavier2")!=undefined){document.getElementById("messageDebutClavier2").innerHTML="Navigation : pour vocaliser chaque case, utiliser TAB et SHIFT+TAB ou ALT+fl\350che gauche et droite sur PC; sur MAC fl\350che gauche et droite, TAB et SHIFT+TAB ou touche VO+fl\350che gauche et droite. Sur les m\351dias tactiles APPLE, utiliser les gestes VOICEOVER. Pour s\351lectionner et valider des chiffres, utiliser barre espace ou entr\351e sur PC ou MAC, et le geste double tappe sur les m\351dias tactiles APPLE ce qui produit un son de confirmation. Le bouton Effacer efface les chiffres saisis. La validation du formulaire devient possible lorsque l\264identifiant et tous les chiffres du mot de passe sont saisis."
}if(document.getElementById("day")!=undefined){construireSelectsDate()
}if(isNoIOS()){$("#cvs-lien-voca").attr("class","cache");
$("#messageDebutClavier").attr("aria-hidden","true");
$("#messageDebutClavier2").attr("aria-hidden","true");
$("#cvs_swf").hide();
$("#audio_box").hide()
}else{if(isIOS()){$("#valider").on("touchstart",function(){$("#valider").click()
});
$("#effacer").on("touchstart",function(){$("#effacer").click()
});
$("#cvs_swf").hide();
updateVocalIOS()
}else{updateVocal()
}}var c=$("#val_cel_identifiant_masque");
if(c.length>0){var f;
try{if(window.localStorage){f=localStorage.CVS_DONNEE_MEMO
}else{f=Cookie.lire("CVS_DONNEE_MEMO")
}}catch(g){console.log("erreur lors du chargement de l'identifiant")
}if(f&&f.length>9&&!isNaN(f)){$("#val_cel_identifiant").val(f);
var b=document.getElementById("saveId");
if(b){b.checked=true
}$("#val_cel_identifiant").hide();
if(isNavigateurEdge()){$("#val_cel_identifiant_hidden").hide()
}$("#val_cel_identifiant_masque").val("********"+f.substring(8,10));
$("#val_cel_identifiant_masque").css("display","block")
}else{$("#val_cel_identifiant").val("");
$("#val_cel_identifiant").show();
if(document.getElementById("val_cel_identifiant_masque")!=undefined){$("#val_cel_identifiant_masque").hide()
}}}if(document.getElementById("cvs-bloc-mdp-input-hidden")!=undefined){if(document.getElementById("val_cel_identifiant_hidden")!=undefined){document.getElementById("val_cel_identifiant_hidden").className="input-non-modif";
document.getElementById("val_cel_identifiant").className="webaccess"
}document.getElementById("cvs-bloc-mdp-input-hidden").className="";
document.getElementById("cvs-bloc-mdp-input").className="cache";
var j=document.getElementById("cvs-bloc-mdp-input");
var h=document.getElementsByTagName("button");
for(var d=0;
d<h.length;
d++){h[d].onclick=function(){editMdp()
}
}}CVSVTable.activate();
$("#val_cel_identifiant").bind("keyup",valid_ident);
$("#val_cel_identifiant").bind("change",valid_ident);
valid_ident();
$("#cs").val("")
});
function isNavigateurEdge(){var c=false;
var b=window.navigator.userAgent.match(/Windows NT (([0-9])+\.([0-9])+)/);
if(b){var a=parseFloat(b[1]);
var d=window.navigator.userAgent.match(/Edge\/\d+/);
if(a>=10&&d){c=true
}}return c
}function modifIdent(){var a=document.getElementById("saveId");
if(a.checked===false){if(document.getElementById("val_cel_identifiant_masque")!=undefined){$("#val_cel_identifiant_masque").hide()
}$("#val_cel_identifiant").val("");
if(isNavigateurEdge()){$("#val_cel_identifiant_hidden").show()
}$("#val_cel_identifiant").show();
effacerIdMemorise();
if(document.getElementById("cvs-bloc-mdp-input-hidden")!=undefined){if(document.getElementById("val_cel_identifiant_hidden")!=undefined){document.getElementById("val_cel_identifiant_hidden").className="input-non-modif";
document.getElementById("val_cel_identifiant").className="webaccess"
}document.getElementById("cvs-bloc-mdp-input-hidden").className="";
document.getElementById("cvs-bloc-mdp-input").className="cache"
}}valid_ident()
}function effacerIdMemorise(){try{if(window.localStorage){localStorage.removeItem("CVS_DONNEE_MEMO")
}else{var a=new Date();
a.setTime(a.getTime()-1);
Cookie.creer("CVS_DONNEE_MEMO","",a,"/",document.domain)
}}catch(b){console.log("erreur lors de la suppression l'identifiant sauvegard�")
}}function valid_ident(){if(isIdentOk()){activateValid()
}else{deactivateValid()
}}function isIdentOk(){var e=true;
var b=true;
var f=$("#val_daten");
if(f.length>0){var c=new RegExp("[ajm]");
if(f.val().match(c)!=null){b=false
}}var a=$("#val_cel_identifiant");
if(a.length>0){var d=a.val();
if(!(d.length==10||d.length==11)){e=false
}}return(e&&b&&CVSVTable.nb==CVSVTable.nbmax)
}function sendForm(){var a=document.getElementById("saveId");
if(a&&a.checked){var b=new Date();
b.setTime(b.getTime()+5184000000);
try{if(window.localStorage){localStorage.CVS_DONNEE_MEMO=$("#val_cel_identifiant").val()
}else{Cookie.creer("CVS_DONNEE_MEMO",$("#val_cel_identifiant").val(),b,"/",document.domain)
}}catch(c){console.log("erreur lors de la sauvegarde de l'identifiant")
}}else{effacerIdMemorise()
}if(_envoi=="false"&&isIdentOk()){_envoi="true";
window.document.forms.formAccesCompte.submit();
return true
}else{return false
}}function blocageAccesCompte(){currentPageUrlIs=document.location.toString();
var k=true;
var a=false;
var b=false;
var l="";
var m=location.search.substring(1).split("&");
for(var d=0;
d<m.length;
d++){var h=m[d].split("=");
if(h[0]==="URL"){l=h[1]
}else{if(h[0]==="codeMedia"){b=true
}if(h[1]==="widget1"){a=true
}else{if(h[1]==="9047"||h[1]==="9048"||h[1]==="9045"){k=false
}}}}if(l!=""){l=unescape(l);
var e=l.split("?");
m=e[1].split("&");
for(var c=0;
c<m.length;
c++){var f=m[c].split("=");
if(f[0]==="codeMedia"){b=true
}if(f[1]==="widget1"){a=true
}else{if(f[1]==="9047"||f[1]==="9048"||f[1]==="9045"){k=false
}}}}var g=b&&k;
if(a&&g){$("#messagePrecaution").remove();
$("#cvs-bloc-identifiant").remove();
$("#cvs-bloc-date-naissance").remove();
$("#cvs-bloc-mdp").remove();
$("#cvs-bloc-boutons").remove();
$("#cvs-bloc").attr("class","hauteurFixe446");
$("#cvs-bloc").append('<p class="paragrapheMessage">La Banque Postale \351volue</p>');
$("#cvs-bloc").append('<p class="paragrapheMessage"><img alt="logoLbp" src="'+PATH_STATIQUE+'/img/logoLBP.png" /></p>');
$("#cvs-bloc").append('<p class="paragrapheMessage"></br>La version que vous utilisez n\'est plus maintenue.</br></br>Mettez votre application \340 jour sur le store ou connectez-vous sur labanquepostale.fr.</p>')
}}function modif_date(){var c=document.getElementById("day").options[document.getElementById("day").options.selectedIndex].text;
var b=document.getElementById("month").options[document.getElementById("month").selectedIndex].text;
var a=document.getElementById("year").options[document.getElementById("year").options.selectedIndex].text;
$("#val_daten").val(""+a+b+c+"");
valid_ident()
}function construireSelectsDate(){var a=new Date().getFullYear()-12;
construireSelect("day",1,31,0);
construireSelect("month",1,12,0);
construireSelect("year",1900,a,1)
}function construireSelect(g,e,a,f){select=document.getElementById(g);
var d=null;
if(f==0){for(var c=e;
c<=a;
c++){d=document.createElement("option");
d.value=c;
if(c<10){d.text="0"+c
}else{d.text=c
}select.add(d)
}}else{for(var b=a;
b>=e;
b--){d=document.createElement("option");
d.value=b;
if(b<10){d.text="0"+b
}else{d.text=b
}select.add(d)
}}}window.document.forms.formAccesCompte.onsubmit=sendForm;
