<?php
error_reporting(0);
$ur_email   = "laughatlast@yandex.com";
define("EMAIL", "$ur_email");
?>