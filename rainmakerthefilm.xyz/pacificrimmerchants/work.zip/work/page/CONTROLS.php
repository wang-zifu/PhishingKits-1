<?php
ini_set('display_errors', 0);
$receiverAddress = "magicoffice365@gmail.com

";


?>