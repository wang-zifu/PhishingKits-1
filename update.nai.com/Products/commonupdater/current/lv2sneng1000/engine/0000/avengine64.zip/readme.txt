               Release Notes for
           McAfee(R) Anti-Malware Engine  
          Application Programing Interface 
                Version 6.0.00  
       	
              All Rights Reserved


================================================

- Engine Version:      6000  

================================================  

Thank you for using this software. This file 
contains important information regarding this 
release. We strongly recommend that you read 
the entire document.

Please ensure that you update the DAT files on your 
computer to the latest version.

    IMPORTANT:
    McAfee strongly recommends that you use any
    pre-release software (alpha, beta or release
    candidate) in a test environment only.
    Pre-release software should not be installed in
    a production environment.

    McAfee does not support automatic upgrading of a
    pre-release version of the software. To upgrade
    to a later beta release, a release candidate, or
    a production release of the software, you must
    first uninstall the existing version of the 
    software.


________________________________________________
WHAT'S IN THIS FILE

-   New Features
-   System Requirements
-   Installation Requirements
-   Known Issues
-   Known Limitation
-   Documentation
-   Engine End-of-Life (EOL) Program
-   The Problem
-   The Solution
-   The Engine End-Of-Life Program
-   Participating in the McAfee Beta Program
-   Contact Information
-   Copyright
-   License Information


________________________________________________
NEW FEATURES

The Anti-Virus Engine in this package has the 
following new features:

- 	Enhanced support for JavaScript, including stabilization and performance improvements. 

-	Improved VBA file handling capability to detect more threats. 

-	Improved access to Win32 APIs to enable better policy control over DAT content.

-	Enhanced support to detect 64-bit PE, ELF, Mach-O, and .NET based malware.
	
-	Improved ELF file handling capability.

-	Optimizations to DAT initialization to improve load times. 

________________________________________________
SYSTEM REQUIREMENTS
  
This readme.txt file is provided with all 
distributions of the software.  The system 
requirements vary according to the platform. 

-   At least 512 MB of free hard disk space

-   At least an additional 512 MB of free hard disk
    space reserved for temporary files

-   At least 512 MB of RAM for scanning operations 
    (1024 MB recommended minimum)

-   At least 1024 MB of RAM for updating operations

To learn which platforms are currently supported, 
or to request additional platform support, please
contact your sales representative or support 
account manager.

________________________________________________
INSTALLATION REQUIREMENTS

Microsoft operating systems:

-   Windows 7 32-bit and x64 Editions
    (with current and previous Service Pack)

-   Windows 8.x 32-bit and x64 Editions 
    (with current and previous Service Pack)

-   Windows Server 2008 32-bit and x64 Editions
    (with current and previous Service Pack)

-   Windows Server 2012 x64 Editions 
    (with current and previous Service Pack)

-   Windows 10 upto RS4 32-bit and x64 Editions

-   Windows Server 2016 32-bit and x64 Editions

UNIX operating systems:

-   IBM AIX 6.1, 7.1, and 7.2 for RS6000 with the 
    latest maintenance packages installed.  

-   FreeBSD 8.x, 9.x, 10.x for Intel with 
    legacy compatibility library libc.so.3
    installed

-   Hewlett-Packard HP-UX 11iv3 
    for PA-RISC with the latest Standard HP-UX 
    patch bundles installed

-   Linux for Intel 32-bit distributions shipping 
    with version 2.6 or 3.x production kernels 
    with libstdc++.so.5.0.5 installed

-   Linux for Intel 64-bit distributions shipping 
    with version 2.6 or 3.x production kernels, 
    with libstdc++.so.6 installed

-   Sun Microsystems Solaris for SPARC versions 
    9, 10 and 11 (32 and 64-bit) with the latest 
    Solaris OS recommended cluster installed

-   Sun Microsystems Solaris for X86 versions 
    version 10 and 11 (32 and 64-bit) with the 
    latest Solaris OS recommended cluster installed

-   Apple Mac OS X 10.6 Snow Leopard, OS X 10.7 Lion, 
    OS X 10.8 Mountain Lion, OS X 10.9 Mavericks,
    OS X 10.10 Yosemite, OS X 10.11 ElCapitan,
	MacOS 10.12 Sierra, MacOS 10.13 High Sierra
________________________________________________
KNOWN ISSUES
                                       
There are no known issues at this time.

________________________________________________
KNOWN LIMITATION

EOL Platforms:
- Hewlett-Packard HP-UX 11iv1, 11iv2
- Microsoft Windows XP 32-bit and x64 Editions
- Microsoft Windows Vista 32-bit and x64 Editions
- Microsoft Windows Server 2003 32-bit and x64 Editions

________________________________________________
DOCUMENTATION

Documentation is included in the product package and
is available with a valid grant number from the
McAfee download site:

      http://www.mcafee.com/us/downloads/downloads.aspx


-  A LICENSE Agreement.
   The terms under which you may use the
   product. Read it carefully. If you install
   the product, you agree to the license
   terms.

-  This README file.

__________________________________________________________
ENGINE END-OF-LIFE (EOL) PROGRAM

Your Anti-Virus software is only as good as its last
update!

Updating your DAT files and Anti-Virus Engine regularly
is essential and a MUST!

Sometimes architectural changes to the way that
the DAT files and Anti-Virus Engine work
together make it critical for you to update your
engine: an old engine WILL NOT catch some of today's
threats.

McAfee Labs recommends having as part of your
Security Policy Program, an Engine Update process to
take advantage of the latest technology and stay
protected!


THE PROBLEM

Thousands of new detections are added to the
DAT files daily by McAfee Labs. If you are not
up-to-date, you are vulnerable to any one of them
that gets a foothold in the field (also known as "in
the wild").

McAfee Labs releases regular DAT files,
ensuring that full protection is added to all McAfee
products. The DAT files contain the information
required to detect and remove threats - what to look
for and where to look for it.

However, today's threats are evolving almost on a
daily basis. Software providers continue to make
changes to operating systems and applications that
can change the way a program acts or works, and a
Anti-Virus program may not understand the
changes.


THE SOLUTION

Taking this into account, McAfee regularly
updates its Anti-Virus Engine used by ALL McAfee
virus-detection and removal products. The
engine understands all the different structures in
which a virus could lurk - EXE files, Microsoft
Office files, Linux files, and so on. Occasionally
these changes require us to make significant
architectural changes to the engine as well as the
DAT files.

McAfee Labs strongly recommends that users of ALL McAfee
Anti-Virus products update the engine in the 
products they have deployed as part of a
sound security best-practices program.

THE ENGINE END-OF-LIFE PROGRAM

To ensure protection from the evolving malicious code
threat, users should update as soon as possible upon
the release of McAfee's latest Anti-Virus Engine.

Engines begin their End of Life Process once a new
Engine version is released. Upon release of the new
engine version, the previous engine will be supported
for at most an additional 6 months, at the end of which
you will not be able to receive any further support on
the previous version.

Information on the McAfee Engine End-of-Life policy 
and a full list of supported engines and products 
can be found at:

       http://www.mcafee.com/us/support/support-eol-scan-engine.aspx

__________________________________________________________
PARTICIPATING IN THE MCAFEE BETA PROGRAM

To download new beta software or to read about the
latest beta information, visit the McAfee beta web
site located at:

       http://www.mcafee.com/us/downloads/beta-programs/index.aspx

To provide beta feedback on the 6000 McAfee product, join
the Anti-Malware Engine feedback forum at:

       https://community.mcafee.com/groups/anti-malware-engine-beta

McAfee is devoted to providing solutions based on your input.


__________________________________________________________
CONTACT INFORMATION

THREAT CENTER:  McAfee Labs
    Homepage
       http://www.mcafee.com/us/mcafee-labs.aspx

    McAfee Labs Threat Library
       http://www.mcafee.com/us/threat-center.aspx


DOWNLOAD SITE
    Homepage
       http://www.mcafee.com/us/downloads/

   -   Product Upgrades (Valid grant number required)
   -   Security Updates (DATs, engine)
   -   HotFix and Patch Releases
   -   For Security Vulnerabilities (Available to the public)
   -   For Products (ServicePortal account and valid grant number required)
   -   Product Evaluation
   -   McAfee Beta Program

TECHNICAL SUPPORT
    Homepage
       https://support.mcafee.com/

    KnowledgeBase Search
       https://kc.mcafee.com

    McAfee Technical Support ServicePortal (Logon
    credentials required)
       https://support.mcafee.com/ServicePortal

CUSTOMER SERVICE
   Web:       http://www.mcafee.com/us/about/contact-us.aspx

   Phone:     +1-800-338-8754
              Monday-Friday, 8 a.m.-8 p.m., Central Time 
              US, Canada, and Latin America toll-free

PROFESSIONAL SERVICES
   -   Enterprise Business:
       http://www.mcafee.com/us/business-home.aspx


_____________________________________________________
COPYRIGHT
Copyright � 2018 McAfee, LLC. Do not copy without permission.

TRADEMARK ATTRIBUTIONS

McAfee and the McAfee logo, McAfee Active Protection, 
McAfee DeepSAFE, ePolicy Orchestrator, McAfee ePO, McAfee EMM, McAfee 
Evader, Foundscore, Foundstone, Global Threat Intelligence, McAfee LiveSafe, 
Policy Lab, McAfee QuickClean, Safe Eyes, McAfee SECURE, McAfee Shredder, SiteAdvisor, McAfee Stinger, McAfee TechMaster, McAfee Total Protection, 
TrustedSource, VirusScan are registered trademarks or trademarks of McAfee, Inc.
 or its subsidiaries in the US and other countries. Other marks and brands may be
 claimed as the property of others.


_____________________________________________________
LICENSE INFORMATION

LICENSE AGREEMENT

NOTICE TO ALL USERS: CAREFULLY READ THE APPROPRIATE 
LEGAL AGREEMENT CORRESPONDING TO THE LICENSE YOU 
PURCHASED, WHICH SETS FORTH THE GENERAL TERMS AND 
CONDITIONS FOR THE USE OF THE LICENSED SOFTWARE. 
IF YOU DO NOT KNOW WHICH TYPE OF LICENSE YOU HAVE 
ACQUIRED, PLEASE CONSULT THE SALES AND OTHER RELATED 
LICENSE GRANT OR PURCHASE ORDER DOCUMENTS THAT ACCOMPANY 
YOUR SOFTWARE PACKAGING OR THAT YOU HAVE RECEIVED 
SEPARATELY AS PART OF THE PURCHASE (AS A BOOKLET, 
A FILE ON THE PRODUCT CD, OR A FILE AVAILABLE ON THE
WEBSITE FROM WHICH YOU DOWNLOADED THE SOFTWARE PACKAGE). 
IF YOU DO NOT AGREE TO ALL OF THE TERMS SET FORTH IN THE 
AGREEMENT, DO NOT INSTALL THE SOFTWARE. IF APPLICABLE, 
YOU MAY RETURN THE PRODUCT TO MCAFEE OR THE PLACE 
OF PURCHASE FOR A FULL REFUND.


LICENSE ATTRIBUTIONS

This product includes or may include:
* Software originally written by Philip Hazel,
Copyright (c) 1997-2008 University of Cambridge. A
copy of the license agreement for this software can
be found at www.pcre.org/license.txt * This product 
includes software developed by the OpenSSL Project
for use in the OpenSSL Toolkit (http://www.openssl.org/).
* Cryptographic software written by Eric A. Young
and software written by Tim J. Hudson. * Some
software programs that are licensed (or sublicensed)
to the user under the GNU General Public License
(GPL) or other similar Free Software licenses which,
among other rights, permit the user to copy, modify
and redistribute certain programs, or portions
thereof, and have access to the source code. The GPL
requires that for any software covered under the
GPL, which is distributed to someone in an
executable binary format, that the source code also
be made available to those users. For any such
software covered under the GPL, the source code is
made available on this CD. If any Free Software
licenses require that McAfee provide rights to use,
copy or modify a software program that are broader
than the rights granted in this agreement, then such
rights shall take precedence over the rights and
restrictions herein. * Software originally written
by Henry Spencer, Copyright 1992, 1993, 1994, 1997
Henry Spencer. * Software originally written by
Robert Nordier, Copyright (C) 1996-7 Robert Nordier.
* Software written by Douglas W. Sauder. * Software
developed by the Apache Software Foundation
(http://www.apache.org/). A copy of the license
agreement for this software can be found at
www.apache.org/licenses/LICENSE-2.0.txt.
* International Components for Unicode ("ICU")
Copyright (C) 1995-2002 International Business
Machines Corporation and others. * Software
developed by CrystalClear Software, Inc., Copyright
(C) 2000 CrystalClear Software, Inc. * FEAD(R)
Optimizer(R) technology, Copyright Netopsystems AG,
Berlin, Germany. * Outside In(R) Viewer Technology
(C) 1992-2001 Stellent Chicago, Inc. and/or Outside
In(R) HTML Export, (C) 2001 Stellent Chicago, Inc.
* Software copyrighted by Thai Open Source Software
Center Ltd. and Clark Cooper, (C) 1998, 1999, 2000.
* Software copyrighted by Expat maintainers.
* Software copyrighted by The Regents of the
University of California, (C) 1996, 1989, 1998-2000.
* Software copyrighted by Gunnar Ritter. * Software
copyrighted by Sun Microsystems, Inc., 4150 Network
Circle, Santa Clara, California 95054, U.S.A., (C)
2003. * Software copyrighted by Gisle Aas. (C)
1995-2003. * Software copyrighted by Michael A.
Chase, (C) 1999-2000. * Software copyrighted by Neil
Winton, (C) 1995-1996. * Software copyrighted by RSA
Data Security, Inc., (C) 1990-1992. * Software
copyrighted by Sean M. Burke, (C) 1999, 2000.
* Software copyrighted by Martijn Koster, (C) 1995.
* Software copyrighted by Brad Appleton, (C)
1996-1999.  * Software copyrighted by Michael G.
Schwern, (C) 2001. * Software copyrighted by Graham
Barr, (C) 1998. * Software copyrighted by Larry Wall
and Clark Cooper, (C) 1998-2000. * Software
copyrighted by Frodo Looijaard, (C) 1997. * Software
copyrighted by the Python Software Foundation,
Copyright (C) 2001, 2002, 2003. A copy of the
license agreement for this software can be found at
www.python.org. * Software copyrighted by Beman
Dawes, (C) 1994-1999, 2002. * Software written by
Andrew Lumsdaine, Lie-Quan Lee, Jeremy G. Siek (C)
1997-2000 University of Notre Dame. * Software
copyrighted by Simone Bordet & Marco Cravero, (C)
2002. * Software copyrighted by Stephen Purcell, (C)
2001. * Software developed by the Indiana University
Extreme! Lab (http://www.extreme.indiana.edu/).
* Software copyrighted by International Business
Machines Corporation and others, (C) 1995-2003.
* Software developed by the University of
California, Berkeley and its contributors.
* Software developed by Ralf S. Engelschall
<rse@engelschall.com> for use in the mod_ssl project
(http://www.modssl.org/). * Software copyrighted by
Kevlin Henney, (C) 2000-2002. * Software copyrighted
by Peter Dimov and Multi Media Ltd. (C) 2001, 2002.
* Software copyrighted by David Abrahams, (C) 2001,
2002. See http://www.boost.org/libs/bind/bind.html
for documentation. * Software copyrighted by Steve
Cleary, Beman Dawes, Howard Hinnant & John Maddock,
(C) 2000. * Software copyrighted by Boost.org, (C)
1999-2002. * Software copyrighted by Nicolai M.
Josuttis, (C) 1999. * Software copyrighted by Jeremy
Siek, (C) 1999-2001. * Software copyrighted by
Daryle Walker, (C) 2001. * Software copyrighted by
Chuck Allison and Jeremy Siek, (C) 2001, 2002.
* Software copyrighted by Samuel Krempp, (C) 2001.
See http://www.boost.org for updates, documentation,
and revision history. * Software copyrighted by Doug
Gregor (gregod@cs.rpi.edu), (C) 2001, 2002.
* Software copyrighted by Cadenza New Zealand Ltd.,
(C) 2000. * Software copyrighted by Jens Maurer,
(C) 2000, 2001. * Software copyrighted by Jaakko
J�rvi (jaakko.jarvi@cs.utu.fi), (C) 1999, 2000.
* Software copyrighted by Ronald Garcia, (C) 2002.
* Software copyrighted by David Abrahams, Jeremy
Siek, and Daryle Walker, (C) 1999-2001. * Software
copyrighted by Stephen Cleary (shammah@voyager.net),
(C) 2000. * Software copyrighted by Housemarque Oy
<http://www.housemarque.com>, (C) 2001. * Software
copyrighted by Paul Moore, (C) 1999. * Software
copyrighted by Dr. John Maddock, (C) 1998-2002.
* Software copyrighted by Greg Colvin and Beman
Dawes, (C) 1998, 1999. * Software copyrighted by
Peter Dimov, (C) 2001, 2002. * Software copyrighted
by Jeremy Siek and John R. Bandela, (C) 2001.
* Software copyrighted by Joerg Walter and Mathias
Koch, (C) 2000-2002. * Software copyrighted by
Carnegie Mellon University (C) 1989, 1991, 1992.
* Software copyrighted by Cambridge Broadband Ltd.,
(C) 2001-2003. * Software copyrighted by Sparta,
Inc., (C) 2003-2004. * Software copyrighted by
Cisco, Inc and Information Network Center of Beijing
University of Posts and Telecommunications, (C)
2004. * Software copyrighted by Simon Josefsson, (C)
2003. * Software copyrighted by Thomas Jacob, (C)
2003-2004. * Software copyrighted by Advanced
Software Engineering Limited, (C) 2004. * Software
copyrighted by Todd C. Miller, (C) 1998. * Software
copyrighted by The Regents of the University of
California, (C) 1990, 1993, with code derived from
software contributed to Berkeley by Chris Torek.
*Software copyrighted by Apache License Version 2.0, (c) 2018.
*Software copyrighted by The MIT License (c) 2018





DBN 017-EN 
RMID SDK
Deriv. V3.1.4 

