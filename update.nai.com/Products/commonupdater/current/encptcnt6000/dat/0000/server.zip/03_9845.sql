-- remove entry , fixed for bz 383217														
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_Desktop_Firewall_80';
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_Desktop_Firewall_85';

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE name='HIP7SP_DeleteTrustedApp' AND xtype='P')
BEGIN
  EXEC HIP7SP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_Desktop_Firewall_80';
  EXEC HIP7SP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_Desktop_Firewall_85';
END

-- (bz 306130) after oct 2006 content release, we can remove from here --
-- remove entry
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_Entercept_51';

-- remove entry
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_Enterprise_51';

-- remove trancated entries for groupshield 5.2.1 and 5.3 (two entries overlapping, and became one)
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_GroupShield_for_Domino_5';

-- remove trancated entry for spamkiller for domino 2.1 and exchange 2.1
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_SpamKiller_for_Domino_21';
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_SpamKiller_for_Exchange_21';

-- remove trancated entry for virusscan for netapp 7.1.0
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_for_NetApp_71.0';

-- remove trancated entry for eBusiness client administration
EXEC ENTSP_DeleteTrustedApp 'ENT6000_TrustedApp_McAfee_eBusiness_Client_Administration';

-- (bz 306130) to here --

-- ENTSP_SetTrustedApp: AppID varchar(50), PolicyIndex, Name nvarchar(100), Note nvarchar(1000),
--						IsEnabled bit, IPSTrustedStatus bit, FWTrustedStatus bit, HookTrustedStatus bit,
--						ProcessList nvarchar(4000)

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_McTray', 0, 'McAfee Tray Icon', NULL, 1, 0, 0, 1, '%ProgramFiles%\McAfee\Common Framework\McTray.exe|%ProgramFiles%\Network Associates\Common Framework\McTray.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_Enterprise_80', 0, 'McAfee VirusScan Enterprise 8.0i, 8.5 and 8.8', NULL, 1, 1, 0, 1, '%CommonProgramFiles%\Network Associates\Engine\Scan.exe|%CommonProgramFiles%\Network Associates\TalkBack\TBMon.exe|%ProgramFiles%\Network Associates\VirusScan\*|%ProgramFiles%\McAfee\VirusScan Enterprise\*|%CommonProgramFiles%\McAfee\SystemCore\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_Common_Framework', 0, 'McAfee Common Framework', NULL, 1, 1, 1, 0, '%ProgramFiles%\Network Associates\Common Framework\*|%ProgramFiles%\McAfee\Common Framework\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_Alert_Manager_47', 0, 'McAfee Alert Manager 4.7', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\Alert Manager\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_Autoupdate_Architect_112', 0, 'McAfee Autoupdate Architect 1.1.2', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\McAfee Autoupdate Architect\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_ePO_36', 0, 'McAfee ePO 3.6, 3.6.1, 4.0 and 4.5', NULL, 1, 1, 0, 0, '%CommonProgramFiles%\McAfee\Apache2\bin\*|%CommonProgramFiles%\McAfee\Common Framework\*|%ProgramFiles%\McAfee\Common Framework\*|%ProgramFiles%\Network Associates\Common Framework\*|%CommonProgramFiles%\McAfee\JAVA\bin\*|%CommonProgramFiles%\McAfee\MSDE\MSSQL$EPOSERVER\Binn\*|%CommonProgramFiles%\McAfee\Tomcat\bin\*|%CommonProgramFiles%\Microsoft Shared\dasetup\dasetup.exe|%ProgramFiles%\McAfee\ePO\3.6.0\*|%ProgramFiles%\Microsoft SQL Server\80\COM\DISTRIB.exe|%ProgramFiles%\Microsoft SQL Server\80\COM\replmerg.exe|%ProgramFiles%\Microsoft SQL Server\80\COM\snapshot.exe|%ProgramFiles%\Microsoft SQL Server\80\Tools\Binn\bcp.exe|%ProgramFiles%\Microsoft SQL Server\80\Tools\Binn\cnfgsvr.exe|%ProgramFiles%\Microsoft SQL Server\80\Tools\Binn\DTSRUN.exe|%ProgramFiles%\Microsoft SQL Server\80\Tools\Binn\scm.exe|%ProgramFiles%\Microsoft SQL Server\80\Tools\Binn\sqlmangr.exe|%ProgramFiles%\Microsoft SQL Server\80\Tools\Binn\SVRNETCN.exe|%ProgramFiles%\McAfee\ePO\3.6.1\*|%ProgramFiles%\McAfee\ePolicy Orchestrator\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_GroupShield_60', 0, 'McAfee GroupShield 6.0', NULL, 1, 1, 0, 0, '%CommonProgramFiles%\McAfee\log and quarantine\bin\*|%CommonProgramFiles%\Network Associates\Outbreak Manager\*|%ProgramFiles%\Network Associates\Alert Manager\*|%ProgramFiles%\Network Associates\McAfee GroupShield\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_AntiSpyware_85', 0, 'McAfee AntiSpyware Enterprise 8.5', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\AntiSpyware Enterprise\Mcshield.exe|%ProgramFiles%\McAfee\AntiSpyware Enterprise\scan32.exe|%ProgramFiles%\McAfee\AntiSpyware Enterprise\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_WebShield_SMTP', 0, 'McAfee WebShield SMTP', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\TVD\WebShield SMTP\mailscan.exe|%ProgramFiles%\Network Associates\TVD\WebShield SMTP\MailCFG.exe|%ProgramFiles%\Network Associates\TVD\WebShield SMTP\*|%CommonProgramFiles%\McAfee\log and quarantine\bin\*|%CommonProgramFiles%\Network Associates\Outbreak Manager\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_Quarantine_Manager', 0, 'McAfee Quarantine Manager', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\Quarantine Manager\bin\*'
GO

-- renew entry with shorter name
EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_GS_for_Domino_521', 0, 'McAfee GroupShield for Domino 5.2.1', NULL, 1, 1, 0, 0, 'C:\Lotus\Domino\GSDConfigWizard.exe|C:\Lotus\Domino\nGSDConfig.exe|C:\Lotus\Domino\nGSDLDI.exe|C:\Lotus\Domino\nGSDOAScan.exe|C:\Lotus\Domino\nGSDODScan.exe|C:\Lotus\Domino\nGSDReport.exe|C:\Lotus\Domino\nGSDUpdate.exe|%CommonProgramFiles%\InstallShield\Engine\6\Intel 32\IKernel.exe|%CommonProgramFiles%\McAfee\log and quarantine\bin\*|%CommonProgramFiles%\Network Associates\Outbreak Manager\*|%ProgramFiles%\McAfee\GroupShield for Lotus Domino\*'
GO

-- renew entry with shorter name
EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_GS_for_Domino_53', 0, 'McAfee GroupShield for Domino 5.3', NULL, 1, 1, 0, 0, 'C:\Lotus\Domino\GSDConfigWizard.exe|C:\Lotus\Domino\nMcAfeeConfig.exe|C:\Lotus\Domino\nMcAfeeLDI.exe|C:\Lotus\Domino\nMcAfeeOAScan.exe|C:\Lotus\Domino\nMcAfeeODScan.exe|C:\Lotus\Domino\nMcAfeeReport.exe|C:\Lotus\Domino\nMcAfeeUpdate.exe|%CommonProgramFiles%\McAfee\log and quarantine\bin\i386\*|%CommonProgramFiles%\Network Associates\Outbreak Manager\*|%ProgramFiles%\McAfee\GroupShield for Lotus Domino\GSDEIWiz.exe|%ProgramFiles%\Network Associates\Alert Manager\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_ProtectionPilot_101', 0, 'McAfee ProtectionPilot 1.0.1', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\ProtectionPilot\*|%SystemRoot%\IsUninst.exe|%SystemRoot%\MUI\muisetup.exe|%SystemRoot%\system32\cliconfg.exe|%SystemRoot%\system32\odbcad32.exe|%SystemRoot%\system32\odbcconf.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_SecurityShield_10', 0, 'McAfee SecurityShield 1.0', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\McAfee SecurityShield\*'
GO

-- renew entry with shorter name
EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_SK_for_Domino_21', 0, 'McAfee SpamKiller for Domino 2.1', NULL, 1, 1, 0, 0, 'C:\Lotus\Domino\nMcAfeeConfig.exe|C:\Lotus\Domino\nMcAfeeLDI.exe|C:\Lotus\Domino\nMcAfeeOAScan.exe|C:\Lotus\Domino\nMcAfeeReport.exe|C:\Lotus\Domino\nMcAfeeUpdate.exe|%ProgramFiles%\McAfee\SpamKiller for Lotus Domino\*|%SystemRoot%\myCIO\Agent\UpdDlg.exe|%CommonProgramFiles%\Network Associates\TalkBack\TBMon.exe'
GO

-- renew entry with shorter name
EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_SK_for_Exchange_21', 0, 'McAfee SpamKiller for Exchange 2.1', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\McAfee SpamKiller\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_asap', 0, 'McAfee VirusScan ASAP', NULL, 1, 1, 0, 0, '%SystemRoot%\myCIO\Agent\HtmlDlg.exe|%SystemRoot%\myCIO\Agent\myAgtSvc.exe|%SystemRoot%\myCIO\Agent\myAgtTry.exe|%SystemRoot%\myCIO\Agent\myINX.exe|%SystemRoot%\myCIO\Agent\myUpdHlp.exe|%SystemRoot%\myCIO\VScan\Browse.exe|%SystemRoot%\myCIO\VScan\Splash.Exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_asap_3', 0, 'McAfee VirusScan for ASAP 3', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\Managed VirusScan\Agent\*|%ProgramFiles%\McAfee\Managed VirusScan\VScan\*'
GO

-- renew entry with shorter name
EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VS_for_NetApp_710', 0, 'McAfee VirusScan for NetApp 7.1.0', NULL, 1, 1, 0, 0, '%CommonProgramFiles%\Network Associates\Engine\Scan.exe|%ProgramFiles%\Network Associates\VirusScan for NetApp\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_eBusiness_Server_80', 0, 'McAfee eBusiness Server 8.0', NULL, 1, 1, 0, 0, '%ProgramFiles%\Network Associates\McAfee E-Business Server\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_eBusiness_Server_85', 0, 'McAfee eBusiness Server 8.5', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\McAfee E-Business Server\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_HIP_60', 0, 'McAfee Host Intrusion Prevention 6.0, 6.1 and 7.0', NULL, 1, 1, 0, 1, '%ProgramFiles%\McAfee\Host Intrusion Prevention\FireSvc.exe|%ProgramFiles%\McAfee\Host Intrusion Prevention\FireTray.exe|%ProgramFiles%\McAfee\Host Intrusion Prevention\HIPSCore\HIPSvc.exe|%SystemRoot%\system32\mfevtps.exe|%ProgramFiles%\McAfee\Host Intrusion Prevention\Helper.exe|%ProgramFiles%\McAfee\Host Intrusion Prevention\x64\Helper.exe|%ProgramFiles%\McAfee\Host Intrusion Prevention\WinSecCtr.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_McMERTool', 0, 'McAfee ePO MER', NULL, 1, 1, 0, 1, '%SystemRoot%\TEMP\McMERTool.exe|%TEMP%\McMERTool.exe|%SystemRoot%\TEMP\WebMERClient.exe|%TEMP%\WebMERClient.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_SafeBoot', 0, 'McAfee SafeBoot', NULL, 1, 1, 0, 1, '%ProgramFiles%\SafeBoot\*|%ProgramFiles%\SafeBoot Content Encryption\SbCeCore.exe|%ProgramFiles%\SafeBoot Content Encryption\SbCeCoreService.exe|%ProgramFiles%\SafeBoot Content Encryption\SbCeSetup.exe|%ProgramFiles%\SafeBoot Content Encryption\SbCeSelfExtractorStub.exe|%ProgramFiles%\SafeBoot Content Encryption\SbCeShell.exe|%ProgramFiles%\SafeBoot Content Encryption\SbCe.sys|%ProgramFiles%\SafeBoot Port Control\SbPcManager.exe|%ProgramFiles%\SafeBoot Port Control\SbPcSetup.exe|%ProgramFiles%\SafeBoot Port Control\SbPrtCtl.sys|%ProgramFiles%\SafeBoot Tray Manager\SbTrayManager.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_winlogon', 0, 'Microsoft Windows Winlogon', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\winlogon.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_WindowsExplorer', 0, 'Microsoft Windows Explorer', NULL, 1, 0, 0, 1, '%SystemRoot%\explorer.exe'
GO

-- renew entry with shorter name
EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_eB_Client_Admin', 0, 'McAfee E-Business Client Administration', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\*\EBCAdmin.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_eBusiness_Client', 0, 'McAfee E-Business Client', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\*\EBClient.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_DLP', 0, 'McAfee Data Loss Prevention', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\DLP\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_WinDefender_UI', 0, 'Windows Defender User Interface', NULL, 1, 0, 0, 1, '%ProgramFiles%\windows defender\msascui.exe|%ProgramFiles%\windows defender\MpCmdRun.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_WinSessionManager', 0, 'Windows Session Manager', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\smss.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_DesktopWindowManager', 0, 'Desktop Window Manager', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\dwm.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_WinLogon_UI_Host', 0, 'Windows Logon User Interface Host', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\LogonUI.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Control_Panel', 0, 'Windows Control Panel', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\control.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Task_Scheduler', 0, 'Windows Task Scheduler Engine', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\taskeng.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Vista_Help', 0, 'Windows Vista Help Engine', NULL, 1, 0, 0, 1, '%SystemRoot%\HelpPane.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Shadow_Copy', 0, 'Microsoft ShadowCopy', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\VSSVC.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Installer', 0, 'Windows Modules Installer', NULL, 1, 0, 0, 1, '%SystemRoot%\Servicing\TrustedInstaller.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Defrag', 0, 'Windows Disk Defragmenter Module', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\Defrag.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_dcom_dll_host', 0, 'Microsoft DCOM DLL Host Process', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\dllhost.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Vista_Activation', 0, 'Windows Vista Activation', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\SLUI.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Logon_ScrnSaver', 0, 'Windows Logon Screen Saver', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\logon.scr'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Shell_Extn', 0, 'Shell Extensions Validation', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\VERCLSID.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Vista_Consent', 0, 'Consent UI for Administrative Applications', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\consent.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_ADAP', 0, 'Windows AutoDiscovery/AutoPurge Process', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\wbem\WMIADAP.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_RELIABILITY', 0, 'Windows Reliability Analysis Executable', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\RacAgent.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_Policy_Auditor', 0, 'McAfee Policy Auditor', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\Policy Auditor Agent\*|%ProgramFiles%\McAfee\Audit Content Update\*|%ProgramFiles%\McAfee\Audit Manager\*|*\MPAAgt.exe|*\MPAAgt.msi|*\MPASrv.exe|*\MPASrv.msi'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_EEFF', 0, 'McAfee Endpoint Encyption', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\Endpoint Encryption for PC\*|%ProgramFiles%\McAfee\Endpoint Encryption for PC v6\*|%ProgramFiles%\McAfee\Endpoint Encryption Agent\*|%ProgramFiles%\McAfee\Endpoint Encryption\*|?:\Program Files (x86)\McAfee\Endpoint Encryption for Files and Folders\*|?:\Program Files\McAfee\Endpoint Encryption for Files and Folders\*|*\McAfee\Endpoint Encryption for Files and Folders\*|*\SbCeCoreService.exe|*\SbCeProxy.exe|*\SbAdmin.exe|*\SbDbServer.exe|*\SbConnectorManager.exe|*\SbHash.exe|*\SbReports.exe|*\SFDBBack.exe|*\EEFF-Setup.exe|*\SBTRAYMANAGER.exe|*\SbPCSetup.exe|*\SBHTTP.exe|*\Setup.exe|*\MfeEERM.exe|*\Sbtrayicon.exe|*\MFEISWIN64.exe|*\MfeEpeHost.exe|*\MFefFconsole.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_USB_Devices', 0, 'Encrypted USB Devices', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\Encrypted USB Administrator\*|%ProgramFiles%\McAfee\Encrypted USB Client\*|*\PortableContentManager.exe|*\ManagerPostInstall.exe|*\mkisofs.exe|*\Start.exe|*\EncryptedUSBPresenter.exe|*\7za.exe|*\Copyupdater.exe|*\Enterprise_Launcher.exe|*\ExmpSrv.exe|*\SplashScreenLauncher.exe|*\Updater.exe|*\wc.exe|*\DdataRevovery.exe|*\SSEBEUC.exe|*\EPOSign.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_Enterprise_SAP', 0, 'McAfee VirusScan Enterprise For Use With SAP Netweaver', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\VirusScan Enterprise for use with SAP\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_Enterprise_STORAGE', 0, 'McAfee VirusScan Enterprise For Storage', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\VirusScan Enterprise for Storage\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_VirusScan_Enterprise_OFFLINE_VIRTUAL_IMAGES', 0, 'McAfee VirusScan Enterprise For Offline Virtual Images', NULL, 1, 1, 0, 0, '%ProgramFiles%\McAfee\VirusScan Enterprise for Offline Virtual Images\*'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_Windows_Indexing_Service', 0, 'Windows Indexing Service', NULL, 1, 0, 0, 1, '%SystemRoot%\system32\cisvc.exe|%SystemRoot%\system32\cidaemon.exe'
GO

EXEC ENTSP_SetTrustedApp 'ENT6000_TrustedApp_McAfee_Agent_5', 0, 'McAfee Agent 5.0', NULL, 1, 1, 1, 0, '*McAfee*\macmnsvc.exe|*McAfee*\macompatsvc.exe|*McAfee*\masvc.exe'
GO
