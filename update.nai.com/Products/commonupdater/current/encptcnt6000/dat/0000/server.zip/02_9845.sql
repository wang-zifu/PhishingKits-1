EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSIE', 0, N'Microsoft Internet Explorer', '', 1, 1, 'iexplore.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSIMN', 0, N'Microsoft Outlook Express', '', 1, 1, 'msimn.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SVCHOST', 0, N'Microsoft Application Hosting Services', '', 1, 1, 'svchost.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_RUNDLL32', 0, N'Microsoft Run a DLL as an App', '', 1, 1, 'rundll32.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXPLORER', 0, N'Microsoft Windows Explorer', '', 1, 1, 'explorer.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MAPISP32', 0, N'Microsoft Outlook component', '', 1, 1, 'mapisp32.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FTP', 0, N'Microsoft FTP Client', '', 1, 1, 'ftp.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SERVICES', 0, N'Microsoft Windows Services','', 1, 1, 'services.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_LSASS', 0, N'Microsoft Local Security Authority','', 1, 1, 'lsass.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_INETINFO', 0, N'Microsoft IIS','', 1, 1, 'inetinfo.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_OUTLOOK', 0, N'Microsoft Outlook','', 1, 1, 'outlook.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WMPLAYER', 0, N'Microsoft Windows Media Player','', 1, 1, 'wmplayer.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MPLAYER2', 0, N'Microsoft Windows Media Player','', 1, 1, 'mplayer2.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_RPCSS', 0, N'Microsoft Windows RPC Subsystem','', 1, 1, 'rpcss.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSMSGS', 0, N'Microsoft Windows Messenger','', 1, 1, 'msmsgs.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WORD', 0, N'Microsoft Word','', 1, 1, 'winword.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCEL', 0, N'Microsoft Excel','', 1, 1, 'excel.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSTASK', 0, N'Microsoft Scheduled Task Services','', 1, 1, 'mstask.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_POWERPOINT', 0, N'Microsoft Powerpoint','', 1, 1, 'powerpnt.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ACCESS', 0, N'Microsoft Access','', 1, 1, 'msaccess.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VISIO', 0, N'Microsoft Visio','', 1, 1, 'visio32.exe|VISIO.EXE';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ONENOTE', 0, N'Microsoft One Note','', 1, 1, 'onenote.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FRONTPAGE', 0, N'Microsoft FrontPage','', 1, 1, 'frontpg.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_PUBLISHER', 0, N'Microsoft Publisher','', 1, 1, 'mspub.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_PROJECT', 0, N'Microsoft Project','', 1, 1, 'winproj.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINUPDATE', 0, N'Microsoft Windows Update','', 1, 1, 'wuauclt.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SQLSERVER', 0, N'Microsoft SQL Server','', 1, 1, 'sqlservr.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DLLHOST', 0, N'Microsoft DLL Hosting Services','', 1, 1, 'dllhost.exe';
	
EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_HH', 0, N'Microsoft HTML Help','', 1, 1, 'hh.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WORDPAD', 0, N'Microsoft Wordpad','', 1, 1, 'wordpad.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_HYPERTRM', 0, N'Microsoft HyperTerminal','', 1, 1, 'hypertrm.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_STEPBYSTEP', 0, N'Microsoft Step-by-Step Interactive Training','', 1, 1, 'Lrun32.exe|Mrun32.exe|Orun32.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EPO', 0, N'McAfee ePO','', 1, 1, 'frameworkservice.exe|naPrdMgr.exe|SrvMon.exe|NaiMServ.exe|EventParser.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_GRPCONV', 0, N'Microsoft Windows Program Group Converter','', 1, 1, 'grpconv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINLOGON', 0, N'Microsoft Windows Logon Service','', 1, 1, 'winlogon.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_PSXSS', 0, N'Microsoft Windows Posix Subsystem','', 1, 1, 'psxss.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_NETDDE', 0, N'Microsoft Windows Network DDE Service','', 1, 1, 'netdde.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINS', 0, N'Microsoft Windows WINS Service','', 1, 1, 'wins.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_LLSSRV', 0, N'Microsoft Windows License Logging Service','', 1, 1, 'llssrv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_CSRSS', 0, N'Microsoft Windows Win32 Runtime Subsystem','', 1, 1, 'csrss.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MQSVC', 0, N'Microsoft Windows Message Queueing Service','', 1, 1, 'mqsvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SPOOLSV', 0, N'Microsoft Windows Printer Spooling Service','', 1, 1, 'spoolsv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSDTC', 0, N'Microsoft Windows Distributed Transaction Co-ordinator Service','', 1, 1, 'msdtc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSPAINT', 0, N'Microsoft Paint','', 1, 1, 'mspaint.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_PPTVIEWER', 0, N'Microsoft Powerpoint Viewer','', 1, 1, 'pptview.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_PICTMGR', 0, N'Microsoft Office Picture Manager','', 1, 1, 'ois.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_Firefox', 0, N'Firefox','', 1, 1, 'firefox.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_Mozilla', 0, N'Mozilla','', 1, 1, 'mozilla.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_Netscape', 0, N'Netscape Browser','', 1, 1, 'netscape.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_KodakImg', 0, N'Kodak Imaging','', 1, 1, 'kodakimg.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSHTA', 0, N'Microsoft HTML Application Host','', 1, 1, 'mshta.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WORDVIEW', 0, N'Microsoft Word Viewer','', 1, 1, 'wordview.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCELVIEW', 0, N'Microsoft Excel Viewer','', 1, 1, 'xlview.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSAGENT', 0, N'Microsoft Agent','', 1, 1, 'agentsvr.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ADOBEACRO', 0, N'Adobe Acrobat Reader','', 1, 1, 'AcroRd32.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINZIP', 0, N'WinZip','', 1, 1, 'WINZIP32.EXE';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINZIPTRAY', 0, N'WinZip QuickPick', '', 1, 1, 'WZQKPICK.EXE';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINZIPSEPE', 0, N'WinZip Self Extracting PE', '', 1, 1, 'WZSEPE32.EXE';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_QUICKTIME', 0, N'QuickTime Player', '', 1, 1, 'QuickTimePlayer.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_QUICKTMPIC', 0, N'QuickTime Picture Viewer', '', 1, 1, 'PictureViewer.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_QTTASK', 0, N'QuickTime Task Tray', '', 1, 1, 'qttask.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_AOLIM', 0, N'AOL Instant Messenger', '', 1, 1, 'aim6.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_NETMEETING', 0, N'Microsoft NetMeeting', '', 1, 1, 'conf.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_RMTDESKTOP', 0, N'Microsft Remote Desktop', '', 1, 1, 'mstsc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINHLP32', 0, N'winhlp32.exe', '', 1, 1, 'winhlp32.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ADOBEDOWN', 0, N'Adobe Download Manager', '', 1, 1, 'AdobeDownloadManager.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SNMP', 0, N'SNMP Service', '', 1, 1, 'snmp.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_INFOPATH', 0, N'Microsoft InfoPath', '', 1, 1, 'infopath.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_HELPWKSHOP', 0, N'Microsoft Help WorkShop', '', 1, 1, 'hcw.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSDEV', 0, N'Microsoft Visual C++', '', 1, 1, 'msdev.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MMC', 0, N'Microsoft Management Console', '', 1, 1, 'mmc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_TOMCAT', 0, N'Tomcat Web Server', '', 1, 1, 'tomcat.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VISTALIC', 0, N'Windows Vista License Service', '', 1, 0, 'slsvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DNSSERVER', 0, N'Windows DNS Server', '', 1, 1, 'dns.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_NET_RDS', 0, N'NetMeeting Remote Desktop Sharing', '', 1, 1, 'mnmsrvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DHCPSER', 0, N'Microsoft Windows Networking Services (DHCPServer, BINLSVC, SimpTcp, LPDSVC)', '', 1, 1, 'tcpsvcs.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_STORE', 0, N'Exchange Server Store', '', 1, 1, 'store.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_CALCON', 0, N'Exchange Server Calendar', '', 1, 1, 'calcon.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_LSCNTRL', 0, N'Exchange Server Connector Support', '', 1, 1, 'lscntrl.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_DISPATCH', 0, N'Exchange Server Lotus Notes Dispatch', '', 1, 1, 'dispatch.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_EVENTS', 0, N'Exchange Server 5.5 Compatibility Events', '', 1, 1, 'events.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_EXMGMT', 0, N'Exchange Server WMI Management', '', 1, 1, 'exmgmt.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_EMSMTA', 0, N'Exchange Server X.400 Services', '', 1, 1, 'emsmta.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_GWROUTER', 0, N'Exchange Server GroupWise Router', '', 1, 1, 'gwrouter.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_SRSMAIN', 0, N'Exchange Server Site Replication Service', '', 1, 1, 'srsmain.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_MAD', 0, N'Exchange Server Active Directory Monitoring', '', 1, 1, 'mad.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MS_VIRTUAL_PC', 0, N'Microsoft Virtual PC', '', 1, 1, 'Virtual PC.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_DSAMAIN', 0, N'Exchange Server Directory Service', '', 1, 1, 'dsamain.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_EXCHSRVR_IMC', 0, N'Exchange Server Internet Mail Connector', '', 1, 1, 'msexcimc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MS_HELPCTR', 0, N'Microsoft Help and Support Center', '', 1, 1, 'helpctr.exe|helpsvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MS_SPOOLSS', 0, N'Microsoft Printer Spooler Subsystem', '', 1, 1, 'spoolss.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MS_DIALER', 0, N'Microsoft Phone Dialing Application', '', 1, 1, 'dialer.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MS_RASMAN', 0, N'Microsoft Remote Access Service', '', 1, 1, 'rasman.exe|rasphone.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSRPC_LOCATOR', 0, N'Microsoft RPC Locator', '', 1, 1, 'locator.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ALG', 0, N'Application Layer Gateway Service', '', 1, 1, 'alg.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_CLIP', 0, N'Microsoft Clipboard-Server', '', 1, 1, 'clipsrv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DFS', 0, N'Distributed File System', '', 1, 1, 'dfssvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FRS', 0, N'File Replication Service', '', 1, 1, 'ntfrs.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MCIS', 0, N'Microsoft Content Index Service', '', 1, 1, 'cisvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_IMAPICD', 0, N'IMAPI CD-Burning COM Service', '', 1, 1, 'imapi.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSIM', 0, N'Microsoft Server Intersite Messaging', '', 1, 1, 'ismserv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DMADMIN', 0, N'Logical Disk Manager Administrative Service', '', 1, 1, 'dmadmin.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MLAS', 0, N'Microsoft Logs and Alerts Service', '', 1, 1, 'smlogsvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SESSMGR', 0, N'Microsoft Remote Desktop Help Session Manager', '', 1, 1, 'sessmgr.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_JAVAWS', 0, N'Java Web Start', '', 1, 1, 'javaws.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SEAMONKEY', 0, N'SeaMonkey Browser', '', 1, 1, 'SeaMonkey.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MCSHIELD', 0, N'McAfee Virusscan', '', 1, 0, 'Mcshield.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_TBIRD', 0, N'Mozilla Thunderbird', '', 1, 1, 'thunderbird.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_OPERA', 0, N'Opera Browser', '', 1, 1, 'opera.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_YAHOOMSG', 0, N'Yahoo Messenger', '', 1, 1, 'yahoomessenger.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SMARTCARD', 0, N'Smart Card Server', '', 1, 1, 'scardsvr.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_TELNETSVR', 0, N'Telnet Server', '', 1, 1, 'tlntsvr.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_UPS', 0, N'Uninterruptible Power Supply Service', '', 1, 1, 'ups.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VOLSHADOWCP', 0, N'Volume Shadow Copy', '', 1, 1, 'vssvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSIEXEC', 0, N'Microsoft Installer', '', 1, 1, 'msiexec.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WMI', 0, N'Windows Management Instrumentation Application Service', '', 1, 1, 'wmiapsrv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_QOSRSVP', 0, N'QoS RSVP', '', 1, 1, 'rsvp.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_UTILMNGR', 0, N'Utility Manager', '', 1, 1, 'utilman.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_KODAKPRV', 0, N'Kodak Preview', '', 1, 1, 'kodakprv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_BAOFENG', 0, N'BaoFeng Storm Player', '', 1, 1, 'storm.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINVISTAMAIL', 0, N'Windows Vista Mail', '', 1, 1, 'winmail.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MFE_EBSADMIN', 0, N'McAfee E-Business Server Admin Service', '', 1, 1, 'ebsadmin.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_TERMSVC', 0, N'Terminal Services', '', 1, 1, 'termsrv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_W3WP', 0, N'Microsoft IIS Worker Process', '', 1, 1, 'w3wp.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_RMTREGSVC', 0, N'Remote Registry Service', '', 1, 1, 'regsvc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VSTUDIO', 0, N'Visual Studio', '', 1, 1, 'devenv.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINMGMT', 0, N'Windows Management Instrumentation', '', 1, 1, 'winmgmt.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SOFFICEBIN', 0, N'OpenOffice.org (soffice.bin)', '', 1, 1, 'soffice.bin';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SOFFICEEXE', 0, N'OpenOffice.org (soffice.exe)', '', 1, 1, 'soffice.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ITUNES', 0, N'Apple iTunes', '', 1, 1, 'iTunes.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VMWAREVMX', 0, N'VMWare Virtual Machine', '', 1, 1, 'vmware-vmx.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ACROBAT', 0, N'Adobe Acrobat', '', 1, 1, 'acrobat.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_REALPLAY', 0, N'RealPlayer', '', 1, 1, 'realplay.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_TRILLIAN', 0, N'Trillian', '', 1, 1, 'trillian.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WINAMP', 0, N'Winamp', '', 1, 1, 'winamp.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MSNMSGR', 0, N'MSN Messenger', '', 1, 1, 'msnmsgr.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VISTAGADGETS', 0, N'Vista Gadget Sidebar', '', 1, 1, 'sidebar.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_PHOTOSHOP', 0, N'Adobe Photoshop', '', 1, 1, 'photoshop.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_VLCMEDIAPLAY', 0, N'VLC Media Player', '', 1, 1, 'vlc.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MACHINEDEBUG', 0, N'Machine Debug Manager', '', 1, 1, 'mdm.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_AOLRADIOCTL', 0, N'AOL Radio Playback Control', '', 1, 1, 'AOLMediaPlaybackControl.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ALBUMSTART', 0, N'Adobe Album Starter Edition', '', 1, 1, 'Photoshop Album Starter Edition.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FOXITREADER', 0, N'Foxit Reader', '', 1, 1, 'Foxit Reader.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FLASHPLAYER', 0, N'Adobe Flash Player', '', 1, 1, 'FlashPlayer.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_APACHE', 0, N'Apache Web service','', 1, 1, 'httpd.exe|Apache.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MOVIE_MAKER', 0, N'Windows Movie Maker','', 1, 1, 'moviemk.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_REGEDIT', 0, N'Registry Editor','', 1, 1, 'regedit.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_MEDIA_SERVER', 0, N'Windows Media Service','', 1, 1, 'nsum.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_WMPNETWK', 0, N'Windows Media Network Sharing Service','', 1, 1, 'wmpnetwk.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SAFARI', 0, N'Apple Safari','', 1, 1, 'safari.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_CHROME', 0, N'Google Chrome','', 1, 1, 'chrome.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FXSCOVER', 0, N'Microsoft Fax Cover Page Editor','', 1, 1, 'fxscover.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_JAVA', 0, N'Java Platform SE binary ','', 1, 1, 'java.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_SYMPCANYWHERE', 0, N'pcAnywhere Host','', 1, 1, 'awhost32.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DLPENDPOINT', 0, N'DLP Endpoint','', 1, 1, 'fcagte.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_FIREFOXPLUGINS', 0, N'Plugin Container for Firefox','', 1, 1, 'plugin-container.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_DOTNETFRAMEHOST', 0, N'.Net Framework Host','', 1, 1, 'PresentationHost.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_JAVAW', 0, N'Java(TM) Platform SE binary', '', 1, 1, 'javaw.exe';

EXEC ENTSP_SetIPSAppHookRule 'ENT6000_IPSAppHookRule_ADOBECOLLABSYNC', 0, N'Adobe Collaboration Synchronizer', '', 1, 1, 'AdobeCollabSync.exe';

