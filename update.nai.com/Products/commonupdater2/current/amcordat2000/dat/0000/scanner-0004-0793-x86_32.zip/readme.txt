TrustedSource SDK 2.5.1.3 (Build 100)
Copyright (c) McAfee LLC, 2017. All Rights Reserved.

*** License ***

Use of this software is restricted.  All partners are required to comply with
the licensing terms as outlined within their signed TrustedSource SDK agreements.

*** Copyright attributions. ***

RSA Data Security, Inc. MD5 Message Digest Algorithm portions Copyright (c) 1990, RSA Data Security, Inc.

/*
 **********************************************************************
 ** Copyright (C) 1990, RSA Data Security, Inc. All rights reserved. **
 **                                                                  **
 ** License to copy and use this software is granted provided that   **
 ** it is identified as the "RSA Data Security, Inc. MD5 Message     **
 ** Digest Algorithm" in all material mentioning or referencing this **
 ** software or this function.                                       **
 **                                                                  **
 ** License is also granted to make and use derivative works         **
 ** provided that such works are identified as "derived from the RSA **
 ** Data Security, Inc. MD5 Message Digest Algorithm" in all         **
 ** material mentioning or referencing the derived work.             **
 **                                                                  **
 ** RSA Data Security, Inc. makes no representations concerning      **
 ** either the merchantability of this software or the suitability   **
 ** of this software for any particular purpose.  It is provided "as **
 ** is" without express or implied warranty of any kind.             **
 **                                                                  **
 ** These notices must be retained in any copies of any part of this **
 ** documentation and/or software.                                   **
 **********************************************************************
 */


