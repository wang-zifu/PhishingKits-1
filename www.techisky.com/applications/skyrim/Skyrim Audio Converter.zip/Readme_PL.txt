===================================================
Skyrim Audio Converter v 1.0 (Lut 08, 2012)
===================================================

To sprytne narz�dzie pozwala ci szybko i �atwo pracowa� z plikami d�wi�kowymi Skyrim (xwm i fuz).

Jego najwi�ksz� zalet� jest to, �e dla ka�dego pliku na li�cie mo�emy ustali� parametry konwersji z osobna.
Przyk�adowo, za�adowawaszy 5 plik�w na list�, odznaczamy dwa z nich i ustawiamy dla pierwszego, by by� konwertowany
z formatu ogg na xwm o przep�ywowo�ci (bitrate) 96k. Drugi, poniewa� jest w formacie fuz, konwertujemy na format mp3
o cz�stotliwo�ci 44.1k ale z tylko jednym kana�em. Ostatni aktywny plik zostawiamy bez zmian.

Pliki s� konwertowane niezale�nie od siebie, w osobnych w�tkach, wi�c nie trzeba si� martwi�, �e jaki� wielki plik
spowolni ca�y proces.

Poni�sza lista podsumowuje w�a�ciwo�ci i zalety programu Skyrim Audio Converter:
- obs�uga kilku r�nych format�w we/wy (aiff, mp3, flac, aac, ogg, wav)
- ustalanie parametr�w konwersji dla ka�dego pliku z osobna
- jednoczesna, asynchroniczna konwersja wielu plik�w
- radzi sobie zar�wno z plikami xwm (muzyka TEV), jak i fuz (g�os TES)
- prosty i przyjazny interfejs
- obs�uguje otwieranie i wielu plik�w na raz (jak r�wnie� drag-drop)

================================================
Instalacja/Deinstalacja
================================================

Nie jest wymagana. Aby odinstalowa� program, po prostu usu� ca�y folder.

================================================
Kompatybilno��
================================================

Wszystko gra i buczy.

================================================
B��dy/usterki
================================================

Jak na razie �adnych.

================================================
Podzi�kowania
================================================

- Agnahim za fuz_extractor (konwersja plik�w fuz)
- tw�rcom ffmpeg za ich fantastyczne narz�dzia
- Microsoft za xWMAEncode (konwersja plik�w xwm)

================================================
Historia wersji
================================================

1.0
-Pierwsze wydanie

1.0.1
-Dodano pusty plik lip dla �atwiejszego tworzenia plik�w g�osu (zar�wno w paczce, jak i osobno na stronie)

1.0.2
-poprawiono ma�ego buga ze zmian� j�zyka
-poprawiono skalowanie okna
-poprawiono buga, gdy przy pozostawieniu pustego pola do pliku lip zmienia� si� typ innych plik�w
-dodano mo�liwo�� pozostawienia pliku .lip przy konwersji fuz->plik d�wi�kowy
-dodano plik INI pozwalaj�cy ustawi� wst�pne parametry konwersji oraz j�zyk

================================================
Dobrej zabawy!
 JohnB