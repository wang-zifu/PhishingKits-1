===================================================
Skyrim Audio Converter v 1.0 (Feb 08, 2012)
===================================================

This handy tool allows you to work with audio files used in Skyrim (xwm and fuz) fast and easy. 

It's biggest advantage is that you can specify different options for each file on the list. It means,
basically, that you can load 5 files on the list, deselect 2 of them and set, for example, first one to be
converted from ogg to 96k bitrated xwm, the other, as it is in fuz format, to be extracted into mp3 format,
with audio rate 44.1k but only 1 channel, and leave the last one untouched.

The files you are converted simultaneously, using separated threads, so you don't have to worry that some big
audio file will slow down the whole conversion proccess.

The following list summarizes the features of Skyrim Audio Converter:
- a lot of formats in/out (aiff, mp3, flac, aac, ogg, wav)
- choosing parameters of conversion for each file separately
- asynchronous conversion (multithreaded)
- can convert both xwm (music) and fuz (voice) files
- easy and friendly GUI
- handles multi-files selection and multi-files drag'n'drop

================================================
Installation/Uninstallation
================================================

None needed. To uninstall, just delete the whole program folder.

================================================
Compatibility
================================================

Everything is cool.

================================================
Known Issues
================================================

Currently none.

================================================
Credits
================================================

- Agnahim for fuz_extractor (extracting and creating fuz files)
- ffmpeg developers for their fantastic tools
- Microsoft for xWMAEncode (coding/decoding xwm files)

================================================
Version history
================================================

1.0
-Initial release.

1.0.1
-Added blank lip file for easier fuz creating (into both package and as an optional file)

1.0.2
-Fixed small language switching bug
-Fixed window scalling
-Fixed bug for changing conversion type swithing when leaving lip file empty
-Added possibility to keep .lip file when converting fuz files to audio
-Added INI file that allows users to specify base converting options and language

================================================

Enjoy!
 JohnB